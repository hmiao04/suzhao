/*
Navicat MySQL Data Transfer

Source Server         : server-pi
Source Server Version : 50716
Source Host           : 192.168.10.100:3306
Source Database       : suzhao

Target Server Type    : MYSQL
Target Server Version : 50716
File Encoding         : 65001

Date: 2017-04-01 21:51:02
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for core_resources
-- ----------------------------
DROP TABLE IF EXISTS `core_resources`;
CREATE TABLE `core_resources` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '编号',
  `content` varchar(500) CHARACTER SET gbk DEFAULT NULL COMMENT '内容',
  `type` varchar(30) DEFAULT NULL COMMENT '类型',
  `addtime` datetime NOT NULL COMMENT '添加时间',
  `status` int(6) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=79 DEFAULT CHARSET=utf8 COMMENT='全局资源表';

-- ----------------------------
-- Records of core_resources
-- ----------------------------

-- ----------------------------
-- Table structure for sz_bills
-- ----------------------------
DROP TABLE IF EXISTS `sz_bills`;
CREATE TABLE `sz_bills` (
  `bill_sn` varchar(30) NOT NULL COMMENT '账单编号',
  `bill_type` varchar(10) DEFAULT '1' COMMENT '账单类型',
  `member_id` int(11) NOT NULL COMMENT '账单所属用户',
  `bill_title` varchar(200) NOT NULL COMMENT '账单标题',
  `bill_data` varchar(2000) DEFAULT NULL COMMENT '账单数据',
  `pay_money` decimal(12,2) DEFAULT NULL COMMENT '账单金额',
  `pay_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '支付状态    1：已支付   0：未支付',
  `pay_way` varchar(20) DEFAULT 'Alipay' COMMENT '支付方式',
  `pay_way_sn` varchar(255) DEFAULT NULL COMMENT '支付服务商交易码',
  `create_time` int(11) unsigned DEFAULT NULL COMMENT '账单创建时间',
  `paid_time` int(11) unsigned DEFAULT NULL COMMENT '账单支付时间',
  `remarks` varchar(200) DEFAULT NULL COMMENT '账单备注',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  PRIMARY KEY (`bill_sn`),
  UNIQUE KEY `pay_sn` (`pay_way_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='账单表';

-- ----------------------------
-- Records of sz_bills
-- ----------------------------
INSERT INTO `sz_bills` VALUES ('201703260614420000303116', '1', '3', '参团', '{\"title\":\"测试团购呀 - AD高端职业装女装套装时尚气质正装白领西装西服套裙ol工作服春秋\",\"group_id\":\"2\",\"join_time\":1490523282,\"join_id\":6,\"price\":\"0.01\",\"count\":\"1\",\"remark\":\"bbbbbbbb\"}', '0.02', '1', 'Alipay', 'ALI2017032607564509544', '1490523282', '1490534184', null, '1');
INSERT INTO `sz_bills` VALUES ('201703280447360000385794', '1', '3', '参团大喜自制 原创复古 清新藕粉短袖雪纺衫衬衫式连衣裙翻领中长款', '{\"title\":\"\\u5927\\u559c\\u81ea\\u5236 \\u539f\\u521b\\u590d\\u53e4 \\u6e05\\u65b0\\u85d5\\u7c89\\u77ed\\u8896\\u96ea\\u7eba\\u886b\\u886c\\u886b\\u5f0f\\u8fde\\u8863\\u88d9\\u7ffb\\u9886\\u4e2d\\u957f\\u6b3e\",\"group_id\":\"14\",\"join_time\":1490690856,\"join_id\":\"7\",\"price\":\"0.01\",\"count\":\"1\",\"remark\":\"xxpc.xyz\"}', '0.01', '1', 'Alipay', 'ALI2017032804541007349', '1490690856', '1490691294', null, '1');

-- ----------------------------
-- Table structure for sz_collection
-- ----------------------------
DROP TABLE IF EXISTS `sz_collection`;
CREATE TABLE `sz_collection` (
  `id` int(20) NOT NULL AUTO_INCREMENT COMMENT '收藏编号',
  `goods_id` int(20) DEFAULT NULL COMMENT '商品编号',
  `member_id` int(11) DEFAULT NULL COMMENT '商品图片',
  `image_url` varchar(200) DEFAULT NULL COMMENT '图片',
  `title` varchar(200) DEFAULT NULL COMMENT '标题',
  `col_type` tinyint(1) DEFAULT NULL COMMENT '收藏类型 1:商品 2：新款图',
  `create_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='收藏';

-- ----------------------------
-- Records of sz_collection
-- ----------------------------

-- ----------------------------
-- Table structure for sz_common_category
-- ----------------------------
DROP TABLE IF EXISTS `sz_common_category`;
CREATE TABLE `sz_common_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `cate_name` varchar(255) NOT NULL COMMENT '名称',
  `state` tinyint(30) NOT NULL DEFAULT '1' COMMENT '状态(1:正常，0:禁用,...)',
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT '父级编号',
  `type` varchar(50) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='通用分类表';

-- ----------------------------
-- Records of sz_common_category
-- ----------------------------
INSERT INTO `sz_common_category` VALUES ('1', '默认目录', '1', '0', 'picture');
INSERT INTO `sz_common_category` VALUES ('2', '款式集结', '1', '0', 'picture');
INSERT INTO `sz_common_category` VALUES ('3', '凉鞋', '1', '0', 'picture');
INSERT INTO `sz_common_category` VALUES ('4', '单鞋', '1', '0', 'picture');
INSERT INTO `sz_common_category` VALUES ('5', '条带凉', '1', '0', 'picture');
INSERT INTO `sz_common_category` VALUES ('6', '细带单鞋', '1', '0', 'picture');

-- ----------------------------
-- Table structure for sz_fast_find
-- ----------------------------
DROP TABLE IF EXISTS `sz_fast_find`;
CREATE TABLE `sz_fast_find` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '编号',
  `find_title` varchar(200) NOT NULL COMMENT '标题',
  `member_id` int(11) NOT NULL COMMENT '发起用户编号',
  `wish_finish_time` smallint(5) DEFAULT NULL COMMENT '希望完成时间',
  `paid_price` varchar(20) DEFAULT NULL COMMENT '完成酬劳',
  `pay_status` tinyint(4) DEFAULT '0' COMMENT '支付状态    1:已支付   0：未支付',
  `main_image` varchar(100) DEFAULT NULL COMMENT '主图',
  `find_brief` varchar(255) DEFAULT NULL COMMENT '简介',
  `find_content` text COMMENT '详情内容',
  `created_date` datetime DEFAULT NULL COMMENT '创建时间',
  `seq` tinyint(2) unsigned DEFAULT '0' COMMENT '排序',
  `status` int(2) DEFAULT '1' COMMENT '状态(1:未接 2:已接 3:取消 0:删除)',
  PRIMARY KEY (`id`),
  KEY `title` (`find_title`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='速找表';

-- ----------------------------
-- Records of sz_fast_find
-- ----------------------------
INSERT INTO `sz_fast_find` VALUES ('1', '我要寻找一只猫猫', '1', '2', '3.00', '1', '223024.jpg', '我要寻找一只猫猫', '我要寻找一只猫猫我要寻找一只猫猫我要寻找一只猫猫我要寻找一只猫猫我要寻找一只猫猫我要寻找一只猫猫我要寻找一只猫猫我要寻找一只猫猫我要寻找一只猫猫我要寻找一只猫猫我要寻找一只猫猫我要寻找一只猫猫我要寻找一只猫猫我要寻找一只猫猫', '2017-03-06 18:43:45', '0', '1');
INSERT INTO `sz_fast_find` VALUES ('2', '自己饿个不错暗帝发', '3', '3', '200', '0', '8f58f471.jpg', '陆陆续续在做，但是还没做完嘎嘎。前情回顾：无法形容的对决', '<p><img src=\"http://127.0.0.1/project/suzhao/resource/assets/upload/0b16176b.jpg\"/></p><p><img src=\"http://127.0.0.1/project/suzhao/resource/assets/upload/8f58f471.jpg\"/></p><p><br/></p>', '2017-04-01 18:21:00', '0', '0');
INSERT INTO `sz_fast_find` VALUES ('3', '自己饿个不错暗帝发', '3', '3', '200', '0', '8f58f471.jpg', '陆陆续续在做，但是还没做完嘎嘎。前情回顾：无法形容的对决', '<p><img src=\"http://127.0.0.1/project/suzhao/resource/assets/upload/0b16176b.jpg\"/></p><p><img src=\"http://127.0.0.1/project/suzhao/resource/assets/upload/8f58f471.jpg\"/></p><p><br/></p>', '2017-04-01 18:43:00', '0', '0');

-- ----------------------------
-- Table structure for sz_fast_find_record
-- ----------------------------
DROP TABLE IF EXISTS `sz_fast_find_record`;
CREATE TABLE `sz_fast_find_record` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '编号',
  `fast_find_id` int(20) unsigned NOT NULL COMMENT '速找编号',
  `member_id` int(11) NOT NULL COMMENT '发起用户编号',
  `status` int(11) DEFAULT '1' COMMENT '状态(1:已接 2:已完成)',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='速找记录表';

-- ----------------------------
-- Records of sz_fast_find_record
-- ----------------------------

-- ----------------------------
-- Table structure for sz_goods
-- ----------------------------
DROP TABLE IF EXISTS `sz_goods`;
CREATE TABLE `sz_goods` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '编号',
  `title` varchar(200) NOT NULL COMMENT '标题',
  `cate_id` smallint(5) DEFAULT NULL,
  `goods_sn` varchar(20) DEFAULT NULL COMMENT '商品编号',
  `member_id` int(11) NOT NULL,
  `goods_image` varchar(500) DEFAULT NULL COMMENT '商品图像-主图',
  `price_sale` decimal(10,2) DEFAULT NULL COMMENT '售价',
  `price_original` decimal(10,2) DEFAULT NULL COMMENT '原价',
  `goods_brief` varchar(255) DEFAULT NULL COMMENT '简介',
  `goods_content` text COMMENT '详情内容',
  `created_date` int(11) DEFAULT NULL COMMENT '创建时间',
  `seq` tinyint(2) unsigned DEFAULT '0' COMMENT '排序',
  `status` int(11) DEFAULT '1' COMMENT '状态(1:正常/上架 2:下架 0:删除)',
  PRIMARY KEY (`id`),
  KEY `goods_title` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='商品表';

-- ----------------------------
-- Records of sz_goods
-- ----------------------------
INSERT INTO `sz_goods` VALUES ('1', '测试笔记本', '4', null, '1', '[\"257e7e6f.jpg\",\"7066603a.jpg\",\"7c9f2c09.jpg\"]', '4500.02', '5000.00', '测试笔记本', '测试笔记本', '1488201742', '0', '1');
INSERT INTO `sz_goods` VALUES ('2', '2016春夏新款鱼嘴超高跟亮片细跟高跟鞋浅口凉鞋单鞋金色婚鞋女鞋', '4', null, '3', '[\"257e7e6f.jpg\",\"7066603a.jpg\",\"7c9f2c09.jpg\"]', '138.00', null, null, '<p><img src=\"https://img.alicdn.com/imgextra/i2/63939563/TB2EVBIlVXXXXX8XXXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i4/63939563/TB2EUpxlVXXXXbSXXXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i1/63939563/TB2RS0ElVXXXXaEXXXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i1/63939563/TB2pfXxlVXXXXb6XXXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i2/63939563/TB2gAQ2lFXXXXcQXpXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i4/63939563/TB2YPRllVXXXXXOXpXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i2/63939563/TB2iMJvlVXXXXcqXXXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i2/63939563/TB2gVxrlVXXXXc_XXXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i2/63939563/TB2ICtplVXXXXXfXpXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i4/63939563/TB2t_0qlVXXXXXcXpXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i3/63939563/TB2wDhllVXXXXX0XpXXXXXXXXXX_!!63939563.jpg\" class=\"\" width=\"750\" height=\"926\"/><img src=\"https://img.alicdn.com/imgextra/i4/63939563/TB2KMhdlVXXXXa0XpXXXXXXXXXX_!!63939563.jpg\" class=\"\" width=\"750\" height=\"960\"/><img src=\"https://img.alicdn.com/imgextra/i3/63939563/TB2pR0MlVXXXXXaXXXXXXXXXXXX_!!63939563.jpg\" class=\"\" width=\"750\" height=\"306\"/></p><br/>', null, '0', '2');
INSERT INTO `sz_goods` VALUES ('3', '2016春夏新款鱼嘴超高跟亮片细跟高跟鞋浅口凉鞋单鞋金色婚鞋女鞋', '4', null, '3', '[\"257e7e6f.jpg\",\"7066603a.jpg\",\"7c9f2c09.jpg\"]', '138.00', null, null, '<p><img src=\"https://img.alicdn.com/imgextra/i2/63939563/TB2EVBIlVXXXXX8XXXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i4/63939563/TB2EUpxlVXXXXbSXXXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i1/63939563/TB2RS0ElVXXXXaEXXXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i1/63939563/TB2pfXxlVXXXXb6XXXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i2/63939563/TB2gAQ2lFXXXXcQXpXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i4/63939563/TB2YPRllVXXXXXOXpXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i2/63939563/TB2iMJvlVXXXXcqXXXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i2/63939563/TB2gVxrlVXXXXc_XXXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i2/63939563/TB2ICtplVXXXXXfXpXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i4/63939563/TB2t_0qlVXXXXXcXpXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i3/63939563/TB2wDhllVXXXXX0XpXXXXXXXXXX_!!63939563.jpg\" class=\"\" width=\"750\" height=\"926\"/><img src=\"https://img.alicdn.com/imgextra/i4/63939563/TB2KMhdlVXXXXa0XpXXXXXXXXXX_!!63939563.jpg\" class=\"\" width=\"750\" height=\"960\"/><img src=\"https://img.alicdn.com/imgextra/i3/63939563/TB2pR0MlVXXXXXaXXXXXXXXXXXX_!!63939563.jpg\" class=\"\" width=\"750\" height=\"306\"/></p><br/>', '1488905572', '0', '2');
INSERT INTO `sz_goods` VALUES ('4', '2016春夏新款鱼嘴超高跟亮片细跟高跟鞋浅口凉鞋单鞋金色婚鞋女鞋', '4', null, '3', '[\"257e7e6f.jpg\",\"7066603a.jpg\",\"7c9f2c09.jpg\"]', '138.00', null, null, '<p><img src=\"https://img.alicdn.com/imgextra/i2/63939563/TB2EVBIlVXXXXX8XXXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i4/63939563/TB2EUpxlVXXXXbSXXXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i1/63939563/TB2RS0ElVXXXXaEXXXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i1/63939563/TB2pfXxlVXXXXb6XXXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i2/63939563/TB2gAQ2lFXXXXcQXpXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i4/63939563/TB2YPRllVXXXXXOXpXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i2/63939563/TB2iMJvlVXXXXcqXXXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i2/63939563/TB2gVxrlVXXXXc_XXXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i2/63939563/TB2ICtplVXXXXXfXpXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i4/63939563/TB2t_0qlVXXXXXcXpXXXXXXXXXX_!!63939563.jpg\" class=\"\"/><img src=\"https://img.alicdn.com/imgextra/i3/63939563/TB2wDhllVXXXXX0XpXXXXXXXXXX_!!63939563.jpg\" class=\"\" width=\"750\" height=\"926\"/><img src=\"https://img.alicdn.com/imgextra/i4/63939563/TB2KMhdlVXXXXa0XpXXXXXXXXXX_!!63939563.jpg\" class=\"\" width=\"750\" height=\"960\"/><img src=\"https://img.alicdn.com/imgextra/i3/63939563/TB2pR0MlVXXXXXaXXXXXXXXXXXX_!!63939563.jpg\" class=\"\" width=\"750\" height=\"306\"/></p><br/>', '1488905617', '0', '2');
INSERT INTO `sz_goods` VALUES ('5', 'AD高端职业装女装套装时尚气质正装白领西装西服套裙ol工作服春秋', '4', null, '3', '[\"3c97f9d3.jpg\",\"05d2e25a.jpg\",\"7ccb48f6.jpg\",\"ff7ef01a.jpg\",\"3ae46d9c.jpg\"]', '488.00', null, null, '<p><span =\"margin: 0px; padding: 0px;\"><img src=\"https://gdp.alicdn.com/imgextra/i4/2126658491/TB2GW1IcpXXXXXtXXXXXXXXXXXX_!!2126658491.jpg\" alt=\" 00\"/></span></p><p><span =\"text-decoration:line-through;\"><str></strong></span></p><p><img class=\"desc_anchor img-ks-lazyload\" id=\"desc-module-1\" src=\"https://assets.alicdn.com/kissy/1.0.0/build/imglazyload/spaceball.gif\"/></p><p =\"margin-top: 1.12em; margin-bottom: 1.12em; padding: 0px; line-height: 1.4;\"><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2f2vqtpXXXXXpXpXXXXXXXXXX_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i4/2126658491/TB2LhXHeXXXXXbFXpXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i3/2126658491/TB2IS_wdVXXXXcyXXXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2vwy.Xai5V1BjSszcXXaDLXXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i3/2126658491/TB2g8W.Xai5V1BjSspdXXXyFFXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2wvKPXV_AQeBjSZFvXXbnKXXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2YLbGdVXXXXa6XXXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i4/2126658491/TB27NYpdVXXXXa7XpXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2cpnldVXXXXbFXpXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i4/2126658491/TB20pjldVXXXXb4XpXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i4/2126658491/TB2McDldVXXXXcpXpXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2JZP8XJfB11BjSspmXXctQVXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2M826XOYC11Bjy1zbXXbYLFXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i2/2126658491/TB2XMfudVXXXXaeXpXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB27oLCdVXXXXbZXXXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i2/2126658491/TB2VOzCdVXXXXbIXXXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i2/2126658491/TB2V2Y6XH2B11BjSsplXXcMDVXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i2/2126658491/TB2Fsv7XP2C11BjSszgXXaKlpXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i4/2126658491/TB2M0JweFXXXXXCXFXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB23HVTeFXXXXcrXXXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i2/2126658491/TB2AQxboVXXXXcbXpXXXXXXXXXX_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i4/2126658491/TB28NYFfFXXXXXEXXXXXXXXXXXX_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i3/2126658491/TB24IPBfFXXXXawXXXXXXXXXXXX_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i2/2126658491/TB25XHyfFXXXXa7XXXXXXXXXXXX_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i3/2126658491/TB2.62vfFXXXXbMXXXXXXXXXXXX_!!2126658491.jpg\" class=\"img-ks-lazyload\"/></p><p><span =\"text-decoration:line-through;\"><str></strong></span></p><p><span =\"margin: 0px; padding: 0px;\"></span></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.278.onqY5M&id=540356139874&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"193\" height=\"296\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.108.onqY5M&id=40511423537&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"194\" height=\"297\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061001.3.zIVoJ6&id=42129011708&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"197\" height=\"295\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.128.onqY5M&id=527077685430&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"198\" height=\"300\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.243.onqY5M&id=538208397843&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"192\" height=\"296\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.238.onqY5M&id=535621872366&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"194\" height=\"293\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061001.12.zIVoJ6&id=521067327584&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"193\" height=\"295\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.173.onqY5M&id=535621124617&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"191\" height=\"296\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061004.3.zIVoJ6&id=536683301174&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"193\" height=\"308\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061002.2.zIVoJ6&id=536841884390&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"195\" height=\"308\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061006.11.zIVoJ6&id=538089843711&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"198\" height=\"290\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a220o.1000855.w5003-15416061021.3.XpaQ5x&id=544142734586&rn=399e3506b52f282be30e9830450c7d50&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"194\" height=\"293\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.268.onqY5M&id=536925692203&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"192\" height=\"293\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.368.onqY5M&id=536250229734&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"190\" height=\"293\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061004.11.zIVoJ6&id=527088856450&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"194\" height=\"318\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061004.12.zIVoJ6&id=538090935844&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"191\" height=\"302\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://adnz.tmall.com/search.htm?spm=a1z10.1-b-s.w11994384-15415840989.1.zIVoJ6&search=y&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"269\" height=\"35\" class=\"img-ks-lazyload\"/></a></p><p></p><p><span =\"text-decoration:line-through;\"><str></strong></span></p><p><span =\"text-decoration:line-through;\"><str></strong></span></p><p><span =\"margin: 0px; padding: 0px;\"><img src=\"https://gdp.alicdn.com/imgextra/i1/2126658491/TB2n5SoXgvA11Bjy0FfXXcVfVXa_!!2126658491.jpg\" alt=\" pc-售后承诺.jpg\" class=\"img-ks-lazyload\"/></span></p><p><span =\"text-decoration:line-through;\"><str></strong></span></p><p><span =\"text-decoration:line-through;\"><str></strong></span></p><p><span =\"margin: 0px; padding: 0px;\"></span></p><p =\"margin-top: 0px; margin-bottom: 0px; padding: 0px; line-height: 1.4;\"><img src=\"https://gdp.alicdn.com/imgextra/i3/2126658491/TB2SvlwbNRzc1FjSZFPXXcGAFXa_!!2126658491.jpg\" alt=\"\" class=\"img-ks-lazyload\"/></p><p></p><p><br/></p>', '1488994861', '0', '2');
INSERT INTO `sz_goods` VALUES ('6', 'AD高端职业装女装套装时尚气质正装白领西装西服套裙ol工作服春秋', '4', null, '3', '[\"3c97f9d3.jpg\",\"05d2e25a.jpg\",\"7ccb48f6.jpg\",\"ff7ef01a.jpg\",\"3ae46d9c.jpg\"]', '488.00', null, null, '<p><span =\"margin: 0px; padding: 0px;\"><img src=\"https://gdp.alicdn.com/imgextra/i4/2126658491/TB2GW1IcpXXXXXtXXXXXXXXXXXX_!!2126658491.jpg\" alt=\" 00\"/></span></p><p><span =\"text-decoration:line-through;\"><str></strong></span></p><p><img class=\"desc_anchor img-ks-lazyload\" id=\"desc-module-1\" src=\"https://assets.alicdn.com/kissy/1.0.0/build/imglazyload/spaceball.gif\"/></p><p =\"margin-top: 1.12em; margin-bottom: 1.12em; padding: 0px; line-height: 1.4;\"><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2f2vqtpXXXXXpXpXXXXXXXXXX_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i4/2126658491/TB2LhXHeXXXXXbFXpXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i3/2126658491/TB2IS_wdVXXXXcyXXXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2vwy.Xai5V1BjSszcXXaDLXXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i3/2126658491/TB2g8W.Xai5V1BjSspdXXXyFFXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2wvKPXV_AQeBjSZFvXXbnKXXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2YLbGdVXXXXa6XXXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i4/2126658491/TB27NYpdVXXXXa7XpXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2cpnldVXXXXbFXpXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i4/2126658491/TB20pjldVXXXXb4XpXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i4/2126658491/TB2McDldVXXXXcpXpXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2JZP8XJfB11BjSspmXXctQVXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2M826XOYC11Bjy1zbXXbYLFXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i2/2126658491/TB2XMfudVXXXXaeXpXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB27oLCdVXXXXbZXXXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i2/2126658491/TB2VOzCdVXXXXbIXXXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i2/2126658491/TB2V2Y6XH2B11BjSsplXXcMDVXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i2/2126658491/TB2Fsv7XP2C11BjSszgXXaKlpXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i4/2126658491/TB2M0JweFXXXXXCXFXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB23HVTeFXXXXcrXXXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i2/2126658491/TB2AQxboVXXXXcbXpXXXXXXXXXX_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i4/2126658491/TB28NYFfFXXXXXEXXXXXXXXXXXX_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i3/2126658491/TB24IPBfFXXXXawXXXXXXXXXXXX_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i2/2126658491/TB25XHyfFXXXXa7XXXXXXXXXXXX_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i3/2126658491/TB2.62vfFXXXXbMXXXXXXXXXXXX_!!2126658491.jpg\" class=\"img-ks-lazyload\"/></p><p><span =\"text-decoration:line-through;\"><str></strong></span></p><p><span =\"margin: 0px; padding: 0px;\"></span></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.278.onqY5M&id=540356139874&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"193\" height=\"296\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.108.onqY5M&id=40511423537&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"194\" height=\"297\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061001.3.zIVoJ6&id=42129011708&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"197\" height=\"295\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.128.onqY5M&id=527077685430&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"198\" height=\"300\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.243.onqY5M&id=538208397843&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"192\" height=\"296\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.238.onqY5M&id=535621872366&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"194\" height=\"293\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061001.12.zIVoJ6&id=521067327584&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"193\" height=\"295\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.173.onqY5M&id=535621124617&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"191\" height=\"296\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061004.3.zIVoJ6&id=536683301174&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"193\" height=\"308\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061002.2.zIVoJ6&id=536841884390&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"195\" height=\"308\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061006.11.zIVoJ6&id=538089843711&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"198\" height=\"290\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a220o.1000855.w5003-15416061021.3.XpaQ5x&id=544142734586&rn=399e3506b52f282be30e9830450c7d50&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"194\" height=\"293\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.268.onqY5M&id=536925692203&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"192\" height=\"293\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.368.onqY5M&id=536250229734&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"190\" height=\"293\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061004.11.zIVoJ6&id=527088856450&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"194\" height=\"318\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061004.12.zIVoJ6&id=538090935844&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"191\" height=\"302\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://adnz.tmall.com/search.htm?spm=a1z10.1-b-s.w11994384-15415840989.1.zIVoJ6&search=y&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"269\" height=\"35\" class=\"img-ks-lazyload\"/></a></p><p></p><p><span =\"text-decoration:line-through;\"><str></strong></span></p><p><span =\"text-decoration:line-through;\"><str></strong></span></p><p><span =\"margin: 0px; padding: 0px;\"><img src=\"https://gdp.alicdn.com/imgextra/i1/2126658491/TB2n5SoXgvA11Bjy0FfXXcVfVXa_!!2126658491.jpg\" alt=\" pc-售后承诺.jpg\" class=\"img-ks-lazyload\"/></span></p><p><span =\"text-decoration:line-through;\"><str></strong></span></p><p><span =\"text-decoration:line-through;\"><str></strong></span></p><p><span =\"margin: 0px; padding: 0px;\"></span></p><p =\"margin-top: 0px; margin-bottom: 0px; padding: 0px; line-height: 1.4;\"><img src=\"https://gdp.alicdn.com/imgextra/i3/2126658491/TB2SvlwbNRzc1FjSZFPXXcGAFXa_!!2126658491.jpg\" alt=\"\" class=\"img-ks-lazyload\"/></p><p></p><p><br/></p>', '1488994940', '0', '2');
INSERT INTO `sz_goods` VALUES ('7', 'AD高端职业装女装套装时尚气质正装白领西装西服套裙ol工作服春秋', '4', null, '3', '[\"3c97f9d3.jpg\",\"05d2e25a.jpg\",\"7ccb48f6.jpg\",\"ff7ef01a.jpg\",\"3ae46d9c.jpg\"]', '488.00', null, null, '<p><span =\"margin: 0px; padding: 0px;\"><img src=\"https://gdp.alicdn.com/imgextra/i4/2126658491/TB2GW1IcpXXXXXtXXXXXXXXXXXX_!!2126658491.jpg\" alt=\" 00\"/></span></p><p><span =\"text-decoration:line-through;\"><str></strong></span></p><p><img class=\"desc_anchor img-ks-lazyload\" id=\"desc-module-1\" src=\"https://assets.alicdn.com/kissy/1.0.0/build/imglazyload/spaceball.gif\"/></p><p =\"margin-top: 1.12em; margin-bottom: 1.12em; padding: 0px; line-height: 1.4;\"><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2f2vqtpXXXXXpXpXXXXXXXXXX_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i4/2126658491/TB2LhXHeXXXXXbFXpXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i3/2126658491/TB2IS_wdVXXXXcyXXXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2vwy.Xai5V1BjSszcXXaDLXXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i3/2126658491/TB2g8W.Xai5V1BjSspdXXXyFFXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2wvKPXV_AQeBjSZFvXXbnKXXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2YLbGdVXXXXa6XXXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i4/2126658491/TB27NYpdVXXXXa7XpXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2cpnldVXXXXbFXpXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i4/2126658491/TB20pjldVXXXXb4XpXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i4/2126658491/TB2McDldVXXXXcpXpXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2JZP8XJfB11BjSspmXXctQVXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2M826XOYC11Bjy1zbXXbYLFXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i2/2126658491/TB2XMfudVXXXXaeXpXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB27oLCdVXXXXbZXXXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i2/2126658491/TB2VOzCdVXXXXbIXXXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i2/2126658491/TB2V2Y6XH2B11BjSsplXXcMDVXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i2/2126658491/TB2Fsv7XP2C11BjSszgXXaKlpXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i4/2126658491/TB2M0JweFXXXXXCXFXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB23HVTeFXXXXcrXXXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i2/2126658491/TB2AQxboVXXXXcbXpXXXXXXXXXX_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i4/2126658491/TB28NYFfFXXXXXEXXXXXXXXXXXX_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i3/2126658491/TB24IPBfFXXXXawXXXXXXXXXXXX_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i2/2126658491/TB25XHyfFXXXXa7XXXXXXXXXXXX_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i3/2126658491/TB2.62vfFXXXXbMXXXXXXXXXXXX_!!2126658491.jpg\" class=\"img-ks-lazyload\"/></p><p><span =\"text-decoration:line-through;\"><str></strong></span></p><p><span =\"margin: 0px; padding: 0px;\"></span></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.278.onqY5M&id=540356139874&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"193\" height=\"296\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.108.onqY5M&id=40511423537&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"194\" height=\"297\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061001.3.zIVoJ6&id=42129011708&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"197\" height=\"295\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.128.onqY5M&id=527077685430&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"198\" height=\"300\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.243.onqY5M&id=538208397843&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"192\" height=\"296\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.238.onqY5M&id=535621872366&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"194\" height=\"293\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061001.12.zIVoJ6&id=521067327584&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"193\" height=\"295\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.173.onqY5M&id=535621124617&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"191\" height=\"296\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061004.3.zIVoJ6&id=536683301174&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"193\" height=\"308\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061002.2.zIVoJ6&id=536841884390&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"195\" height=\"308\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061006.11.zIVoJ6&id=538089843711&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"198\" height=\"290\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a220o.1000855.w5003-15416061021.3.XpaQ5x&id=544142734586&rn=399e3506b52f282be30e9830450c7d50&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"194\" height=\"293\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.268.onqY5M&id=536925692203&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"192\" height=\"293\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.368.onqY5M&id=536250229734&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"190\" height=\"293\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061004.11.zIVoJ6&id=527088856450&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"194\" height=\"318\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061004.12.zIVoJ6&id=538090935844&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"191\" height=\"302\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://adnz.tmall.com/search.htm?spm=a1z10.1-b-s.w11994384-15415840989.1.zIVoJ6&search=y&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"269\" height=\"35\" class=\"img-ks-lazyload\"/></a></p><p></p><p><span =\"text-decoration:line-through;\"><str></strong></span></p><p><span =\"text-decoration:line-through;\"><str></strong></span></p><p><span =\"margin: 0px; padding: 0px;\"><img src=\"https://gdp.alicdn.com/imgextra/i1/2126658491/TB2n5SoXgvA11Bjy0FfXXcVfVXa_!!2126658491.jpg\" alt=\" pc-售后承诺.jpg\" class=\"img-ks-lazyload\"/></span></p><p><span =\"text-decoration:line-through;\"><str></strong></span></p><p><span =\"text-decoration:line-through;\"><str></strong></span></p><p><span =\"margin: 0px; padding: 0px;\"></span></p><p =\"margin-top: 0px; margin-bottom: 0px; padding: 0px; line-height: 1.4;\"><img src=\"https://gdp.alicdn.com/imgextra/i3/2126658491/TB2SvlwbNRzc1FjSZFPXXcGAFXa_!!2126658491.jpg\" alt=\"\" class=\"img-ks-lazyload\"/></p><p></p><p><br/></p>', '1488995048', '0', '1');
INSERT INTO `sz_goods` VALUES ('9', '大喜自制 原创复古 清新藕粉短袖雪纺衫衬衫式连衣裙翻领中长款', '4', null, '3', '[\"1eeec5d9.jpg\"]', '188.00', null, null, '<p =\"margin-top: 1.12em; margin-bottom: 1.12em; padding: 0px; font-family: tahoma, arial, 宋体, sans-serif; font-size: 14px; line-height: 21px; white-space: normal; text-align: center; background-color: rgb(255, 255, 255);\"><str><span =\"font-family: \';microsoft yahei\';;\"><span =\"font-size: 18px;\"><strong>此款产品为现货，我们将在72小时内发出</strong></span></span></strong><str><span =\"font-family: \';microsoft yahei\';;\"><span =\"font-size: 18px;\">。</span></span></strong><str><span =\"font-family: \';microsoft yahei\';;\"></span></strong></p><p =\"margin-top: 1.12em; margin-bottom: 1.12em; padding: 0px; font-family: tahoma, arial, 宋体, sans-serif; font-size: 14px; line-height: 21px; white-space: normal; text-align: center; background-color: rgb(255, 255, 255);\"><img src=\"https://img.alicdn.com/imgextra/i4/704298669/TB24nnfuXXXXXcsXXXXXXXXXXXX_!!704298669.jpg\"/></p><p =\"margin-top: 1.12em; margin-bottom: 1.12em; padding: 0px; font-family: tahoma, arial, 宋体, sans-serif; font-size: 14px; line-height: 21px; white-space: normal; text-align: center; background-color: rgb(255, 255, 255);\">&nbsp;</p><p =\"margin-top: 1.12em; margin-bottom: 1.12em; padding: 0px; font-family: tahoma, arial, 宋体, sans-serif; font-size: 14px; line-height: 21px; white-space: normal; text-align: center; background-color: rgb(255, 255, 255);\"><img src=\"https://img.alicdn.com/imgextra/i1/704298669/TB2nR5UuXXXXXbhXpXXXXXXXXXX_!!704298669.jpg\"/></p><p =\"margin-top: 1.12em; margin-bottom: 1.12em; padding: 0px; font-family: tahoma, arial, 宋体, sans-serif; font-size: 14px; line-height: 21px; white-space: normal; text-align: center; background-color: rgb(255, 255, 255);\"><img src=\"https://img.alicdn.com/imgextra/i2/704298669/TB2ZuKYuXXXXXbxXpXXXXXXXXXX_!!704298669.jpg\"/></p><p><br/></p>', '1490198727', '0', '1');
INSERT INTO `sz_goods` VALUES ('8', 'AD高端职业装女装套装时尚气质正装白领西装西服套裙ol工作服春秋', '4', null, '3', '[\"3c97f9d3.jpg\",\"05d2e25a.jpg\",\"7ccb48f6.jpg\",\"ff7ef01a.jpg\",\"3ae46d9c.jpg\"]', '0.01', null, null, '<p><span =\"margin: 0px; padding: 0px;\"><img src=\"https://gdp.alicdn.com/imgextra/i4/2126658491/TB2GW1IcpXXXXXtXXXXXXXXXXXX_!!2126658491.jpg\" alt=\" 00\"/></span></p><p><span =\"text-decoration:line-through;\"><str></strong></span></p><p><img class=\"desc_anchor img-ks-lazyload\" id=\"desc-module-1\" src=\"https://assets.alicdn.com/kissy/1.0.0/build/imglazyload/spaceball.gif\"/></p><p =\"margin-top: 1.12em; margin-bottom: 1.12em; padding: 0px; line-height: 1.4;\"><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2f2vqtpXXXXXpXpXXXXXXXXXX_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i4/2126658491/TB2LhXHeXXXXXbFXpXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i3/2126658491/TB2IS_wdVXXXXcyXXXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2vwy.Xai5V1BjSszcXXaDLXXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i3/2126658491/TB2g8W.Xai5V1BjSspdXXXyFFXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2wvKPXV_AQeBjSZFvXXbnKXXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2YLbGdVXXXXa6XXXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i4/2126658491/TB27NYpdVXXXXa7XpXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2cpnldVXXXXbFXpXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i4/2126658491/TB20pjldVXXXXb4XpXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i4/2126658491/TB2McDldVXXXXcpXpXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2JZP8XJfB11BjSspmXXctQVXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB2M826XOYC11Bjy1zbXXbYLFXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i2/2126658491/TB2XMfudVXXXXaeXpXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB27oLCdVXXXXbZXXXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i2/2126658491/TB2VOzCdVXXXXbIXXXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i2/2126658491/TB2V2Y6XH2B11BjSsplXXcMDVXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i2/2126658491/TB2Fsv7XP2C11BjSszgXXaKlpXa_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i4/2126658491/TB2M0JweFXXXXXCXFXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i1/2126658491/TB23HVTeFXXXXcrXXXXXXXXXXXX-2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i2/2126658491/TB2AQxboVXXXXcbXpXXXXXXXXXX_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i4/2126658491/TB28NYFfFXXXXXEXXXXXXXXXXXX_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i3/2126658491/TB24IPBfFXXXXawXXXXXXXXXXXX_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i2/2126658491/TB25XHyfFXXXXa7XXXXXXXXXXXX_!!2126658491.jpg\" class=\"img-ks-lazyload\"/><img src=\"https://img.alicdn.com/imgextra/i3/2126658491/TB2.62vfFXXXXbMXXXXXXXXXXXX_!!2126658491.jpg\" class=\"img-ks-lazyload\"/></p><p><span =\"text-decoration:line-through;\"><str></strong></span></p><p><span =\"margin: 0px; padding: 0px;\"></span></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.278.onqY5M&id=540356139874&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"193\" height=\"296\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.108.onqY5M&id=40511423537&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"194\" height=\"297\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061001.3.zIVoJ6&id=42129011708&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"197\" height=\"295\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.128.onqY5M&id=527077685430&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"198\" height=\"300\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.243.onqY5M&id=538208397843&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"192\" height=\"296\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.238.onqY5M&id=535621872366&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"194\" height=\"293\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061001.12.zIVoJ6&id=521067327584&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"193\" height=\"295\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.173.onqY5M&id=535621124617&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"191\" height=\"296\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061004.3.zIVoJ6&id=536683301174&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"193\" height=\"308\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061002.2.zIVoJ6&id=536841884390&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"195\" height=\"308\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061006.11.zIVoJ6&id=538089843711&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"198\" height=\"290\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a220o.1000855.w5003-15416061021.3.XpaQ5x&id=544142734586&rn=399e3506b52f282be30e9830450c7d50&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"194\" height=\"293\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.268.onqY5M&id=536925692203&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"192\" height=\"293\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.5-b-s.w4011-15416061029.368.onqY5M&id=536250229734&rn=f90051543aa1ba927f775be2d0d4196a&abbucket=20&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"190\" height=\"293\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061004.11.zIVoJ6&id=527088856450&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"194\" height=\"318\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://detail.tmall.com/item.htm?spm=a1z10.1-b-s.w5003-15416061004.12.zIVoJ6&id=538090935844&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"191\" height=\"302\" class=\"img-ks-lazyload\"/></a></p><p><a href=\"https://adnz.tmall.com/search.htm?spm=a1z10.1-b-s.w11994384-15415840989.1.zIVoJ6&search=y&scene=taobao_shop\" target=\"_blank\"><img src=\"https://gdp.alicdn.com/imgextra/i4/1862941194/T2a2R1XD0aXXXXXXXX-1862941194.png\" width=\"269\" height=\"35\" class=\"img-ks-lazyload\"/></a></p><p></p><p><span =\"text-decoration:line-through;\"><str></strong></span></p><p><span =\"text-decoration:line-through;\"><str></strong></span></p><p><span =\"margin: 0px; padding: 0px;\"><img src=\"https://gdp.alicdn.com/imgextra/i1/2126658491/TB2n5SoXgvA11Bjy0FfXXcVfVXa_!!2126658491.jpg\" alt=\" pc-售后承诺.jpg\" class=\"img-ks-lazyload\"/></span></p><p><span =\"text-decoration:line-through;\"><str></strong></span></p><p><span =\"text-decoration:line-through;\"><str></strong></span></p><p><span =\"margin: 0px; padding: 0px;\"></span></p><p =\"margin-top: 0px; margin-bottom: 0px; padding: 0px; line-height: 1.4;\"><img src=\"https://gdp.alicdn.com/imgextra/i3/2126658491/TB2SvlwbNRzc1FjSZFPXXcGAFXa_!!2126658491.jpg\" alt=\"\" class=\"img-ks-lazyload\"/></p><p></p><p><br/></p>', '1488995081', '0', '2');
INSERT INTO `sz_goods` VALUES ('10', '大喜自制 原创复古 清新藕粉短袖雪纺衫衬衫式连衣裙翻领中长款', '4', null, '3', '[\"1eeec5d9.jpg\"]', '0.01', '0.01', null, null, '1490686061', '0', '2');
INSERT INTO `sz_goods` VALUES ('11', '大喜自制 原创复古 清新藕粉短袖雪纺衫衬衫式连衣裙翻领中长款', '4', null, '3', '[\"1eeec5d9.jpg\"]', '0.01', '0.01', null, null, '1490686067', '0', '2');
INSERT INTO `sz_goods` VALUES ('12', '大喜自制 原创复古 清新藕粉短袖雪纺衫衬衫式连衣裙翻领中长款', '4', null, '3', '[\"1eeec5d9.jpg\"]', '0.01', '0.01', null, null, '1490686085', '0', '2');
INSERT INTO `sz_goods` VALUES ('13', '大喜自制 原创复古 清新藕粉短袖雪纺衫衬衫式连衣裙翻领中长款', '4', null, '3', '[\"1eeec5d9.jpg\"]', '0.01', '0.01', null, '<p></p><p><img src=\"https://img.alicdn.com/imgextra/i4/704298669/TB24nnfuXXXXXcsXXXXXXXXXXXX_!!704298669.jpg\"/></p><p>&nbsp;</p><p><img src=\"https://img.alicdn.com/imgextra/i1/704298669/TB2nR5UuXXXXXbhXpXXXXXXXXXX_!!704298669.jpg\"/></p><p><img src=\"https://img.alicdn.com/imgextra/i2/704298669/TB2ZuKYuXXXXXbxXpXXXXXXXXXX_!!704298669.jpg\"/></p><p><br/></p>', '1490686186', '0', '1');
INSERT INTO `sz_goods` VALUES ('14', '针织长裙2017春秋季性感女装前后v领包臀中长款紧修身打底连衣裙', null, null, '3', '[\"8f55efc2.jpg\",\"0cb69bc1.jpg\",\"7f125c91.jpg\"]', '99.00', null, null, '<p><img src=\"https://img.alicdn.com/imgextra/i4/2857989582/TB22tFDhrxmpuFjSZJiXXXauVXa_!!2857989582.jpg\"/><img src=\"https://img.alicdn.com/imgextra/i4/2857989582/TB2jOXBhC8mpuFjSZFMXXaxpVXa_!!2857989582.jpg\"/><img src=\"https://img.alicdn.com/imgextra/i1/2857989582/TB2T3xvhtRopuFjSZFtXXcanpXa_!!2857989582.jpg\"/><img src=\"https://img.alicdn.com/imgextra/i4/2857989582/TB2Npk.hbJmpuFjSZFwXXaE4VXa_!!2857989582.jpg\"/><img src=\"https://img.alicdn.com/imgextra/i3/2857989582/TB2JsBpht0opuFjSZFxXXaDNVXa_!!2857989582.jpg\" class=\"\" width=\"750\" height=\"1331\"/><img src=\"https://img.alicdn.com/imgextra/i1/2857989582/TB2MwhHhrBmpuFjSZFAXXaQ0pXa_!!2857989582.jpg\" class=\"\" width=\"750\" height=\"404\"/><img src=\"https://img.alicdn.com/imgextra/i1/2857989582/TB2fHpLhxlmpuFjSZPfXXc9iXXa_!!2857989582.jpg\" class=\"\" width=\"750\" height=\"1036\"/><img src=\"https://img.alicdn.com/imgextra/i3/2857989582/TB2UgRzhC0mpuFjSZPiXXbssVXa_!!2857989582.jpg\" class=\"\" width=\"750\" height=\"1001\"/><img src=\"https://img.alicdn.com/imgextra/i1/2857989582/TB2U5FwhxhmpuFjSZFyXXcLdFXa_!!2857989582.jpg\" class=\"\" width=\"750\" height=\"995\"/><img src=\"https://img.alicdn.com/imgextra/i4/2857989582/TB2X3XvhxxmpuFjSZFNXXXrRXXa_!!2857989582.jpg\" class=\"\" width=\"750\" height=\"950\"/><img src=\"https://img.alicdn.com/imgextra/i2/2857989582/TB2m3pHhrBmpuFjSZFAXXaQ0pXa_!!2857989582.jpg\" class=\"\" width=\"750\" height=\"1005\"/><img src=\"https://img.alicdn.com/imgextra/i4/2857989582/TB2csJ3b5C9MuFjSZFoXXbUzFXa_!!2857989582.jpg\" class=\"\" width=\"750\" height=\"956\"/><img src=\"https://img.alicdn.com/imgextra/i3/2857989582/TB2uShIht4opuFjSZFLXXX8mXXa_!!2857989582.jpg\" class=\"\" width=\"750\" height=\"967\"/><img src=\"https://img.alicdn.com/imgextra/i4/2857989582/TB25Vw.hbJmpuFjSZFwXXaE4VXa_!!2857989582.jpg\" class=\"\" width=\"750\" height=\"986\"/><img src=\"https://img.alicdn.com/imgextra/i1/2857989582/TB2u1xihxBmpuFjSZFsXXcXpFXa_!!2857989582.jpg\" class=\"\" width=\"750\" height=\"994\"/><img src=\"https://img.alicdn.com/imgextra/i1/2857989582/TB2dbBLhxlmpuFjSZPfXXc9iXXa_!!2857989582.jpg\" class=\"\" width=\"750\" height=\"978\"/><img src=\"https://img.alicdn.com/imgextra/i4/2857989582/TB2bpFchCVmpuFjSZFFXXcZApXa_!!2857989582.jpg\" class=\"\" width=\"750\" height=\"962\"/><img src=\"https://img.alicdn.com/imgextra/i4/2857989582/TB2B3xHhrBmpuFjSZFAXXaQ0pXa_!!2857989582.jpg\" class=\"\" width=\"750\" height=\"1005\"/><img src=\"https://img.alicdn.com/imgextra/i1/2857989582/TB2dYFLhxlmpuFjSZPfXXc9iXXa_!!2857989582.jpg\" class=\"\" width=\"750\" height=\"935\"/></p>', '1490807814', '0', '1');
INSERT INTO `sz_goods` VALUES ('15', '女装春秋款2017新款收腰连衣裙春装小香风中长款七分袖修身a字裙', null, null, '3', '[\"001f4845.jpg\",\"f0ddd84e.jpg\",\"ca81f1e1.jpg\",\"1f9948da.jpg\",\"c2b26a1c.jpg\"]', '145.00', null, null, '<p><img src=\"http://127.0.0.1/project/suzhao/resource/assets/upload/ca81f1e1.jpg\"/></p><p><img src=\"http://127.0.0.1/project/suzhao/resource/assets/upload/1f9948da.jpg\"/></p><p><img src=\"http://127.0.0.1/project/suzhao/resource/assets/upload/c2b26a1c.jpg\"/></p><p><img src=\"http://127.0.0.1/project/suzhao/resource/assets/upload/001f4845.jpg\"/></p><p><img src=\"http://127.0.0.1/project/suzhao/resource/assets/upload/f0ddd84e.jpg\"/></p><p><br/></p>', '1490812459', '0', '1');

-- ----------------------------
-- Table structure for sz_goods_attr
-- ----------------------------
DROP TABLE IF EXISTS `sz_goods_attr`;
CREATE TABLE `sz_goods_attr` (
  `goods_id` int(10) unsigned NOT NULL COMMENT '商品编号',
  `attr_id` mediumint(8) NOT NULL COMMENT '属性编号',
  `value` varchar(160) NOT NULL DEFAULT '' COMMENT '属性值'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='商品属性表';

-- ----------------------------
-- Records of sz_goods_attr
-- ----------------------------
INSERT INTO `sz_goods_attr` VALUES ('1', '1', '13.3');

-- ----------------------------
-- Table structure for sz_goods_cate
-- ----------------------------
DROP TABLE IF EXISTS `sz_goods_cate`;
CREATE TABLE `sz_goods_cate` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '编号',
  `parent_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '父级编号',
  `cate_name` varchar(60) NOT NULL DEFAULT '' COMMENT '分类名称',
  `meta_keywords` varchar(240) NOT NULL DEFAULT '' COMMENT '关键字',
  `meta_description` varchar(240) NOT NULL DEFAULT '' COMMENT '描述',
  `seq` tinyint(2) unsigned NOT NULL DEFAULT '99' COMMENT '排序',
  `status` tinyint(2) unsigned DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='商品分类表';

-- ----------------------------
-- Records of sz_goods_cate
-- ----------------------------
INSERT INTO `sz_goods_cate` VALUES ('1', '0', '家用电器', '家用电器', '家用电器', '0', '1');
INSERT INTO `sz_goods_cate` VALUES ('2', '0', '手机', '手机', '手机', '0', '1');
INSERT INTO `sz_goods_cate` VALUES ('3', '0', '电脑办公', '电脑办公', '电脑办公', '0', '1');
INSERT INTO `sz_goods_cate` VALUES ('4', '3', '笔记本', '笔记本', '笔记本', '0', '1');
INSERT INTO `sz_goods_cate` VALUES ('5', '3', '超极本', '超极本', '超极本', '0', '1');

-- ----------------------------
-- Table structure for sz_group_buy
-- ----------------------------
DROP TABLE IF EXISTS `sz_group_buy`;
CREATE TABLE `sz_group_buy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '团购ID',
  `title` varchar(255) NOT NULL COMMENT '团购标题',
  `member_id` int(11) unsigned NOT NULL COMMENT '发起用户编号',
  `goods_id` int(20) unsigned NOT NULL COMMENT '团购关联商品编号',
  `main_image` varchar(100) DEFAULT NULL,
  `require` varchar(1000) DEFAULT NULL COMMENT '团购要求',
  `create_time` int(11) NOT NULL COMMENT '发起时间',
  `end_time` int(11) DEFAULT NULL COMMENT '结束时间,空则表示没有结束时间',
  `group_status` tinyint(2) unsigned NOT NULL DEFAULT '4' COMMENT '团购状态  1.发起中... 2.已接   3.已完结 4.保存中',
  `seq` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '1:正常 0:删除',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COMMENT='团购信息表';

-- ----------------------------
-- Records of sz_group_buy
-- ----------------------------
INSERT INTO `sz_group_buy` VALUES ('1', '测试团购呀 - AD高端职业装女装套装时尚气质正装白领西装西服套裙ol工作服春秋', '3', '8', '3c97f9d3.jpg', '团购用户暂不享受店内其他优惠\r\n每张糯米券限1人使用\r\n每次消费不限使用糯米券张数，可叠加使用\r\n自助餐仅限堂食，不提供打包服务\r\n部分菜品因时令原因有所不同，请以店内当日实际供应为准', '1488201742', '0', '1', '0', '1');
INSERT INTO `sz_group_buy` VALUES ('2', '测试团购呀 - AD高端职业装女装套装时尚气质正装白领西装西服套裙ol工作服春秋', '3', '8', '3c97f9d3.jpg', '团购用户暂不享受店内其他优惠\r\n每张糯米券限1人使用\r\n每次消费不限使用糯米券张数，可叠加使用\r\n自助餐仅限堂食，不提供打包服务\r\n部分菜品因时令原因有所不同，请以店内当日实际供应为准', '1488201742', null, '1', '0', '1');
INSERT INTO `sz_group_buy` VALUES ('3', '大喜自制 原创复古 清新藕粉短袖雪纺衫衬衫式连衣裙翻领中长款', '3', '9', '1eeec5d9.jpg', '团购用户暂不享受店内其他优惠\r\n每张糯米券限1人使用\r\n每次消费不限使用糯米券张数，可叠加使用\r\n自助餐仅限堂食，不提供打包服务\r\n部分菜品因时令原因有所不同，请以店内当日实际供应为准', '1490687617', null, '4', '0', '1');
INSERT INTO `sz_group_buy` VALUES ('4', '大喜自制 原创复古 清新藕粉短袖雪纺衫衬衫式连衣裙翻领中长款', '3', '9', '1eeec5d9.jpg', '团购用户暂不享受店内其他优惠\r\n每张糯米券限1人使用\r\n每次消费不限使用糯米券张数，可叠加使用\r\n自助餐仅限堂食，不提供打包服务\r\n部分菜品因时令原因有所不同，请以店内当日实际供应为准', '1490687617', null, '4', '0', '1');
INSERT INTO `sz_group_buy` VALUES ('5', '大喜自制 原创复古 清新藕粉短袖雪纺衫衬衫式连衣裙翻领中长款', '3', '9', '1eeec5d9.jpg', '团购用户暂不享受店内其他优惠\r\n每张糯米券限1人使用\r\n每次消费不限使用糯米券张数，可叠加使用\r\n自助餐仅限堂食，不提供打包服务\r\n部分菜品因时令原因有所不同，请以店内当日实际供应为准', '1490687617', null, '4', '0', '1');
INSERT INTO `sz_group_buy` VALUES ('6', '大喜自制 原创复古 清新藕粉短袖雪纺衫衬衫式连衣裙翻领中长款', '3', '9', '1eeec5d9.jpg', '团购用户暂不享受店内其他优惠\r\n每张糯米券限1人使用\r\n每次消费不限使用糯米券张数，可叠加使用\r\n自助餐仅限堂食，不提供打包服务\r\n部分菜品因时令原因有所不同，请以店内当日实际供应为准', '1490687617', null, '4', '0', '1');
INSERT INTO `sz_group_buy` VALUES ('7', '大喜自制 原创复古 清新藕粉短袖雪纺衫衬衫式连衣裙翻领中长款', '3', '9', '1eeec5d9.jpg', '团购用户暂不享受店内其他优惠\r\n每张糯米券限1人使用\r\n每次消费不限使用糯米券张数，可叠加使用\r\n自助餐仅限堂食，不提供打包服务\r\n部分菜品因时令原因有所不同，请以店内当日实际供应为准', '1490687617', null, '4', '0', '1');
INSERT INTO `sz_group_buy` VALUES ('8', '大喜自制 原创复古 清新藕粉短袖雪纺衫衬衫式连衣裙翻领中长款', '3', '9', '1eeec5d9.jpg', '团购用户暂不享受店内其他优惠\r\n每张糯米券限1人使用\r\n每次消费不限使用糯米券张数，可叠加使用\r\n自助餐仅限堂食，不提供打包服务\r\n部分菜品因时令原因有所不同，请以店内当日实际供应为准', '1490687617', null, '4', '0', '1');
INSERT INTO `sz_group_buy` VALUES ('9', '大喜自制 原创复古 清新藕粉短袖雪纺衫衬衫式连衣裙翻领中长款', '3', '9', '1eeec5d9.jpg', '团购用户暂不享受店内其他优惠\r\n每张糯米券限1人使用\r\n每次消费不限使用糯米券张数，可叠加使用\r\n自助餐仅限堂食，不提供打包服务\r\n部分菜品因时令原因有所不同，请以店内当日实际供应为准', '1490687617', null, '4', '0', '1');
INSERT INTO `sz_group_buy` VALUES ('10', '大喜自制 原创复古 清新藕粉短袖雪纺衫衬衫式连衣裙翻领中长款', '3', '9', '1eeec5d9.jpg', '团购用户暂不享受店内其他优惠\r\n每张糯米券限1人使用\r\n每次消费不限使用糯米券张数，可叠加使用\r\n自助餐仅限堂食，不提供打包服务\r\n部分菜品因时令原因有所不同，请以店内当日实际供应为准', '1490687617', null, '4', '0', '1');
INSERT INTO `sz_group_buy` VALUES ('11', '大喜自制 原创复古 清新藕粉短袖雪纺衫衬衫式连衣裙翻领中长款', '3', '9', '1eeec5d9.jpg', '团购用户暂不享受店内其他优惠\r\n每张糯米券限1人使用\r\n每次消费不限使用糯米券张数，可叠加使用\r\n自助餐仅限堂食，不提供打包服务\r\n部分菜品因时令原因有所不同，请以店内当日实际供应为准', '1490687617', null, '4', '0', '1');
INSERT INTO `sz_group_buy` VALUES ('12', '大喜自制 原创复古 清新藕粉短袖雪纺衫衬衫式连衣裙翻领中长款', '3', '9', '1eeec5d9.jpg', '团购用户暂不享受店内其他优惠\r\n每张糯米券限1人使用\r\n每次消费不限使用糯米券张数，可叠加使用\r\n自助餐仅限堂食，不提供打包服务\r\n部分菜品因时令原因有所不同，请以店内当日实际供应为准', '1490687617', null, '4', '0', '1');
INSERT INTO `sz_group_buy` VALUES ('13', '大喜自制 原创复古 清新藕粉短袖雪纺衫衬衫式连衣裙翻领中长款', '3', '9', '1eeec5d9.jpg', '团购用户暂不享受店内其他优惠\r\n每张糯米券限1人使用\r\n每次消费不限使用糯米券张数，可叠加使用\r\n自助餐仅限堂食，不提供打包服务\r\n部分菜品因时令原因有所不同，请以店内当日实际供应为准', '1490687933', null, '4', '0', '1');
INSERT INTO `sz_group_buy` VALUES ('14', '大喜自制 原创复古 清新藕粉短袖雪纺衫衬衫式连衣裙翻领中长款', '3', '13', '1eeec5d9.jpg', '团购用户暂不享受店内其他优惠\r\n每张糯米券限1人使用\r\n每次消费不限使用糯米券张数，可叠加使用\r\n自助餐仅限堂食，不提供打包服务\r\n部分菜品因时令原因有所不同，请以店内当日实际供应为准', '1490687990', null, '4', '0', '1');

-- ----------------------------
-- Table structure for sz_group_buy_join
-- ----------------------------
DROP TABLE IF EXISTS `sz_group_buy_join`;
CREATE TABLE `sz_group_buy_join` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `group_id` int(20) NOT NULL COMMENT '团购编号',
  `member_id` int(11) NOT NULL COMMENT '用户编号',
  `buy_price` decimal(10,2) NOT NULL COMMENT '团购单价',
  `buy_count` int(11) NOT NULL DEFAULT '1' COMMENT '团购数量',
  `receiver` varchar(20) DEFAULT NULL COMMENT '收货人',
  `shipping_address` varchar(200) DEFAULT NULL COMMENT '收货地址',
  `telephone` varchar(11) DEFAULT NULL COMMENT '收货人手机号',
  `remarks` varchar(200) DEFAULT NULL COMMENT '备注',
  `cancel_reason` varchar(200) DEFAULT NULL COMMENT '取消原因,status:2时有效',
  `pay_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '支付状态    1:已支付   0：未支付',
  `join_time` int(11) DEFAULT NULL,
  `bill_sn` varchar(25) DEFAULT NULL COMMENT '账单编号',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态 1：正常 2:取消 ',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='参团信息';

-- ----------------------------
-- Records of sz_group_buy_join
-- ----------------------------
INSERT INTO `sz_group_buy_join` VALUES ('6', '2', '3', '0.01', '2', '张三丰', 'aaaaaaa', '13288808124', 'bbbbbbbb', null, '1', '1490523282', '201703260614420000303116', '1');
INSERT INTO `sz_group_buy_join` VALUES ('7', '14', '3', '0.01', '1', 'xxpc', '中国四川成都', '18982208214', 'xxpc.xyz', null, '1', '1490690856', '201703280447360000385794', '1');

-- ----------------------------
-- Table structure for sz_member_certification
-- ----------------------------
DROP TABLE IF EXISTS `sz_member_certification`;
CREATE TABLE `sz_member_certification` (
  `mid` int(11) NOT NULL,
  `type` varchar(10) NOT NULL COMMENT '认证类型(person:个人,company:公司)',
  `certification_status` tinyint(2) unsigned NOT NULL DEFAULT '2' COMMENT '认证状态(1:认证成功2:认证中;3:未通过认证;)',
  `certification_data` text NOT NULL COMMENT '认证数据',
  `post_time` int(11) DEFAULT NULL COMMENT '提交认证时间',
  `certification_time` int(11) DEFAULT NULL COMMENT '认证时间',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `status` tinyint(2) DEFAULT '1' COMMENT '状态(1:正常 0:删除)',
  PRIMARY KEY (`mid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sz_member_certification
-- ----------------------------
INSERT INTO `sz_member_certification` VALUES ('3', 'person', '1', 'YToxMDp7czo4OiJwZXJzb25RUSI7czozOiIxMjMiO3M6MTA6InBlcnNvbk5hbWUiO3M6OToi5byg5YWo6JuLIjtzOjEyOiJwZXJzb25HZW5kZXIiO3M6Mzoi55S3IjtzOjE1OiJwZXJzb25CaXJ0aERhdGUiO3M6MTA6IjE5ODctMDktMTIiO3M6MTE6InBlcnNvblBob25lIjtzOjExOiIxMzgxMjEyMDQyOSI7czo2OiJJZENhcmQiO3M6MTg6IjUxMDEyMjE5ODkxMDE0Mjk0OSI7czoxMzoicGVyc29uQWRkcmVzcyI7czoyOToi5Zub5bed55yBIOaIkOmDveW4giDlj4zmtYHljr8iO3M6MTM6IklkQ2FyZEFkZHJlc3MiO3M6Mjk6IuWbm+W3neecgSDmiJDpg73luIIg5Y+M5rWB5Y6/IjtzOjE2OiJJZENhcmRGcm9udFBob3RvIjtzOjE3OiI1OGE3YjEwMTcxNDQ0LmpwZyI7czoxNToiSWRDYXJkQmFja1Bob3RvIjtzOjE3OiI1OGE3YjExNDhkMWYxLmpwZyI7fQ==', '1487386265', null, 'test', '1');
INSERT INTO `sz_member_certification` VALUES ('1', 'company', '2', 'YToxNTp7czo4OiJwZXJzb25RUSI7czozOiIxMjMiO3M6MTA6InBlcnNvbk5hbWUiO3M6OToi5byg5YWo6JuLIjtzOjEyOiJwZXJzb25HZW5kZXIiO3M6Mzoi55S3IjtzOjE1OiJwZXJzb25CaXJ0aERhdGUiO3M6MTA6IjE5ODctMDktMTIiO3M6MTE6InBlcnNvblBob25lIjtzOjExOiIxMzgxMjEyMDQyOSI7czo2OiJJZENhcmQiO3M6MTg6IjUxMDEyMjE5ODkxMDE0Mjk0OSI7czoxMzoicGVyc29uQWRkcmVzcyI7czoyOToi5Zub5bed55yBIOaIkOmDveW4giDlj4zmtYHljr8iO3M6MTM6IklkQ2FyZEFkZHJlc3MiO3M6Mjk6IuWbm+W3neecgSDmiJDpg73luIIg5Y+M5rWB5Y6/IjtzOjE2OiJJZENhcmRGcm9udFBob3RvIjtzOjE3OiI1OGE3YjEwMTcxNDQ0LmpwZyI7czoxNToiSWRDYXJkQmFja1Bob3RvIjtzOjE3OiI1OGE3YjExNDhkMWYxLmpwZyI7czoxNzoiYnVzaW5lc3NMaWNlbnNlTm8iO3M6MTI6IjMxMDExNDEyMzEyMyI7czoxNDoiY29tcGFueUFkZHJlc3MiO3M6Mzg6IuS4iua1t+W4guWYieWumuWMuuWuieS6remVh3h46LeveHh45Y+3IjtzOjEyOiJsaWNlbnNlUGhvdG8iO3M6MTA6IjIyMzAyNC5qcGciO3M6MTU6InRheExpY2Vuc2VQaG90byI7czoxMDoiMjIzMDI4LmpwZyI7czoxNzoib3JnYW5pemF0aW9uUGhvdG8iO3M6MTA6IjIyMzAyNS5qcGciO30=', '1487387561', null, null, '1');

-- ----------------------------
-- Table structure for sz_orders
-- ----------------------------
DROP TABLE IF EXISTS `sz_orders`;
CREATE TABLE `sz_orders` (
  `order_sn` varchar(25) NOT NULL COMMENT '订单编号',
  `bill_sn` varchar(25) DEFAULT NULL COMMENT '账单标号',
  `order_type` varchar(10) DEFAULT 'G' COMMENT '订单类型',
  `member_id` int(11) NOT NULL COMMENT '订单所属用户',
  `order_image` varchar(200) DEFAULT NULL COMMENT '显示的图片',
  `order_data` varchar(2000) DEFAULT NULL COMMENT '订单数据',
  `receiver` varchar(20) DEFAULT NULL COMMENT '收货人',
  `shipping_address` varchar(200) DEFAULT NULL COMMENT '收货地址',
  `telephone` varchar(11) DEFAULT NULL COMMENT '收货人手机号',
  `pay_time` varchar(11) DEFAULT NULL COMMENT '支付时间',
  `price_total` decimal(10,2) DEFAULT NULL COMMENT '应付金额',
  `price_pay` int(11) DEFAULT NULL COMMENT '实付金额',
  `pay_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '支付状态    1：已支付   0：未支付',
  `create_time` int(11) DEFAULT NULL COMMENT '订单创建时间',
  `express_name` varchar(20) DEFAULT NULL COMMENT '物流名称',
  `express_code` varchar(30) DEFAULT NULL COMMENT '物流单号',
  `order_status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '订单状态     1:未发货    0:取消状态    2:已发货  3:已完成   4:已退货',
  `paid_time` int(11) DEFAULT NULL COMMENT '订单支付时间',
  `complete_time` int(11) DEFAULT NULL COMMENT '订单完成时间',
  `shipping_time` int(11) DEFAULT NULL COMMENT '发货时间',
  `rate_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '评价状态   0:未评价   1:评价',
  `rate_content` tinyint(4) DEFAULT NULL COMMENT '评价内容',
  `rate_time` int(11) DEFAULT NULL COMMENT '评价时间',
  `order_remarks` varchar(200) DEFAULT NULL COMMENT '订单备注',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  PRIMARY KEY (`order_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='<del>订单表--该表暂时不用</del>';

-- ----------------------------
-- Records of sz_orders
-- ----------------------------

-- ----------------------------
-- Table structure for sz_pictures
-- ----------------------------
DROP TABLE IF EXISTS `sz_pictures`;
CREATE TABLE `sz_pictures` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '图片编号',
  `file_id` int(20) unsigned NOT NULL COMMENT '文件资源编号',
  `member_id` int(10) unsigned NOT NULL COMMENT '会员编号',
  `upload_time` int(11) NOT NULL COMMENT '上传日期',
  `category_id` int(11) NOT NULL COMMENT '所属分类',
  `like_count` int(10) unsigned DEFAULT '0',
  `seq` int(11) DEFAULT '0',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sz_pictures
-- ----------------------------
INSERT INTO `sz_pictures` VALUES ('1', '12', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('2', '14', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('3', '15', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('4', '16', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('5', '17', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('6', '18', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('7', '19', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('8', '20', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('9', '21', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('10', '22', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('11', '23', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('12', '24', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('13', '25', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('14', '26', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('15', '27', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('16', '28', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('17', '29', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('18', '30', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('19', '31', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('20', '32', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('21', '33', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('22', '34', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('23', '35', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('24', '36', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('25', '37', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('26', '38', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('27', '39', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('28', '40', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('29', '41', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('30', '42', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('31', '43', '3', '1490989527', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('32', '45', '3', '1490990509', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('33', '47', '3', '1491005890', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('34', '46', '3', '1491005890', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('35', '48', '3', '1491006684', '2', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('36', '49', '3', '1491006684', '2', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('37', '50', '3', '1491007137', '3', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('38', '51', '3', '1491007137', '3', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('39', '52', '3', '1491007320', '4', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('40', '53', '3', '1491007320', '4', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('41', '54', '3', '1491007320', '4', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('42', '55', '3', '1491041268', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('43', '56', '3', '1491041885', '1', '0', '0', '1');
INSERT INTO `sz_pictures` VALUES ('44', '57', '3', '1491042026', '1', '0', '0', '1');

-- ----------------------------
-- Table structure for yc_account_local
-- ----------------------------
DROP TABLE IF EXISTS `yc_account_local`;
CREATE TABLE `yc_account_local` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '数据标识符',
  `mid` int(11) NOT NULL COMMENT '用户编号',
  `login_account` varchar(20) DEFAULT NULL COMMENT '登陆帐号',
  `login_pass` varchar(50) DEFAULT NULL COMMENT '登陆密码',
  `salt` varchar(20) DEFAULT NULL COMMENT '密码加密所需随机字符串',
  `state` tinyint(2) DEFAULT '1' COMMENT '数据状态,1为正常，默认1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='本地账号';

-- ----------------------------
-- Records of yc_account_local
-- ----------------------------
INSERT INTO `yc_account_local` VALUES ('1', '1', 'wuyun', '16aeab6101914e180c6661be710987f3', '7d2ffe8c88', '1');
INSERT INTO `yc_account_local` VALUES ('3', '3', 'yaclty', 'e059276d0ed137a142c84b0bf2191151', 'a84e021125', '1');

-- ----------------------------
-- Table structure for yc_account_social
-- ----------------------------
DROP TABLE IF EXISTS `yc_account_social`;
CREATE TABLE `yc_account_social` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `open_id` varchar(255) DEFAULT NULL,
  `mid` int(11) DEFAULT NULL,
  `ext` varchar(500) DEFAULT NULL,
  `provider` varchar(20) DEFAULT NULL,
  `state` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='社会化登录';

-- ----------------------------
-- Records of yc_account_social
-- ----------------------------
INSERT INTO `yc_account_social` VALUES ('4', '1516257534', '3', '', 'weibo', '1');

-- ----------------------------
-- Table structure for yc_admin
-- ----------------------------
DROP TABLE IF EXISTS `yc_admin`;
CREATE TABLE `yc_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '管理员编号',
  `account` varchar(128) NOT NULL COMMENT '管理员帐号',
  `nick_name` varchar(255) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `pwd` varchar(128) NOT NULL COMMENT '管理员密码',
  `type` int(11) NOT NULL COMMENT '管理员类型，如省级公司管理员，操作员等。',
  `role_id` int(11) NOT NULL COMMENT '角色',
  `note` text COMMENT '备注',
  `status` tinyint(4) DEFAULT '1' COMMENT '状态(1:正常)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='管理员信息表';

-- ----------------------------
-- Records of yc_admin
-- ----------------------------
INSERT INTO `yc_admin` VALUES ('1', 'admin', '我是boss', '44697117cd56845e5d35c4d68295fd77.png', 'e7816e9a10590b1e33b87ec2fa65e6cd', '1', '1', null, '1');
INSERT INTO `yc_admin` VALUES ('2', 'yaclty', '请叫我总管大人', '9bf2e73282051e16b634bdcba9dafd4a.jpg', 'ad9852b48c23ba07347026ed87e39e42', '1', '2', null, '1');

-- ----------------------------
-- Table structure for yc_admin_log
-- ----------------------------
DROP TABLE IF EXISTS `yc_admin_log`;
CREATE TABLE `yc_admin_log` (
  `log_time` int(11) NOT NULL COMMENT '日志记录时间',
  `admin_id` int(11) NOT NULL COMMENT '操作用户',
  `log_type` varchar(255) DEFAULT NULL COMMENT '日志类型',
  `log_item` varchar(255) DEFAULT NULL COMMENT '日志内容',
  `origin_value` varchar(255) DEFAULT NULL COMMENT '原始值',
  `new_value` varchar(255) DEFAULT NULL COMMENT '新的值',
  `ip_address` varchar(255) DEFAULT NULL COMMENT '操作者ip',
  `log_state` tinyint(2) DEFAULT '1',
  `log_data` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`log_time`,`admin_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yc_admin_log
-- ----------------------------
INSERT INTO `yc_admin_log` VALUES ('1488344211', '1', 'login', '/account/admin.login', null, null, '127.0.0.1', '1', '{\"loginId\":\"admin\",\"loginPwd\":\"e7816e9a10590b1e33b87ec2fa65e6cd\"}', null);
INSERT INTO `yc_admin_log` VALUES ('1488643048', '1', 'login', '/account/admin.login', null, null, '127.0.0.1', '1', '{\"loginId\":\"admin\",\"loginPwd\":\"e7816e9a10590b1e33b87ec2fa65e6cd\"}', null);
INSERT INTO `yc_admin_log` VALUES ('1488644289', '1', 'login', '/account/admin.login', null, null, '127.0.0.1', '1', '{\"loginId\":\"admin\",\"loginPwd\":\"e7816e9a10590b1e33b87ec2fa65e6cd\"}', null);
INSERT INTO `yc_admin_log` VALUES ('1488644728', '1', 'insert', '/admin/api/resource.save', null, null, '127.0.0.1', '1', '{\"id\":\"0\",\"res_name\":\"\\u901f\\u627e\\u7ba1\\u7406\",\"res_id\":\"task-manager\",\"res_url\":\"#\",\"res_icon\":\"\",\"parent_id\":\"0\",\"create_time\":1488644728,\"sort\":\"0\",\"type\":\"m\",\"state\":\"1\",\"lastInsertId\":\"35\",\"extraData\":[]}', null);
INSERT INTO `yc_admin_log` VALUES ('1488644751', '1', 'update', '/admin/api/resource.save', null, null, '127.0.0.1', '1', '{\"id\":\"35\",\"res_name\":\"\\u901f\\u627e\\u7ba1\\u7406\",\"res_id\":\"task-manager\",\"res_url\":\"#\",\"res_icon\":\"\",\"parent_id\":\"0\",\"create_time\":\"1488644728\",\"sort\":\"6\",\"type\":\"m\",\"state\":\"1\",\"lastInsertId\":\"0\",\"extraData\":[]}', null);
INSERT INTO `yc_admin_log` VALUES ('1488645123', '1', 'update', '/admin/api/resource.save', null, null, '127.0.0.1', '1', '{\"id\":\"35\",\"res_name\":\"\\u901f\\u627e\\u7ba1\\u7406\",\"res_id\":\"task-manager\",\"res_url\":\"#\",\"res_icon\":\"fa  fa-briefcase\",\"parent_id\":\"0\",\"create_time\":\"1488644728\",\"sort\":\"6\",\"type\":\"m\",\"state\":\"1\",\"lastInsertId\":\"0\",\"extraData\":[]}', null);
INSERT INTO `yc_admin_log` VALUES ('1488645179', '1', 'insert', '/admin/api/resource.save', null, null, '127.0.0.1', '1', '{\"id\":\"0\",\"res_name\":\"\\u7ba1\\u7406\\u901f\\u627e\\u4fe1\\u606f\",\"res_id\":\"manage-suzhao\",\"res_url\":\"\\/admin\\/suzhao\\/view.suzhao-list\",\"res_icon\":\"\",\"parent_id\":\"35\",\"create_time\":1488645179,\"sort\":\"5\",\"type\":\"m\",\"state\":\"1\",\"lastInsertId\":\"36\",\"extraData\":[]', null);
INSERT INTO `yc_admin_log` VALUES ('1488693096', '1', 'login', '/account/admin.login', null, null, '127.0.0.1', '1', '{\"loginId\":\"admin\",\"loginPwd\":\"e7816e9a10590b1e33b87ec2fa65e6cd\"}', null);
INSERT INTO `yc_admin_log` VALUES ('1488693639', '1', 'update', '/admin/api/resource.save', null, null, '127.0.0.1', '1', '{\"id\":\"36\",\"res_name\":\"\\u7ba1\\u7406\\u901f\\u627e\\u4fe1\\u606f\",\"res_id\":\"manage-suzhao\",\"res_url\":\"\\/admin\\/task\\/view.task-list\",\"res_icon\":\"\",\"parent_id\":\"35\",\"create_time\":\"1488645179\",\"sort\":\"5\",\"type\":\"m\",\"state\":\"1\",\"lastInsertId\":\"0\",\"extraData\":[]}', null);
INSERT INTO `yc_admin_log` VALUES ('1488696689', '1', 'login', '/account/admin.login', null, null, '127.0.0.1', '1', '{\"loginId\":\"admin\",\"loginPwd\":\"e7816e9a10590b1e33b87ec2fa65e6cd\"}', null);
INSERT INTO `yc_admin_log` VALUES ('1488699408', '1', 'login', '/account/admin.login', null, null, '127.0.0.1', '1', '{\"loginId\":\"admin\",\"loginPwd\":\"e7816e9a10590b1e33b87ec2fa65e6cd\"}', null);
INSERT INTO `yc_admin_log` VALUES ('1488702497', '1', 'login', '/account/admin.login', null, null, '127.0.0.1', '1', '{\"loginId\":\"admin\",\"loginPwd\":\"e7816e9a10590b1e33b87ec2fa65e6cd\"}', null);
INSERT INTO `yc_admin_log` VALUES ('1488706296', '1', 'login', '/account/admin.login', null, null, '127.0.0.1', '1', '{\"loginId\":\"admin\",\"loginPwd\":\"e7816e9a10590b1e33b87ec2fa65e6cd\"}', null);
INSERT INTO `yc_admin_log` VALUES ('1488712553', '1', 'login', '/account/admin.login', null, null, '127.0.0.1', '1', '{\"loginId\":\"admin\",\"loginPwd\":\"e7816e9a10590b1e33b87ec2fa65e6cd\"}', null);
INSERT INTO `yc_admin_log` VALUES ('1488719482', '1', 'login', '/account/admin.login', null, null, '127.0.0.1', '1', '{\"loginId\":\"admin\",\"loginPwd\":\"e7816e9a10590b1e33b87ec2fa65e6cd\"}', null);
INSERT INTO `yc_admin_log` VALUES ('1488721629', '1', 'login', '/account/admin.login', null, null, '127.0.0.1', '1', '{\"loginId\":\"admin\",\"loginPwd\":\"e7816e9a10590b1e33b87ec2fa65e6cd\"}', null);
INSERT INTO `yc_admin_log` VALUES ('1488726367', '1', 'update', '/admin/task/task.updateid=1', null, null, '127.0.0.1', '1', '[]', null);
INSERT INTO `yc_admin_log` VALUES ('1488726381', '1', 'update', '/admin/task/task.updateid=1', null, null, '127.0.0.1', '1', '[]', null);
INSERT INTO `yc_admin_log` VALUES ('1488726429', '1', 'update', '/admin/task/task.updateid=1', null, null, '127.0.0.1', '1', '[]', null);
INSERT INTO `yc_admin_log` VALUES ('1488726446', '1', 'update', '/admin/task/task.updateid=1', null, null, '127.0.0.1', '1', '[]', null);
INSERT INTO `yc_admin_log` VALUES ('1488726471', '1', 'update', '/admin/task/task.updateid=1', null, null, '127.0.0.1', '1', '[]', null);
INSERT INTO `yc_admin_log` VALUES ('1488726477', '1', 'update', '/admin/task/task.updateid=1', null, null, '127.0.0.1', '1', '[]', null);
INSERT INTO `yc_admin_log` VALUES ('1488727071', '1', 'update', '/admin/task/task.updateid=1', null, null, '127.0.0.1', '1', '[]', null);
INSERT INTO `yc_admin_log` VALUES ('1488727130', '1', 'update', '/admin/task/task.updateid=1', null, null, '127.0.0.1', '1', '[]', null);
INSERT INTO `yc_admin_log` VALUES ('1488727155', '1', 'update', '/admin/task/task.updateid=1', null, null, '127.0.0.1', '1', '[]', null);
INSERT INTO `yc_admin_log` VALUES ('1488727188', '1', 'update', '/admin/task/task.updateid=1', null, null, '127.0.0.1', '1', '[]', null);
INSERT INTO `yc_admin_log` VALUES ('1488727204', '1', 'update', '/admin/task/task.updateid=1', null, null, '127.0.0.1', '1', '[]', null);
INSERT INTO `yc_admin_log` VALUES ('1488727385', '1', 'update', '/admin/task/task.updateid=1', null, null, '127.0.0.1', '1', '[]', null);
INSERT INTO `yc_admin_log` VALUES ('1488727405', '1', 'update', '/admin/task/task.updateid=1', null, null, '127.0.0.1', '1', '[]', null);
INSERT INTO `yc_admin_log` VALUES ('1488727407', '1', 'update', '/admin/task/task.updateid=1', null, null, '127.0.0.1', '1', '[]', null);
INSERT INTO `yc_admin_log` VALUES ('1488727435', '1', 'update', '/admin/task/task.updateid=1', null, null, '127.0.0.1', '1', '[]', null);
INSERT INTO `yc_admin_log` VALUES ('1488727438', '1', 'update', '/admin/task/task.updateid=1', null, null, '127.0.0.1', '1', '[]', null);
INSERT INTO `yc_admin_log` VALUES ('1488802739', '1', 'login', '/account/admin.login', null, null, '127.0.0.1', '1', '{\"loginId\":\"admin\",\"loginPwd\":\"e7816e9a10590b1e33b87ec2fa65e6cd\"}', null);
INSERT INTO `yc_admin_log` VALUES ('1488811342', '1', 'login', '/account/admin.login', null, null, '127.0.0.1', '1', '{\"loginId\":\"admin\",\"loginPwd\":\"e7816e9a10590b1e33b87ec2fa65e6cd\"}', null);
INSERT INTO `yc_admin_log` VALUES ('1488816113', '1', 'insert', '/admin/api/resource.save', null, null, '127.0.0.1', '1', '{\"id\":\"0\",\"res_name\":\"\\u5546\\u54c1\\u7ba1\\u7406\",\"res_id\":\"manage-goods\",\"res_url\":\"#\",\"res_icon\":\"icon-handbag\",\"parent_id\":\"0\",\"create_time\":1488816113,\"sort\":\"8\",\"type\":\"m\",\"state\":\"1\",\"lastInsertId\":\"37\",\"extraData\":[]}', null);
INSERT INTO `yc_admin_log` VALUES ('1488816161', '1', 'insert', '/admin/api/resource.save', null, null, '127.0.0.1', '1', '{\"id\":\"0\",\"res_name\":\"\\u7ba1\\u7406\\u5546\\u54c1\\u4fe1\\u606f\",\"res_id\":\"manage-goods-list\",\"res_url\":\"\\/admin\\/goods\\/view.goods-list\",\"res_icon\":\"\",\"parent_id\":\"37\",\"create_time\":1488816161,\"sort\":\"\",\"type\":\"m\",\"state\":\"1\",\"lastInsertId\":\"38\",\"extraData\":[', null);
INSERT INTO `yc_admin_log` VALUES ('1488816291', '1', 'update', '/admin/api/resource.save', null, null, '127.0.0.1', '1', '{\"id\":\"37\",\"res_name\":\"\\u5546\\u54c1\\u7ba1\\u7406\",\"res_id\":\"manage-goods\",\"res_url\":\"#\",\"res_icon\":\"fa fa-credit-card\",\"parent_id\":\"0\",\"create_time\":\"1488816113\",\"sort\":\"8\",\"type\":\"m\",\"state\":\"1\",\"lastInsertId\":\"0\",\"extraData\":[]}', null);
INSERT INTO `yc_admin_log` VALUES ('1488948625', '1', 'login', '/account/admin.login', null, null, '127.0.0.1', '1', '{\"loginId\":\"admin\",\"loginPwd\":\"e7816e9a10590b1e33b87ec2fa65e6cd\"}', null);
INSERT INTO `yc_admin_log` VALUES ('1488985662', '1', 'login', '/account/admin.login', null, null, '127.0.0.1', '1', '{\"loginId\":\"admin\",\"loginPwd\":\"e7816e9a10590b1e33b87ec2fa65e6cd\"}', null);
INSERT INTO `yc_admin_log` VALUES ('1488988677', '1', 'update', '/admin/goods/change.statusid=1&status=2', null, null, '127.0.0.1', '1', '[]', null);
INSERT INTO `yc_admin_log` VALUES ('1488988736', '1', 'update', '/admin/goods/change.status?id=1&status=1', null, null, '127.0.0.1', '1', '[]', null);
INSERT INTO `yc_admin_log` VALUES ('1489827210', '1', 'login', '/account/admin.login', null, null, '127.0.0.1', '1', '{\"loginId\":\"admin\",\"loginPwd\":\"e7816e9a10590b1e33b87ec2fa65e6cd\"}', null);
INSERT INTO `yc_admin_log` VALUES ('1489827239', '1', 'login', '/account/admin.login', null, null, '127.0.0.1', '1', '{\"loginId\":\"admin\",\"loginPwd\":\"e7816e9a10590b1e33b87ec2fa65e6cd\"}', null);
INSERT INTO `yc_admin_log` VALUES ('1489836535', '1', 'login', '/account/admin.login', null, null, '127.0.0.1', '1', '{\"loginId\":\"admin\",\"loginPwd\":\"e7816e9a10590b1e33b87ec2fa65e6cd\"}', null);
INSERT INTO `yc_admin_log` VALUES ('1489837114', '1', 'update', '/admin/tuan/pay_status.change?id=1&status=1', null, null, '127.0.0.1', '1', '[]', null);
INSERT INTO `yc_admin_log` VALUES ('1489837144', '1', 'update', '/admin/tuan/pay_status.change?id=1&status=1', null, null, '127.0.0.1', '1', '[]', null);
INSERT INTO `yc_admin_log` VALUES ('1489837181', '1', 'update', '/admin/tuan/pay_status.change?id=1&status=1', null, null, '127.0.0.1', '1', '[]', null);
INSERT INTO `yc_admin_log` VALUES ('1489844014', '1', 'login', '/account/admin.login', null, null, '127.0.0.1', '1', '{\"loginId\":\"admin\",\"loginPwd\":\"e7816e9a10590b1e33b87ec2fa65e6cd\"}', null);
INSERT INTO `yc_admin_log` VALUES ('1489846021', '1', 'update', '/admin/tuan/pay_status.change?id=1&status=0', null, null, '127.0.0.1', '1', '[]', null);
INSERT INTO `yc_admin_log` VALUES ('1489846348', '1', 'update', '/admin/tuan/pay_status.change?id=1&status=1', null, null, '127.0.0.1', '1', '[]', null);
INSERT INTO `yc_admin_log` VALUES ('1489846357', '1', 'update', '/admin/tuan/pay_status.change?id=1&status=0', null, null, '127.0.0.1', '1', '[]', null);
INSERT INTO `yc_admin_log` VALUES ('1489846359', '1', 'update', '/admin/tuan/pay_status.change?id=1&status=1', null, null, '127.0.0.1', '1', '[]', null);
INSERT INTO `yc_admin_log` VALUES ('1490197888', '1', 'login', '/account/admin.login', null, null, '127.0.0.1', '1', '{\"loginId\":\"admin\",\"loginPwd\":\"e7816e9a10590b1e33b87ec2fa65e6cd\"}', null);
INSERT INTO `yc_admin_log` VALUES ('1490367754', '1', 'login', '/account/admin.login', null, null, '127.0.0.1', '1', '{\"loginId\":\"admin\",\"loginPwd\":\"e7816e9a10590b1e33b87ec2fa65e6cd\"}', null);
INSERT INTO `yc_admin_log` VALUES ('1490631096', '1', 'login', '/account/admin.login', null, null, '127.0.0.1', '1', '{\"loginId\":\"admin\",\"loginPwd\":\"e7816e9a10590b1e33b87ec2fa65e6cd\"}', null);
INSERT INTO `yc_admin_log` VALUES ('1490674942', '1', 'login', '/account/admin.login', null, null, '127.0.0.1', '1', '{\"loginId\":\"admin\",\"loginPwd\":\"e7816e9a10590b1e33b87ec2fa65e6cd\"}', null);
INSERT INTO `yc_admin_log` VALUES ('1491039123', '1', 'login', '/account/admin.login', null, null, '127.0.0.1', '1', '{\"loginId\":\"admin\",\"loginPwd\":\"e7816e9a10590b1e33b87ec2fa65e6cd\"}', null);

-- ----------------------------
-- Table structure for yc_admin_resources
-- ----------------------------
DROP TABLE IF EXISTS `yc_admin_resources`;
CREATE TABLE `yc_admin_resources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `res_name` varchar(255) DEFAULT NULL,
  `res_id` varchar(255) DEFAULT NULL,
  `res_url` varchar(255) DEFAULT NULL,
  `res_icon` varchar(255) DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `create_time` int(11) DEFAULT NULL,
  `type` varchar(5) DEFAULT NULL,
  `sort` int(5) DEFAULT NULL,
  `state` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of yc_admin_resources
-- ----------------------------
INSERT INTO `yc_admin_resources` VALUES ('2', '后台首页', 'admin_index', '/admin/', 'fa fa-home', '0', '1477900091', 'm', '10', '1');
INSERT INTO `yc_admin_resources` VALUES ('7', '管理员管理', 'admin_manage', '#', 'fa fa-user', '0', '1479296583', 'm', '9', '1');
INSERT INTO `yc_admin_resources` VALUES ('8', '管理员查询', 'admin_query', '/admin/user/view.admin-list', 'glyphicon glyphicon-th-large', '7', '1479296583', 'm', '1', '1');
INSERT INTO `yc_admin_resources` VALUES ('9', '管理员注册', 'admin_reg', '/admin/user/view.admin-register', 'glyphicon glyphicon-th-large', '7', '1479296583', 'm', '1', '1');
INSERT INTO `yc_admin_resources` VALUES ('10', '会员管理', 'member_manage', '#', 'fa fa-users', '0', '1479296583', 'm', '8', '1');
INSERT INTO `yc_admin_resources` VALUES ('11', '会员查询', 'member_query', '/admin/member/view.member-list', 'glyphicon glyphicon-th-large', '10', '1479296583', 'm', '1', '1');
INSERT INTO `yc_admin_resources` VALUES ('12', '会员注册', 'member_register', '/admin/member/view.member-register', 'glyphicon glyphicon-th-large', '10', '1479296583', 'm', '1', '1');
INSERT INTO `yc_admin_resources` VALUES ('28', '系统管理', 'sys', '#', 'fa  fa-cogs', '0', '1479296583', 'm', '1', '1');
INSERT INTO `yc_admin_resources` VALUES ('30', '系统资源管理', 'sys_res', '/admin/system/view.system-resource', 'glyphicon glyphicon-th-large', '28', '1479296583', 'm', '1', '1');
INSERT INTO `yc_admin_resources` VALUES ('31', '角色资源管理', 'sys_role', '/admin/system/view.role-list', 'glyphicon glyphicon-th-large', '28', '1479296583', 'm', '1', '1');
INSERT INTO `yc_admin_resources` VALUES ('32', '操作日志', 'sys_log', '/admin/system/view.system-log', 'glyphicon glyphicon-th-large', '28', '1479296583', 'm', '1', '1');
INSERT INTO `yc_admin_resources` VALUES ('33', '团购管理', 'tuan', '#', 'fa fa-shopping-bag', '0', '1488199573', 'm', '7', '1');
INSERT INTO `yc_admin_resources` VALUES ('34', '团购列表', 'tuan-list', '/admin/tuan/view.tuan-list', 'glyphicon glyphicon-th-large', '33', '1488200145', 'm', '1', '1');
INSERT INTO `yc_admin_resources` VALUES ('35', '速找管理', 'task-manager', '#', 'fa  fa-briefcase', '0', '1488644728', 'm', '6', '1');
INSERT INTO `yc_admin_resources` VALUES ('36', '管理速找信息', 'manage-suzhao', '/admin/task/view.task-list', null, '35', '1488645179', 'm', '5', '1');
INSERT INTO `yc_admin_resources` VALUES ('37', '商品管理', 'manage-goods', '#', 'fa fa-credit-card', '0', '1488816113', 'm', '8', '1');
INSERT INTO `yc_admin_resources` VALUES ('38', '管理商品信息', 'manage-goods-list', '/admin/goods/view.goods-list', null, '37', '1488816161', 'm', null, '1');

-- ----------------------------
-- Table structure for yc_admin_role
-- ----------------------------
DROP TABLE IF EXISTS `yc_admin_role`;
CREATE TABLE `yc_admin_role` (
  `id` int(11) NOT NULL,
  `role_name` varchar(50) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `res_id` varchar(2000) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `is_sys` tinyint(2) DEFAULT '0',
  `addition` varchar(100) DEFAULT NULL,
  `level` varchar(20) DEFAULT '0',
  `status` tinyint(255) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yc_admin_role
-- ----------------------------
INSERT INTO `yc_admin_role` VALUES ('1', '超级管理员', '1', '2,7,8,9,10,11,12,28,30,31,32,33,34,35,36,37,38', 'root', '此数据不允许修改', '0', 'admin', 's', '1');
INSERT INTO `yc_admin_role` VALUES ('2', '系统管理员', '1', '2,7,8,9,10,11,12,28,32,33,34,35,36', 'admin', '系统管理员', '0', 'admin', 'a', '1');

-- ----------------------------
-- Table structure for yc_city
-- ----------------------------
DROP TABLE IF EXISTS `yc_city`;
CREATE TABLE `yc_city` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '城市编号',
  `city_name` varchar(45) NOT NULL COMMENT '城市名称',
  `parent_id` int(11) NOT NULL COMMENT '父级城市编号',
  `state` tinyint(4) DEFAULT '1' COMMENT '数据状态,1为正常，默认1',
  `remark` varchar(45) DEFAULT NULL COMMENT '备注',
  `city_sort` tinyint(4) DEFAULT NULL COMMENT '排序，数字越大排在前',
  `city_area` varchar(45) DEFAULT NULL,
  `id_card_code` varchar(45) DEFAULT NULL COMMENT '城市身份证号',
  `first_pinyin` varchar(45) DEFAULT NULL COMMENT '城市首字母',
  `full_pinyin` varchar(150) DEFAULT NULL COMMENT '城市拼音',
  `simple_pinyin` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3239 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yc_city
-- ----------------------------
INSERT INTO `yc_city` VALUES ('1', '中国', '0', '1', null, null, null, '000000', 'z', 'zhongguo', 'zg');
INSERT INTO `yc_city` VALUES ('2', '北京', '1', '1', '北京', null, null, '110000', 'b', 'beijing', 'bj');
INSERT INTO `yc_city` VALUES ('3', '东城区', '2', '1', '北京,东城区', null, null, '110101', 'd', 'dongchengqu', 'dcq');
INSERT INTO `yc_city` VALUES ('4', '西城区', '2', '1', '北京,西城区', null, null, '110102', 'x', 'xichengqu', 'xcq');
INSERT INTO `yc_city` VALUES ('5', '朝阳区', '2', '1', '北京,朝阳区', null, null, '110105', 'z', 'zhaoyangqu', 'cyq');
INSERT INTO `yc_city` VALUES ('6', '丰台区', '2', '1', '北京,丰台区', null, null, '110106', 'f', 'fengtaiqu', 'ftq');
INSERT INTO `yc_city` VALUES ('7', '石景山区', '2', '1', '北京,石景山区', null, null, '110107', 's', 'shijingshanqu', 'sjsq');
INSERT INTO `yc_city` VALUES ('8', '海淀区', '2', '1', '北京,海淀区', null, null, '110108', 'h', 'haidianqu', 'hdq');
INSERT INTO `yc_city` VALUES ('9', '门头沟区', '2', '1', '北京,门头沟区', null, null, '110109', 'm', 'mentougouqu', 'mtgq');
INSERT INTO `yc_city` VALUES ('10', '房山区', '2', '1', '北京,房山区', null, null, '110111', 'f', 'fangshanqu', 'fsq');
INSERT INTO `yc_city` VALUES ('11', '通州区', '2', '1', '北京,通州区', null, null, '110112', 't', 'tongzhouqu', 'tzq');
INSERT INTO `yc_city` VALUES ('12', '顺义区', '2', '1', '北京,顺义区', null, null, '110113', 's', 'shunyiqu', 'syq');
INSERT INTO `yc_city` VALUES ('13', '昌平区', '2', '1', '北京,昌平区', null, null, '110114', 'c', 'changpingqu', 'cpq');
INSERT INTO `yc_city` VALUES ('14', '大兴区', '2', '1', '北京,大兴区', null, null, '110115', 'd', 'daxingqu', 'dxq');
INSERT INTO `yc_city` VALUES ('15', '怀柔区', '2', '1', '北京,怀柔区', null, null, '110116', 'h', 'huairouqu', 'hrq');
INSERT INTO `yc_city` VALUES ('16', '平谷区', '2', '1', '北京,平谷区', null, null, '110117', 'p', 'pingguqu', 'pgq');
INSERT INTO `yc_city` VALUES ('17', '密云县', '2', '1', '北京,密云县', null, null, '110228', 'm', 'miyunxian', 'myx');
INSERT INTO `yc_city` VALUES ('18', '延庆县', '2', '1', '北京,延庆县', null, null, '110229', 'y', 'yanqingxian', 'yqx');
INSERT INTO `yc_city` VALUES ('19', '天津', '1', '1', '天津', null, null, '120000', 't', 'tianjin', 'tj');
INSERT INTO `yc_city` VALUES ('20', '和平区', '19', '1', '天津,和平区', null, null, '120101', 'h', 'hepingqu', 'hpq');
INSERT INTO `yc_city` VALUES ('21', '河东区', '19', '1', '天津,河东区', null, null, '120102', 'h', 'hedongqu', 'hdq');
INSERT INTO `yc_city` VALUES ('22', '河西区', '19', '1', '天津,河西区', null, null, '120103', 'h', 'hexiqu', 'hxq');
INSERT INTO `yc_city` VALUES ('23', '南开区', '19', '1', '天津,南开区', null, null, '120104', 'n', 'nankaiqu', 'nkq');
INSERT INTO `yc_city` VALUES ('24', '河北区', '19', '1', '天津,河北区', null, null, '120105', 'h', 'hebeiqu', 'hbq');
INSERT INTO `yc_city` VALUES ('25', '红桥区', '19', '1', '天津,红桥区', null, null, '120106', 'h', 'hongqiaoqu', 'hqq');
INSERT INTO `yc_city` VALUES ('26', '东丽区', '19', '1', '天津,东丽区', null, null, '120110', 'd', 'dongliqu', 'dlq');
INSERT INTO `yc_city` VALUES ('27', '西青区', '19', '1', '天津,西青区', null, null, '120111', 'x', 'xiqingqu', 'xqq');
INSERT INTO `yc_city` VALUES ('28', '津南区', '19', '1', '天津,津南区', null, null, '120112', 'j', 'jinnanqu', 'jnq');
INSERT INTO `yc_city` VALUES ('29', '北辰区', '19', '1', '天津,北辰区', null, null, '120113', 'b', 'beichenqu', 'bcq');
INSERT INTO `yc_city` VALUES ('30', '武清区', '19', '1', '天津,武清区', null, null, '120114', 'w', 'wuqingqu', 'wqq');
INSERT INTO `yc_city` VALUES ('31', '宝坻区', '19', '1', '天津,宝坻区', null, null, '120115', 'b', 'baodiqu', 'bq');
INSERT INTO `yc_city` VALUES ('32', '滨海新区', '19', '1', '天津,滨海新区', null, null, '120116', 'b', 'binhaixinqu', 'bhxq');
INSERT INTO `yc_city` VALUES ('33', '宁河县', '19', '1', '天津,宁河县', null, null, '120221', 'n', 'ninghexian', 'nhx');
INSERT INTO `yc_city` VALUES ('34', '静海县', '19', '1', '天津,静海县', null, null, '120223', 'j', 'jinghaixian', 'jhx');
INSERT INTO `yc_city` VALUES ('35', '蓟县', '19', '1', '天津,蓟县', null, null, '120225', 'j', 'jixian', 'jx');
INSERT INTO `yc_city` VALUES ('36', '河北', '1', '1', '河北', null, null, '130000', 'h', 'hebei', 'hb');
INSERT INTO `yc_city` VALUES ('37', '石家庄市', '36', '1', '河北,石家庄市', null, null, '130100', 's', 'shijiazhuangshi', 'sjzs');
INSERT INTO `yc_city` VALUES ('38', '长安区', '37', '1', '河北,石家庄市,长安区', null, null, '130102', 'c', 'changanqu', 'caq');
INSERT INTO `yc_city` VALUES ('39', '桥西区', '37', '1', '河北,石家庄市,桥西区', null, null, '130104', 'q', 'qiaoxiqu', 'qxq');
INSERT INTO `yc_city` VALUES ('40', '新华区', '37', '1', '河北,石家庄市,新华区', null, null, '130105', 'x', 'xinhuaqu', 'xhq');
INSERT INTO `yc_city` VALUES ('41', '井陉矿区', '37', '1', '河北,石家庄市,井陉矿区', null, null, '130107', 'j', 'jingxingkuangqu', 'jkq');
INSERT INTO `yc_city` VALUES ('42', '裕华区', '37', '1', '河北,石家庄市,裕华区', null, null, '130108', 'y', 'yuhuaqu', 'yhq');
INSERT INTO `yc_city` VALUES ('43', '藁城区', '37', '1', '河北,石家庄市,藁城区', null, null, '130182', 'g', 'gaochengqu', 'cq');
INSERT INTO `yc_city` VALUES ('44', '鹿泉区', '37', '1', '河北,石家庄市,鹿泉区', null, null, '130185', 'l', 'luquanqu', 'lqq');
INSERT INTO `yc_city` VALUES ('45', '栾城区', '37', '1', '河北,石家庄市,栾城区', null, null, '130124', 'l', 'luanchengqu', 'cq');
INSERT INTO `yc_city` VALUES ('46', '井陉县', '37', '1', '河北,石家庄市,井陉县', null, null, '130121', 'j', 'jingxingxian', 'jx');
INSERT INTO `yc_city` VALUES ('47', '正定县', '37', '1', '河北,石家庄市,正定县', null, null, '130123', 'z', 'zhengdingxian', 'zdx');
INSERT INTO `yc_city` VALUES ('48', '行唐县', '37', '1', '河北,石家庄市,行唐县', null, null, '130125', 'x', 'xingtangxian', 'xtx');
INSERT INTO `yc_city` VALUES ('49', '灵寿县', '37', '1', '河北,石家庄市,灵寿县', null, null, '130126', 'l', 'lingshouxian', 'lsx');
INSERT INTO `yc_city` VALUES ('50', '高邑县', '37', '1', '河北,石家庄市,高邑县', null, null, '130127', 'g', 'gaoyixian', 'gyx');
INSERT INTO `yc_city` VALUES ('51', '深泽县', '37', '1', '河北,石家庄市,深泽县', null, null, '130128', 's', 'shenzexian', 'szx');
INSERT INTO `yc_city` VALUES ('52', '赞皇县', '37', '1', '河北,石家庄市,赞皇县', null, null, '130129', 'z', 'zanhuangxian', 'zhx');
INSERT INTO `yc_city` VALUES ('53', '无极县', '37', '1', '河北,石家庄市,无极县', null, null, '130130', 'w', 'wujixian', 'wjx');
INSERT INTO `yc_city` VALUES ('54', '平山县', '37', '1', '河北,石家庄市,平山县', null, null, '130131', 'p', 'pingshanxian', 'psx');
INSERT INTO `yc_city` VALUES ('55', '元氏县', '37', '1', '河北,石家庄市,元氏县', null, null, '130132', 'y', 'yuanshixian', 'ysx');
INSERT INTO `yc_city` VALUES ('56', '赵县', '37', '1', '河北,石家庄市,赵县', null, null, '130133', 'z', 'zhaoxian', 'zx');
INSERT INTO `yc_city` VALUES ('57', '辛集市', '37', '1', '河北,石家庄市,辛集市', null, null, '130181', 'x', 'xinjishi', 'xjs');
INSERT INTO `yc_city` VALUES ('58', '晋州市', '37', '1', '河北,石家庄市,晋州市', null, null, '130183', 'j', 'jinzhoushi', 'jzs');
INSERT INTO `yc_city` VALUES ('59', '新乐市', '37', '1', '河北,石家庄市,新乐市', null, null, '130184', 'x', 'xinleshi', 'xls');
INSERT INTO `yc_city` VALUES ('60', '唐山市', '36', '1', '河北,唐山市', null, null, '130200', 't', 'tangshanshi', 'tss');
INSERT INTO `yc_city` VALUES ('61', '路南区', '60', '1', '河北,唐山市,路南区', null, null, '130202', 'l', 'lunanqu', 'lnq');
INSERT INTO `yc_city` VALUES ('62', '路北区', '60', '1', '河北,唐山市,路北区', null, null, '130203', 'l', 'lubeiqu', 'lbq');
INSERT INTO `yc_city` VALUES ('63', '古冶区', '60', '1', '河北,唐山市,古冶区', null, null, '130204', 'g', 'guyequ', 'gyq');
INSERT INTO `yc_city` VALUES ('64', '开平区', '60', '1', '河北,唐山市,开平区', null, null, '130205', 'k', 'kaipingqu', 'kpq');
INSERT INTO `yc_city` VALUES ('65', '丰南区', '60', '1', '河北,唐山市,丰南区', null, null, '130207', 'f', 'fengnanqu', 'fnq');
INSERT INTO `yc_city` VALUES ('66', '丰润区', '60', '1', '河北,唐山市,丰润区', null, null, '130208', 'f', 'fengrunqu', 'frq');
INSERT INTO `yc_city` VALUES ('67', '曹妃甸区', '60', '1', '河北,唐山市,曹妃甸区', null, null, '130230', 'c', 'caofeidianqu', 'cdq');
INSERT INTO `yc_city` VALUES ('68', '滦县', '60', '1', '河北,唐山市,滦县', null, null, '130223', 'l', 'luanxian', 'lx');
INSERT INTO `yc_city` VALUES ('69', '滦南县', '60', '1', '河北,唐山市,滦南县', null, null, '130224', 'l', 'luannanxian', 'lnx');
INSERT INTO `yc_city` VALUES ('70', '乐亭县', '60', '1', '河北,唐山市,乐亭县', null, null, '130225', 'l', 'letingxian', 'ltx');
INSERT INTO `yc_city` VALUES ('71', '迁西县', '60', '1', '河北,唐山市,迁西县', null, null, '130227', 'q', 'qianxixian', 'qxx');
INSERT INTO `yc_city` VALUES ('72', '玉田县', '60', '1', '河北,唐山市,玉田县', null, null, '130229', 'y', 'yutianxian', 'ytx');
INSERT INTO `yc_city` VALUES ('73', '遵化市', '60', '1', '河北,唐山市,遵化市', null, null, '130281', 'z', 'zunhuashi', 'zhs');
INSERT INTO `yc_city` VALUES ('74', '迁安市', '60', '1', '河北,唐山市,迁安市', null, null, '130283', 'q', 'qiananshi', 'qas');
INSERT INTO `yc_city` VALUES ('75', '秦皇岛市', '36', '1', '河北,秦皇岛市', null, null, '130300', 'q', 'qinhuangdaoshi', 'qhds');
INSERT INTO `yc_city` VALUES ('76', '海港区', '75', '1', '河北,秦皇岛市,海港区', null, null, '130302', 'h', 'haigangqu', 'hgq');
INSERT INTO `yc_city` VALUES ('77', '山海关区', '75', '1', '河北,秦皇岛市,山海关区', null, null, '130303', 's', 'shanhaiguanqu', 'shgq');
INSERT INTO `yc_city` VALUES ('78', '北戴河区', '75', '1', '河北,秦皇岛市,北戴河区', null, null, '130304', 'b', 'beidaihequ', 'bdhq');
INSERT INTO `yc_city` VALUES ('79', '青龙满族自治县', '75', '1', '河北,秦皇岛市,青龙满族自治县', null, null, '130321', 'q', 'qinglongmanzuzizhixian', 'qlmzzzx');
INSERT INTO `yc_city` VALUES ('80', '昌黎县', '75', '1', '河北,秦皇岛市,昌黎县', null, null, '130322', 'c', 'changlixian', 'clx');
INSERT INTO `yc_city` VALUES ('81', '抚宁县', '75', '1', '河北,秦皇岛市,抚宁县', null, null, '130323', 'f', 'funingxian', 'fnx');
INSERT INTO `yc_city` VALUES ('82', '卢龙县', '75', '1', '河北,秦皇岛市,卢龙县', null, null, '130324', 'l', 'lulongxian', 'llx');
INSERT INTO `yc_city` VALUES ('83', '邯郸市', '36', '1', '河北,邯郸市', null, null, '130400', 'h', 'handanshi', 'hds');
INSERT INTO `yc_city` VALUES ('84', '邯山区', '83', '1', '河北,邯郸市,邯山区', null, null, '130402', 'h', 'hanshanqu', 'hsq');
INSERT INTO `yc_city` VALUES ('85', '丛台区', '83', '1', '河北,邯郸市,丛台区', null, null, '130403', 'c', 'congtaiqu', 'ctq');
INSERT INTO `yc_city` VALUES ('86', '复兴区', '83', '1', '河北,邯郸市,复兴区', null, null, '130404', 'f', 'fuxingqu', 'fxq');
INSERT INTO `yc_city` VALUES ('87', '峰峰矿区', '83', '1', '河北,邯郸市,峰峰矿区', null, null, '130406', 'f', 'fengfengkuangqu', 'ffkq');
INSERT INTO `yc_city` VALUES ('88', '邯郸县', '83', '1', '河北,邯郸市,邯郸县', null, null, '130421', 'h', 'handanxian', 'hdx');
INSERT INTO `yc_city` VALUES ('89', '临漳县', '83', '1', '河北,邯郸市,临漳县', null, null, '130423', 'l', 'linzhangxian', 'lzx');
INSERT INTO `yc_city` VALUES ('90', '成安县', '83', '1', '河北,邯郸市,成安县', null, null, '130424', 'c', 'chenganxian', 'cax');
INSERT INTO `yc_city` VALUES ('91', '大名县', '83', '1', '河北,邯郸市,大名县', null, null, '130425', 'd', 'damingxian', 'dmx');
INSERT INTO `yc_city` VALUES ('92', '涉县', '83', '1', '河北,邯郸市,涉县', null, null, '130426', 's', 'shexian', 'sx');
INSERT INTO `yc_city` VALUES ('93', '磁县', '83', '1', '河北,邯郸市,磁县', null, null, '130427', 'c', 'cixian', 'cx');
INSERT INTO `yc_city` VALUES ('94', '肥乡县', '83', '1', '河北,邯郸市,肥乡县', null, null, '130428', 'f', 'feixiangxian', 'fxx');
INSERT INTO `yc_city` VALUES ('95', '永年县', '83', '1', '河北,邯郸市,永年县', null, null, '130429', 'y', 'yongnianxian', 'ynx');
INSERT INTO `yc_city` VALUES ('96', '邱县', '83', '1', '河北,邯郸市,邱县', null, null, '130430', 'q', 'qiuxian', 'qx');
INSERT INTO `yc_city` VALUES ('97', '鸡泽县', '83', '1', '河北,邯郸市,鸡泽县', null, null, '130431', 'j', 'jizexian', 'jzx');
INSERT INTO `yc_city` VALUES ('98', '广平县', '83', '1', '河北,邯郸市,广平县', null, null, '130432', 'g', 'guangpingxian', 'gpx');
INSERT INTO `yc_city` VALUES ('99', '馆陶县', '83', '1', '河北,邯郸市,馆陶县', null, null, '130433', 'g', 'guantaoxian', 'gtx');
INSERT INTO `yc_city` VALUES ('100', '魏县', '83', '1', '河北,邯郸市,魏县', null, null, '130434', 'w', 'weixian', 'wx');
INSERT INTO `yc_city` VALUES ('101', '曲周县', '83', '1', '河北,邯郸市,曲周县', null, null, '130435', 'q', 'quzhouxian', 'qzx');
INSERT INTO `yc_city` VALUES ('102', '武安市', '83', '1', '河北,邯郸市,武安市', null, null, '130481', 'w', 'wuanshi', 'was');
INSERT INTO `yc_city` VALUES ('103', '邢台市', '36', '1', '河北,邢台市', null, null, '130500', 'x', 'xingtaishi', 'xts');
INSERT INTO `yc_city` VALUES ('104', '桥东区', '103', '1', '河北,邢台市,桥东区', null, null, '130502', 'q', 'qiaodongqu', 'qdq');
INSERT INTO `yc_city` VALUES ('105', '桥西区', '103', '1', '河北,邢台市,桥西区', null, null, '130503', 'q', 'qiaoxiqu', 'qxq');
INSERT INTO `yc_city` VALUES ('106', '邢台县', '103', '1', '河北,邢台市,邢台县', null, null, '130521', 'x', 'xingtaixian', 'xtx');
INSERT INTO `yc_city` VALUES ('107', '临城县', '103', '1', '河北,邢台市,临城县', null, null, '130522', 'l', 'linchengxian', 'lcx');
INSERT INTO `yc_city` VALUES ('108', '内丘县', '103', '1', '河北,邢台市,内丘县', null, null, '130523', 'n', 'neiqiuxian', 'nqx');
INSERT INTO `yc_city` VALUES ('109', '柏乡县', '103', '1', '河北,邢台市,柏乡县', null, null, '130524', 'b', 'baixiangxian', 'bxx');
INSERT INTO `yc_city` VALUES ('110', '隆尧县', '103', '1', '河北,邢台市,隆尧县', null, null, '130525', 'l', 'longyaoxian', 'lyx');
INSERT INTO `yc_city` VALUES ('111', '任县', '103', '1', '河北,邢台市,任县', null, null, '130526', 'r', 'renxian', 'rx');
INSERT INTO `yc_city` VALUES ('112', '南和县', '103', '1', '河北,邢台市,南和县', null, null, '130527', 'n', 'nanhexian', 'nhx');
INSERT INTO `yc_city` VALUES ('113', '宁晋县', '103', '1', '河北,邢台市,宁晋县', null, null, '130528', 'n', 'ningjinxian', 'njx');
INSERT INTO `yc_city` VALUES ('114', '巨鹿县', '103', '1', '河北,邢台市,巨鹿县', null, null, '130529', 'j', 'juluxian', 'jlx');
INSERT INTO `yc_city` VALUES ('115', '新河县', '103', '1', '河北,邢台市,新河县', null, null, '130530', 'x', 'xinhexian', 'xhx');
INSERT INTO `yc_city` VALUES ('116', '广宗县', '103', '1', '河北,邢台市,广宗县', null, null, '130531', 'g', 'guangzongxian', 'gzx');
INSERT INTO `yc_city` VALUES ('117', '平乡县', '103', '1', '河北,邢台市,平乡县', null, null, '130532', 'p', 'pingxiangxian', 'pxx');
INSERT INTO `yc_city` VALUES ('118', '威县', '103', '1', '河北,邢台市,威县', null, null, '130533', 'w', 'weixian', 'wx');
INSERT INTO `yc_city` VALUES ('119', '清河县', '103', '1', '河北,邢台市,清河县', null, null, '130534', 'q', 'qinghexian', 'qhx');
INSERT INTO `yc_city` VALUES ('120', '临西县', '103', '1', '河北,邢台市,临西县', null, null, '130535', 'l', 'linxixian', 'lxx');
INSERT INTO `yc_city` VALUES ('121', '南宫市', '103', '1', '河北,邢台市,南宫市', null, null, '130581', 'n', 'nangongshi', 'ngs');
INSERT INTO `yc_city` VALUES ('122', '沙河市', '103', '1', '河北,邢台市,沙河市', null, null, '130582', 's', 'shaheshi', 'shs');
INSERT INTO `yc_city` VALUES ('123', '保定市', '36', '1', '河北,保定市', null, null, '130600', 'b', 'baodingshi', 'bds');
INSERT INTO `yc_city` VALUES ('124', '新市区', '123', '1', '河北,保定市,新市区', null, null, '130602', 'x', 'xinshiqu', 'xsq');
INSERT INTO `yc_city` VALUES ('125', '北市区', '123', '1', '河北,保定市,北市区', null, null, '130603', 'b', 'beishiqu', 'bsq');
INSERT INTO `yc_city` VALUES ('126', '南市区', '123', '1', '河北,保定市,南市区', null, null, '130604', 'n', 'nanshiqu', 'nsq');
INSERT INTO `yc_city` VALUES ('127', '满城县', '123', '1', '河北,保定市,满城县', null, null, '130621', 'm', 'manchengxian', 'mcx');
INSERT INTO `yc_city` VALUES ('128', '清苑县', '123', '1', '河北,保定市,清苑县', null, null, '130622', 'q', 'qingyuanxian', 'qyx');
INSERT INTO `yc_city` VALUES ('129', '涞水县', '123', '1', '河北,保定市,涞水县', null, null, '130623', 'l', 'laishuixian', 'sx');
INSERT INTO `yc_city` VALUES ('130', '阜平县', '123', '1', '河北,保定市,阜平县', null, null, '130624', 'f', 'fupingxian', 'fpx');
INSERT INTO `yc_city` VALUES ('131', '徐水县', '123', '1', '河北,保定市,徐水县', null, null, '130625', 'x', 'xushuixian', 'xsx');
INSERT INTO `yc_city` VALUES ('132', '定兴县', '123', '1', '河北,保定市,定兴县', null, null, '130626', 'd', 'dingxingxian', 'dxx');
INSERT INTO `yc_city` VALUES ('133', '唐县', '123', '1', '河北,保定市,唐县', null, null, '130627', 't', 'tangxian', 'tx');
INSERT INTO `yc_city` VALUES ('134', '高阳县', '123', '1', '河北,保定市,高阳县', null, null, '130628', 'g', 'gaoyangxian', 'gyx');
INSERT INTO `yc_city` VALUES ('135', '容城县', '123', '1', '河北,保定市,容城县', null, null, '130629', 'r', 'rongchengxian', 'rcx');
INSERT INTO `yc_city` VALUES ('136', '涞源县', '123', '1', '河北,保定市,涞源县', null, null, '130630', 'l', 'laiyuanxian', 'yx');
INSERT INTO `yc_city` VALUES ('137', '望都县', '123', '1', '河北,保定市,望都县', null, null, '130631', 'w', 'wangduxian', 'wdx');
INSERT INTO `yc_city` VALUES ('138', '安新县', '123', '1', '河北,保定市,安新县', null, null, '130632', 'a', 'anxinxian', 'axx');
INSERT INTO `yc_city` VALUES ('139', '易县', '123', '1', '河北,保定市,易县', null, null, '130633', 'y', 'yixian', 'yx');
INSERT INTO `yc_city` VALUES ('140', '曲阳县', '123', '1', '河北,保定市,曲阳县', null, null, '130634', 'q', 'quyangxian', 'qyx');
INSERT INTO `yc_city` VALUES ('141', '蠡县', '123', '1', '河北,保定市,蠡县', null, null, '130635', 'l', 'lixian', 'x');
INSERT INTO `yc_city` VALUES ('142', '顺平县', '123', '1', '河北,保定市,顺平县', null, null, '130636', 's', 'shunpingxian', 'spx');
INSERT INTO `yc_city` VALUES ('143', '博野县', '123', '1', '河北,保定市,博野县', null, null, '130637', 'b', 'boyexian', 'byx');
INSERT INTO `yc_city` VALUES ('144', '雄县', '123', '1', '河北,保定市,雄县', null, null, '130638', 'x', 'xiongxian', 'xx');
INSERT INTO `yc_city` VALUES ('145', '涿州市', '123', '1', '河北,保定市,涿州市', null, null, '130681', 'z', 'zhuozhoushi', 'zs');
INSERT INTO `yc_city` VALUES ('146', '定州市', '123', '1', '河北,保定市,定州市', null, null, '130682', 'd', 'dingzhoushi', 'dzs');
INSERT INTO `yc_city` VALUES ('147', '安国市', '123', '1', '河北,保定市,安国市', null, null, '130683', 'a', 'anguoshi', 'ags');
INSERT INTO `yc_city` VALUES ('148', '高碑店市', '123', '1', '河北,保定市,高碑店市', null, null, '130684', 'g', 'gaobeidianshi', 'gbds');
INSERT INTO `yc_city` VALUES ('149', '张家口市', '36', '1', '河北,张家口市', null, null, '130700', 'z', 'zhangjiakoushi', 'zjks');
INSERT INTO `yc_city` VALUES ('150', '桥东区', '149', '1', '河北,张家口市,桥东区', null, null, '130702', 'q', 'qiaodongqu', 'qdq');
INSERT INTO `yc_city` VALUES ('151', '桥西区', '149', '1', '河北,张家口市,桥西区', null, null, '130703', 'q', 'qiaoxiqu', 'qxq');
INSERT INTO `yc_city` VALUES ('152', '宣化区', '149', '1', '河北,张家口市,宣化区', null, null, '130705', 'x', 'xuanhuaqu', 'xhq');
INSERT INTO `yc_city` VALUES ('153', '下花园区', '149', '1', '河北,张家口市,下花园区', null, null, '130706', 'x', 'xiahuayuanqu', 'xhyq');
INSERT INTO `yc_city` VALUES ('154', '宣化县', '149', '1', '河北,张家口市,宣化县', null, null, '130721', 'x', 'xuanhuaxian', 'xhx');
INSERT INTO `yc_city` VALUES ('155', '张北县', '149', '1', '河北,张家口市,张北县', null, null, '130722', 'z', 'zhangbeixian', 'zbx');
INSERT INTO `yc_city` VALUES ('156', '康保县', '149', '1', '河北,张家口市,康保县', null, null, '130723', 'k', 'kangbaoxian', 'kbx');
INSERT INTO `yc_city` VALUES ('157', '沽源县', '149', '1', '河北,张家口市,沽源县', null, null, '130724', 'g', 'guyuanxian', 'gyx');
INSERT INTO `yc_city` VALUES ('158', '尚义县', '149', '1', '河北,张家口市,尚义县', null, null, '130725', 's', 'shangyixian', 'syx');
INSERT INTO `yc_city` VALUES ('159', '蔚县', '149', '1', '河北,张家口市,蔚县', null, null, '130726', 'y', 'yuxian', 'wx');
INSERT INTO `yc_city` VALUES ('160', '阳原县', '149', '1', '河北,张家口市,阳原县', null, null, '130727', 'y', 'yangyuanxian', 'yyx');
INSERT INTO `yc_city` VALUES ('161', '怀安县', '149', '1', '河北,张家口市,怀安县', null, null, '130728', 'h', 'huaianxian', 'hax');
INSERT INTO `yc_city` VALUES ('162', '万全县', '149', '1', '河北,张家口市,万全县', null, null, '130729', 'w', 'wanquanxian', 'wqx');
INSERT INTO `yc_city` VALUES ('163', '怀来县', '149', '1', '河北,张家口市,怀来县', null, null, '130730', 'h', 'huailaixian', 'hlx');
INSERT INTO `yc_city` VALUES ('164', '涿鹿县', '149', '1', '河北,张家口市,涿鹿县', null, null, '130731', 'z', 'zhuoluxian', 'lx');
INSERT INTO `yc_city` VALUES ('165', '赤城县', '149', '1', '河北,张家口市,赤城县', null, null, '130732', 'c', 'chichengxian', 'ccx');
INSERT INTO `yc_city` VALUES ('166', '崇礼县', '149', '1', '河北,张家口市,崇礼县', null, null, '130733', 'c', 'chonglixian', 'clx');
INSERT INTO `yc_city` VALUES ('167', '承德市', '36', '1', '河北,承德市', null, null, '130800', 'c', 'chengdeshi', 'cds');
INSERT INTO `yc_city` VALUES ('168', '双桥区', '167', '1', '河北,承德市,双桥区', null, null, '130802', 's', 'shuangqiaoqu', 'sqq');
INSERT INTO `yc_city` VALUES ('169', '双滦区', '167', '1', '河北,承德市,双滦区', null, null, '130803', 's', 'shuangluanqu', 'slq');
INSERT INTO `yc_city` VALUES ('170', '鹰手营子矿区', '167', '1', '河北,承德市,鹰手营子矿区', null, null, '130804', 'y', 'yingshouyingzikuangqu', 'ysyzkq');
INSERT INTO `yc_city` VALUES ('171', '承德县', '167', '1', '河北,承德市,承德县', null, null, '130821', 'c', 'chengdexian', 'cdx');
INSERT INTO `yc_city` VALUES ('172', '兴隆县', '167', '1', '河北,承德市,兴隆县', null, null, '130822', 'x', 'xinglongxian', 'xlx');
INSERT INTO `yc_city` VALUES ('173', '平泉县', '167', '1', '河北,承德市,平泉县', null, null, '130823', 'p', 'pingquanxian', 'pqx');
INSERT INTO `yc_city` VALUES ('174', '滦平县', '167', '1', '河北,承德市,滦平县', null, null, '130824', 'l', 'luanpingxian', 'lpx');
INSERT INTO `yc_city` VALUES ('175', '隆化县', '167', '1', '河北,承德市,隆化县', null, null, '130825', 'l', 'longhuaxian', 'lhx');
INSERT INTO `yc_city` VALUES ('176', '丰宁满族自治县', '167', '1', '河北,承德市,丰宁满族自治县', null, null, '130826', 'f', 'fengningmanzuzizhixian', 'fnmzzzx');
INSERT INTO `yc_city` VALUES ('177', '宽城满族自治县', '167', '1', '河北,承德市,宽城满族自治县', null, null, '130827', 'k', 'kuanchengmanzuzizhixian', 'kcmzzzx');
INSERT INTO `yc_city` VALUES ('178', '围场满族蒙古族自治县', '167', '1', '河北,承德市,围场满族蒙古族自治县', null, null, '130828', 'w', 'weichangmanzumengguzuzizhixian', 'wcmzmgzzzx');
INSERT INTO `yc_city` VALUES ('179', '沧州市', '36', '1', '河北,沧州市', null, null, '130900', 'c', 'cangzhoushi', 'czs');
INSERT INTO `yc_city` VALUES ('180', '新华区', '179', '1', '河北,沧州市,新华区', null, null, '130902', 'x', 'xinhuaqu', 'xhq');
INSERT INTO `yc_city` VALUES ('181', '运河区', '179', '1', '河北,沧州市,运河区', null, null, '130903', 'y', 'yunhequ', 'yhq');
INSERT INTO `yc_city` VALUES ('182', '沧县', '179', '1', '河北,沧州市,沧县', null, null, '130921', 'c', 'cangxian', 'cx');
INSERT INTO `yc_city` VALUES ('183', '青县', '179', '1', '河北,沧州市,青县', null, null, '130922', 'q', 'qingxian', 'qx');
INSERT INTO `yc_city` VALUES ('184', '东光县', '179', '1', '河北,沧州市,东光县', null, null, '130923', 'd', 'dongguangxian', 'dgx');
INSERT INTO `yc_city` VALUES ('185', '海兴县', '179', '1', '河北,沧州市,海兴县', null, null, '130924', 'h', 'haixingxian', 'hxx');
INSERT INTO `yc_city` VALUES ('186', '盐山县', '179', '1', '河北,沧州市,盐山县', null, null, '130925', 'y', 'yanshanxian', 'ysx');
INSERT INTO `yc_city` VALUES ('187', '肃宁县', '179', '1', '河北,沧州市,肃宁县', null, null, '130926', 's', 'suningxian', 'snx');
INSERT INTO `yc_city` VALUES ('188', '南皮县', '179', '1', '河北,沧州市,南皮县', null, null, '130927', 'n', 'nanpixian', 'npx');
INSERT INTO `yc_city` VALUES ('189', '吴桥县', '179', '1', '河北,沧州市,吴桥县', null, null, '130928', 'w', 'wuqiaoxian', 'wqx');
INSERT INTO `yc_city` VALUES ('190', '献县', '179', '1', '河北,沧州市,献县', null, null, '130929', 'x', 'xianxian', 'xx');
INSERT INTO `yc_city` VALUES ('191', '孟村回族自治县', '179', '1', '河北,沧州市,孟村回族自治县', null, null, '130930', 'm', 'mengcunhuizuzizhixian', 'mchzzzx');
INSERT INTO `yc_city` VALUES ('192', '泊头市', '179', '1', '河北,沧州市,泊头市', null, null, '130981', 'b', 'botoushi', 'bts');
INSERT INTO `yc_city` VALUES ('193', '任丘市', '179', '1', '河北,沧州市,任丘市', null, null, '130982', 'r', 'renqiushi', 'rqs');
INSERT INTO `yc_city` VALUES ('194', '黄骅市', '179', '1', '河北,沧州市,黄骅市', null, null, '130983', 'h', 'huanghuashi', 'hs');
INSERT INTO `yc_city` VALUES ('195', '河间市', '179', '1', '河北,沧州市,河间市', null, null, '130984', 'h', 'hejianshi', 'hjs');
INSERT INTO `yc_city` VALUES ('196', '廊坊市', '36', '1', '河北,廊坊市', null, null, '131000', 'l', 'langfangshi', 'lfs');
INSERT INTO `yc_city` VALUES ('197', '安次区', '196', '1', '河北,廊坊市,安次区', null, null, '131002', 'a', 'anciqu', 'acq');
INSERT INTO `yc_city` VALUES ('198', '广阳区', '196', '1', '河北,廊坊市,广阳区', null, null, '131003', 'g', 'guangyangqu', 'gyq');
INSERT INTO `yc_city` VALUES ('199', '固安县', '196', '1', '河北,廊坊市,固安县', null, null, '131022', 'g', 'guanxian', 'gax');
INSERT INTO `yc_city` VALUES ('200', '永清县', '196', '1', '河北,廊坊市,永清县', null, null, '131023', 'y', 'yongqingxian', 'yqx');
INSERT INTO `yc_city` VALUES ('201', '香河县', '196', '1', '河北,廊坊市,香河县', null, null, '131024', 'x', 'xianghexian', 'xhx');
INSERT INTO `yc_city` VALUES ('202', '大城县', '196', '1', '河北,廊坊市,大城县', null, null, '131025', 'd', 'daichengxian', 'dcx');
INSERT INTO `yc_city` VALUES ('203', '文安县', '196', '1', '河北,廊坊市,文安县', null, null, '131026', 'w', 'wenanxian', 'wax');
INSERT INTO `yc_city` VALUES ('204', '大厂回族自治县', '196', '1', '河北,廊坊市,大厂回族自治县', null, null, '131028', 'd', 'dachanghuizuzizhixian', 'dchzzzx');
INSERT INTO `yc_city` VALUES ('205', '霸州市', '196', '1', '河北,廊坊市,霸州市', null, null, '131081', 'b', 'bazhoushi', 'bzs');
INSERT INTO `yc_city` VALUES ('206', '三河市', '196', '1', '河北,廊坊市,三河市', null, null, '131082', 's', 'sanheshi', 'shs');
INSERT INTO `yc_city` VALUES ('207', '衡水市', '36', '1', '河北,衡水市', null, null, '131100', 'h', 'hengshuishi', 'hss');
INSERT INTO `yc_city` VALUES ('208', '桃城区', '207', '1', '河北,衡水市,桃城区', null, null, '131102', 't', 'taochengqu', 'tcq');
INSERT INTO `yc_city` VALUES ('209', '枣强县', '207', '1', '河北,衡水市,枣强县', null, null, '131121', 'z', 'zaoqiangxian', 'zqx');
INSERT INTO `yc_city` VALUES ('210', '武邑县', '207', '1', '河北,衡水市,武邑县', null, null, '131122', 'w', 'wuyixian', 'wyx');
INSERT INTO `yc_city` VALUES ('211', '武强县', '207', '1', '河北,衡水市,武强县', null, null, '131123', 'w', 'wuqiangxian', 'wqx');
INSERT INTO `yc_city` VALUES ('212', '饶阳县', '207', '1', '河北,衡水市,饶阳县', null, null, '131124', 'r', 'raoyangxian', 'ryx');
INSERT INTO `yc_city` VALUES ('213', '安平县', '207', '1', '河北,衡水市,安平县', null, null, '131125', 'a', 'anpingxian', 'apx');
INSERT INTO `yc_city` VALUES ('214', '故城县', '207', '1', '河北,衡水市,故城县', null, null, '131126', 'g', 'guchengxian', 'gcx');
INSERT INTO `yc_city` VALUES ('215', '景县', '207', '1', '河北,衡水市,景县', null, null, '131127', 'j', 'jingxian', 'jx');
INSERT INTO `yc_city` VALUES ('216', '阜城县', '207', '1', '河北,衡水市,阜城县', null, null, '131128', 'f', 'fuchengxian', 'fcx');
INSERT INTO `yc_city` VALUES ('217', '冀州市', '207', '1', '河北,衡水市,冀州市', null, null, '131181', 'j', 'jizhoushi', 'jzs');
INSERT INTO `yc_city` VALUES ('218', '深州市', '207', '1', '河北,衡水市,深州市', null, null, '131182', 's', 'shenzhoushi', 'szs');
INSERT INTO `yc_city` VALUES ('219', '山西', '1', '1', '山西', null, null, '140000', 's', 'shanxi', 'sx');
INSERT INTO `yc_city` VALUES ('220', '太原市', '219', '1', '山西,太原市', null, null, '140100', 't', 'taiyuanshi', 'tys');
INSERT INTO `yc_city` VALUES ('221', '小店区', '220', '1', '山西,太原市,小店区', null, null, '140105', 'x', 'xiaodianqu', 'xdq');
INSERT INTO `yc_city` VALUES ('222', '迎泽区', '220', '1', '山西,太原市,迎泽区', null, null, '140106', 'y', 'yingzequ', 'yzq');
INSERT INTO `yc_city` VALUES ('223', '杏花岭区', '220', '1', '山西,太原市,杏花岭区', null, null, '140107', 'x', 'xinghualingqu', 'xhlq');
INSERT INTO `yc_city` VALUES ('224', '尖草坪区', '220', '1', '山西,太原市,尖草坪区', null, null, '140108', 'j', 'jiancaopingqu', 'jcpq');
INSERT INTO `yc_city` VALUES ('225', '万柏林区', '220', '1', '山西,太原市,万柏林区', null, null, '140109', 'w', 'wanbolinqu', 'wblq');
INSERT INTO `yc_city` VALUES ('226', '晋源区', '220', '1', '山西,太原市,晋源区', null, null, '140110', 'j', 'jinyuanqu', 'jyq');
INSERT INTO `yc_city` VALUES ('227', '清徐县', '220', '1', '山西,太原市,清徐县', null, null, '140121', 'q', 'qingxuxian', 'qxx');
INSERT INTO `yc_city` VALUES ('228', '阳曲县', '220', '1', '山西,太原市,阳曲县', null, null, '140122', 'y', 'yangquxian', 'yqx');
INSERT INTO `yc_city` VALUES ('229', '娄烦县', '220', '1', '山西,太原市,娄烦县', null, null, '140123', 'l', 'loufanxian', 'lfx');
INSERT INTO `yc_city` VALUES ('230', '古交市', '220', '1', '山西,太原市,古交市', null, null, '140181', 'g', 'gujiaoshi', 'gjs');
INSERT INTO `yc_city` VALUES ('231', '大同市', '219', '1', '山西,大同市', null, null, '140200', 'd', 'datongshi', 'dts');
INSERT INTO `yc_city` VALUES ('232', '城区', '231', '1', '山西,大同市,城区', null, null, '140202', 'c', 'chengqu', 'cq');
INSERT INTO `yc_city` VALUES ('233', '矿区', '231', '1', '山西,大同市,矿区', null, null, '140203', 'k', 'kuangqu', 'kq');
INSERT INTO `yc_city` VALUES ('234', '南郊区', '231', '1', '山西,大同市,南郊区', null, null, '140211', 'n', 'nanjiaoqu', 'njq');
INSERT INTO `yc_city` VALUES ('235', '新荣区', '231', '1', '山西,大同市,新荣区', null, null, '140212', 'x', 'xinrongqu', 'xrq');
INSERT INTO `yc_city` VALUES ('236', '阳高县', '231', '1', '山西,大同市,阳高县', null, null, '140221', 'y', 'yanggaoxian', 'ygx');
INSERT INTO `yc_city` VALUES ('237', '天镇县', '231', '1', '山西,大同市,天镇县', null, null, '140222', 't', 'tianzhenxian', 'tzx');
INSERT INTO `yc_city` VALUES ('238', '广灵县', '231', '1', '山西,大同市,广灵县', null, null, '140223', 'g', 'guanglingxian', 'glx');
INSERT INTO `yc_city` VALUES ('239', '灵丘县', '231', '1', '山西,大同市,灵丘县', null, null, '140224', 'l', 'lingqiuxian', 'lqx');
INSERT INTO `yc_city` VALUES ('240', '浑源县', '231', '1', '山西,大同市,浑源县', null, null, '140225', 'h', 'hunyuanxian', 'hyx');
INSERT INTO `yc_city` VALUES ('241', '左云县', '231', '1', '山西,大同市,左云县', null, null, '140226', 'z', 'zuoyunxian', 'zyx');
INSERT INTO `yc_city` VALUES ('242', '大同县', '231', '1', '山西,大同市,大同县', null, null, '140227', 'd', 'datongxian', 'dtx');
INSERT INTO `yc_city` VALUES ('243', '阳泉市', '219', '1', '山西,阳泉市', null, null, '140300', 'y', 'yangquanshi', 'yqs');
INSERT INTO `yc_city` VALUES ('244', '城区', '243', '1', '山西,阳泉市,城区', null, null, '140302', 'c', 'chengqu', 'cq');
INSERT INTO `yc_city` VALUES ('245', '矿区', '243', '1', '山西,阳泉市,矿区', null, null, '140303', 'k', 'kuangqu', 'kq');
INSERT INTO `yc_city` VALUES ('246', '郊区', '243', '1', '山西,阳泉市,郊区', null, null, '140311', 'j', 'jiaoqu', 'jq');
INSERT INTO `yc_city` VALUES ('247', '平定县', '243', '1', '山西,阳泉市,平定县', null, null, '140321', 'p', 'pingdingxian', 'pdx');
INSERT INTO `yc_city` VALUES ('248', '盂县', '243', '1', '山西,阳泉市,盂县', null, null, '140322', 'y', 'yuxian', 'yx');
INSERT INTO `yc_city` VALUES ('249', '长治市', '219', '1', '山西,长治市', null, null, '140400', 'c', 'changzhishi', 'czs');
INSERT INTO `yc_city` VALUES ('250', '城区', '249', '1', '山西,长治市,城区', null, null, '140402', 'c', 'chengqu', 'cq');
INSERT INTO `yc_city` VALUES ('251', '郊区', '249', '1', '山西,长治市,郊区', null, null, '140411', 'j', 'jiaoqu', 'jq');
INSERT INTO `yc_city` VALUES ('252', '长治县', '249', '1', '山西,长治市,长治县', null, null, '140421', 'c', 'changzhixian', 'czx');
INSERT INTO `yc_city` VALUES ('253', '襄垣县', '249', '1', '山西,长治市,襄垣县', null, null, '140423', 'x', 'xiangyuanxian', 'xyx');
INSERT INTO `yc_city` VALUES ('254', '屯留县', '249', '1', '山西,长治市,屯留县', null, null, '140424', 't', 'tunliuxian', 'tlx');
INSERT INTO `yc_city` VALUES ('255', '平顺县', '249', '1', '山西,长治市,平顺县', null, null, '140425', 'p', 'pingshunxian', 'psx');
INSERT INTO `yc_city` VALUES ('256', '黎城县', '249', '1', '山西,长治市,黎城县', null, null, '140426', 'l', 'lichengxian', 'lcx');
INSERT INTO `yc_city` VALUES ('257', '壶关县', '249', '1', '山西,长治市,壶关县', null, null, '140427', 'h', 'huguanxian', 'hgx');
INSERT INTO `yc_city` VALUES ('258', '长子县', '249', '1', '山西,长治市,长子县', null, null, '140428', 'c', 'changzixian', 'czx');
INSERT INTO `yc_city` VALUES ('259', '武乡县', '249', '1', '山西,长治市,武乡县', null, null, '140429', 'w', 'wuxiangxian', 'wxx');
INSERT INTO `yc_city` VALUES ('260', '沁县', '249', '1', '山西,长治市,沁县', null, null, '140430', 'q', 'qinxian', 'qx');
INSERT INTO `yc_city` VALUES ('261', '沁源县', '249', '1', '山西,长治市,沁源县', null, null, '140431', 'q', 'qinyuanxian', 'qyx');
INSERT INTO `yc_city` VALUES ('262', '潞城市', '249', '1', '山西,长治市,潞城市', null, null, '140481', 'l', 'luchengshi', 'lcs');
INSERT INTO `yc_city` VALUES ('263', '晋城市', '219', '1', '山西,晋城市', null, null, '140500', 'j', 'jinchengshi', 'jcs');
INSERT INTO `yc_city` VALUES ('264', '城区', '263', '1', '山西,晋城市,城区', null, null, '140502', 'c', 'chengqu', 'cq');
INSERT INTO `yc_city` VALUES ('265', '沁水县', '263', '1', '山西,晋城市,沁水县', null, null, '140521', 'q', 'qinshuixian', 'qsx');
INSERT INTO `yc_city` VALUES ('266', '阳城县', '263', '1', '山西,晋城市,阳城县', null, null, '140522', 'y', 'yangchengxian', 'ycx');
INSERT INTO `yc_city` VALUES ('267', '陵川县', '263', '1', '山西,晋城市,陵川县', null, null, '140524', 'l', 'lingchuanxian', 'lcx');
INSERT INTO `yc_city` VALUES ('268', '泽州县', '263', '1', '山西,晋城市,泽州县', null, null, '140525', 'z', 'zezhouxian', 'zzx');
INSERT INTO `yc_city` VALUES ('269', '高平市', '263', '1', '山西,晋城市,高平市', null, null, '140581', 'g', 'gaopingshi', 'gps');
INSERT INTO `yc_city` VALUES ('270', '朔州市', '219', '1', '山西,朔州市', null, null, '140600', 's', 'shuozhoushi', 'szs');
INSERT INTO `yc_city` VALUES ('271', '朔城区', '270', '1', '山西,朔州市,朔城区', null, null, '140602', 's', 'shuochengqu', 'scq');
INSERT INTO `yc_city` VALUES ('272', '平鲁区', '270', '1', '山西,朔州市,平鲁区', null, null, '140603', 'p', 'pingluqu', 'plq');
INSERT INTO `yc_city` VALUES ('273', '山阴县', '270', '1', '山西,朔州市,山阴县', null, null, '140621', 's', 'shanyinxian', 'syx');
INSERT INTO `yc_city` VALUES ('274', '应县', '270', '1', '山西,朔州市,应县', null, null, '140622', 'y', 'yingxian', 'yx');
INSERT INTO `yc_city` VALUES ('275', '右玉县', '270', '1', '山西,朔州市,右玉县', null, null, '140623', 'y', 'youyuxian', 'yyx');
INSERT INTO `yc_city` VALUES ('276', '怀仁县', '270', '1', '山西,朔州市,怀仁县', null, null, '140624', 'h', 'huairenxian', 'hrx');
INSERT INTO `yc_city` VALUES ('277', '晋中市', '219', '1', '山西,晋中市', null, null, '140700', 'j', 'jinzhongshi', 'jzs');
INSERT INTO `yc_city` VALUES ('278', '榆次区', '277', '1', '山西,晋中市,榆次区', null, null, '140702', 'y', 'yuciqu', 'ycq');
INSERT INTO `yc_city` VALUES ('279', '榆社县', '277', '1', '山西,晋中市,榆社县', null, null, '140721', 'y', 'yushexian', 'ysx');
INSERT INTO `yc_city` VALUES ('280', '左权县', '277', '1', '山西,晋中市,左权县', null, null, '140722', 'z', 'zuoquanxian', 'zqx');
INSERT INTO `yc_city` VALUES ('281', '和顺县', '277', '1', '山西,晋中市,和顺县', null, null, '140723', 'h', 'heshunxian', 'hsx');
INSERT INTO `yc_city` VALUES ('282', '昔阳县', '277', '1', '山西,晋中市,昔阳县', null, null, '140724', 'x', 'xiyangxian', 'xyx');
INSERT INTO `yc_city` VALUES ('283', '寿阳县', '277', '1', '山西,晋中市,寿阳县', null, null, '140725', 's', 'shouyangxian', 'syx');
INSERT INTO `yc_city` VALUES ('284', '太谷县', '277', '1', '山西,晋中市,太谷县', null, null, '140726', 't', 'taiguxian', 'tgx');
INSERT INTO `yc_city` VALUES ('285', '祁县', '277', '1', '山西,晋中市,祁县', null, null, '140727', 'q', 'qixian', 'qx');
INSERT INTO `yc_city` VALUES ('286', '平遥县', '277', '1', '山西,晋中市,平遥县', null, null, '140728', 'p', 'pingyaoxian', 'pyx');
INSERT INTO `yc_city` VALUES ('287', '灵石县', '277', '1', '山西,晋中市,灵石县', null, null, '140729', 'l', 'lingshixian', 'lsx');
INSERT INTO `yc_city` VALUES ('288', '介休市', '277', '1', '山西,晋中市,介休市', null, null, '140781', 'j', 'jiexiushi', 'jxs');
INSERT INTO `yc_city` VALUES ('289', '运城市', '219', '1', '山西,运城市', null, null, '140800', 'y', 'yunchengshi', 'ycs');
INSERT INTO `yc_city` VALUES ('290', '盐湖区', '289', '1', '山西,运城市,盐湖区', null, null, '140802', 'y', 'yanhuqu', 'yhq');
INSERT INTO `yc_city` VALUES ('291', '临猗县', '289', '1', '山西,运城市,临猗县', null, null, '140821', 'l', 'linyixian', 'lx');
INSERT INTO `yc_city` VALUES ('292', '万荣县', '289', '1', '山西,运城市,万荣县', null, null, '140822', 'w', 'wanrongxian', 'wrx');
INSERT INTO `yc_city` VALUES ('293', '闻喜县', '289', '1', '山西,运城市,闻喜县', null, null, '140823', 'w', 'wenxixian', 'wxx');
INSERT INTO `yc_city` VALUES ('294', '稷山县', '289', '1', '山西,运城市,稷山县', null, null, '140824', 'j', 'jishanxian', 'sx');
INSERT INTO `yc_city` VALUES ('295', '新绛县', '289', '1', '山西,运城市,新绛县', null, null, '140825', 'x', 'xinjiangxian', 'xx');
INSERT INTO `yc_city` VALUES ('296', '绛县', '289', '1', '山西,运城市,绛县', null, null, '140826', 'j', 'jiangxian', 'x');
INSERT INTO `yc_city` VALUES ('297', '垣曲县', '289', '1', '山西,运城市,垣曲县', null, null, '140827', 'y', 'yuanquxian', 'yqx');
INSERT INTO `yc_city` VALUES ('298', '夏县', '289', '1', '山西,运城市,夏县', null, null, '140828', 'x', 'xiaxian', 'xx');
INSERT INTO `yc_city` VALUES ('299', '平陆县', '289', '1', '山西,运城市,平陆县', null, null, '140829', 'p', 'pingluxian', 'plx');
INSERT INTO `yc_city` VALUES ('300', '芮城县', '289', '1', '山西,运城市,芮城县', null, null, '140830', 'r', 'ruichengxian', 'cx');
INSERT INTO `yc_city` VALUES ('301', '永济市', '289', '1', '山西,运城市,永济市', null, null, '140881', 'y', 'yongjishi', 'yjs');
INSERT INTO `yc_city` VALUES ('302', '河津市', '289', '1', '山西,运城市,河津市', null, null, '140882', 'h', 'hejinshi', 'hjs');
INSERT INTO `yc_city` VALUES ('303', '忻州市', '219', '1', '山西,忻州市', null, null, '140900', 'x', 'xinzhoushi', 'xzs');
INSERT INTO `yc_city` VALUES ('304', '忻府区', '303', '1', '山西,忻州市,忻府区', null, null, '140902', 'x', 'xinfuqu', 'xfq');
INSERT INTO `yc_city` VALUES ('305', '定襄县', '303', '1', '山西,忻州市,定襄县', null, null, '140921', 'd', 'dingxiangxian', 'dxx');
INSERT INTO `yc_city` VALUES ('306', '五台县', '303', '1', '山西,忻州市,五台县', null, null, '140922', 'w', 'wutaixian', 'wtx');
INSERT INTO `yc_city` VALUES ('307', '代县', '303', '1', '山西,忻州市,代县', null, null, '140923', 'd', 'daixian', 'dx');
INSERT INTO `yc_city` VALUES ('308', '繁峙县', '303', '1', '山西,忻州市,繁峙县', null, null, '140924', 'f', 'fanshixian', 'fzx');
INSERT INTO `yc_city` VALUES ('309', '宁武县', '303', '1', '山西,忻州市,宁武县', null, null, '140925', 'n', 'ningwuxian', 'nwx');
INSERT INTO `yc_city` VALUES ('310', '静乐县', '303', '1', '山西,忻州市,静乐县', null, null, '140926', 'j', 'jinglexian', 'jlx');
INSERT INTO `yc_city` VALUES ('311', '神池县', '303', '1', '山西,忻州市,神池县', null, null, '140927', 's', 'shenchixian', 'scx');
INSERT INTO `yc_city` VALUES ('312', '五寨县', '303', '1', '山西,忻州市,五寨县', null, null, '140928', 'w', 'wuzhaixian', 'wzx');
INSERT INTO `yc_city` VALUES ('313', '岢岚县', '303', '1', '山西,忻州市,岢岚县', null, null, '140929', 'k', 'kelanxian', 'x');
INSERT INTO `yc_city` VALUES ('314', '河曲县', '303', '1', '山西,忻州市,河曲县', null, null, '140930', 'h', 'hequxian', 'hqx');
INSERT INTO `yc_city` VALUES ('315', '保德县', '303', '1', '山西,忻州市,保德县', null, null, '140931', 'b', 'baodexian', 'bdx');
INSERT INTO `yc_city` VALUES ('316', '偏关县', '303', '1', '山西,忻州市,偏关县', null, null, '140932', 'p', 'pianguanxian', 'pgx');
INSERT INTO `yc_city` VALUES ('317', '原平市', '303', '1', '山西,忻州市,原平市', null, null, '140981', 'y', 'yuanpingshi', 'yps');
INSERT INTO `yc_city` VALUES ('318', '临汾市', '219', '1', '山西,临汾市', null, null, '141000', 'l', 'linfenshi', 'lfs');
INSERT INTO `yc_city` VALUES ('319', '尧都区', '318', '1', '山西,临汾市,尧都区', null, null, '141002', 'y', 'yaoduqu', 'ydq');
INSERT INTO `yc_city` VALUES ('320', '曲沃县', '318', '1', '山西,临汾市,曲沃县', null, null, '141021', 'q', 'quwoxian', 'qwx');
INSERT INTO `yc_city` VALUES ('321', '翼城县', '318', '1', '山西,临汾市,翼城县', null, null, '141022', 'y', 'yichengxian', 'ycx');
INSERT INTO `yc_city` VALUES ('322', '襄汾县', '318', '1', '山西,临汾市,襄汾县', null, null, '141023', 'x', 'xiangfenxian', 'xfx');
INSERT INTO `yc_city` VALUES ('323', '洪洞县', '318', '1', '山西,临汾市,洪洞县', null, null, '141024', 'h', 'hongtongxian', 'hdx');
INSERT INTO `yc_city` VALUES ('324', '古县', '318', '1', '山西,临汾市,古县', null, null, '141025', 'g', 'guxian', 'gx');
INSERT INTO `yc_city` VALUES ('325', '安泽县', '318', '1', '山西,临汾市,安泽县', null, null, '141026', 'a', 'anzexian', 'azx');
INSERT INTO `yc_city` VALUES ('326', '浮山县', '318', '1', '山西,临汾市,浮山县', null, null, '141027', 'f', 'fushanxian', 'fsx');
INSERT INTO `yc_city` VALUES ('327', '吉县', '318', '1', '山西,临汾市,吉县', null, null, '141028', 'j', 'jixian', 'jx');
INSERT INTO `yc_city` VALUES ('328', '乡宁县', '318', '1', '山西,临汾市,乡宁县', null, null, '141029', 'x', 'xiangningxian', 'xnx');
INSERT INTO `yc_city` VALUES ('329', '大宁县', '318', '1', '山西,临汾市,大宁县', null, null, '141030', 'd', 'daningxian', 'dnx');
INSERT INTO `yc_city` VALUES ('330', '隰县', '318', '1', '山西,临汾市,隰县', null, null, '141031', 'x', 'xixian', 'x');
INSERT INTO `yc_city` VALUES ('331', '永和县', '318', '1', '山西,临汾市,永和县', null, null, '141032', 'y', 'yonghexian', 'yhx');
INSERT INTO `yc_city` VALUES ('332', '蒲县', '318', '1', '山西,临汾市,蒲县', null, null, '141033', 'p', 'puxian', 'px');
INSERT INTO `yc_city` VALUES ('333', '汾西县', '318', '1', '山西,临汾市,汾西县', null, null, '141034', 'f', 'fenxixian', 'fxx');
INSERT INTO `yc_city` VALUES ('334', '侯马市', '318', '1', '山西,临汾市,侯马市', null, null, '141081', 'h', 'houmashi', 'hms');
INSERT INTO `yc_city` VALUES ('335', '霍州市', '318', '1', '山西,临汾市,霍州市', null, null, '141082', 'h', 'huozhoushi', 'hzs');
INSERT INTO `yc_city` VALUES ('336', '吕梁市', '219', '1', '山西,吕梁市', null, null, '141100', 'l', 'lvliangshi', 'lls');
INSERT INTO `yc_city` VALUES ('337', '离石区', '336', '1', '山西,吕梁市,离石区', null, null, '141102', 'l', 'lishiqu', 'lsq');
INSERT INTO `yc_city` VALUES ('338', '文水县', '336', '1', '山西,吕梁市,文水县', null, null, '141121', 'w', 'wenshuixian', 'wsx');
INSERT INTO `yc_city` VALUES ('339', '交城县', '336', '1', '山西,吕梁市,交城县', null, null, '141122', 'j', 'jiaochengxian', 'jcx');
INSERT INTO `yc_city` VALUES ('340', '兴县', '336', '1', '山西,吕梁市,兴县', null, null, '141123', 'x', 'xingxian', 'xx');
INSERT INTO `yc_city` VALUES ('341', '临县', '336', '1', '山西,吕梁市,临县', null, null, '141124', 'l', 'linxian', 'lx');
INSERT INTO `yc_city` VALUES ('342', '柳林县', '336', '1', '山西,吕梁市,柳林县', null, null, '141125', 'l', 'liulinxian', 'llx');
INSERT INTO `yc_city` VALUES ('343', '石楼县', '336', '1', '山西,吕梁市,石楼县', null, null, '141126', 's', 'shilouxian', 'slx');
INSERT INTO `yc_city` VALUES ('344', '岚县', '336', '1', '山西,吕梁市,岚县', null, null, '141127', 'l', 'lanxian', 'x');
INSERT INTO `yc_city` VALUES ('345', '方山县', '336', '1', '山西,吕梁市,方山县', null, null, '141128', 'f', 'fangshanxian', 'fsx');
INSERT INTO `yc_city` VALUES ('346', '中阳县', '336', '1', '山西,吕梁市,中阳县', null, null, '141129', 'z', 'zhongyangxian', 'zyx');
INSERT INTO `yc_city` VALUES ('347', '交口县', '336', '1', '山西,吕梁市,交口县', null, null, '141130', 'j', 'jiaokouxian', 'jkx');
INSERT INTO `yc_city` VALUES ('348', '孝义市', '336', '1', '山西,吕梁市,孝义市', null, null, '141181', 'x', 'xiaoyishi', 'xys');
INSERT INTO `yc_city` VALUES ('349', '汾阳市', '336', '1', '山西,吕梁市,汾阳市', null, null, '141182', 'f', 'fenyangshi', 'fys');
INSERT INTO `yc_city` VALUES ('350', '内蒙古', '1', '1', '内蒙古', null, null, '150000', 'n', 'neimenggu', 'nmg');
INSERT INTO `yc_city` VALUES ('351', '呼和浩特市', '350', '1', '内蒙古,呼和浩特市', null, null, '150100', 'h', 'huhehaoteshi', 'hhhts');
INSERT INTO `yc_city` VALUES ('352', '新城区', '351', '1', '内蒙古,呼和浩特市,新城区', null, null, '150102', 'x', 'xinchengqu', 'xcq');
INSERT INTO `yc_city` VALUES ('353', '回民区', '351', '1', '内蒙古,呼和浩特市,回民区', null, null, '150103', 'h', 'huiminqu', 'hmq');
INSERT INTO `yc_city` VALUES ('354', '玉泉区', '351', '1', '内蒙古,呼和浩特市,玉泉区', null, null, '150104', 'y', 'yuquanqu', 'yqq');
INSERT INTO `yc_city` VALUES ('355', '赛罕区', '351', '1', '内蒙古,呼和浩特市,赛罕区', null, null, '150105', 's', 'saihanqu', 'shq');
INSERT INTO `yc_city` VALUES ('356', '土默特左旗', '351', '1', '内蒙古,呼和浩特市,土默特左旗', null, null, '150121', 't', 'tumotezuoqi', 'tmtzq');
INSERT INTO `yc_city` VALUES ('357', '托克托县', '351', '1', '内蒙古,呼和浩特市,托克托县', null, null, '150122', 't', 'tuoketuoxian', 'tktx');
INSERT INTO `yc_city` VALUES ('358', '和林格尔县', '351', '1', '内蒙古,呼和浩特市,和林格尔县', null, null, '150123', 'h', 'helingeerxian', 'hlgex');
INSERT INTO `yc_city` VALUES ('359', '清水河县', '351', '1', '内蒙古,呼和浩特市,清水河县', null, null, '150124', 'q', 'qingshuihexian', 'qshx');
INSERT INTO `yc_city` VALUES ('360', '武川县', '351', '1', '内蒙古,呼和浩特市,武川县', null, null, '150125', 'w', 'wuchuanxian', 'wcx');
INSERT INTO `yc_city` VALUES ('361', '包头市', '350', '1', '内蒙古,包头市', null, null, '150200', 'b', 'baotoushi', 'bts');
INSERT INTO `yc_city` VALUES ('362', '东河区', '361', '1', '内蒙古,包头市,东河区', null, null, '150202', 'd', 'donghequ', 'dhq');
INSERT INTO `yc_city` VALUES ('363', '昆都仑区', '361', '1', '内蒙古,包头市,昆都仑区', null, null, '150203', 'k', 'kundulunqu', 'kdlq');
INSERT INTO `yc_city` VALUES ('364', '青山区', '361', '1', '内蒙古,包头市,青山区', null, null, '150204', 'q', 'qingshanqu', 'qsq');
INSERT INTO `yc_city` VALUES ('365', '石拐区', '361', '1', '内蒙古,包头市,石拐区', null, null, '150205', 's', 'shiguaiqu', 'sgq');
INSERT INTO `yc_city` VALUES ('366', '白云鄂博矿区', '361', '1', '内蒙古,包头市,白云鄂博矿区', null, null, '150206', 'b', 'baiyunebokuangqu', 'byebkq');
INSERT INTO `yc_city` VALUES ('367', '九原区', '361', '1', '内蒙古,包头市,九原区', null, null, '150207', 'j', 'jiuyuanqu', 'jyq');
INSERT INTO `yc_city` VALUES ('368', '土默特右旗', '361', '1', '内蒙古,包头市,土默特右旗', null, null, '150221', 't', 'tumoteyouqi', 'tmtyq');
INSERT INTO `yc_city` VALUES ('369', '固阳县', '361', '1', '内蒙古,包头市,固阳县', null, null, '150222', 'g', 'guyangxian', 'gyx');
INSERT INTO `yc_city` VALUES ('370', '达尔罕茂明安联合旗', '361', '1', '内蒙古,包头市,达尔罕茂明安联合旗', null, null, '150223', 'd', 'daerhanmaominganlianheqi', 'dehmmalhq');
INSERT INTO `yc_city` VALUES ('371', '乌海市', '350', '1', '内蒙古,乌海市', null, null, '150300', 'w', 'wuhaishi', 'whs');
INSERT INTO `yc_city` VALUES ('372', '海勃湾区', '371', '1', '内蒙古,乌海市,海勃湾区', null, null, '150302', 'h', 'haibowanqu', 'hbwq');
INSERT INTO `yc_city` VALUES ('373', '海南区', '371', '1', '内蒙古,乌海市,海南区', null, null, '150303', 'h', 'hainanqu', 'hnq');
INSERT INTO `yc_city` VALUES ('374', '乌达区', '371', '1', '内蒙古,乌海市,乌达区', null, null, '150304', 'w', 'wudaqu', 'wdq');
INSERT INTO `yc_city` VALUES ('375', '赤峰市', '350', '1', '内蒙古,赤峰市', null, null, '150400', 'c', 'chifengshi', 'cfs');
INSERT INTO `yc_city` VALUES ('376', '红山区', '375', '1', '内蒙古,赤峰市,红山区', null, null, '150402', 'h', 'hongshanqu', 'hsq');
INSERT INTO `yc_city` VALUES ('377', '元宝山区', '375', '1', '内蒙古,赤峰市,元宝山区', null, null, '150403', 'y', 'yuanbaoshanqu', 'ybsq');
INSERT INTO `yc_city` VALUES ('378', '松山区', '375', '1', '内蒙古,赤峰市,松山区', null, null, '150404', 's', 'songshanqu', 'ssq');
INSERT INTO `yc_city` VALUES ('379', '阿鲁科尔沁旗', '375', '1', '内蒙古,赤峰市,阿鲁科尔沁旗', null, null, '150421', 'a', 'alukeerqinqi', 'alkeqq');
INSERT INTO `yc_city` VALUES ('380', '巴林左旗', '375', '1', '内蒙古,赤峰市,巴林左旗', null, null, '150422', 'b', 'balinzuoqi', 'blzq');
INSERT INTO `yc_city` VALUES ('381', '巴林右旗', '375', '1', '内蒙古,赤峰市,巴林右旗', null, null, '150423', 'b', 'balinyouqi', 'blyq');
INSERT INTO `yc_city` VALUES ('382', '林西县', '375', '1', '内蒙古,赤峰市,林西县', null, null, '150424', 'l', 'linxixian', 'lxx');
INSERT INTO `yc_city` VALUES ('383', '克什克腾旗', '375', '1', '内蒙古,赤峰市,克什克腾旗', null, null, '150425', 'k', 'keshiketengqi', 'ksktq');
INSERT INTO `yc_city` VALUES ('384', '翁牛特旗', '375', '1', '内蒙古,赤峰市,翁牛特旗', null, null, '150426', 'w', 'wengniuteqi', 'wntq');
INSERT INTO `yc_city` VALUES ('385', '喀喇沁旗', '375', '1', '内蒙古,赤峰市,喀喇沁旗', null, null, '150428', 'k', 'kalaqinqi', 'klqq');
INSERT INTO `yc_city` VALUES ('386', '宁城县', '375', '1', '内蒙古,赤峰市,宁城县', null, null, '150429', 'n', 'ningchengxian', 'ncx');
INSERT INTO `yc_city` VALUES ('387', '敖汉旗', '375', '1', '内蒙古,赤峰市,敖汉旗', null, null, '150430', 'a', 'aohanqi', 'ahq');
INSERT INTO `yc_city` VALUES ('388', '通辽市', '350', '1', '内蒙古,通辽市', null, null, '150500', 't', 'tongliaoshi', 'tls');
INSERT INTO `yc_city` VALUES ('389', '科尔沁区', '388', '1', '内蒙古,通辽市,科尔沁区', null, null, '150502', 'k', 'keerqinqu', 'keqq');
INSERT INTO `yc_city` VALUES ('390', '科尔沁左翼中旗', '388', '1', '内蒙古,通辽市,科尔沁左翼中旗', null, null, '150521', 'k', 'keerqinzuoyizhongqi', 'keqzyzq');
INSERT INTO `yc_city` VALUES ('391', '科尔沁左翼后旗', '388', '1', '内蒙古,通辽市,科尔沁左翼后旗', null, null, '150522', 'k', 'keerqinzuoyihouqi', 'keqzyhq');
INSERT INTO `yc_city` VALUES ('392', '开鲁县', '388', '1', '内蒙古,通辽市,开鲁县', null, null, '150523', 'k', 'kailuxian', 'klx');
INSERT INTO `yc_city` VALUES ('393', '库伦旗', '388', '1', '内蒙古,通辽市,库伦旗', null, null, '150524', 'k', 'kulunqi', 'klq');
INSERT INTO `yc_city` VALUES ('394', '奈曼旗', '388', '1', '内蒙古,通辽市,奈曼旗', null, null, '150525', 'n', 'naimanqi', 'nmq');
INSERT INTO `yc_city` VALUES ('395', '扎鲁特旗', '388', '1', '内蒙古,通辽市,扎鲁特旗', null, null, '150526', 'z', 'zaluteqi', 'zltq');
INSERT INTO `yc_city` VALUES ('396', '霍林郭勒市', '388', '1', '内蒙古,通辽市,霍林郭勒市', null, null, '150581', 'h', 'huolinguoleshi', 'hlgls');
INSERT INTO `yc_city` VALUES ('397', '鄂尔多斯市', '350', '1', '内蒙古,鄂尔多斯市', null, null, '150600', 'e', 'eerduosishi', 'eedss');
INSERT INTO `yc_city` VALUES ('398', '东胜区', '397', '1', '内蒙古,鄂尔多斯市,东胜区', null, null, '150602', 'd', 'dongshengqu', 'dsq');
INSERT INTO `yc_city` VALUES ('399', '达拉特旗', '397', '1', '内蒙古,鄂尔多斯市,达拉特旗', null, null, '150621', 'd', 'dalateqi', 'dltq');
INSERT INTO `yc_city` VALUES ('400', '准格尔旗', '397', '1', '内蒙古,鄂尔多斯市,准格尔旗', null, null, '150622', 'z', 'zhungeerqi', 'zgeq');
INSERT INTO `yc_city` VALUES ('401', '鄂托克前旗', '397', '1', '内蒙古,鄂尔多斯市,鄂托克前旗', null, null, '150623', 'e', 'etuokeqianqi', 'etkqq');
INSERT INTO `yc_city` VALUES ('402', '鄂托克旗', '397', '1', '内蒙古,鄂尔多斯市,鄂托克旗', null, null, '150624', 'e', 'etuokeqi', 'etkq');
INSERT INTO `yc_city` VALUES ('403', '杭锦旗', '397', '1', '内蒙古,鄂尔多斯市,杭锦旗', null, null, '150625', 'h', 'hangjinqi', 'hjq');
INSERT INTO `yc_city` VALUES ('404', '乌审旗', '397', '1', '内蒙古,鄂尔多斯市,乌审旗', null, null, '150626', 'w', 'wushenqi', 'wsq');
INSERT INTO `yc_city` VALUES ('405', '伊金霍洛旗', '397', '1', '内蒙古,鄂尔多斯市,伊金霍洛旗', null, null, '150627', 'y', 'yijinhuoluoqi', 'yjhlq');
INSERT INTO `yc_city` VALUES ('406', '呼伦贝尔市', '350', '1', '内蒙古,呼伦贝尔市', null, null, '150700', 'h', 'hulunbeiershi', 'hlbes');
INSERT INTO `yc_city` VALUES ('407', '海拉尔区', '406', '1', '内蒙古,呼伦贝尔市,海拉尔区', null, null, '150702', 'h', 'hailaerqu', 'hleq');
INSERT INTO `yc_city` VALUES ('408', '扎赉诺尔区', '406', '1', '内蒙古,呼伦贝尔市,扎赉诺尔区', null, null, '152223', 'z', 'zhalainuoerqu', 'zneq');
INSERT INTO `yc_city` VALUES ('409', '阿荣旗', '406', '1', '内蒙古,呼伦贝尔市,阿荣旗', null, null, '150721', 'a', 'arongqi', 'arq');
INSERT INTO `yc_city` VALUES ('410', '莫力达瓦达斡尔族自治旗', '406', '1', '内蒙古,呼伦贝尔市,莫力达瓦达斡尔族自治旗', null, null, '150722', 'm', 'molidawadawoerzuzizhiqi', 'mldwdwezzzq');
INSERT INTO `yc_city` VALUES ('411', '鄂伦春自治旗', '406', '1', '内蒙古,呼伦贝尔市,鄂伦春自治旗', null, null, '150723', 'e', 'elunchunzizhiqi', 'elczzq');
INSERT INTO `yc_city` VALUES ('412', '鄂温克族自治旗', '406', '1', '内蒙古,呼伦贝尔市,鄂温克族自治旗', null, null, '150724', 'e', 'ewenkezuzizhiqi', 'ewkzzzq');
INSERT INTO `yc_city` VALUES ('413', '陈巴尔虎旗', '406', '1', '内蒙古,呼伦贝尔市,陈巴尔虎旗', null, null, '150725', 'c', 'chenbaerhuqi', 'cbehq');
INSERT INTO `yc_city` VALUES ('414', '新巴尔虎左旗', '406', '1', '内蒙古,呼伦贝尔市,新巴尔虎左旗', null, null, '150726', 'x', 'xinbaerhuzuoqi', 'xbehzq');
INSERT INTO `yc_city` VALUES ('415', '新巴尔虎右旗', '406', '1', '内蒙古,呼伦贝尔市,新巴尔虎右旗', null, null, '150727', 'x', 'xinbaerhuyouqi', 'xbehyq');
INSERT INTO `yc_city` VALUES ('416', '满洲里市', '406', '1', '内蒙古,呼伦贝尔市,满洲里市', null, null, '150781', 'm', 'manzhoulishi', 'mzls');
INSERT INTO `yc_city` VALUES ('417', '牙克石市', '406', '1', '内蒙古,呼伦贝尔市,牙克石市', null, null, '150782', 'y', 'yakeshishi', 'ykss');
INSERT INTO `yc_city` VALUES ('418', '扎兰屯市', '406', '1', '内蒙古,呼伦贝尔市,扎兰屯市', null, null, '150783', 'z', 'zhalantunshi', 'zlts');
INSERT INTO `yc_city` VALUES ('419', '额尔古纳市', '406', '1', '内蒙古,呼伦贝尔市,额尔古纳市', null, null, '150784', 'e', 'eergunashi', 'eegns');
INSERT INTO `yc_city` VALUES ('420', '根河市', '406', '1', '内蒙古,呼伦贝尔市,根河市', null, null, '150785', 'g', 'genheshi', 'ghs');
INSERT INTO `yc_city` VALUES ('421', '巴彦淖尔市', '350', '1', '内蒙古,巴彦淖尔市', null, null, '150800', 'b', 'bayannaoershi', 'bynes');
INSERT INTO `yc_city` VALUES ('422', '临河区', '421', '1', '内蒙古,巴彦淖尔市,临河区', null, null, '150802', 'l', 'linhequ', 'lhq');
INSERT INTO `yc_city` VALUES ('423', '五原县', '421', '1', '内蒙古,巴彦淖尔市,五原县', null, null, '150821', 'w', 'wuyuanxian', 'wyx');
INSERT INTO `yc_city` VALUES ('424', '磴口县', '421', '1', '内蒙古,巴彦淖尔市,磴口县', null, null, '150822', 'd', 'dengkouxian', 'kx');
INSERT INTO `yc_city` VALUES ('425', '乌拉特前旗', '421', '1', '内蒙古,巴彦淖尔市,乌拉特前旗', null, null, '150823', 'w', 'wulteqianqi', 'wltqq');
INSERT INTO `yc_city` VALUES ('426', '乌拉特中旗', '421', '1', '内蒙古,巴彦淖尔市,乌拉特中旗', null, null, '150824', 'w', 'wultezhongqi', 'wltzq');
INSERT INTO `yc_city` VALUES ('427', '乌拉特后旗', '421', '1', '内蒙古,巴彦淖尔市,乌拉特后旗', null, null, '150825', 'w', 'wultehouqi', 'wlthq');
INSERT INTO `yc_city` VALUES ('428', '杭锦后旗', '421', '1', '内蒙古,巴彦淖尔市,杭锦后旗', null, null, '150826', 'h', 'hangjinhouqi', 'hjhq');
INSERT INTO `yc_city` VALUES ('429', '乌兰察布市', '350', '1', '内蒙古,乌兰察布市', null, null, '150900', 'w', 'wulanchabushi', 'wlcbs');
INSERT INTO `yc_city` VALUES ('430', '集宁区', '429', '1', '内蒙古,乌兰察布市,集宁区', null, null, '150902', 'j', 'jiningqu', 'jnq');
INSERT INTO `yc_city` VALUES ('431', '卓资县', '429', '1', '内蒙古,乌兰察布市,卓资县', null, null, '150921', 'z', 'zhuozixian', 'zzx');
INSERT INTO `yc_city` VALUES ('432', '化德县', '429', '1', '内蒙古,乌兰察布市,化德县', null, null, '150922', 'h', 'huadexian', 'hdx');
INSERT INTO `yc_city` VALUES ('433', '商都县', '429', '1', '内蒙古,乌兰察布市,商都县', null, null, '150923', 's', 'shangduxian', 'sdx');
INSERT INTO `yc_city` VALUES ('434', '兴和县', '429', '1', '内蒙古,乌兰察布市,兴和县', null, null, '150924', 'x', 'xinghexian', 'xhx');
INSERT INTO `yc_city` VALUES ('435', '凉城县', '429', '1', '内蒙古,乌兰察布市,凉城县', null, null, '150925', 'l', 'liangchengxian', 'lcx');
INSERT INTO `yc_city` VALUES ('436', '察哈尔右翼前旗', '429', '1', '内蒙古,乌兰察布市,察哈尔右翼前旗', null, null, '150926', 'c', 'chahaeryouyiqianqi', 'cheyyqq');
INSERT INTO `yc_city` VALUES ('437', '察哈尔右翼中旗', '429', '1', '内蒙古,乌兰察布市,察哈尔右翼中旗', null, null, '150927', 'c', 'chahaeryouyizhongqi', 'cheyyzq');
INSERT INTO `yc_city` VALUES ('438', '察哈尔右翼后旗', '429', '1', '内蒙古,乌兰察布市,察哈尔右翼后旗', null, null, '150928', 'c', 'chahaeryouyihouqi', 'cheyyhq');
INSERT INTO `yc_city` VALUES ('439', '四子王旗', '429', '1', '内蒙古,乌兰察布市,四子王旗', null, null, '150929', 's', 'siziwangqi', 'szwq');
INSERT INTO `yc_city` VALUES ('440', '丰镇市', '429', '1', '内蒙古,乌兰察布市,丰镇市', null, null, '150981', 'f', 'fengzhenshi', 'fzs');
INSERT INTO `yc_city` VALUES ('441', '兴安盟', '350', '1', '内蒙古,兴安盟', null, null, '152200', 'x', 'xinganmeng', 'xam');
INSERT INTO `yc_city` VALUES ('442', '乌兰浩特市', '441', '1', '内蒙古,兴安盟,乌兰浩特市', null, null, '152201', 'w', 'wulanhaoteshi', 'wlhts');
INSERT INTO `yc_city` VALUES ('443', '阿尔山市', '441', '1', '内蒙古,兴安盟,阿尔山市', null, null, '152202', 'a', 'aershanshi', 'aess');
INSERT INTO `yc_city` VALUES ('444', '科尔沁右翼前旗', '441', '1', '内蒙古,兴安盟,科尔沁右翼前旗', null, null, '152221', 'k', 'keerqinyouyiqianqi', 'keqyyqq');
INSERT INTO `yc_city` VALUES ('445', '科尔沁右翼中旗', '441', '1', '内蒙古,兴安盟,科尔沁右翼中旗', null, null, '152222', 'k', 'keerqinyouyizhongqi', 'keqyyzq');
INSERT INTO `yc_city` VALUES ('446', '扎赉特旗', '441', '1', '内蒙古,兴安盟,扎赉特旗', null, null, '152223', 'z', 'zhalaiteqi', 'ztq');
INSERT INTO `yc_city` VALUES ('447', '突泉县', '441', '1', '内蒙古,兴安盟,突泉县', null, null, '152224', 't', 'tuquanxian', 'tqx');
INSERT INTO `yc_city` VALUES ('448', '锡林郭勒盟', '350', '1', '内蒙古,锡林郭勒盟', null, null, '152500', 'x', 'xilinguolemeng', 'xlglm');
INSERT INTO `yc_city` VALUES ('449', '二连浩特市', '448', '1', '内蒙古,锡林郭勒盟,二连浩特市', null, null, '152501', 'e', 'erlianhaoteshi', 'elhts');
INSERT INTO `yc_city` VALUES ('450', '锡林浩特市', '448', '1', '内蒙古,锡林郭勒盟,锡林浩特市', null, null, '152502', 'x', 'xilinhaoteshi', 'xlhts');
INSERT INTO `yc_city` VALUES ('451', '阿巴嘎旗', '448', '1', '内蒙古,锡林郭勒盟,阿巴嘎旗', null, null, '152522', 'a', 'abagaqi', 'abgq');
INSERT INTO `yc_city` VALUES ('452', '苏尼特左旗', '448', '1', '内蒙古,锡林郭勒盟,苏尼特左旗', null, null, '152523', 's', 'sunitezuoqi', 'sntzq');
INSERT INTO `yc_city` VALUES ('453', '苏尼特右旗', '448', '1', '内蒙古,锡林郭勒盟,苏尼特右旗', null, null, '152524', 's', 'suniteyouqi', 'sntyq');
INSERT INTO `yc_city` VALUES ('454', '东乌珠穆沁旗', '448', '1', '内蒙古,锡林郭勒盟,东乌珠穆沁旗', null, null, '152525', 'd', 'dongwuzhumuqinqi', 'dwzmqq');
INSERT INTO `yc_city` VALUES ('455', '西乌珠穆沁旗', '448', '1', '内蒙古,锡林郭勒盟,西乌珠穆沁旗', null, null, '152526', 'x', 'xiwuzhumuqinqi', 'xwzmqq');
INSERT INTO `yc_city` VALUES ('456', '太仆寺旗', '448', '1', '内蒙古,锡林郭勒盟,太仆寺旗', null, null, '152527', 't', 'taipusiqi', 'tpsq');
INSERT INTO `yc_city` VALUES ('457', '镶黄旗', '448', '1', '内蒙古,锡林郭勒盟,镶黄旗', null, null, '152528', 'x', 'xianghuangqi', 'xhq');
INSERT INTO `yc_city` VALUES ('458', '正镶白旗', '448', '1', '内蒙古,锡林郭勒盟,正镶白旗', null, null, '152529', 'z', 'zhengxiangbaiqi', 'zxbq');
INSERT INTO `yc_city` VALUES ('459', '正蓝旗', '448', '1', '内蒙古,锡林郭勒盟,正蓝旗', null, null, '152530', 'z', 'zhenglanqi', 'zlq');
INSERT INTO `yc_city` VALUES ('460', '多伦县', '448', '1', '内蒙古,锡林郭勒盟,多伦县', null, null, '152531', 'd', 'duolunxian', 'dlx');
INSERT INTO `yc_city` VALUES ('461', '阿拉善盟', '350', '1', '内蒙古,阿拉善盟', null, null, '152900', 'a', 'alashanmeng', 'alsm');
INSERT INTO `yc_city` VALUES ('462', '阿拉善左旗', '461', '1', '内蒙古,阿拉善盟,阿拉善左旗', null, null, '152921', 'a', 'alashanzuoqi', 'alszq');
INSERT INTO `yc_city` VALUES ('463', '阿拉善右旗', '461', '1', '内蒙古,阿拉善盟,阿拉善右旗', null, null, '152922', 'a', 'alashanyouqi', 'alsyq');
INSERT INTO `yc_city` VALUES ('464', '额济纳旗', '461', '1', '内蒙古,阿拉善盟,额济纳旗', null, null, '152923', 'e', 'ejinaqi', 'ejnq');
INSERT INTO `yc_city` VALUES ('465', '辽宁', '1', '1', '辽宁', null, null, '210000', 'l', 'liaoning', 'ln');
INSERT INTO `yc_city` VALUES ('466', '沈阳市', '465', '1', '辽宁,沈阳市', null, null, '210100', 's', 'shenyangshi', 'sys');
INSERT INTO `yc_city` VALUES ('467', '和平区', '466', '1', '辽宁,沈阳市,和平区', null, null, '210102', 'h', 'hepingqu', 'hpq');
INSERT INTO `yc_city` VALUES ('468', '沈河区', '466', '1', '辽宁,沈阳市,沈河区', null, null, '210103', 's', 'shenhequ', 'shq');
INSERT INTO `yc_city` VALUES ('469', '大东区', '466', '1', '辽宁,沈阳市,大东区', null, null, '210104', 'd', 'dadongqu', 'ddq');
INSERT INTO `yc_city` VALUES ('470', '皇姑区', '466', '1', '辽宁,沈阳市,皇姑区', null, null, '210105', 'h', 'huangguqu', 'hgq');
INSERT INTO `yc_city` VALUES ('471', '铁西区', '466', '1', '辽宁,沈阳市,铁西区', null, null, '210106', 't', 'tiexiqu', 'txq');
INSERT INTO `yc_city` VALUES ('472', '苏家屯区', '466', '1', '辽宁,沈阳市,苏家屯区', null, null, '210111', 's', 'sujiatunqu', 'sjtq');
INSERT INTO `yc_city` VALUES ('473', '浑南区', '466', '1', '辽宁,沈阳市,浑南区', null, null, '210112', 'h', 'hunnanqu', 'hnq');
INSERT INTO `yc_city` VALUES ('474', '沈北新区', '466', '1', '辽宁,沈阳市,沈北新区', null, null, '210113', 's', 'shenbeixinqu', 'sbxq');
INSERT INTO `yc_city` VALUES ('475', '于洪区', '466', '1', '辽宁,沈阳市,于洪区', null, null, '210114', 'y', 'yuhongqu', 'yhq');
INSERT INTO `yc_city` VALUES ('476', '辽中县', '466', '1', '辽宁,沈阳市,辽中县', null, null, '210122', 'l', 'liaozhongxian', 'lzx');
INSERT INTO `yc_city` VALUES ('477', '康平县', '466', '1', '辽宁,沈阳市,康平县', null, null, '210123', 'k', 'kangpingxian', 'kpx');
INSERT INTO `yc_city` VALUES ('478', '法库县', '466', '1', '辽宁,沈阳市,法库县', null, null, '210124', 'f', 'fakuxian', 'fkx');
INSERT INTO `yc_city` VALUES ('479', '新民市', '466', '1', '辽宁,沈阳市,新民市', null, null, '210181', 'x', 'xinminshi', 'xms');
INSERT INTO `yc_city` VALUES ('480', '大连市', '465', '1', '辽宁,大连市', null, null, '210200', 'd', 'dalianshi', 'dls');
INSERT INTO `yc_city` VALUES ('481', '中山区', '480', '1', '辽宁,大连市,中山区', null, null, '210202', 'z', 'zhongshanqu', 'zsq');
INSERT INTO `yc_city` VALUES ('482', '西岗区', '480', '1', '辽宁,大连市,西岗区', null, null, '210203', 'x', 'xigangqu', 'xgq');
INSERT INTO `yc_city` VALUES ('483', '沙河口区', '480', '1', '辽宁,大连市,沙河口区', null, null, '210204', 's', 'shahekouqu', 'shkq');
INSERT INTO `yc_city` VALUES ('484', '甘井子区', '480', '1', '辽宁,大连市,甘井子区', null, null, '210211', 'g', 'ganjingziqu', 'gjzq');
INSERT INTO `yc_city` VALUES ('485', '旅顺口区', '480', '1', '辽宁,大连市,旅顺口区', null, null, '210212', 'l', 'lvshunkouqu', 'lskq');
INSERT INTO `yc_city` VALUES ('486', '金州区', '480', '1', '辽宁,大连市,金州区', null, null, '210213', 'j', 'jinzhouqu', 'jzq');
INSERT INTO `yc_city` VALUES ('487', '长海县', '480', '1', '辽宁,大连市,长海县', null, null, '210224', 'c', 'changhaixian', 'chx');
INSERT INTO `yc_city` VALUES ('488', '瓦房店市', '480', '1', '辽宁,大连市,瓦房店市', null, null, '210281', 'w', 'wafangdianshi', 'wfds');
INSERT INTO `yc_city` VALUES ('489', '普兰店市', '480', '1', '辽宁,大连市,普兰店市', null, null, '210282', 'p', 'pulandianshi', 'plds');
INSERT INTO `yc_city` VALUES ('490', '庄河市', '480', '1', '辽宁,大连市,庄河市', null, null, '210283', 'z', 'zhuangheshi', 'zhs');
INSERT INTO `yc_city` VALUES ('491', '鞍山市', '465', '1', '辽宁,鞍山市', null, null, '210300', 'a', 'anshanshi', 'ass');
INSERT INTO `yc_city` VALUES ('492', '铁东区', '491', '1', '辽宁,鞍山市,铁东区', null, null, '210302', 't', 'tiedongqu', 'tdq');
INSERT INTO `yc_city` VALUES ('493', '铁西区', '491', '1', '辽宁,鞍山市,铁西区', null, null, '210303', 't', 'tiexiqu', 'txq');
INSERT INTO `yc_city` VALUES ('494', '立山区', '491', '1', '辽宁,鞍山市,立山区', null, null, '210304', 'l', 'lishanqu', 'lsq');
INSERT INTO `yc_city` VALUES ('495', '千山区', '491', '1', '辽宁,鞍山市,千山区', null, null, '210311', 'q', 'qianshanqu', 'qsq');
INSERT INTO `yc_city` VALUES ('496', '台安县', '491', '1', '辽宁,鞍山市,台安县', null, null, '210321', 't', 'taianxian', 'tax');
INSERT INTO `yc_city` VALUES ('497', '岫岩满族自治县', '491', '1', '辽宁,鞍山市,岫岩满族自治县', null, null, '210323', 'x', 'xiuyanmanzuzizhixian', 'ymzzzx');
INSERT INTO `yc_city` VALUES ('498', '海城市', '491', '1', '辽宁,鞍山市,海城市', null, null, '210381', 'h', 'haichengshi', 'hcs');
INSERT INTO `yc_city` VALUES ('499', '抚顺市', '465', '1', '辽宁,抚顺市', null, null, '210400', 'f', 'fushunshi', 'fss');
INSERT INTO `yc_city` VALUES ('500', '新抚区', '499', '1', '辽宁,抚顺市,新抚区', null, null, '210402', 'x', 'xinfuqu', 'xfq');
INSERT INTO `yc_city` VALUES ('501', '东洲区', '499', '1', '辽宁,抚顺市,东洲区', null, null, '210403', 'd', 'dongzhouqu', 'dzq');
INSERT INTO `yc_city` VALUES ('502', '望花区', '499', '1', '辽宁,抚顺市,望花区', null, null, '210404', 'w', 'wanghuaqu', 'whq');
INSERT INTO `yc_city` VALUES ('503', '顺城区', '499', '1', '辽宁,抚顺市,顺城区', null, null, '210411', 's', 'shunchengqu', 'scq');
INSERT INTO `yc_city` VALUES ('504', '抚顺县', '499', '1', '辽宁,抚顺市,抚顺县', null, null, '210421', 'f', 'fushunxian', 'fsx');
INSERT INTO `yc_city` VALUES ('505', '新宾满族自治县', '499', '1', '辽宁,抚顺市,新宾满族自治县', null, null, '210422', 'x', 'xinbinmanzuzizhixian', 'xbmzzzx');
INSERT INTO `yc_city` VALUES ('506', '清原满族自治县', '499', '1', '辽宁,抚顺市,清原满族自治县', null, null, '210423', 'q', 'qingyuanmanzuzizhixian', 'qymzzzx');
INSERT INTO `yc_city` VALUES ('507', '本溪市', '465', '1', '辽宁,本溪市', null, null, '210500', 'b', 'benxishi', 'bxs');
INSERT INTO `yc_city` VALUES ('508', '平山区', '507', '1', '辽宁,本溪市,平山区', null, null, '210502', 'p', 'pingshanqu', 'psq');
INSERT INTO `yc_city` VALUES ('509', '溪湖区', '507', '1', '辽宁,本溪市,溪湖区', null, null, '210503', 'x', 'xihuqu', 'xhq');
INSERT INTO `yc_city` VALUES ('510', '明山区', '507', '1', '辽宁,本溪市,明山区', null, null, '210504', 'm', 'mingshanqu', 'msq');
INSERT INTO `yc_city` VALUES ('511', '南芬区', '507', '1', '辽宁,本溪市,南芬区', null, null, '210505', 'n', 'nanfenqu', 'nfq');
INSERT INTO `yc_city` VALUES ('512', '本溪满族自治县', '507', '1', '辽宁,本溪市,本溪满族自治县', null, null, '210521', 'b', 'benximanzuzizhixian', 'bxmzzzx');
INSERT INTO `yc_city` VALUES ('513', '桓仁满族自治县', '507', '1', '辽宁,本溪市,桓仁满族自治县', null, null, '210522', 'h', 'huanrenmanzuzizhixian', 'hrmzzzx');
INSERT INTO `yc_city` VALUES ('514', '丹东市', '465', '1', '辽宁,丹东市', null, null, '210600', 'd', 'dandongshi', 'dds');
INSERT INTO `yc_city` VALUES ('515', '元宝区', '514', '1', '辽宁,丹东市,元宝区', null, null, '210602', 'y', 'yuanbaoqu', 'ybq');
INSERT INTO `yc_city` VALUES ('516', '振兴区', '514', '1', '辽宁,丹东市,振兴区', null, null, '210603', 'z', 'zhenxingqu', 'zxq');
INSERT INTO `yc_city` VALUES ('517', '振安区', '514', '1', '辽宁,丹东市,振安区', null, null, '210604', 'z', 'zhenanqu', 'zaq');
INSERT INTO `yc_city` VALUES ('518', '宽甸满族自治县', '514', '1', '辽宁,丹东市,宽甸满族自治县', null, null, '210624', 'k', 'kuandianmanzuzizhixian', 'kdmzzzx');
INSERT INTO `yc_city` VALUES ('519', '东港市', '514', '1', '辽宁,丹东市,东港市', null, null, '210681', 'd', 'donggangshi', 'dgs');
INSERT INTO `yc_city` VALUES ('520', '凤城市', '514', '1', '辽宁,丹东市,凤城市', null, null, '210682', 'f', 'fengchengshi', 'fcs');
INSERT INTO `yc_city` VALUES ('521', '锦州市', '465', '1', '辽宁,锦州市', null, null, '210700', 'j', 'jinzhoushi', 'jzs');
INSERT INTO `yc_city` VALUES ('522', '古塔区', '521', '1', '辽宁,锦州市,古塔区', null, null, '210702', 'g', 'gutaqu', 'gtq');
INSERT INTO `yc_city` VALUES ('523', '凌河区', '521', '1', '辽宁,锦州市,凌河区', null, null, '210703', 'l', 'linghequ', 'lhq');
INSERT INTO `yc_city` VALUES ('524', '太和区', '521', '1', '辽宁,锦州市,太和区', null, null, '210711', 't', 'taihequ', 'thq');
INSERT INTO `yc_city` VALUES ('525', '黑山县', '521', '1', '辽宁,锦州市,黑山县', null, null, '210726', 'h', 'heishanxian', 'hsx');
INSERT INTO `yc_city` VALUES ('526', '义县', '521', '1', '辽宁,锦州市,义县', null, null, '210727', 'y', 'yixian', 'yx');
INSERT INTO `yc_city` VALUES ('527', '凌海市', '521', '1', '辽宁,锦州市,凌海市', null, null, '210781', 'l', 'linghaishi', 'lhs');
INSERT INTO `yc_city` VALUES ('528', '北镇市', '521', '1', '辽宁,锦州市,北镇市', null, null, '210782', 'b', 'beizhenshi', 'bzs');
INSERT INTO `yc_city` VALUES ('529', '营口市', '465', '1', '辽宁,营口市', null, null, '210800', 'y', 'yingkoushi', 'yks');
INSERT INTO `yc_city` VALUES ('530', '站前区', '529', '1', '辽宁,营口市,站前区', null, null, '210802', 'z', 'zhanqianqu', 'zqq');
INSERT INTO `yc_city` VALUES ('531', '西市区', '529', '1', '辽宁,营口市,西市区', null, null, '210803', 'x', 'xishiqu', 'xsq');
INSERT INTO `yc_city` VALUES ('532', '鲅鱼圈区', '529', '1', '辽宁,营口市,鲅鱼圈区', null, null, '210804', 'b', 'bayuquanqu', 'yqq');
INSERT INTO `yc_city` VALUES ('533', '老边区', '529', '1', '辽宁,营口市,老边区', null, null, '210811', 'l', 'laobianqu', 'lbq');
INSERT INTO `yc_city` VALUES ('534', '盖州市', '529', '1', '辽宁,营口市,盖州市', null, null, '210881', 'g', 'gaizhoushi', 'gzs');
INSERT INTO `yc_city` VALUES ('535', '大石桥市', '529', '1', '辽宁,营口市,大石桥市', null, null, '210882', 'd', 'dashiqiaoshi', 'dsqs');
INSERT INTO `yc_city` VALUES ('536', '阜新市', '465', '1', '辽宁,阜新市', null, null, '210900', 'f', 'fuxinshi', 'fxs');
INSERT INTO `yc_city` VALUES ('537', '海州区', '536', '1', '辽宁,阜新市,海州区', null, null, '210902', 'h', 'haizhouqu', 'hzq');
INSERT INTO `yc_city` VALUES ('538', '新邱区', '536', '1', '辽宁,阜新市,新邱区', null, null, '210903', 'x', 'xinqiuqu', 'xqq');
INSERT INTO `yc_city` VALUES ('539', '太平区', '536', '1', '辽宁,阜新市,太平区', null, null, '210904', 't', 'taipingqu', 'tpq');
INSERT INTO `yc_city` VALUES ('540', '清河门区', '536', '1', '辽宁,阜新市,清河门区', null, null, '210905', 'q', 'qinghemenqu', 'qhmq');
INSERT INTO `yc_city` VALUES ('541', '细河区', '536', '1', '辽宁,阜新市,细河区', null, null, '210911', 'x', 'xihequ', 'xhq');
INSERT INTO `yc_city` VALUES ('542', '阜新蒙古族自治县', '536', '1', '辽宁,阜新市,阜新蒙古族自治县', null, null, '210921', 'f', 'fuxinmengguzuzizhixian', 'fxmgzzzx');
INSERT INTO `yc_city` VALUES ('543', '彰武县', '536', '1', '辽宁,阜新市,彰武县', null, null, '210922', 'z', 'zhangwuxian', 'zwx');
INSERT INTO `yc_city` VALUES ('544', '辽阳市', '465', '1', '辽宁,辽阳市', null, null, '211000', 'l', 'liaoyangshi', 'lys');
INSERT INTO `yc_city` VALUES ('545', '白塔区', '544', '1', '辽宁,辽阳市,白塔区', null, null, '211002', 'b', 'baitaqu', 'btq');
INSERT INTO `yc_city` VALUES ('546', '文圣区', '544', '1', '辽宁,辽阳市,文圣区', null, null, '211003', 'w', 'wenshengqu', 'wsq');
INSERT INTO `yc_city` VALUES ('547', '宏伟区', '544', '1', '辽宁,辽阳市,宏伟区', null, null, '211004', 'h', 'hongweiqu', 'hwq');
INSERT INTO `yc_city` VALUES ('548', '弓长岭区', '544', '1', '辽宁,辽阳市,弓长岭区', null, null, '211005', 'g', 'gongchanglingqu', 'gclq');
INSERT INTO `yc_city` VALUES ('549', '太子河区', '544', '1', '辽宁,辽阳市,太子河区', null, null, '211011', 't', 'taizihequ', 'tzhq');
INSERT INTO `yc_city` VALUES ('550', '辽阳县', '544', '1', '辽宁,辽阳市,辽阳县', null, null, '211021', 'l', 'liaoyangxian', 'lyx');
INSERT INTO `yc_city` VALUES ('551', '灯塔市', '544', '1', '辽宁,辽阳市,灯塔市', null, null, '211081', 'd', 'dengtashi', 'dts');
INSERT INTO `yc_city` VALUES ('552', '双台子区', '465', '1', '辽宁,双台子区', null, null, '211102', 's', 'shuangtaiziqu', 'stzq');
INSERT INTO `yc_city` VALUES ('553', '兴隆台区', '465', '1', '辽宁,兴隆台区', null, null, '211103', 'x', 'xinglongtaiqu', 'xltq');
INSERT INTO `yc_city` VALUES ('554', '大洼县', '465', '1', '辽宁,大洼县', null, null, '211121', 'd', 'dawaxian', 'dwx');
INSERT INTO `yc_city` VALUES ('555', '盘山县', '465', '1', '辽宁,盘山县', null, null, '211122', 'p', 'panshanxian', 'psx');
INSERT INTO `yc_city` VALUES ('556', '铁岭市', '465', '1', '辽宁,铁岭市', null, null, '211200', 't', 'tielingshi', 'tls');
INSERT INTO `yc_city` VALUES ('557', '银州区', '556', '1', '辽宁,铁岭市,银州区', null, null, '211202', 'y', 'yinzhouqu', 'yzq');
INSERT INTO `yc_city` VALUES ('558', '清河区', '556', '1', '辽宁,铁岭市,清河区', null, null, '211204', 'q', 'qinghequ', 'qhq');
INSERT INTO `yc_city` VALUES ('559', '铁岭县', '556', '1', '辽宁,铁岭市,铁岭县', null, null, '211221', 't', 'tielingxian', 'tlx');
INSERT INTO `yc_city` VALUES ('560', '西丰县', '556', '1', '辽宁,铁岭市,西丰县', null, null, '211223', 'x', 'xifengxian', 'xfx');
INSERT INTO `yc_city` VALUES ('561', '昌图县', '556', '1', '辽宁,铁岭市,昌图县', null, null, '211224', 'c', 'changtuxian', 'ctx');
INSERT INTO `yc_city` VALUES ('562', '调兵山市', '556', '1', '辽宁,铁岭市,调兵山市', null, null, '211281', 'd', 'diaobingshanshi', 'dbss');
INSERT INTO `yc_city` VALUES ('563', '开原市', '556', '1', '辽宁,铁岭市,开原市', null, null, '211282', 'k', 'kaiyuanshi', 'kys');
INSERT INTO `yc_city` VALUES ('564', '朝阳市', '465', '1', '辽宁,朝阳市', null, null, '211300', 'z', 'zhaoyangshi', 'cys');
INSERT INTO `yc_city` VALUES ('565', '双塔区', '564', '1', '辽宁,朝阳市,双塔区', null, null, '211302', 's', 'shuangtaqu', 'stq');
INSERT INTO `yc_city` VALUES ('566', '龙城区', '564', '1', '辽宁,朝阳市,龙城区', null, null, '211303', 'l', 'longchengqu', 'lcq');
INSERT INTO `yc_city` VALUES ('567', '朝阳县', '564', '1', '辽宁,朝阳市,朝阳县', null, null, '211321', 'z', 'zhaoyangxian', 'cyx');
INSERT INTO `yc_city` VALUES ('568', '建平县', '564', '1', '辽宁,朝阳市,建平县', null, null, '211322', 'j', 'jianpingxian', 'jpx');
INSERT INTO `yc_city` VALUES ('569', '喀喇沁左翼蒙古族自治县', '564', '1', '辽宁,朝阳市,喀喇沁左翼蒙古族自治县', null, null, '211324', 'k', 'kalaqinzuoyimengguzuzizhixian', 'klqzymgzzzx');
INSERT INTO `yc_city` VALUES ('570', '北票市', '564', '1', '辽宁,朝阳市,北票市', null, null, '211381', 'b', 'beipiaoshi', 'bps');
INSERT INTO `yc_city` VALUES ('571', '凌源市', '564', '1', '辽宁,朝阳市,凌源市', null, null, '211382', 'l', 'lingyuanshi', 'lys');
INSERT INTO `yc_city` VALUES ('572', '葫芦岛市', '465', '1', '辽宁,葫芦岛市', null, null, '211400', 'h', 'huludaoshi', 'hlds');
INSERT INTO `yc_city` VALUES ('573', '连山区', '572', '1', '辽宁,葫芦岛市,连山区', null, null, '211402', 'l', 'lianshanqu', 'lsq');
INSERT INTO `yc_city` VALUES ('574', '龙港区', '572', '1', '辽宁,葫芦岛市,龙港区', null, null, '211403', 'l', 'longgangqu', 'lgq');
INSERT INTO `yc_city` VALUES ('575', '南票区', '572', '1', '辽宁,葫芦岛市,南票区', null, null, '211404', 'n', 'nanpiaoqu', 'npq');
INSERT INTO `yc_city` VALUES ('576', '绥中县', '572', '1', '辽宁,葫芦岛市,绥中县', null, null, '211421', 's', 'suizhongxian', 'szx');
INSERT INTO `yc_city` VALUES ('577', '建昌县', '572', '1', '辽宁,葫芦岛市,建昌县', null, null, '211422', 'j', 'jianchangxian', 'jcx');
INSERT INTO `yc_city` VALUES ('578', '兴城市', '572', '1', '辽宁,葫芦岛市,兴城市', null, null, '211481', 'x', 'xingchengshi', 'xcs');
INSERT INTO `yc_city` VALUES ('579', '吉林', '1', '1', '吉林', null, null, '220000', 'j', 'jilin', 'jl');
INSERT INTO `yc_city` VALUES ('580', '长春市', '579', '1', '吉林,长春市', null, null, '220100', 'c', 'changchunshi', 'ccs');
INSERT INTO `yc_city` VALUES ('581', '南关区', '580', '1', '吉林,长春市,南关区', null, null, '220102', 'n', 'nanguanqu', 'ngq');
INSERT INTO `yc_city` VALUES ('582', '宽城区', '580', '1', '吉林,长春市,宽城区', null, null, '220103', 'k', 'kuanchengqu', 'kcq');
INSERT INTO `yc_city` VALUES ('583', '朝阳区', '580', '1', '吉林,长春市,朝阳区', null, null, '220104', 'z', 'zhaoyangqu', 'cyq');
INSERT INTO `yc_city` VALUES ('584', '二道区', '580', '1', '吉林,长春市,二道区', null, null, '220105', 'e', 'erdaoqu', 'edq');
INSERT INTO `yc_city` VALUES ('585', '绿园区', '580', '1', '吉林,长春市,绿园区', null, null, '220106', 'l', 'lvyuanqu', 'lyq');
INSERT INTO `yc_city` VALUES ('586', '双阳区', '580', '1', '吉林,长春市,双阳区', null, null, '220112', 's', 'shuangyangqu', 'syq');
INSERT INTO `yc_city` VALUES ('587', '九台区', '580', '1', '吉林,长春市,九台区', null, null, '220181', 'j', 'jiutaiqu', 'jtq');
INSERT INTO `yc_city` VALUES ('588', '农安县', '580', '1', '吉林,长春市,农安县', null, null, '220122', 'n', 'nonganxian', 'nax');
INSERT INTO `yc_city` VALUES ('589', '榆树市', '580', '1', '吉林,长春市,榆树市', null, null, '220182', 'y', 'yushushi', 'yss');
INSERT INTO `yc_city` VALUES ('590', '德惠市', '580', '1', '吉林,长春市,德惠市', null, null, '220183', 'd', 'dehuishi', 'dhs');
INSERT INTO `yc_city` VALUES ('591', '吉林市', '579', '1', '吉林,吉林市', null, null, '220200', 'j', 'jilinshi', 'jls');
INSERT INTO `yc_city` VALUES ('592', '昌邑区', '591', '1', '吉林,吉林市,昌邑区', null, null, '220202', 'c', 'changyiqu', 'cyq');
INSERT INTO `yc_city` VALUES ('593', '龙潭区', '591', '1', '吉林,吉林市,龙潭区', null, null, '220203', 'l', 'longtanqu', 'ltq');
INSERT INTO `yc_city` VALUES ('594', '船营区', '591', '1', '吉林,吉林市,船营区', null, null, '220204', 'c', 'chuanyingqu', 'cyq');
INSERT INTO `yc_city` VALUES ('595', '丰满区', '591', '1', '吉林,吉林市,丰满区', null, null, '220211', 'f', 'fengmanqu', 'fmq');
INSERT INTO `yc_city` VALUES ('596', '永吉县', '591', '1', '吉林,吉林市,永吉县', null, null, '220221', 'y', 'yongjixian', 'yjx');
INSERT INTO `yc_city` VALUES ('597', '蛟河市', '591', '1', '吉林,吉林市,蛟河市', null, null, '220281', 'j', 'jiaoheshi', 'hs');
INSERT INTO `yc_city` VALUES ('598', '桦甸市', '591', '1', '吉林,吉林市,桦甸市', null, null, '220282', 'h', 'huadianshi', 'ds');
INSERT INTO `yc_city` VALUES ('599', '舒兰市', '591', '1', '吉林,吉林市,舒兰市', null, null, '220283', 's', 'shulanshi', 'sls');
INSERT INTO `yc_city` VALUES ('600', '磐石市', '591', '1', '吉林,吉林市,磐石市', null, null, '220284', 'p', 'panshishi', 'pss');
INSERT INTO `yc_city` VALUES ('601', '四平市', '579', '1', '吉林,四平市', null, null, '220300', 's', 'sipingshi', 'sps');
INSERT INTO `yc_city` VALUES ('602', '铁西区', '601', '1', '吉林,四平市,铁西区', null, null, '220302', 't', 'tiexiqu', 'txq');
INSERT INTO `yc_city` VALUES ('603', '铁东区', '601', '1', '吉林,四平市,铁东区', null, null, '220303', 't', 'tiedongqu', 'tdq');
INSERT INTO `yc_city` VALUES ('604', '梨树县', '601', '1', '吉林,四平市,梨树县', null, null, '220322', 'l', 'lishuxian', 'lsx');
INSERT INTO `yc_city` VALUES ('605', '伊通满族自治县', '601', '1', '吉林,四平市,伊通满族自治县', null, null, '220323', 'y', 'yitongmanzuzizhixian', 'ytmzzzx');
INSERT INTO `yc_city` VALUES ('606', '公主岭市', '601', '1', '吉林,四平市,公主岭市', null, null, '220381', 'g', 'gongzhulingshi', 'gzls');
INSERT INTO `yc_city` VALUES ('607', '双辽市', '601', '1', '吉林,四平市,双辽市', null, null, '220382', 's', 'shuangliaoshi', 'sls');
INSERT INTO `yc_city` VALUES ('608', '辽源市', '579', '1', '吉林,辽源市', null, null, '220400', 'l', 'liaoyuanshi', 'lys');
INSERT INTO `yc_city` VALUES ('609', '龙山区', '608', '1', '吉林,辽源市,龙山区', null, null, '220402', 'l', 'longshanqu', 'lsq');
INSERT INTO `yc_city` VALUES ('610', '西安区', '608', '1', '吉林,辽源市,西安区', null, null, '220403', 'x', 'xianqu', 'xaq');
INSERT INTO `yc_city` VALUES ('611', '东丰县', '608', '1', '吉林,辽源市,东丰县', null, null, '220421', 'd', 'dongfengxian', 'dfx');
INSERT INTO `yc_city` VALUES ('612', '东辽县', '608', '1', '吉林,辽源市,东辽县', null, null, '220422', 'd', 'dongliaoxian', 'dlx');
INSERT INTO `yc_city` VALUES ('613', '通化市', '579', '1', '吉林,通化市', null, null, '220500', 't', 'tonghuashi', 'ths');
INSERT INTO `yc_city` VALUES ('614', '东昌区', '613', '1', '吉林,通化市,东昌区', null, null, '220502', 'd', 'dongchangqu', 'dcq');
INSERT INTO `yc_city` VALUES ('615', '二道江区', '613', '1', '吉林,通化市,二道江区', null, null, '220503', 'e', 'erdaojiangqu', 'edjq');
INSERT INTO `yc_city` VALUES ('616', '通化县', '613', '1', '吉林,通化市,通化县', null, null, '220521', 't', 'tonghuaxian', 'thx');
INSERT INTO `yc_city` VALUES ('617', '辉南县', '613', '1', '吉林,通化市,辉南县', null, null, '220523', 'h', 'huinanxian', 'hnx');
INSERT INTO `yc_city` VALUES ('618', '柳河县', '613', '1', '吉林,通化市,柳河县', null, null, '220524', 'l', 'liuhexian', 'lhx');
INSERT INTO `yc_city` VALUES ('619', '梅河口市', '613', '1', '吉林,通化市,梅河口市', null, null, '220581', 'm', 'meihekoushi', 'mhks');
INSERT INTO `yc_city` VALUES ('620', '集安市', '613', '1', '吉林,通化市,集安市', null, null, '220582', 'j', 'jianshi', 'jas');
INSERT INTO `yc_city` VALUES ('621', '白山市', '579', '1', '吉林,白山市', null, null, '220600', 'b', 'baishanshi', 'bss');
INSERT INTO `yc_city` VALUES ('622', '浑江区', '621', '1', '吉林,白山市,浑江区', null, null, null, 'h', 'hunjiangqu', 'hjq');
INSERT INTO `yc_city` VALUES ('623', '江源区', '621', '1', '吉林,白山市,江源区', null, null, '220605', 'j', 'jiangyuanqu', 'jyq');
INSERT INTO `yc_city` VALUES ('624', '抚松县', '621', '1', '吉林,白山市,抚松县', null, null, '220621', 'f', 'fusongxian', 'fsx');
INSERT INTO `yc_city` VALUES ('625', '靖宇县', '621', '1', '吉林,白山市,靖宇县', null, null, '220622', 'j', 'jingyuxian', 'jyx');
INSERT INTO `yc_city` VALUES ('626', '长白朝鲜族自治县', '621', '1', '吉林,白山市,长白朝鲜族自治县', null, null, '220623', 'c', 'changbaichaoxianzuzizhixian', 'cbcxzzzx');
INSERT INTO `yc_city` VALUES ('627', '临江市', '621', '1', '吉林,白山市,临江市', null, null, '220681', 'l', 'linjiangshi', 'ljs');
INSERT INTO `yc_city` VALUES ('628', '松原市', '579', '1', '吉林,松原市', null, null, '220700', 's', 'songyuanshi', 'sys');
INSERT INTO `yc_city` VALUES ('629', '宁江区', '628', '1', '吉林,松原市,宁江区', null, null, '220702', 'n', 'ningjiangqu', 'njq');
INSERT INTO `yc_city` VALUES ('630', '前郭尔罗斯蒙古族自治县', '628', '1', '吉林,松原市,前郭尔罗斯蒙古族自治县', null, null, '220721', 'q', 'qianguoerluosimengguzuzizhixian', 'qgelsmgzzzx');
INSERT INTO `yc_city` VALUES ('631', '长岭县', '628', '1', '吉林,松原市,长岭县', null, null, '220722', 'c', 'changlingxian', 'clx');
INSERT INTO `yc_city` VALUES ('632', '乾安县', '628', '1', '吉林,松原市,乾安县', null, null, '220723', 'q', 'qiananxian', 'qax');
INSERT INTO `yc_city` VALUES ('633', '扶余市', '628', '1', '吉林,松原市,扶余市', null, null, null, 'f', 'fuyushi', 'fys');
INSERT INTO `yc_city` VALUES ('634', '白城市', '579', '1', '吉林,白城市', null, null, '220800', 'b', 'baichengshi', 'bcs');
INSERT INTO `yc_city` VALUES ('635', '洮北区', '634', '1', '吉林,白城市,洮北区', null, null, '220802', 't', 'taobeiqu', 'bq');
INSERT INTO `yc_city` VALUES ('636', '镇赉县', '634', '1', '吉林,白城市,镇赉县', null, null, '220821', 'z', 'zhenlaixian', 'zx');
INSERT INTO `yc_city` VALUES ('637', '通榆县', '634', '1', '吉林,白城市,通榆县', null, null, '220822', 't', 'tongyuxian', 'tyx');
INSERT INTO `yc_city` VALUES ('638', '洮南市', '634', '1', '吉林,白城市,洮南市', null, null, '220881', 't', 'taonanshi', 'ns');
INSERT INTO `yc_city` VALUES ('639', '大安市', '634', '1', '吉林,白城市,大安市', null, null, '220882', 'd', 'daanshi', 'das');
INSERT INTO `yc_city` VALUES ('640', '延边朝鲜族自治州', '579', '1', '吉林,延边朝鲜族自治州', null, null, '222400', 'y', 'yanbianchaoxianzuzizhizhou', 'ybcxzzzz');
INSERT INTO `yc_city` VALUES ('641', '延吉市', '640', '1', '吉林,延边朝鲜族自治州,延吉市', null, null, '222401', 'y', 'yanjishi', 'yjs');
INSERT INTO `yc_city` VALUES ('642', '图们市', '640', '1', '吉林,延边朝鲜族自治州,图们市', null, null, '222402', 't', 'tumenshi', 'tms');
INSERT INTO `yc_city` VALUES ('643', '敦化市', '640', '1', '吉林,延边朝鲜族自治州,敦化市', null, null, '222403', 'd', 'dunhuashi', 'dhs');
INSERT INTO `yc_city` VALUES ('644', '珲春市', '640', '1', '吉林,延边朝鲜族自治州,珲春市', null, null, '222404', 'h', 'hunchunshi', 'cs');
INSERT INTO `yc_city` VALUES ('645', '龙井市', '640', '1', '吉林,延边朝鲜族自治州,龙井市', null, null, '222405', 'l', 'longjingshi', 'ljs');
INSERT INTO `yc_city` VALUES ('646', '和龙市', '640', '1', '吉林,延边朝鲜族自治州,和龙市', null, null, '222406', 'h', 'helongshi', 'hls');
INSERT INTO `yc_city` VALUES ('647', '汪清县', '640', '1', '吉林,延边朝鲜族自治州,汪清县', null, null, '222424', 'w', 'wangqingxian', 'wqx');
INSERT INTO `yc_city` VALUES ('648', '安图县', '640', '1', '吉林,延边朝鲜族自治州,安图县', null, null, '222426', 'a', 'antuxian', 'atx');
INSERT INTO `yc_city` VALUES ('649', '黑龙江', '1', '1', '黑龙江', null, null, '230000', 'h', 'heilongjiang', 'hlj');
INSERT INTO `yc_city` VALUES ('650', '哈尔滨市', '649', '1', '黑龙江,哈尔滨市', null, null, '230100', 'h', 'haerbinshi', 'hebs');
INSERT INTO `yc_city` VALUES ('651', '道里区', '650', '1', '黑龙江,哈尔滨市,道里区', null, null, '230102', 'd', 'daoliqu', 'dlq');
INSERT INTO `yc_city` VALUES ('652', '南岗区', '650', '1', '黑龙江,哈尔滨市,南岗区', null, null, '230103', 'n', 'nangangqu', 'ngq');
INSERT INTO `yc_city` VALUES ('653', '道外区', '650', '1', '黑龙江,哈尔滨市,道外区', null, null, '230104', 'd', 'daowaiqu', 'dwq');
INSERT INTO `yc_city` VALUES ('654', '平房区', '650', '1', '黑龙江,哈尔滨市,平房区', null, null, '230108', 'p', 'pingfangqu', 'pfq');
INSERT INTO `yc_city` VALUES ('655', '松北区', '650', '1', '黑龙江,哈尔滨市,松北区', null, null, '230109', 's', 'songbeiqu', 'sbq');
INSERT INTO `yc_city` VALUES ('656', '香坊区', '650', '1', '黑龙江,哈尔滨市,香坊区', null, null, '230110', 'x', 'xiangfangqu', 'xfq');
INSERT INTO `yc_city` VALUES ('657', '呼兰区', '650', '1', '黑龙江,哈尔滨市,呼兰区', null, null, '230111', 'h', 'hulanqu', 'hlq');
INSERT INTO `yc_city` VALUES ('658', '阿城区', '650', '1', '黑龙江,哈尔滨市,阿城区', null, null, '230112', 'a', 'achengqu', 'acq');
INSERT INTO `yc_city` VALUES ('659', '依兰县', '650', '1', '黑龙江,哈尔滨市,依兰县', null, null, '230123', 'y', 'yilanxian', 'ylx');
INSERT INTO `yc_city` VALUES ('660', '方正县', '650', '1', '黑龙江,哈尔滨市,方正县', null, null, '230124', 'f', 'fangzhengxian', 'fzx');
INSERT INTO `yc_city` VALUES ('661', '宾县', '650', '1', '黑龙江,哈尔滨市,宾县', null, null, '230125', 'b', 'binxian', 'bx');
INSERT INTO `yc_city` VALUES ('662', '巴彦县', '650', '1', '黑龙江,哈尔滨市,巴彦县', null, null, '230126', 'b', 'bayanxian', 'byx');
INSERT INTO `yc_city` VALUES ('663', '木兰县', '650', '1', '黑龙江,哈尔滨市,木兰县', null, null, '230127', 'm', 'mulanxian', 'mlx');
INSERT INTO `yc_city` VALUES ('664', '通河县', '650', '1', '黑龙江,哈尔滨市,通河县', null, null, '230128', 't', 'tonghexian', 'thx');
INSERT INTO `yc_city` VALUES ('665', '延寿县', '650', '1', '黑龙江,哈尔滨市,延寿县', null, null, '230129', 'y', 'yanshouxian', 'ysx');
INSERT INTO `yc_city` VALUES ('666', '双城市', '650', '1', '黑龙江,哈尔滨市,双城市', null, null, '230182', 's', 'shuangchengshi', 'scs');
INSERT INTO `yc_city` VALUES ('667', '尚志市', '650', '1', '黑龙江,哈尔滨市,尚志市', null, null, '230183', 's', 'shangzhishi', 'szs');
INSERT INTO `yc_city` VALUES ('668', '五常市', '650', '1', '黑龙江,哈尔滨市,五常市', null, null, '230184', 'w', 'wuchangshi', 'wcs');
INSERT INTO `yc_city` VALUES ('669', '齐齐哈尔市', '649', '1', '黑龙江,齐齐哈尔市', null, null, '230200', 'q', 'qiqihaershi', 'qqhes');
INSERT INTO `yc_city` VALUES ('670', '龙沙区', '669', '1', '黑龙江,齐齐哈尔市,龙沙区', null, null, '230202', 'l', 'longshaqu', 'lsq');
INSERT INTO `yc_city` VALUES ('671', '建华区', '669', '1', '黑龙江,齐齐哈尔市,建华区', null, null, '230203', 'j', 'jianhuaqu', 'jhq');
INSERT INTO `yc_city` VALUES ('672', '铁锋区', '669', '1', '黑龙江,齐齐哈尔市,铁锋区', null, null, '230204', 't', 'tiefengqu', 'tfq');
INSERT INTO `yc_city` VALUES ('673', '昂昂溪区', '669', '1', '黑龙江,齐齐哈尔市,昂昂溪区', null, null, '230205', 'a', 'angangxiqu', 'aaxq');
INSERT INTO `yc_city` VALUES ('674', '富拉尔基区', '669', '1', '黑龙江,齐齐哈尔市,富拉尔基区', null, null, '230206', 'f', 'fulaerjiqu', 'flejq');
INSERT INTO `yc_city` VALUES ('675', '碾子山区', '669', '1', '黑龙江,齐齐哈尔市,碾子山区', null, null, '230207', 'n', 'nianzishanqu', 'nzsq');
INSERT INTO `yc_city` VALUES ('676', '梅里斯达斡尔族区', '669', '1', '黑龙江,齐齐哈尔市,梅里斯达斡尔族区', null, null, '230208', 'm', 'meilisidawoerzuqu', 'mlsdwezq');
INSERT INTO `yc_city` VALUES ('677', '龙江县', '669', '1', '黑龙江,齐齐哈尔市,龙江县', null, null, '230221', 'l', 'longjiangxian', 'ljx');
INSERT INTO `yc_city` VALUES ('678', '依安县', '669', '1', '黑龙江,齐齐哈尔市,依安县', null, null, '230223', 'y', 'yianxian', 'yax');
INSERT INTO `yc_city` VALUES ('679', '泰来县', '669', '1', '黑龙江,齐齐哈尔市,泰来县', null, null, '230224', 't', 'tailaixian', 'tlx');
INSERT INTO `yc_city` VALUES ('680', '甘南县', '669', '1', '黑龙江,齐齐哈尔市,甘南县', null, null, '230225', 'g', 'gannanxian', 'gnx');
INSERT INTO `yc_city` VALUES ('681', '富裕县', '669', '1', '黑龙江,齐齐哈尔市,富裕县', null, null, '230227', 'f', 'fuyuxian', 'fyx');
INSERT INTO `yc_city` VALUES ('682', '克山县', '669', '1', '黑龙江,齐齐哈尔市,克山县', null, null, '230229', 'k', 'keshanxian', 'ksx');
INSERT INTO `yc_city` VALUES ('683', '克东县', '669', '1', '黑龙江,齐齐哈尔市,克东县', null, null, '230230', 'k', 'kedongxian', 'kdx');
INSERT INTO `yc_city` VALUES ('684', '拜泉县', '669', '1', '黑龙江,齐齐哈尔市,拜泉县', null, null, '230231', 'b', 'baiquanxian', 'bqx');
INSERT INTO `yc_city` VALUES ('685', '讷河市', '669', '1', '黑龙江,齐齐哈尔市,讷河市', null, null, '230281', 'n', 'neheshi', 'hs');
INSERT INTO `yc_city` VALUES ('686', '鸡西市', '649', '1', '黑龙江,鸡西市', null, null, '230300', 'j', 'jixishi', 'jxs');
INSERT INTO `yc_city` VALUES ('687', '鸡冠区', '686', '1', '黑龙江,鸡西市,鸡冠区', null, null, '230302', 'j', 'jiguanqu', 'jgq');
INSERT INTO `yc_city` VALUES ('688', '恒山区', '686', '1', '黑龙江,鸡西市,恒山区', null, null, '230303', 'h', 'hengshanqu', 'hsq');
INSERT INTO `yc_city` VALUES ('689', '滴道区', '686', '1', '黑龙江,鸡西市,滴道区', null, null, '230304', 'd', 'didaoqu', 'ddq');
INSERT INTO `yc_city` VALUES ('690', '梨树区', '686', '1', '黑龙江,鸡西市,梨树区', null, null, '230305', 'l', 'lishuqu', 'lsq');
INSERT INTO `yc_city` VALUES ('691', '城子河区', '686', '1', '黑龙江,鸡西市,城子河区', null, null, '230306', 'c', 'chengzihequ', 'czhq');
INSERT INTO `yc_city` VALUES ('692', '麻山区', '686', '1', '黑龙江,鸡西市,麻山区', null, null, '230307', 'm', 'mashanqu', 'msq');
INSERT INTO `yc_city` VALUES ('693', '鸡东县', '686', '1', '黑龙江,鸡西市,鸡东县', null, null, '230321', 'j', 'jidongxian', 'jdx');
INSERT INTO `yc_city` VALUES ('694', '虎林市', '686', '1', '黑龙江,鸡西市,虎林市', null, null, '230381', 'h', 'hulinshi', 'hls');
INSERT INTO `yc_city` VALUES ('695', '密山市', '686', '1', '黑龙江,鸡西市,密山市', null, null, '230382', 'm', 'mishanshi', 'mss');
INSERT INTO `yc_city` VALUES ('696', '鹤岗市', '649', '1', '黑龙江,鹤岗市', null, null, '230400', 'h', 'hegangshi', 'hgs');
INSERT INTO `yc_city` VALUES ('697', '向阳区', '696', '1', '黑龙江,鹤岗市,向阳区', null, null, '230402', 'x', 'xiangyangqu', 'xyq');
INSERT INTO `yc_city` VALUES ('698', '工农区', '696', '1', '黑龙江,鹤岗市,工农区', null, null, '230403', 'g', 'gongnongqu', 'gnq');
INSERT INTO `yc_city` VALUES ('699', '南山区', '696', '1', '黑龙江,鹤岗市,南山区', null, null, '230404', 'n', 'nanshanqu', 'nsq');
INSERT INTO `yc_city` VALUES ('700', '兴安区', '696', '1', '黑龙江,鹤岗市,兴安区', null, null, '230405', 'x', 'xinganqu', 'xaq');
INSERT INTO `yc_city` VALUES ('701', '东山区', '696', '1', '黑龙江,鹤岗市,东山区', null, null, '230406', 'd', 'dongshanqu', 'dsq');
INSERT INTO `yc_city` VALUES ('702', '兴山区', '696', '1', '黑龙江,鹤岗市,兴山区', null, null, '230407', 'x', 'xingshanqu', 'xsq');
INSERT INTO `yc_city` VALUES ('703', '萝北县', '696', '1', '黑龙江,鹤岗市,萝北县', null, null, '230421', 'l', 'luobeixian', 'lbx');
INSERT INTO `yc_city` VALUES ('704', '绥滨县', '696', '1', '黑龙江,鹤岗市,绥滨县', null, null, '230422', 's', 'suibinxian', 'sbx');
INSERT INTO `yc_city` VALUES ('705', '双鸭山市', '649', '1', '黑龙江,双鸭山市', null, null, '230500', 's', 'shuangyashanshi', 'syss');
INSERT INTO `yc_city` VALUES ('706', '尖山区', '705', '1', '黑龙江,双鸭山市,尖山区', null, null, '230502', 'j', 'jianshanqu', 'jsq');
INSERT INTO `yc_city` VALUES ('707', '岭东区', '705', '1', '黑龙江,双鸭山市,岭东区', null, null, '230503', 'l', 'lingdongqu', 'ldq');
INSERT INTO `yc_city` VALUES ('708', '四方台区', '705', '1', '黑龙江,双鸭山市,四方台区', null, null, '230505', 's', 'sifangtaiqu', 'sftq');
INSERT INTO `yc_city` VALUES ('709', '宝山区', '705', '1', '黑龙江,双鸭山市,宝山区', null, null, '230506', 'b', 'baoshanqu', 'bsq');
INSERT INTO `yc_city` VALUES ('710', '集贤县', '705', '1', '黑龙江,双鸭山市,集贤县', null, null, '230521', 'j', 'jixianxian', 'jxx');
INSERT INTO `yc_city` VALUES ('711', '友谊县', '705', '1', '黑龙江,双鸭山市,友谊县', null, null, '230522', 'y', 'youyixian', 'yyx');
INSERT INTO `yc_city` VALUES ('712', '宝清县', '705', '1', '黑龙江,双鸭山市,宝清县', null, null, '230523', 'b', 'baoqingxian', 'bqx');
INSERT INTO `yc_city` VALUES ('713', '饶河县', '705', '1', '黑龙江,双鸭山市,饶河县', null, null, '230524', 'r', 'raohexian', 'rhx');
INSERT INTO `yc_city` VALUES ('714', '大庆市', '649', '1', '黑龙江,大庆市', null, null, '230600', 'd', 'daqingshi', 'dqs');
INSERT INTO `yc_city` VALUES ('715', '萨尔图区', '714', '1', '黑龙江,大庆市,萨尔图区', null, null, '230602', 's', 'saertuqu', 'setq');
INSERT INTO `yc_city` VALUES ('716', '龙凤区', '714', '1', '黑龙江,大庆市,龙凤区', null, null, '230603', 'l', 'longfengqu', 'lfq');
INSERT INTO `yc_city` VALUES ('717', '让胡路区', '714', '1', '黑龙江,大庆市,让胡路区', null, null, '230604', 'r', 'ranghuluqu', 'rhlq');
INSERT INTO `yc_city` VALUES ('718', '红岗区', '714', '1', '黑龙江,大庆市,红岗区', null, null, '230605', 'h', 'honggangqu', 'hgq');
INSERT INTO `yc_city` VALUES ('719', '大同区', '714', '1', '黑龙江,大庆市,大同区', null, null, '230606', 'd', 'datongqu', 'dtq');
INSERT INTO `yc_city` VALUES ('720', '肇州县', '714', '1', '黑龙江,大庆市,肇州县', null, null, '230621', 'z', 'zhaozhouxian', 'zzx');
INSERT INTO `yc_city` VALUES ('721', '肇源县', '714', '1', '黑龙江,大庆市,肇源县', null, null, '230622', 'z', 'zhaoyuanxian', 'zyx');
INSERT INTO `yc_city` VALUES ('722', '林甸县', '714', '1', '黑龙江,大庆市,林甸县', null, null, '230623', 'l', 'lindianxian', 'ldx');
INSERT INTO `yc_city` VALUES ('723', '杜尔伯特蒙古族自治县', '714', '1', '黑龙江,大庆市,杜尔伯特蒙古族自治县', null, null, '230624', 'd', 'duerbotemengguzuzizhixian', 'debtmgzzzx');
INSERT INTO `yc_city` VALUES ('724', '伊春市', '649', '1', '黑龙江,伊春市', null, null, '230700', 'y', 'yichunshi', 'ycs');
INSERT INTO `yc_city` VALUES ('725', '伊春区', '724', '1', '黑龙江,伊春市,伊春区', null, null, '230702', 'y', 'yichunqu', 'ycq');
INSERT INTO `yc_city` VALUES ('726', '南岔区', '724', '1', '黑龙江,伊春市,南岔区', null, null, '230703', 'n', 'nanchaqu', 'ncq');
INSERT INTO `yc_city` VALUES ('727', '友好区', '724', '1', '黑龙江,伊春市,友好区', null, null, '230704', 'y', 'youhaoqu', 'yhq');
INSERT INTO `yc_city` VALUES ('728', '西林区', '724', '1', '黑龙江,伊春市,西林区', null, null, '230705', 'x', 'xilinqu', 'xlq');
INSERT INTO `yc_city` VALUES ('729', '翠峦区', '724', '1', '黑龙江,伊春市,翠峦区', null, null, '230706', 'c', 'cuiluanqu', 'clq');
INSERT INTO `yc_city` VALUES ('730', '新青区', '724', '1', '黑龙江,伊春市,新青区', null, null, '230707', 'x', 'xinqingqu', 'xqq');
INSERT INTO `yc_city` VALUES ('731', '美溪区', '724', '1', '黑龙江,伊春市,美溪区', null, null, '230708', 'm', 'meixiqu', 'mxq');
INSERT INTO `yc_city` VALUES ('732', '金山屯区', '724', '1', '黑龙江,伊春市,金山屯区', null, null, '230709', 'j', 'jinshanzhunqu', 'jstq');
INSERT INTO `yc_city` VALUES ('733', '五营区', '724', '1', '黑龙江,伊春市,五营区', null, null, '230710', 'w', 'wuyingqu', 'wyq');
INSERT INTO `yc_city` VALUES ('734', '乌马河区', '724', '1', '黑龙江,伊春市,乌马河区', null, null, '230711', 'w', 'wumahequ', 'wmhq');
INSERT INTO `yc_city` VALUES ('735', '汤旺河区', '724', '1', '黑龙江,伊春市,汤旺河区', null, null, '230712', 't', 'tangwanghequ', 'twhq');
INSERT INTO `yc_city` VALUES ('736', '带岭区', '724', '1', '黑龙江,伊春市,带岭区', null, null, '230713', 'd', 'dailingqu', 'dlq');
INSERT INTO `yc_city` VALUES ('737', '乌伊岭区', '724', '1', '黑龙江,伊春市,乌伊岭区', null, null, '230714', 'w', 'wuyilingqu', 'wylq');
INSERT INTO `yc_city` VALUES ('738', '红星区', '724', '1', '黑龙江,伊春市,红星区', null, null, '230715', 'h', 'hongxingqu', 'hxq');
INSERT INTO `yc_city` VALUES ('739', '上甘岭区', '724', '1', '黑龙江,伊春市,上甘岭区', null, null, '230716', 's', 'shangganlingqu', 'sglq');
INSERT INTO `yc_city` VALUES ('740', '嘉荫县', '724', '1', '黑龙江,伊春市,嘉荫县', null, null, '230722', 'j', 'jiayinxian', 'jyx');
INSERT INTO `yc_city` VALUES ('741', '铁力市', '724', '1', '黑龙江,伊春市,铁力市', null, null, '230781', 't', 'tielishi', 'tls');
INSERT INTO `yc_city` VALUES ('742', '佳木斯市', '649', '1', '黑龙江,佳木斯市', null, null, '230800', 'j', 'jiamusishi', 'jmss');
INSERT INTO `yc_city` VALUES ('743', '向阳区', '742', '1', '黑龙江,佳木斯市,向阳区', null, null, '230803', 'x', 'xiangyangqu', 'xyq');
INSERT INTO `yc_city` VALUES ('744', '前进区', '742', '1', '黑龙江,佳木斯市,前进区', null, null, '230804', 'q', 'qianjinqu', 'qjq');
INSERT INTO `yc_city` VALUES ('745', '东风区', '742', '1', '黑龙江,佳木斯市,东风区', null, null, '230805', 'd', 'dongfengqu', 'dfq');
INSERT INTO `yc_city` VALUES ('746', '郊区', '742', '1', '黑龙江,佳木斯市,郊区', null, null, '230811', 'j', 'jiaoqu', 'jq');
INSERT INTO `yc_city` VALUES ('747', '桦南县', '742', '1', '黑龙江,佳木斯市,桦南县', null, null, '230822', 'h', 'huananxian', 'nx');
INSERT INTO `yc_city` VALUES ('748', '桦川县', '742', '1', '黑龙江,佳木斯市,桦川县', null, null, '230826', 'h', 'huachuanxian', 'cx');
INSERT INTO `yc_city` VALUES ('749', '汤原县', '742', '1', '黑龙江,佳木斯市,汤原县', null, null, '230828', 't', 'tangyuanxian', 'tyx');
INSERT INTO `yc_city` VALUES ('750', '抚远县', '742', '1', '黑龙江,佳木斯市,抚远县', null, null, '230833', 'f', 'fuyuanxian', 'fyx');
INSERT INTO `yc_city` VALUES ('751', '同江市', '742', '1', '黑龙江,佳木斯市,同江市', null, null, '230881', 't', 'tongjiangshi', 'tjs');
INSERT INTO `yc_city` VALUES ('752', '富锦市', '742', '1', '黑龙江,佳木斯市,富锦市', null, null, '230882', 'f', 'fujinshi', 'fjs');
INSERT INTO `yc_city` VALUES ('753', '七台河市', '649', '1', '黑龙江,七台河市', null, null, '230900', 'q', 'qitaiheshi', 'qths');
INSERT INTO `yc_city` VALUES ('754', '新兴区', '753', '1', '黑龙江,七台河市,新兴区', null, null, '230902', 'x', 'xinxingqu', 'xxq');
INSERT INTO `yc_city` VALUES ('755', '桃山区', '753', '1', '黑龙江,七台河市,桃山区', null, null, '230903', 't', 'taoshanqu', 'tsq');
INSERT INTO `yc_city` VALUES ('756', '茄子河区', '753', '1', '黑龙江,七台河市,茄子河区', null, null, '230904', 'q', 'qiezihequ', 'qzhq');
INSERT INTO `yc_city` VALUES ('757', '勃利县', '753', '1', '黑龙江,七台河市,勃利县', null, null, '230921', 'b', 'bolixian', 'blx');
INSERT INTO `yc_city` VALUES ('758', '牡丹江市', '649', '1', '黑龙江,牡丹江市', null, null, '231000', 'm', 'mudanjiangshi', 'mdjs');
INSERT INTO `yc_city` VALUES ('759', '东安区', '758', '1', '黑龙江,牡丹江市,东安区', null, null, '231002', 'd', 'donganqu', 'daq');
INSERT INTO `yc_city` VALUES ('760', '阳明区', '758', '1', '黑龙江,牡丹江市,阳明区', null, null, '231003', 'y', 'yangmingqu', 'ymq');
INSERT INTO `yc_city` VALUES ('761', '爱民区', '758', '1', '黑龙江,牡丹江市,爱民区', null, null, '231004', 'a', 'aiminqu', 'amq');
INSERT INTO `yc_city` VALUES ('762', '西安区', '758', '1', '黑龙江,牡丹江市,西安区', null, null, '231005', 'x', 'xianqu', 'xaq');
INSERT INTO `yc_city` VALUES ('763', '东宁县', '758', '1', '黑龙江,牡丹江市,东宁县', null, null, '231024', 'd', 'dongningxian', 'dnx');
INSERT INTO `yc_city` VALUES ('764', '林口县', '758', '1', '黑龙江,牡丹江市,林口县', null, null, '231025', 'l', 'linkouxian', 'lkx');
INSERT INTO `yc_city` VALUES ('765', '绥芬河市', '758', '1', '黑龙江,牡丹江市,绥芬河市', null, null, '231081', 's', 'suifenheshi', 'sfhs');
INSERT INTO `yc_city` VALUES ('766', '海林市', '758', '1', '黑龙江,牡丹江市,海林市', null, null, '231083', 'h', 'hailinshi', 'hls');
INSERT INTO `yc_city` VALUES ('767', '宁安市', '758', '1', '黑龙江,牡丹江市,宁安市', null, null, '231084', 'n', 'ninganshi', 'nas');
INSERT INTO `yc_city` VALUES ('768', '穆棱市', '758', '1', '黑龙江,牡丹江市,穆棱市', null, null, '231085', 'm', 'mulingshi', 'mls');
INSERT INTO `yc_city` VALUES ('769', '黑河市', '649', '1', '黑龙江,黑河市', null, null, '231100', 'h', 'heiheshi', 'hhs');
INSERT INTO `yc_city` VALUES ('770', '爱辉区', '769', '1', '黑龙江,黑河市,爱辉区', null, null, '231102', 'a', 'aihuiqu', 'ahq');
INSERT INTO `yc_city` VALUES ('771', '嫩江县', '769', '1', '黑龙江,黑河市,嫩江县', null, null, '231121', 'n', 'nenjiangxian', 'njx');
INSERT INTO `yc_city` VALUES ('772', '逊克县', '769', '1', '黑龙江,黑河市,逊克县', null, null, '231123', 'x', 'xunkexian', 'xkx');
INSERT INTO `yc_city` VALUES ('773', '孙吴县', '769', '1', '黑龙江,黑河市,孙吴县', null, null, '231124', 's', 'sunwuxian', 'swx');
INSERT INTO `yc_city` VALUES ('774', '北安市', '769', '1', '黑龙江,黑河市,北安市', null, null, '231181', 'b', 'beianshi', 'bas');
INSERT INTO `yc_city` VALUES ('775', '五大连池市', '769', '1', '黑龙江,黑河市,五大连池市', null, null, '231182', 'w', 'wudalianchishi', 'wdlcs');
INSERT INTO `yc_city` VALUES ('776', '绥化市', '649', '1', '黑龙江,绥化市', null, null, '231200', 's', 'suihuashi', 'shs');
INSERT INTO `yc_city` VALUES ('777', '北林区', '776', '1', '黑龙江,绥化市,北林区', null, null, '231202', 'b', 'beilinqu', 'blq');
INSERT INTO `yc_city` VALUES ('778', '望奎县', '776', '1', '黑龙江,绥化市,望奎县', null, null, '231221', 'w', 'wangkuixian', 'wkx');
INSERT INTO `yc_city` VALUES ('779', '兰西县', '776', '1', '黑龙江,绥化市,兰西县', null, null, '231222', 'l', 'lanxixian', 'lxx');
INSERT INTO `yc_city` VALUES ('780', '青冈县', '776', '1', '黑龙江,绥化市,青冈县', null, null, '231223', 'q', 'qinggangxian', 'qgx');
INSERT INTO `yc_city` VALUES ('781', '庆安县', '776', '1', '黑龙江,绥化市,庆安县', null, null, '231224', 'q', 'qinganxian', 'qax');
INSERT INTO `yc_city` VALUES ('782', '明水县', '776', '1', '黑龙江,绥化市,明水县', null, null, '231225', 'm', 'mingshuixian', 'msx');
INSERT INTO `yc_city` VALUES ('783', '绥棱县', '776', '1', '黑龙江,绥化市,绥棱县', null, null, '231226', 's', 'suilengxian', 'slx');
INSERT INTO `yc_city` VALUES ('784', '安达市', '776', '1', '黑龙江,绥化市,安达市', null, null, '231281', 'a', 'andashi', 'ads');
INSERT INTO `yc_city` VALUES ('785', '肇东市', '776', '1', '黑龙江,绥化市,肇东市', null, null, '231282', 'z', 'zhaodongshi', 'zds');
INSERT INTO `yc_city` VALUES ('786', '海伦市', '776', '1', '黑龙江,绥化市,海伦市', null, null, '231283', 'h', 'hailunshi', 'hls');
INSERT INTO `yc_city` VALUES ('787', '大兴安岭地区', '649', '1', '黑龙江,大兴安岭地区', null, null, '232700', 'd', 'daxinganlingdiqu', 'dxaldq');
INSERT INTO `yc_city` VALUES ('788', '呼玛县', '787', '1', '黑龙江,大兴安岭地区,呼玛县', null, null, '232721', 'h', 'humaxian', 'hmx');
INSERT INTO `yc_city` VALUES ('789', '塔河县', '787', '1', '黑龙江,大兴安岭地区,塔河县', null, null, '232722', 't', 'tahexian', 'thx');
INSERT INTO `yc_city` VALUES ('790', '漠河县', '787', '1', '黑龙江,大兴安岭地区,漠河县', null, null, '232723', 'm', 'mohexian', 'mhx');
INSERT INTO `yc_city` VALUES ('791', '上海', '1', '1', '上海', null, null, '310000', 's', 'shanghai', 'sh');
INSERT INTO `yc_city` VALUES ('792', '黄浦区', '791', '1', '上海,黄浦区', null, null, '310101', 'h', 'huangpuqu', 'hpq');
INSERT INTO `yc_city` VALUES ('793', '徐汇区', '791', '1', '上海,徐汇区', null, null, '310104', 'x', 'xuhuiqu', 'xhq');
INSERT INTO `yc_city` VALUES ('794', '长宁区', '791', '1', '上海,长宁区', null, null, '310105', 'c', 'changningqu', 'cnq');
INSERT INTO `yc_city` VALUES ('795', '静安区', '791', '1', '上海,静安区', null, null, '310106', 'j', 'jinganqu', 'jaq');
INSERT INTO `yc_city` VALUES ('796', '普陀区', '791', '1', '上海,普陀区', null, null, '310107', 'p', 'putuoqu', 'ptq');
INSERT INTO `yc_city` VALUES ('797', '闸北区', '791', '1', '上海,闸北区', null, null, '310108', 'z', 'zhabeiqu', 'zbq');
INSERT INTO `yc_city` VALUES ('798', '虹口区', '791', '1', '上海,虹口区', null, null, '310109', 'h', 'hongkouqu', 'hkq');
INSERT INTO `yc_city` VALUES ('799', '杨浦区', '791', '1', '上海,杨浦区', null, null, '310110', 'y', 'yangpuqu', 'ypq');
INSERT INTO `yc_city` VALUES ('800', '闵行区', '791', '1', '上海,闵行区', null, null, '310112', 'm', 'minhangqu', 'xq');
INSERT INTO `yc_city` VALUES ('801', '宝山区', '791', '1', '上海,宝山区', null, null, '310113', 'b', 'baoshanqu', 'bsq');
INSERT INTO `yc_city` VALUES ('802', '嘉定区', '791', '1', '上海,嘉定区', null, null, '310114', 'j', 'jiadingqu', 'jdq');
INSERT INTO `yc_city` VALUES ('803', '浦东新区', '791', '1', '上海,浦东新区', null, null, '310115', 'p', 'pudongxinqu', 'pdxq');
INSERT INTO `yc_city` VALUES ('804', '金山区', '791', '1', '上海,金山区', null, null, '310116', 'j', 'jinshanqu', 'jsq');
INSERT INTO `yc_city` VALUES ('805', '松江区', '791', '1', '上海,松江区', null, null, '310117', 's', 'songjiangqu', 'sjq');
INSERT INTO `yc_city` VALUES ('806', '青浦区', '791', '1', '上海,青浦区', null, null, '310118', 'q', 'qingpuqu', 'qpq');
INSERT INTO `yc_city` VALUES ('807', '奉贤区', '791', '1', '上海,奉贤区', null, null, '310120', 'f', 'fengxianqu', 'fxq');
INSERT INTO `yc_city` VALUES ('808', '崇明县', '791', '1', '上海,崇明县', null, null, '310230', 'c', 'chongmingxian', 'cmx');
INSERT INTO `yc_city` VALUES ('809', '江苏', '1', '1', '江苏', null, null, '320000', 'j', 'jiangsu', 'js');
INSERT INTO `yc_city` VALUES ('810', '南京市', '809', '1', '江苏,南京市', null, null, '320100', 'n', 'nanjingshi', 'njs');
INSERT INTO `yc_city` VALUES ('811', '玄武区', '810', '1', '江苏,南京市,玄武区', null, null, '320102', 'x', 'xuanwuqu', 'xwq');
INSERT INTO `yc_city` VALUES ('812', '秦淮区', '810', '1', '江苏,南京市,秦淮区', null, null, '320104', 'q', 'qinhuaiqu', 'qhq');
INSERT INTO `yc_city` VALUES ('813', '建邺区', '810', '1', '江苏,南京市,建邺区', null, null, '320105', 'j', 'jianyequ', 'jq');
INSERT INTO `yc_city` VALUES ('814', '鼓楼区', '810', '1', '江苏,南京市,鼓楼区', null, null, '320106', 'g', 'gulouqu', 'glq');
INSERT INTO `yc_city` VALUES ('815', '浦口区', '810', '1', '江苏,南京市,浦口区', null, null, '320111', 'p', 'pukouqu', 'pkq');
INSERT INTO `yc_city` VALUES ('816', '栖霞区', '810', '1', '江苏,南京市,栖霞区', null, null, '320113', 'q', 'qixiaqu', 'qxq');
INSERT INTO `yc_city` VALUES ('817', '雨花台区', '810', '1', '江苏,南京市,雨花台区', null, null, '320114', 'y', 'yuhuataiqu', 'yhtq');
INSERT INTO `yc_city` VALUES ('818', '江宁区', '810', '1', '江苏,南京市,江宁区', null, null, '320115', 'j', 'jiangningqu', 'jnq');
INSERT INTO `yc_city` VALUES ('819', '六合区', '810', '1', '江苏,南京市,六合区', null, null, '320116', 'l', 'luhequ', 'lhq');
INSERT INTO `yc_city` VALUES ('820', '溧水区', '810', '1', '江苏,南京市,溧水区', null, null, null, 'l', 'lishuiqu', 'sq');
INSERT INTO `yc_city` VALUES ('821', '高淳区', '810', '1', '江苏,南京市,高淳区', null, null, null, 'g', 'gaochunqu', 'gcq');
INSERT INTO `yc_city` VALUES ('822', '无锡市', '809', '1', '江苏,无锡市', null, null, '320200', 'w', 'wuxishi', 'wxs');
INSERT INTO `yc_city` VALUES ('823', '崇安区', '822', '1', '江苏,无锡市,崇安区', null, null, '320202', 'c', 'chonganqu', 'caq');
INSERT INTO `yc_city` VALUES ('824', '南长区', '822', '1', '江苏,无锡市,南长区', null, null, '320203', 'n', 'nanchangqu', 'ncq');
INSERT INTO `yc_city` VALUES ('825', '北塘区', '822', '1', '江苏,无锡市,北塘区', null, null, '320204', 'b', 'beitangqu', 'btq');
INSERT INTO `yc_city` VALUES ('826', '锡山区', '822', '1', '江苏,无锡市,锡山区', null, null, '320205', 'x', 'xishanqu', 'xsq');
INSERT INTO `yc_city` VALUES ('827', '惠山区', '822', '1', '江苏,无锡市,惠山区', null, null, '320206', 'h', 'huishanqu', 'hsq');
INSERT INTO `yc_city` VALUES ('828', '滨湖区', '822', '1', '江苏,无锡市,滨湖区', null, null, '320211', 'b', 'binhuqu', 'bhq');
INSERT INTO `yc_city` VALUES ('829', '江阴市', '822', '1', '江苏,无锡市,江阴市', null, null, '320281', 'j', 'jiangyinshi', 'jys');
INSERT INTO `yc_city` VALUES ('830', '宜兴市', '822', '1', '江苏,无锡市,宜兴市', null, null, '320282', 'y', 'yixingshi', 'yxs');
INSERT INTO `yc_city` VALUES ('831', '徐州市', '809', '1', '江苏,徐州市', null, null, '320300', 'x', 'xuzhoushi', 'xzs');
INSERT INTO `yc_city` VALUES ('832', '鼓楼区', '831', '1', '江苏,徐州市,鼓楼区', null, null, '320302', 'g', 'gulouqu', 'glq');
INSERT INTO `yc_city` VALUES ('833', '云龙区', '831', '1', '江苏,徐州市,云龙区', null, null, '320303', 'y', 'yunlongqu', 'ylq');
INSERT INTO `yc_city` VALUES ('834', '贾汪区', '831', '1', '江苏,徐州市,贾汪区', null, null, '320305', 'j', 'jiawangqu', 'jwq');
INSERT INTO `yc_city` VALUES ('835', '泉山区', '831', '1', '江苏,徐州市,泉山区', null, null, '320311', 'q', 'quanshanqu', 'qsq');
INSERT INTO `yc_city` VALUES ('836', '铜山区', '831', '1', '江苏,徐州市,铜山区', null, null, null, 't', 'tongshanqu', 'tsq');
INSERT INTO `yc_city` VALUES ('837', '丰县', '831', '1', '江苏,徐州市,丰县', null, null, '320321', 'f', 'fengxian', 'fx');
INSERT INTO `yc_city` VALUES ('838', '沛县', '831', '1', '江苏,徐州市,沛县', null, null, '320322', 'p', 'peixian', 'px');
INSERT INTO `yc_city` VALUES ('839', '睢宁县', '831', '1', '江苏,徐州市,睢宁县', null, null, '320324', 's', 'suiningxian', 'nx');
INSERT INTO `yc_city` VALUES ('840', '新沂市', '831', '1', '江苏,徐州市,新沂市', null, null, '320381', 'x', 'xinyishi', 'xys');
INSERT INTO `yc_city` VALUES ('841', '邳州市', '831', '1', '江苏,徐州市,邳州市', null, null, '320382', 'p', 'pizhoushi', 'zs');
INSERT INTO `yc_city` VALUES ('842', '常州市', '809', '1', '江苏,常州市', null, null, '320400', 'c', 'changzhoushi', 'czs');
INSERT INTO `yc_city` VALUES ('843', '天宁区', '842', '1', '江苏,常州市,天宁区', null, null, '320402', 't', 'tianningqu', 'tnq');
INSERT INTO `yc_city` VALUES ('844', '钟楼区', '842', '1', '江苏,常州市,钟楼区', null, null, '320404', 'z', 'zhonglouqu', 'zlq');
INSERT INTO `yc_city` VALUES ('845', '戚墅堰区', '842', '1', '江苏,常州市,戚墅堰区', null, null, '320405', 'q', 'qishuyanqu', 'qsyq');
INSERT INTO `yc_city` VALUES ('846', '新北区', '842', '1', '江苏,常州市,新北区', null, null, '320411', 'x', 'xinbeiqu', 'xbq');
INSERT INTO `yc_city` VALUES ('847', '武进区', '842', '1', '江苏,常州市,武进区', null, null, '320412', 'w', 'wujinqu', 'wjq');
INSERT INTO `yc_city` VALUES ('848', '溧阳市', '842', '1', '江苏,常州市,溧阳市', null, null, '320481', 'l', 'liyangshi', 'ys');
INSERT INTO `yc_city` VALUES ('849', '金坛市', '842', '1', '江苏,常州市,金坛市', null, null, '320482', 'j', 'jintanshi', 'jts');
INSERT INTO `yc_city` VALUES ('850', '苏州市', '809', '1', '江苏,苏州市', null, null, '320500', 's', 'suzhoushi', 'szs');
INSERT INTO `yc_city` VALUES ('851', '虎丘区', '850', '1', '江苏,苏州市,虎丘区', null, null, '320505', 'h', 'huqiuqu', 'hqq');
INSERT INTO `yc_city` VALUES ('852', '吴中区', '850', '1', '江苏,苏州市,吴中区', null, null, '320506', 'w', 'wuzhongqu', 'wzq');
INSERT INTO `yc_city` VALUES ('853', '相城区', '850', '1', '江苏,苏州市,相城区', null, null, '320507', 'x', 'xiangchengqu', 'xcq');
INSERT INTO `yc_city` VALUES ('854', '姑苏区', '850', '1', '江苏,苏州市,姑苏区', null, null, null, 'g', 'gusuqu', 'gsq');
INSERT INTO `yc_city` VALUES ('855', '吴江区', '850', '1', '江苏,苏州市,吴江区', null, null, '320584', 'w', 'wujiangqu', 'wjq');
INSERT INTO `yc_city` VALUES ('856', '常熟市', '850', '1', '江苏,苏州市,常熟市', null, null, '320581', 'c', 'changshushi', 'css');
INSERT INTO `yc_city` VALUES ('857', '张家港市', '850', '1', '江苏,苏州市,张家港市', null, null, '320582', 'z', 'zhangjiagangshi', 'zjgs');
INSERT INTO `yc_city` VALUES ('858', '昆山市', '850', '1', '江苏,苏州市,昆山市', null, null, '320583', 'k', 'kunshanshi', 'kss');
INSERT INTO `yc_city` VALUES ('859', '太仓市', '850', '1', '江苏,苏州市,太仓市', null, null, '320585', 't', 'taicangshi', 'tcs');
INSERT INTO `yc_city` VALUES ('860', '南通市', '809', '1', '江苏,南通市', null, null, '320600', 'n', 'nantongshi', 'nts');
INSERT INTO `yc_city` VALUES ('861', '崇川区', '860', '1', '江苏,南通市,崇川区', null, null, '320602', 'c', 'chongchuanqu', 'ccq');
INSERT INTO `yc_city` VALUES ('862', '港闸区', '860', '1', '江苏,南通市,港闸区', null, null, '320611', 'g', 'gangzhaqu', 'gzq');
INSERT INTO `yc_city` VALUES ('863', '通州区', '860', '1', '江苏,南通市,通州区', null, null, '320683', 't', 'tongzhouqu', 'tzq');
INSERT INTO `yc_city` VALUES ('864', '海安县', '860', '1', '江苏,南通市,海安县', null, null, '320621', 'h', 'haianxian', 'hax');
INSERT INTO `yc_city` VALUES ('865', '如东县', '860', '1', '江苏,南通市,如东县', null, null, '320623', 'r', 'rudongxian', 'rdx');
INSERT INTO `yc_city` VALUES ('866', '启东市', '860', '1', '江苏,南通市,启东市', null, null, '320681', 'q', 'qidongshi', 'qds');
INSERT INTO `yc_city` VALUES ('867', '如皋市', '860', '1', '江苏,南通市,如皋市', null, null, '320682', 'r', 'rugaoshi', 'rgs');
INSERT INTO `yc_city` VALUES ('868', '海门市', '860', '1', '江苏,南通市,海门市', null, null, '320684', 'h', 'haimenshi', 'hms');
INSERT INTO `yc_city` VALUES ('869', '连云港市', '809', '1', '江苏,连云港市', null, null, '320700', 'l', 'lianyungangshi', 'lygs');
INSERT INTO `yc_city` VALUES ('870', '连云区', '869', '1', '江苏,连云港市,连云区', null, null, '320703', 'l', 'lianyunqu', 'lyq');
INSERT INTO `yc_city` VALUES ('871', '海州区', '869', '1', '江苏,连云港市,海州区', null, null, '320706', 'h', 'haizhouqu', 'hzq');
INSERT INTO `yc_city` VALUES ('872', '赣榆区', '869', '1', '江苏,连云港市,赣榆区', null, null, null, 'g', 'ganyuqu', 'gyq');
INSERT INTO `yc_city` VALUES ('873', '东海县', '869', '1', '江苏,连云港市,东海县', null, null, '320722', 'd', 'donghaixian', 'dhx');
INSERT INTO `yc_city` VALUES ('874', '灌云县', '869', '1', '江苏,连云港市,灌云县', null, null, '320723', 'g', 'guanyunxian', 'gyx');
INSERT INTO `yc_city` VALUES ('875', '灌南县', '869', '1', '江苏,连云港市,灌南县', null, null, '320724', 'g', 'guannanxian', 'gnx');
INSERT INTO `yc_city` VALUES ('876', '淮安市', '809', '1', '江苏,淮安市', null, null, '320800', 'h', 'huaianshi', 'has');
INSERT INTO `yc_city` VALUES ('877', '清河区', '876', '1', '江苏,淮安市,清河区', null, null, '320802', 'q', 'qinghequ', 'qhq');
INSERT INTO `yc_city` VALUES ('878', '淮安区', '876', '1', '江苏,淮安市,淮安区', null, null, null, 'h', 'huaianqu', 'haq');
INSERT INTO `yc_city` VALUES ('879', '淮阴区', '876', '1', '江苏,淮安市,淮阴区', null, null, '320804', 'h', 'huaiyinqu', 'hyq');
INSERT INTO `yc_city` VALUES ('880', '清浦区', '876', '1', '江苏,淮安市,清浦区', null, null, '320811', 'q', 'qingpuqu', 'qpq');
INSERT INTO `yc_city` VALUES ('881', '涟水县', '876', '1', '江苏,淮安市,涟水县', null, null, '320826', 'l', 'lianshuixian', 'lsx');
INSERT INTO `yc_city` VALUES ('882', '洪泽县', '876', '1', '江苏,淮安市,洪泽县', null, null, '320829', 'h', 'hongzexian', 'hzx');
INSERT INTO `yc_city` VALUES ('883', '盱眙县', '876', '1', '江苏,淮安市,盱眙县', null, null, '320830', 'x', 'xuyixian', 'x');
INSERT INTO `yc_city` VALUES ('884', '金湖县', '876', '1', '江苏,淮安市,金湖县', null, null, '320831', 'j', 'jinhuxian', 'jhx');
INSERT INTO `yc_city` VALUES ('885', '盐城市', '809', '1', '江苏,盐城市', null, null, '320900', 'y', 'yanchengshi', 'ycs');
INSERT INTO `yc_city` VALUES ('886', '亭湖区', '885', '1', '江苏,盐城市,亭湖区', null, null, '320902', 't', 'tinghuqu', 'thq');
INSERT INTO `yc_city` VALUES ('887', '盐都区', '885', '1', '江苏,盐城市,盐都区', null, null, '320903', 'y', 'yanduqu', 'ydq');
INSERT INTO `yc_city` VALUES ('888', '响水县', '885', '1', '江苏,盐城市,响水县', null, null, '320921', 'x', 'xiangshuixian', 'xsx');
INSERT INTO `yc_city` VALUES ('889', '滨海县', '885', '1', '江苏,盐城市,滨海县', null, null, '320922', 'b', 'binhaixian', 'bhx');
INSERT INTO `yc_city` VALUES ('890', '阜宁县', '885', '1', '江苏,盐城市,阜宁县', null, null, '320923', 'f', 'funingxian', 'fnx');
INSERT INTO `yc_city` VALUES ('891', '射阳县', '885', '1', '江苏,盐城市,射阳县', null, null, '320924', 's', 'sheyangxian', 'syx');
INSERT INTO `yc_city` VALUES ('892', '建湖县', '885', '1', '江苏,盐城市,建湖县', null, null, '320925', 'j', 'jianhuxian', 'jhx');
INSERT INTO `yc_city` VALUES ('893', '东台市', '885', '1', '江苏,盐城市,东台市', null, null, '320981', 'd', 'dongtaishi', 'dts');
INSERT INTO `yc_city` VALUES ('894', '大丰市', '885', '1', '江苏,盐城市,大丰市', null, null, '320982', 'd', 'dafengshi', 'dfs');
INSERT INTO `yc_city` VALUES ('895', '扬州市', '809', '1', '江苏,扬州市', null, null, '321000', 'y', 'yangzhoushi', 'yzs');
INSERT INTO `yc_city` VALUES ('896', '广陵区', '895', '1', '江苏,扬州市,广陵区', null, null, '321002', 'g', 'guanglingqu', 'glq');
INSERT INTO `yc_city` VALUES ('897', '邗江区', '895', '1', '江苏,扬州市,邗江区', null, null, '321003', 'h', 'hanjiangqu', 'jq');
INSERT INTO `yc_city` VALUES ('898', '江都区', '895', '1', '江苏,扬州市,江都区', null, null, '321088', 'j', 'jiangduqu', 'jdq');
INSERT INTO `yc_city` VALUES ('899', '宝应县', '895', '1', '江苏,扬州市,宝应县', null, null, '321023', 'b', 'baoyingxian', 'byx');
INSERT INTO `yc_city` VALUES ('900', '仪征市', '895', '1', '江苏,扬州市,仪征市', null, null, '321081', 'y', 'yizhengshi', 'yzs');
INSERT INTO `yc_city` VALUES ('901', '高邮市', '895', '1', '江苏,扬州市,高邮市', null, null, '321084', 'g', 'gaoyoushi', 'gys');
INSERT INTO `yc_city` VALUES ('902', '镇江市', '809', '1', '江苏,镇江市', null, null, '321100', 'z', 'zhenjiangshi', 'zjs');
INSERT INTO `yc_city` VALUES ('903', '京口区', '902', '1', '江苏,镇江市,京口区', null, null, '321102', 'j', 'jingkouqu', 'jkq');
INSERT INTO `yc_city` VALUES ('904', '润州区', '902', '1', '江苏,镇江市,润州区', null, null, '321111', 'r', 'runzhouqu', 'rzq');
INSERT INTO `yc_city` VALUES ('905', '丹徒区', '902', '1', '江苏,镇江市,丹徒区', null, null, '321112', 'd', 'dantuqu', 'dtq');
INSERT INTO `yc_city` VALUES ('906', '丹阳市', '902', '1', '江苏,镇江市,丹阳市', null, null, '321181', 'd', 'danyangshi', 'dys');
INSERT INTO `yc_city` VALUES ('907', '扬中市', '902', '1', '江苏,镇江市,扬中市', null, null, '321182', 'y', 'yangzhongshi', 'yzs');
INSERT INTO `yc_city` VALUES ('908', '句容市', '902', '1', '江苏,镇江市,句容市', null, null, '321183', 'j', 'jurongshi', 'jrs');
INSERT INTO `yc_city` VALUES ('909', '泰州市', '809', '1', '江苏,泰州市', null, null, '321200', 't', 'taizhoushi', 'tzs');
INSERT INTO `yc_city` VALUES ('910', '海陵区', '909', '1', '江苏,泰州市,海陵区', null, null, '321202', 'h', 'hailingqu', 'hlq');
INSERT INTO `yc_city` VALUES ('911', '高港区', '909', '1', '江苏,泰州市,高港区', null, null, '321203', 'g', 'gaogangqu', 'ggq');
INSERT INTO `yc_city` VALUES ('912', '姜堰区', '909', '1', '江苏,泰州市,姜堰区', null, null, '321284', 'j', 'jiangyanqu', 'jyq');
INSERT INTO `yc_city` VALUES ('913', '兴化市', '909', '1', '江苏,泰州市,兴化市', null, null, '321281', 'x', 'xinghuashi', 'xhs');
INSERT INTO `yc_city` VALUES ('914', '靖江市', '909', '1', '江苏,泰州市,靖江市', null, null, '321282', 'j', 'jingjiangshi', 'jjs');
INSERT INTO `yc_city` VALUES ('915', '泰兴市', '909', '1', '江苏,泰州市,泰兴市', null, null, '321283', 't', 'taixingshi', 'txs');
INSERT INTO `yc_city` VALUES ('916', '宿迁市', '809', '1', '江苏,宿迁市', null, null, '321300', 's', 'suqianshi', 'sqs');
INSERT INTO `yc_city` VALUES ('917', '宿城区', '916', '1', '江苏,宿迁市,宿城区', null, null, '321302', 's', 'suchengqu', 'scq');
INSERT INTO `yc_city` VALUES ('918', '宿豫区', '916', '1', '江苏,宿迁市,宿豫区', null, null, '321311', 's', 'suyuqu', 'syq');
INSERT INTO `yc_city` VALUES ('919', '沭阳县', '916', '1', '江苏,宿迁市,沭阳县', null, null, '321322', 's', 'shuyangxian', 'yx');
INSERT INTO `yc_city` VALUES ('920', '泗阳县', '916', '1', '江苏,宿迁市,泗阳县', null, null, '321323', 's', 'siyangxian', 'yx');
INSERT INTO `yc_city` VALUES ('921', '泗洪县', '916', '1', '江苏,宿迁市,泗洪县', null, null, '321324', 's', 'sihongxian', 'hx');
INSERT INTO `yc_city` VALUES ('922', '浙江', '1', '1', '浙江', null, null, '330000', 'z', 'zhejiang', 'zj');
INSERT INTO `yc_city` VALUES ('923', '杭州市', '922', '1', '浙江,杭州市', null, null, '330100', 'h', 'hangzhoushi', 'hzs');
INSERT INTO `yc_city` VALUES ('924', '上城区', '923', '1', '浙江,杭州市,上城区', null, null, '330102', 's', 'shangchengqu', 'scq');
INSERT INTO `yc_city` VALUES ('925', '下城区', '923', '1', '浙江,杭州市,下城区', null, null, '330103', 'x', 'xiachengqu', 'xcq');
INSERT INTO `yc_city` VALUES ('926', '江干区', '923', '1', '浙江,杭州市,江干区', null, null, '330104', 'j', 'jiangganqu', 'jgq');
INSERT INTO `yc_city` VALUES ('927', '拱墅区', '923', '1', '浙江,杭州市,拱墅区', null, null, '330105', 'g', 'gongshuqu', 'gsq');
INSERT INTO `yc_city` VALUES ('928', '西湖区', '923', '1', '浙江,杭州市,西湖区', null, null, '330106', 'x', 'xihuqu', 'xhq');
INSERT INTO `yc_city` VALUES ('929', '滨江区', '923', '1', '浙江,杭州市,滨江区', null, null, '330108', 'b', 'binjiangqu', 'bjq');
INSERT INTO `yc_city` VALUES ('930', '萧山区', '923', '1', '浙江,杭州市,萧山区', null, null, '330109', 'x', 'xiaoshanqu', 'xsq');
INSERT INTO `yc_city` VALUES ('931', '余杭区', '923', '1', '浙江,杭州市,余杭区', null, null, '330110', 'y', 'yuhangqu', 'yhq');
INSERT INTO `yc_city` VALUES ('932', '桐庐县', '923', '1', '浙江,杭州市,桐庐县', null, null, '330122', 't', 'tongluxian', 'tlx');
INSERT INTO `yc_city` VALUES ('933', '淳安县', '923', '1', '浙江,杭州市,淳安县', null, null, '330127', 'c', 'chunanxian', 'cax');
INSERT INTO `yc_city` VALUES ('934', '建德市', '923', '1', '浙江,杭州市,建德市', null, null, '330182', 'j', 'jiandeshi', 'jds');
INSERT INTO `yc_city` VALUES ('935', '富阳市', '923', '1', '浙江,杭州市,富阳市', null, null, '330183', 'f', 'fuyangshi', 'fys');
INSERT INTO `yc_city` VALUES ('936', '临安市', '923', '1', '浙江,杭州市,临安市', null, null, '330185', 'l', 'linanshi', 'las');
INSERT INTO `yc_city` VALUES ('937', '宁波市', '922', '1', '浙江,宁波市', null, null, '330200', 'n', 'ningboshi', 'nbs');
INSERT INTO `yc_city` VALUES ('938', '海曙区', '937', '1', '浙江,宁波市,海曙区', null, null, '330203', 'h', 'haishuqu', 'hsq');
INSERT INTO `yc_city` VALUES ('939', '江东区', '937', '1', '浙江,宁波市,江东区', null, null, '330204', 'j', 'jiangdongqu', 'jdq');
INSERT INTO `yc_city` VALUES ('940', '江北区', '937', '1', '浙江,宁波市,江北区', null, null, '330205', 'j', 'jiangbeiqu', 'jbq');
INSERT INTO `yc_city` VALUES ('941', '北仑区', '937', '1', '浙江,宁波市,北仑区', null, null, '330206', 'b', 'beilunqu', 'blq');
INSERT INTO `yc_city` VALUES ('942', '镇海区', '937', '1', '浙江,宁波市,镇海区', null, null, '330211', 'z', 'zhenhaiqu', 'zhq');
INSERT INTO `yc_city` VALUES ('943', '鄞州区', '937', '1', '浙江,宁波市,鄞州区', null, null, '330212', 'y', 'yinzhouqu', 'zq');
INSERT INTO `yc_city` VALUES ('944', '象山县', '937', '1', '浙江,宁波市,象山县', null, null, '330225', 'x', 'xiangshanxian', 'xsx');
INSERT INTO `yc_city` VALUES ('945', '宁海县', '937', '1', '浙江,宁波市,宁海县', null, null, '330226', 'n', 'ninghaixian', 'nhx');
INSERT INTO `yc_city` VALUES ('946', '余姚市', '937', '1', '浙江,宁波市,余姚市', null, null, '330281', 'y', 'yuyaoshi', 'yys');
INSERT INTO `yc_city` VALUES ('947', '慈溪市', '937', '1', '浙江,宁波市,慈溪市', null, null, '330282', 'c', 'cixishi', 'cxs');
INSERT INTO `yc_city` VALUES ('948', '奉化市', '937', '1', '浙江,宁波市,奉化市', null, null, '330283', 'f', 'fenghuashi', 'fhs');
INSERT INTO `yc_city` VALUES ('949', '温州市', '922', '1', '浙江,温州市', null, null, '330300', 'w', 'wenzhoushi', 'wzs');
INSERT INTO `yc_city` VALUES ('950', '鹿城区', '949', '1', '浙江,温州市,鹿城区', null, null, '330302', 'l', 'luchengqu', 'lcq');
INSERT INTO `yc_city` VALUES ('951', '龙湾区', '949', '1', '浙江,温州市,龙湾区', null, null, '330303', 'l', 'longwanqu', 'lwq');
INSERT INTO `yc_city` VALUES ('952', '瓯海区', '949', '1', '浙江,温州市,瓯海区', null, null, '330304', 'o', 'ouhaiqu', 'hq');
INSERT INTO `yc_city` VALUES ('953', '洞头县', '949', '1', '浙江,温州市,洞头县', null, null, '330322', 'd', 'dongtouxian', 'dtx');
INSERT INTO `yc_city` VALUES ('954', '永嘉县', '949', '1', '浙江,温州市,永嘉县', null, null, '330324', 'y', 'yongjiaxian', 'yjx');
INSERT INTO `yc_city` VALUES ('955', '平阳县', '949', '1', '浙江,温州市,平阳县', null, null, '330326', 'p', 'pingyangxian', 'pyx');
INSERT INTO `yc_city` VALUES ('956', '苍南县', '949', '1', '浙江,温州市,苍南县', null, null, '330327', 'c', 'cangnanxian', 'cnx');
INSERT INTO `yc_city` VALUES ('957', '文成县', '949', '1', '浙江,温州市,文成县', null, null, '330328', 'w', 'wenchengxian', 'wcx');
INSERT INTO `yc_city` VALUES ('958', '泰顺县', '949', '1', '浙江,温州市,泰顺县', null, null, '330329', 't', 'taishunxian', 'tsx');
INSERT INTO `yc_city` VALUES ('959', '瑞安市', '949', '1', '浙江,温州市,瑞安市', null, null, '330381', 'r', 'ruianshi', 'ras');
INSERT INTO `yc_city` VALUES ('960', '乐清市', '949', '1', '浙江,温州市,乐清市', null, null, '330382', 'y', 'yueqingshi', 'lqs');
INSERT INTO `yc_city` VALUES ('961', '嘉兴市', '922', '1', '浙江,嘉兴市', null, null, '330400', 'j', 'jiaxingshi', 'jxs');
INSERT INTO `yc_city` VALUES ('962', '南湖区', '961', '1', '浙江,嘉兴市,南湖区', null, null, '330402', 'n', 'nanhuqu', 'nhq');
INSERT INTO `yc_city` VALUES ('963', '秀洲区', '961', '1', '浙江,嘉兴市,秀洲区', null, null, '330411', 'x', 'xiuzhouqu', 'xzq');
INSERT INTO `yc_city` VALUES ('964', '嘉善县', '961', '1', '浙江,嘉兴市,嘉善县', null, null, '330421', 'j', 'jiashanxian', 'jsx');
INSERT INTO `yc_city` VALUES ('965', '海盐县', '961', '1', '浙江,嘉兴市,海盐县', null, null, '330424', 'h', 'haiyanxian', 'hyx');
INSERT INTO `yc_city` VALUES ('966', '海宁市', '961', '1', '浙江,嘉兴市,海宁市', null, null, '330481', 'h', 'hainingshi', 'hns');
INSERT INTO `yc_city` VALUES ('967', '平湖市', '961', '1', '浙江,嘉兴市,平湖市', null, null, '330482', 'p', 'pinghushi', 'phs');
INSERT INTO `yc_city` VALUES ('968', '桐乡市', '961', '1', '浙江,嘉兴市,桐乡市', null, null, '330483', 't', 'tongxiangshi', 'txs');
INSERT INTO `yc_city` VALUES ('969', '湖州市', '922', '1', '浙江,湖州市', null, null, '330500', 'h', 'huzhoushi', 'hzs');
INSERT INTO `yc_city` VALUES ('970', '吴兴区', '969', '1', '浙江,湖州市,吴兴区', null, null, '330502', 'w', 'wuxingqu', 'wxq');
INSERT INTO `yc_city` VALUES ('971', '南浔区', '969', '1', '浙江,湖州市,南浔区', null, null, '330503', 'n', 'nanxunqu', 'nq');
INSERT INTO `yc_city` VALUES ('972', '德清县', '969', '1', '浙江,湖州市,德清县', null, null, '330521', 'd', 'deqingxian', 'dqx');
INSERT INTO `yc_city` VALUES ('973', '长兴县', '969', '1', '浙江,湖州市,长兴县', null, null, '330522', 'c', 'changxingxian', 'cxx');
INSERT INTO `yc_city` VALUES ('974', '安吉县', '969', '1', '浙江,湖州市,安吉县', null, null, '330523', 'a', 'anjixian', 'ajx');
INSERT INTO `yc_city` VALUES ('975', '绍兴市', '922', '1', '浙江,绍兴市', null, null, '330600', 's', 'shaoxingshi', 'sxs');
INSERT INTO `yc_city` VALUES ('976', '越城区', '975', '1', '浙江,绍兴市,越城区', null, null, '330602', 'y', 'yuechengqu', 'ycq');
INSERT INTO `yc_city` VALUES ('977', '柯桥区', '975', '1', '浙江,绍兴市,柯桥区', null, null, '330603', 'k', 'keqiaoqu', 'kqq');
INSERT INTO `yc_city` VALUES ('978', '上虞区', '975', '1', '浙江,绍兴市,上虞区', null, null, '330682', 's', 'shangyuqu', 'syq');
INSERT INTO `yc_city` VALUES ('979', '新昌县', '975', '1', '浙江,绍兴市,新昌县', null, null, '330624', 'x', 'xinchangxian', 'xcx');
INSERT INTO `yc_city` VALUES ('980', '诸暨市', '975', '1', '浙江,绍兴市,诸暨市', null, null, '330681', 'z', 'zhujishi', 'zs');
INSERT INTO `yc_city` VALUES ('981', '嵊州市', '975', '1', '浙江,绍兴市,嵊州市', null, null, '330683', 's', 'shengzhoushi', 'zs');
INSERT INTO `yc_city` VALUES ('982', '金华市', '922', '1', '浙江,金华市', null, null, '330700', 'j', 'jinhuashi', 'jhs');
INSERT INTO `yc_city` VALUES ('983', '婺城区', '982', '1', '浙江,金华市,婺城区', null, null, '330702', 'w', 'wuchengqu', 'cq');
INSERT INTO `yc_city` VALUES ('984', '金东区', '982', '1', '浙江,金华市,金东区', null, null, '330703', 'j', 'jindongqu', 'jdq');
INSERT INTO `yc_city` VALUES ('985', '武义县', '982', '1', '浙江,金华市,武义县', null, null, '330723', 'w', 'wuyixian', 'wyx');
INSERT INTO `yc_city` VALUES ('986', '浦江县', '982', '1', '浙江,金华市,浦江县', null, null, '330726', 'p', 'pujiangxian', 'pjx');
INSERT INTO `yc_city` VALUES ('987', '磐安县', '982', '1', '浙江,金华市,磐安县', null, null, '330727', 'p', 'pananxian', 'pax');
INSERT INTO `yc_city` VALUES ('988', '兰溪市', '982', '1', '浙江,金华市,兰溪市', null, null, '330781', 'l', 'lanxishi', 'lxs');
INSERT INTO `yc_city` VALUES ('989', '义乌市', '982', '1', '浙江,金华市,义乌市', null, null, '330782', 'y', 'yiwushi', 'yws');
INSERT INTO `yc_city` VALUES ('990', '东阳市', '982', '1', '浙江,金华市,东阳市', null, null, '330783', 'd', 'dongyangshi', 'dys');
INSERT INTO `yc_city` VALUES ('991', '永康市', '982', '1', '浙江,金华市,永康市', null, null, '330784', 'y', 'yongkangshi', 'yks');
INSERT INTO `yc_city` VALUES ('992', '衢州市', '922', '1', '浙江,衢州市', null, null, '330800', 'q', 'quzhoushi', 'zs');
INSERT INTO `yc_city` VALUES ('993', '柯城区', '992', '1', '浙江,衢州市,柯城区', null, null, '330802', 'k', 'kechengqu', 'kcq');
INSERT INTO `yc_city` VALUES ('994', '衢江区', '992', '1', '浙江,衢州市,衢江区', null, null, '330803', 'q', 'qujiangqu', 'jq');
INSERT INTO `yc_city` VALUES ('995', '常山县', '992', '1', '浙江,衢州市,常山县', null, null, '330822', 'c', 'changshanxian', 'csx');
INSERT INTO `yc_city` VALUES ('996', '开化县', '992', '1', '浙江,衢州市,开化县', null, null, '330824', 'k', 'kaihuaxian', 'khx');
INSERT INTO `yc_city` VALUES ('997', '龙游县', '992', '1', '浙江,衢州市,龙游县', null, null, '330825', 'l', 'longyouxian', 'lyx');
INSERT INTO `yc_city` VALUES ('998', '江山市', '992', '1', '浙江,衢州市,江山市', null, null, '330881', 'j', 'jiangshanshi', 'jss');
INSERT INTO `yc_city` VALUES ('999', '舟山市', '922', '1', '浙江,舟山市', null, null, '330900', 'z', 'zhoushanshi', 'zss');
INSERT INTO `yc_city` VALUES ('1000', '定海区', '999', '1', '浙江,舟山市,定海区', null, null, '330902', 'd', 'dinghaiqu', 'dhq');
INSERT INTO `yc_city` VALUES ('1001', '普陀区', '999', '1', '浙江,舟山市,普陀区', null, null, '330903', 'p', 'putuoqu', 'ptq');
INSERT INTO `yc_city` VALUES ('1002', '岱山县', '999', '1', '浙江,舟山市,岱山县', null, null, '330921', 'd', 'daishanxian', 'sx');
INSERT INTO `yc_city` VALUES ('1003', '嵊泗县', '999', '1', '浙江,舟山市,嵊泗县', null, null, '330922', 's', 'shengsixian', 'x');
INSERT INTO `yc_city` VALUES ('1004', '台州市', '922', '1', '浙江,台州市', null, null, '331000', 't', 'taizhoushi', 'tzs');
INSERT INTO `yc_city` VALUES ('1005', '椒江区', '1004', '1', '浙江,台州市,椒江区', null, null, '331002', 'j', 'jiaojiangqu', 'jjq');
INSERT INTO `yc_city` VALUES ('1006', '黄岩区', '1004', '1', '浙江,台州市,黄岩区', null, null, '331003', 'h', 'huangyanqu', 'hyq');
INSERT INTO `yc_city` VALUES ('1007', '路桥区', '1004', '1', '浙江,台州市,路桥区', null, null, '331004', 'l', 'luqiaoqu', 'lqq');
INSERT INTO `yc_city` VALUES ('1008', '玉环县', '1004', '1', '浙江,台州市,玉环县', null, null, '331021', 'y', 'yuhuanxian', 'yhx');
INSERT INTO `yc_city` VALUES ('1009', '三门县', '1004', '1', '浙江,台州市,三门县', null, null, '331022', 's', 'sanmenxian', 'smx');
INSERT INTO `yc_city` VALUES ('1010', '天台县', '1004', '1', '浙江,台州市,天台县', null, null, '331023', 't', 'tiantaixian', 'ttx');
INSERT INTO `yc_city` VALUES ('1011', '仙居县', '1004', '1', '浙江,台州市,仙居县', null, null, '331024', 'x', 'xianjuxian', 'xjx');
INSERT INTO `yc_city` VALUES ('1012', '温岭市', '1004', '1', '浙江,台州市,温岭市', null, null, '331081', 'w', 'wenlingshi', 'wls');
INSERT INTO `yc_city` VALUES ('1013', '临海市', '1004', '1', '浙江,台州市,临海市', null, null, '331082', 'l', 'linhaishi', 'lhs');
INSERT INTO `yc_city` VALUES ('1014', '丽水市', '922', '1', '浙江,丽水市', null, null, '331100', 'l', 'lishuishi', 'lss');
INSERT INTO `yc_city` VALUES ('1015', '莲都区', '1014', '1', '浙江,丽水市,莲都区', null, null, '331102', 'l', 'lianduqu', 'ldq');
INSERT INTO `yc_city` VALUES ('1016', '青田县', '1014', '1', '浙江,丽水市,青田县', null, null, '331121', 'q', 'qingtianxian', 'qtx');
INSERT INTO `yc_city` VALUES ('1017', '缙云县', '1014', '1', '浙江,丽水市,缙云县', null, null, '331122', 'j', 'jinyunxian', 'yx');
INSERT INTO `yc_city` VALUES ('1018', '遂昌县', '1014', '1', '浙江,丽水市,遂昌县', null, null, '331123', 's', 'suichangxian', 'scx');
INSERT INTO `yc_city` VALUES ('1019', '松阳县', '1014', '1', '浙江,丽水市,松阳县', null, null, '331124', 's', 'songyangxian', 'syx');
INSERT INTO `yc_city` VALUES ('1020', '云和县', '1014', '1', '浙江,丽水市,云和县', null, null, '331125', 'y', 'yunhexian', 'yhx');
INSERT INTO `yc_city` VALUES ('1021', '庆元县', '1014', '1', '浙江,丽水市,庆元县', null, null, '331126', 'q', 'qingyuanxian', 'qyx');
INSERT INTO `yc_city` VALUES ('1022', '景宁畲族自治县', '1014', '1', '浙江,丽水市,景宁畲族自治县', null, null, '331127', 'j', 'jingningshezuzizhixian', 'jnzzzx');
INSERT INTO `yc_city` VALUES ('1023', '龙泉市', '1014', '1', '浙江,丽水市,龙泉市', null, null, '331181', 'l', 'longquanshi', 'lqs');
INSERT INTO `yc_city` VALUES ('1024', '安徽', '1', '1', '安徽', null, null, '340000', 'a', 'anhui', 'ah');
INSERT INTO `yc_city` VALUES ('1025', '合肥市', '1024', '1', '安徽,合肥市', null, null, '340100', 'h', 'hefeishi', 'hfs');
INSERT INTO `yc_city` VALUES ('1026', '瑶海区', '1025', '1', '安徽,合肥市,瑶海区', null, null, '340102', 'y', 'yaohaiqu', 'yhq');
INSERT INTO `yc_city` VALUES ('1027', '庐阳区', '1025', '1', '安徽,合肥市,庐阳区', null, null, '340103', 'l', 'luyangqu', 'lyq');
INSERT INTO `yc_city` VALUES ('1028', '蜀山区', '1025', '1', '安徽,合肥市,蜀山区', null, null, '340104', 's', 'shushanqu', 'ssq');
INSERT INTO `yc_city` VALUES ('1029', '包河区', '1025', '1', '安徽,合肥市,包河区', null, null, '340111', 'b', 'baohequ', 'bhq');
INSERT INTO `yc_city` VALUES ('1030', '长丰县', '1025', '1', '安徽,合肥市,长丰县', null, null, '340121', 'c', 'changfengxian', 'cfx');
INSERT INTO `yc_city` VALUES ('1031', '肥东县', '1025', '1', '安徽,合肥市,肥东县', null, null, '340122', 'f', 'feidongxian', 'fdx');
INSERT INTO `yc_city` VALUES ('1032', '肥西县', '1025', '1', '安徽,合肥市,肥西县', null, null, '340123', 'f', 'feixixian', 'fxx');
INSERT INTO `yc_city` VALUES ('1033', '庐江县', '1025', '1', '安徽,合肥市,庐江县', null, null, '341421', 'l', 'lujiangxian', 'ljx');
INSERT INTO `yc_city` VALUES ('1034', '巢湖市', '1025', '1', '安徽,合肥市,巢湖市', null, null, '341402', 'c', 'chaohushi', 'chs');
INSERT INTO `yc_city` VALUES ('1035', '芜湖市', '1024', '1', '安徽,芜湖市', null, null, '340200', 'w', 'wuhushi', 'whs');
INSERT INTO `yc_city` VALUES ('1036', '镜湖区', '1035', '1', '安徽,芜湖市,镜湖区', null, null, '340202', 'j', 'jinghuqu', 'jhq');
INSERT INTO `yc_city` VALUES ('1037', '弋江区', '1035', '1', '安徽,芜湖市,弋江区', null, null, '340203', 'y', 'yijiangqu', 'jq');
INSERT INTO `yc_city` VALUES ('1038', '鸠江区', '1035', '1', '安徽,芜湖市,鸠江区', null, null, '340207', 'j', 'jiujiangqu', 'jq');
INSERT INTO `yc_city` VALUES ('1039', '三山区', '1035', '1', '安徽,芜湖市,三山区', null, null, '340208', 's', 'sanshanqu', 'ssq');
INSERT INTO `yc_city` VALUES ('1040', '芜湖县', '1035', '1', '安徽,芜湖市,芜湖县', null, null, '340221', 'w', 'wuhuxian', 'whx');
INSERT INTO `yc_city` VALUES ('1041', '繁昌县', '1035', '1', '安徽,芜湖市,繁昌县', null, null, '340222', 'f', 'fanchangxian', 'fcx');
INSERT INTO `yc_city` VALUES ('1042', '南陵县', '1035', '1', '安徽,芜湖市,南陵县', null, null, '340223', 'n', 'nanlingxian', 'nlx');
INSERT INTO `yc_city` VALUES ('1043', '无为县', '1035', '1', '安徽,芜湖市,无为县', null, null, null, 'w', 'wuweixian', 'wwx');
INSERT INTO `yc_city` VALUES ('1044', '蚌埠市', '1024', '1', '安徽,蚌埠市', null, null, '340300', 'b', 'bengbushi', 'bbs');
INSERT INTO `yc_city` VALUES ('1045', '龙子湖区', '1044', '1', '安徽,蚌埠市,龙子湖区', null, null, '340302', 'l', 'longzihuqu', 'lzhq');
INSERT INTO `yc_city` VALUES ('1046', '蚌山区', '1044', '1', '安徽,蚌埠市,蚌山区', null, null, '340303', 'b', 'bengshanqu', 'bsq');
INSERT INTO `yc_city` VALUES ('1047', '禹会区', '1044', '1', '安徽,蚌埠市,禹会区', null, null, '340304', 'y', 'yuhuiqu', 'yhq');
INSERT INTO `yc_city` VALUES ('1048', '淮上区', '1044', '1', '安徽,蚌埠市,淮上区', null, null, '340311', 'h', 'huaishangqu', 'hsq');
INSERT INTO `yc_city` VALUES ('1049', '怀远县', '1044', '1', '安徽,蚌埠市,怀远县', null, null, '340321', 'h', 'huaiyuanxian', 'hyx');
INSERT INTO `yc_city` VALUES ('1050', '五河县', '1044', '1', '安徽,蚌埠市,五河县', null, null, '340322', 'w', 'wuhexian', 'whx');
INSERT INTO `yc_city` VALUES ('1051', '固镇县', '1044', '1', '安徽,蚌埠市,固镇县', null, null, '340323', 'g', 'guzhenxian', 'gzx');
INSERT INTO `yc_city` VALUES ('1052', '淮南市', '1024', '1', '安徽,淮南市', null, null, '340400', 'h', 'huainanshi', 'hns');
INSERT INTO `yc_city` VALUES ('1053', '大通区', '1052', '1', '安徽,淮南市,大通区', null, null, '340402', 'd', 'datongqu', 'dtq');
INSERT INTO `yc_city` VALUES ('1054', '田家庵区', '1052', '1', '安徽,淮南市,田家庵区', null, null, '340403', 't', 'tianjiaanqu', 'tjq');
INSERT INTO `yc_city` VALUES ('1055', '谢家集区', '1052', '1', '安徽,淮南市,谢家集区', null, null, '340404', 'x', 'xiejiajiqu', 'xjjq');
INSERT INTO `yc_city` VALUES ('1056', '八公山区', '1052', '1', '安徽,淮南市,八公山区', null, null, '340405', 'b', 'bagongshanqu', 'bgsq');
INSERT INTO `yc_city` VALUES ('1057', '潘集区', '1052', '1', '安徽,淮南市,潘集区', null, null, '340406', 'p', 'panjiqu', 'pjq');
INSERT INTO `yc_city` VALUES ('1058', '凤台县', '1052', '1', '安徽,淮南市,凤台县', null, null, '340421', 'f', 'fengtaixian', 'ftx');
INSERT INTO `yc_city` VALUES ('1059', '马鞍山市', '1024', '1', '安徽,马鞍山市', null, null, '340500', 'm', 'maanshanshi', 'mass');
INSERT INTO `yc_city` VALUES ('1060', '花山区', '1059', '1', '安徽,马鞍山市,花山区', null, null, '340503', 'h', 'huashanqu', 'hsq');
INSERT INTO `yc_city` VALUES ('1061', '雨山区', '1059', '1', '安徽,马鞍山市,雨山区', null, null, '340504', 'y', 'yushanqu', 'ysq');
INSERT INTO `yc_city` VALUES ('1062', '博望区', '1059', '1', '安徽,马鞍山市,博望区', null, null, '340502', 'b', 'bowangqu', 'bwq');
INSERT INTO `yc_city` VALUES ('1063', '当涂县', '1059', '1', '安徽,马鞍山市,当涂县', null, null, '340521', 'd', 'dangtuxian', 'dtx');
INSERT INTO `yc_city` VALUES ('1064', '含山县', '1059', '1', '安徽,马鞍山市,含山县', null, null, '341423', 'h', 'hanshanxian', 'hsx');
INSERT INTO `yc_city` VALUES ('1065', '和县', '1059', '1', '安徽,马鞍山市,和县', null, null, '341424', 'h', 'hexian', 'hx');
INSERT INTO `yc_city` VALUES ('1066', '淮北市', '1024', '1', '安徽,淮北市', null, null, '340600', 'h', 'huaibeishi', 'hbs');
INSERT INTO `yc_city` VALUES ('1067', '杜集区', '1066', '1', '安徽,淮北市,杜集区', null, null, '340602', 'd', 'dujiqu', 'djq');
INSERT INTO `yc_city` VALUES ('1068', '相山区', '1066', '1', '安徽,淮北市,相山区', null, null, '340603', 'x', 'xiangshanqu', 'xsq');
INSERT INTO `yc_city` VALUES ('1069', '烈山区', '1066', '1', '安徽,淮北市,烈山区', null, null, '340604', 'l', 'lieshanqu', 'lsq');
INSERT INTO `yc_city` VALUES ('1070', '濉溪县', '1066', '1', '安徽,淮北市,濉溪县', null, null, '340621', 's', 'suixixian', 'xx');
INSERT INTO `yc_city` VALUES ('1071', '铜陵市', '1024', '1', '安徽,铜陵市', null, null, '340700', 't', 'tonglingshi', 'tls');
INSERT INTO `yc_city` VALUES ('1072', '铜官山区', '1071', '1', '安徽,铜陵市,铜官山区', null, null, '340702', 't', 'tongguanshanqu', 'tgsq');
INSERT INTO `yc_city` VALUES ('1073', '狮子山区', '1071', '1', '安徽,铜陵市,狮子山区', null, null, '340703', 's', 'shizishanqu', 'szsq');
INSERT INTO `yc_city` VALUES ('1074', '郊区', '1071', '1', '安徽,铜陵市,郊区', null, null, '340711', 'j', 'jiaoqu', 'jq');
INSERT INTO `yc_city` VALUES ('1075', '铜陵县', '1071', '1', '安徽,铜陵市,铜陵县', null, null, '340721', 't', 'tonglingxian', 'tlx');
INSERT INTO `yc_city` VALUES ('1076', '安庆市', '1024', '1', '安徽,安庆市', null, null, '340800', 'a', 'anqingshi', 'aqs');
INSERT INTO `yc_city` VALUES ('1077', '迎江区', '1076', '1', '安徽,安庆市,迎江区', null, null, '340802', 'y', 'yingjiangqu', 'yjq');
INSERT INTO `yc_city` VALUES ('1078', '大观区', '1076', '1', '安徽,安庆市,大观区', null, null, '340803', 'd', 'daguanqu', 'dgq');
INSERT INTO `yc_city` VALUES ('1079', '宜秀区', '1076', '1', '安徽,安庆市,宜秀区', null, null, '340811', 'y', 'yixiuqu', 'yxq');
INSERT INTO `yc_city` VALUES ('1080', '怀宁县', '1076', '1', '安徽,安庆市,怀宁县', null, null, '340822', 'h', 'huainingxian', 'hnx');
INSERT INTO `yc_city` VALUES ('1081', '枞阳县', '1076', '1', '安徽,安庆市,枞阳县', null, null, '340823', 'z', 'zongyangxian', 'yx');
INSERT INTO `yc_city` VALUES ('1082', '潜山县', '1076', '1', '安徽,安庆市,潜山县', null, null, '340824', 'q', 'qianshanxian', 'qsx');
INSERT INTO `yc_city` VALUES ('1083', '太湖县', '1076', '1', '安徽,安庆市,太湖县', null, null, '340825', 't', 'taihuxian', 'thx');
INSERT INTO `yc_city` VALUES ('1084', '宿松县', '1076', '1', '安徽,安庆市,宿松县', null, null, '340826', 's', 'susongxian', 'ssx');
INSERT INTO `yc_city` VALUES ('1085', '望江县', '1076', '1', '安徽,安庆市,望江县', null, null, '340827', 'w', 'wangjiangxian', 'wjx');
INSERT INTO `yc_city` VALUES ('1086', '岳西县', '1076', '1', '安徽,安庆市,岳西县', null, null, '340828', 'y', 'yuexixian', 'yxx');
INSERT INTO `yc_city` VALUES ('1087', '桐城市', '1076', '1', '安徽,安庆市,桐城市', null, null, '340881', 't', 'tongchengshi', 'tcs');
INSERT INTO `yc_city` VALUES ('1088', '黄山市', '1024', '1', '安徽,黄山市', null, null, '341000', 'h', 'huangshanshi', 'hss');
INSERT INTO `yc_city` VALUES ('1089', '屯溪区', '1088', '1', '安徽,黄山市,屯溪区', null, null, '341002', 't', 'tunxiqu', 'txq');
INSERT INTO `yc_city` VALUES ('1090', '黄山区', '1088', '1', '安徽,黄山市,黄山区', null, null, '341003', 'h', 'huangshanqu', 'hsq');
INSERT INTO `yc_city` VALUES ('1091', '徽州区', '1088', '1', '安徽,黄山市,徽州区', null, null, '341004', 'h', 'huizhouqu', 'hzq');
INSERT INTO `yc_city` VALUES ('1092', '歙县', '1088', '1', '安徽,黄山市,歙县', null, null, '341021', 's', 'shexian', 'x');
INSERT INTO `yc_city` VALUES ('1093', '休宁县', '1088', '1', '安徽,黄山市,休宁县', null, null, '341022', 'x', 'xiuningxian', 'xnx');
INSERT INTO `yc_city` VALUES ('1094', '黟县', '1088', '1', '安徽,黄山市,黟县', null, null, '341023', 'y', 'yixian', 'x');
INSERT INTO `yc_city` VALUES ('1095', '祁门县', '1088', '1', '安徽,黄山市,祁门县', null, null, '341024', 'q', 'qimenxian', 'qmx');
INSERT INTO `yc_city` VALUES ('1096', '滁州市', '1024', '1', '安徽,滁州市', null, null, '341100', 'c', 'chuzhoushi', 'czs');
INSERT INTO `yc_city` VALUES ('1097', '琅琊区', '1096', '1', '安徽,滁州市,琅琊区', null, null, '341102', 'l', 'langyaqu', 'lq');
INSERT INTO `yc_city` VALUES ('1098', '南谯区', '1096', '1', '安徽,滁州市,南谯区', null, null, '341103', 'n', 'nanqiaoqu', 'nq');
INSERT INTO `yc_city` VALUES ('1099', '来安县', '1096', '1', '安徽,滁州市,来安县', null, null, '341122', 'l', 'laianxian', 'lax');
INSERT INTO `yc_city` VALUES ('1100', '全椒县', '1096', '1', '安徽,滁州市,全椒县', null, null, '341124', 'q', 'quanjiaoxian', 'qjx');
INSERT INTO `yc_city` VALUES ('1101', '定远县', '1096', '1', '安徽,滁州市,定远县', null, null, '341125', 'd', 'dingyuanxian', 'dyx');
INSERT INTO `yc_city` VALUES ('1102', '凤阳县', '1096', '1', '安徽,滁州市,凤阳县', null, null, '341126', 'f', 'fengyangxian', 'fyx');
INSERT INTO `yc_city` VALUES ('1103', '天长市', '1096', '1', '安徽,滁州市,天长市', null, null, '341181', 't', 'tianchangshi', 'tcs');
INSERT INTO `yc_city` VALUES ('1104', '明光市', '1096', '1', '安徽,滁州市,明光市', null, null, '341182', 'm', 'mingguangshi', 'mgs');
INSERT INTO `yc_city` VALUES ('1105', '阜阳市', '1024', '1', '安徽,阜阳市', null, null, '341200', 'f', 'fuyangshi', 'fys');
INSERT INTO `yc_city` VALUES ('1106', '颍州区', '1105', '1', '安徽,阜阳市,颍州区', null, null, '341202', 'y', 'yingzhouqu', 'zq');
INSERT INTO `yc_city` VALUES ('1107', '颍东区', '1105', '1', '安徽,阜阳市,颍东区', null, null, '341203', 'y', 'yingdongqu', 'dq');
INSERT INTO `yc_city` VALUES ('1108', '颍泉区', '1105', '1', '安徽,阜阳市,颍泉区', null, null, '341204', 'y', 'yingquanqu', 'qq');
INSERT INTO `yc_city` VALUES ('1109', '临泉县', '1105', '1', '安徽,阜阳市,临泉县', null, null, '341221', 'l', 'linquanxian', 'lqx');
INSERT INTO `yc_city` VALUES ('1110', '太和县', '1105', '1', '安徽,阜阳市,太和县', null, null, '341222', 't', 'taihexian', 'thx');
INSERT INTO `yc_city` VALUES ('1111', '阜南县', '1105', '1', '安徽,阜阳市,阜南县', null, null, '341225', 'f', 'funanxian', 'fnx');
INSERT INTO `yc_city` VALUES ('1112', '颍上县', '1105', '1', '安徽,阜阳市,颍上县', null, null, '341226', 'y', 'yingshangxian', 'sx');
INSERT INTO `yc_city` VALUES ('1113', '界首市', '1105', '1', '安徽,阜阳市,界首市', null, null, '341282', 'j', 'jieshoushi', 'jss');
INSERT INTO `yc_city` VALUES ('1114', '宿州市', '1024', '1', '安徽,宿州市', null, null, '341300', 's', 'suzhoushi', 'szs');
INSERT INTO `yc_city` VALUES ('1115', '埇桥区', '1114', '1', '安徽,宿州市,埇桥区', null, null, '341302', 'y', 'yongqiaoqu', '');
INSERT INTO `yc_city` VALUES ('1116', '砀山县', '1114', '1', '安徽,宿州市,砀山县', null, null, '341321', 'd', 'dangshanxian', 'sx');
INSERT INTO `yc_city` VALUES ('1117', '萧县', '1114', '1', '安徽,宿州市,萧县', null, null, '341322', 'x', 'xiaoxian', 'xx');
INSERT INTO `yc_city` VALUES ('1118', '灵璧县', '1114', '1', '安徽,宿州市,灵璧县', null, null, '341323', 'l', 'lingbixian', 'lx');
INSERT INTO `yc_city` VALUES ('1119', '泗县', '1114', '1', '安徽,宿州市,泗县', null, null, '341324', 's', 'sixian', 'x');
INSERT INTO `yc_city` VALUES ('1120', '六安市', '1024', '1', '安徽,六安市', null, null, '341500', 'l', 'luanshi', 'las');
INSERT INTO `yc_city` VALUES ('1121', '金安区', '1120', '1', '安徽,六安市,金安区', null, null, '341502', 'j', 'jinanqu', 'jaq');
INSERT INTO `yc_city` VALUES ('1122', '裕安区', '1120', '1', '安徽,六安市,裕安区', null, null, '341503', 'y', 'yuanqu', 'yaq');
INSERT INTO `yc_city` VALUES ('1123', '寿县', '1120', '1', '安徽,六安市,寿县', null, null, '341521', 's', 'shouxian', 'sx');
INSERT INTO `yc_city` VALUES ('1124', '霍邱县', '1120', '1', '安徽,六安市,霍邱县', null, null, '341522', 'h', 'huoqiuxian', 'hqx');
INSERT INTO `yc_city` VALUES ('1125', '舒城县', '1120', '1', '安徽,六安市,舒城县', null, null, '341523', 's', 'shuchengxian', 'scx');
INSERT INTO `yc_city` VALUES ('1126', '金寨县', '1120', '1', '安徽,六安市,金寨县', null, null, '341524', 'j', 'jinzhaixian', 'jzx');
INSERT INTO `yc_city` VALUES ('1127', '霍山县', '1120', '1', '安徽,六安市,霍山县', null, null, '341525', 'h', 'huoshanxian', 'hsx');
INSERT INTO `yc_city` VALUES ('1128', '亳州市', '1024', '1', '安徽,亳州市', null, null, '341600', 'b', 'bozhoushi', 'zs');
INSERT INTO `yc_city` VALUES ('1129', '谯城区', '1128', '1', '安徽,亳州市,谯城区', null, null, '341602', 'q', 'qiaochengqu', 'cq');
INSERT INTO `yc_city` VALUES ('1130', '涡阳县', '1128', '1', '安徽,亳州市,涡阳县', null, null, '341621', 'g', 'guoyangxian', 'wyx');
INSERT INTO `yc_city` VALUES ('1131', '蒙城县', '1128', '1', '安徽,亳州市,蒙城县', null, null, '341622', 'm', 'mengchengxian', 'mcx');
INSERT INTO `yc_city` VALUES ('1132', '利辛县', '1128', '1', '安徽,亳州市,利辛县', null, null, '341623', 'l', 'lixinxian', 'lxx');
INSERT INTO `yc_city` VALUES ('1133', '池州市', '1024', '1', '安徽,池州市', null, null, '341700', 'c', 'chizhoushi', 'czs');
INSERT INTO `yc_city` VALUES ('1134', '贵池区', '1133', '1', '安徽,池州市,贵池区', null, null, '341702', 'g', 'guichiqu', 'gcq');
INSERT INTO `yc_city` VALUES ('1135', '东至县', '1133', '1', '安徽,池州市,东至县', null, null, '341721', 'd', 'dongzhixian', 'dzx');
INSERT INTO `yc_city` VALUES ('1136', '石台县', '1133', '1', '安徽,池州市,石台县', null, null, '341722', 's', 'shitaixian', 'stx');
INSERT INTO `yc_city` VALUES ('1137', '青阳县', '1133', '1', '安徽,池州市,青阳县', null, null, '341723', 'q', 'qingyangxian', 'qyx');
INSERT INTO `yc_city` VALUES ('1138', '宣城市', '1024', '1', '安徽,宣城市', null, null, '341800', 'x', 'xuanchengshi', 'xcs');
INSERT INTO `yc_city` VALUES ('1139', '宣州区', '1138', '1', '安徽,宣城市,宣州区', null, null, '341802', 'x', 'xuanzhouqu', 'xzq');
INSERT INTO `yc_city` VALUES ('1140', '郎溪县', '1138', '1', '安徽,宣城市,郎溪县', null, null, '341821', 'l', 'langxixian', 'lxx');
INSERT INTO `yc_city` VALUES ('1141', '广德县', '1138', '1', '安徽,宣城市,广德县', null, null, '341822', 'g', 'guangdexian', 'gdx');
INSERT INTO `yc_city` VALUES ('1142', '泾县', '1138', '1', '安徽,宣城市,泾县', null, null, '341823', 'j', 'jingxian', 'x');
INSERT INTO `yc_city` VALUES ('1143', '绩溪县', '1138', '1', '安徽,宣城市,绩溪县', null, null, '341824', 'j', 'jixixian', 'jxx');
INSERT INTO `yc_city` VALUES ('1144', '旌德县', '1138', '1', '安徽,宣城市,旌德县', null, null, '341825', 'j', 'jingdexian', 'dx');
INSERT INTO `yc_city` VALUES ('1145', '宁国市', '1138', '1', '安徽,宣城市,宁国市', null, null, '341881', 'n', 'ningguoshi', 'ngs');
INSERT INTO `yc_city` VALUES ('1146', '福建', '1', '1', '福建', null, null, '350000', 'f', 'fujian', 'fj');
INSERT INTO `yc_city` VALUES ('1147', '福州市', '1146', '1', '福建,福州市', null, null, '350100', 'f', 'fuzhoushi', 'fzs');
INSERT INTO `yc_city` VALUES ('1148', '鼓楼区', '1147', '1', '福建,福州市,鼓楼区', null, null, '350102', 'g', 'gulouqu', 'glq');
INSERT INTO `yc_city` VALUES ('1149', '台江区', '1147', '1', '福建,福州市,台江区', null, null, '350103', 't', 'taijiangqu', 'tjq');
INSERT INTO `yc_city` VALUES ('1150', '仓山区', '1147', '1', '福建,福州市,仓山区', null, null, '350104', 'c', 'cangshanqu', 'csq');
INSERT INTO `yc_city` VALUES ('1151', '马尾区', '1147', '1', '福建,福州市,马尾区', null, null, '350105', 'm', 'mayiqu', 'mwq');
INSERT INTO `yc_city` VALUES ('1152', '晋安区', '1147', '1', '福建,福州市,晋安区', null, null, '350111', 'j', 'jinanqu', 'jaq');
INSERT INTO `yc_city` VALUES ('1153', '闽侯县', '1147', '1', '福建,福州市,闽侯县', null, null, '350121', 'm', 'minhouxian', 'mhx');
INSERT INTO `yc_city` VALUES ('1154', '连江县', '1147', '1', '福建,福州市,连江县', null, null, '350122', 'l', 'lianjiangxian', 'ljx');
INSERT INTO `yc_city` VALUES ('1155', '罗源县', '1147', '1', '福建,福州市,罗源县', null, null, '350123', 'l', 'luoyuanxian', 'lyx');
INSERT INTO `yc_city` VALUES ('1156', '闽清县', '1147', '1', '福建,福州市,闽清县', null, null, '350124', 'm', 'minqingxian', 'mqx');
INSERT INTO `yc_city` VALUES ('1157', '永泰县', '1147', '1', '福建,福州市,永泰县', null, null, '350125', 'y', 'yongtaixian', 'ytx');
INSERT INTO `yc_city` VALUES ('1158', '平潭县', '1147', '1', '福建,福州市,平潭县', null, null, '350128', 'p', 'pingtanxian', 'ptx');
INSERT INTO `yc_city` VALUES ('1159', '福清市', '1147', '1', '福建,福州市,福清市', null, null, '350181', 'f', 'fuqingshi', 'fqs');
INSERT INTO `yc_city` VALUES ('1160', '长乐市', '1147', '1', '福建,福州市,长乐市', null, null, '350182', 'c', 'changleshi', 'cls');
INSERT INTO `yc_city` VALUES ('1161', '厦门市', '1146', '1', '福建,厦门市', null, null, '350200', 'x', 'xiamenshi', 'xms');
INSERT INTO `yc_city` VALUES ('1162', '思明区', '1161', '1', '福建,厦门市,思明区', null, null, '350203', 's', 'simingqu', 'smq');
INSERT INTO `yc_city` VALUES ('1163', '海沧区', '1161', '1', '福建,厦门市,海沧区', null, null, '350205', 'h', 'haicangqu', 'hcq');
INSERT INTO `yc_city` VALUES ('1164', '湖里区', '1161', '1', '福建,厦门市,湖里区', null, null, '350206', 'h', 'huliqu', 'hlq');
INSERT INTO `yc_city` VALUES ('1165', '集美区', '1161', '1', '福建,厦门市,集美区', null, null, '350211', 'j', 'jimeiqu', 'jmq');
INSERT INTO `yc_city` VALUES ('1166', '同安区', '1161', '1', '福建,厦门市,同安区', null, null, '350212', 't', 'tonganqu', 'taq');
INSERT INTO `yc_city` VALUES ('1167', '翔安区', '1161', '1', '福建,厦门市,翔安区', null, null, '350213', 'x', 'xianganqu', 'xaq');
INSERT INTO `yc_city` VALUES ('1168', '莆田市', '1146', '1', '福建,莆田市', null, null, '350300', 'p', 'putianshi', 'pts');
INSERT INTO `yc_city` VALUES ('1169', '城厢区', '1168', '1', '福建,莆田市,城厢区', null, null, '350302', 'c', 'chengxiangqu', 'cxq');
INSERT INTO `yc_city` VALUES ('1170', '涵江区', '1168', '1', '福建,莆田市,涵江区', null, null, '350303', 'h', 'hanjiangqu', 'hjq');
INSERT INTO `yc_city` VALUES ('1171', '荔城区', '1168', '1', '福建,莆田市,荔城区', null, null, '350304', 'l', 'lichengqu', 'lcq');
INSERT INTO `yc_city` VALUES ('1172', '秀屿区', '1168', '1', '福建,莆田市,秀屿区', null, null, '350305', 'x', 'xiuyuqu', 'xyq');
INSERT INTO `yc_city` VALUES ('1173', '仙游县', '1168', '1', '福建,莆田市,仙游县', null, null, '350322', 'x', 'xianyouxian', 'xyx');
INSERT INTO `yc_city` VALUES ('1174', '三明市', '1146', '1', '福建,三明市', null, null, '350400', 's', 'sanmingshi', 'sms');
INSERT INTO `yc_city` VALUES ('1175', '梅列区', '1174', '1', '福建,三明市,梅列区', null, null, '350402', 'm', 'meiliequ', 'mlq');
INSERT INTO `yc_city` VALUES ('1176', '三元区', '1174', '1', '福建,三明市,三元区', null, null, '350403', 's', 'sanyuanqu', 'syq');
INSERT INTO `yc_city` VALUES ('1177', '明溪县', '1174', '1', '福建,三明市,明溪县', null, null, '350421', 'm', 'mingxixian', 'mxx');
INSERT INTO `yc_city` VALUES ('1178', '清流县', '1174', '1', '福建,三明市,清流县', null, null, '350423', 'q', 'qingliuxian', 'qlx');
INSERT INTO `yc_city` VALUES ('1179', '宁化县', '1174', '1', '福建,三明市,宁化县', null, null, '350424', 'n', 'ninghuaxian', 'nhx');
INSERT INTO `yc_city` VALUES ('1180', '大田县', '1174', '1', '福建,三明市,大田县', null, null, '350425', 'd', 'datianxian', 'dtx');
INSERT INTO `yc_city` VALUES ('1181', '尤溪县', '1174', '1', '福建,三明市,尤溪县', null, null, '350426', 'y', 'youxixian', 'yxx');
INSERT INTO `yc_city` VALUES ('1182', '沙县', '1174', '1', '福建,三明市,沙县', null, null, '350427', 's', 'shaxian', 'sx');
INSERT INTO `yc_city` VALUES ('1183', '将乐县', '1174', '1', '福建,三明市,将乐县', null, null, '350428', 'j', 'jianglexian', 'jlx');
INSERT INTO `yc_city` VALUES ('1184', '泰宁县', '1174', '1', '福建,三明市,泰宁县', null, null, '350429', 't', 'tainingxian', 'tnx');
INSERT INTO `yc_city` VALUES ('1185', '建宁县', '1174', '1', '福建,三明市,建宁县', null, null, '350430', 'j', 'jianningxian', 'jnx');
INSERT INTO `yc_city` VALUES ('1186', '永安市', '1174', '1', '福建,三明市,永安市', null, null, '350481', 'y', 'yonganshi', 'yas');
INSERT INTO `yc_city` VALUES ('1187', '泉州市', '1146', '1', '福建,泉州市', null, null, '350500', 'q', 'quanzhoushi', 'qzs');
INSERT INTO `yc_city` VALUES ('1188', '鲤城区', '1187', '1', '福建,泉州市,鲤城区', null, null, '350502', 'l', 'lichengqu', 'lcq');
INSERT INTO `yc_city` VALUES ('1189', '丰泽区', '1187', '1', '福建,泉州市,丰泽区', null, null, '350503', 'f', 'fengzequ', 'fzq');
INSERT INTO `yc_city` VALUES ('1190', '洛江区', '1187', '1', '福建,泉州市,洛江区', null, null, '350504', 'l', 'luojiangqu', 'ljq');
INSERT INTO `yc_city` VALUES ('1191', '泉港区', '1187', '1', '福建,泉州市,泉港区', null, null, '350505', 'q', 'quangangqu', 'qgq');
INSERT INTO `yc_city` VALUES ('1192', '惠安县', '1187', '1', '福建,泉州市,惠安县', null, null, '350521', 'h', 'huianxian', 'hax');
INSERT INTO `yc_city` VALUES ('1193', '安溪县', '1187', '1', '福建,泉州市,安溪县', null, null, '350524', 'a', 'anxixian', 'axx');
INSERT INTO `yc_city` VALUES ('1194', '永春县', '1187', '1', '福建,泉州市,永春县', null, null, '350525', 'y', 'yongchunxian', 'ycx');
INSERT INTO `yc_city` VALUES ('1195', '德化县', '1187', '1', '福建,泉州市,德化县', null, null, '350526', 'd', 'dehuaxian', 'dhx');
INSERT INTO `yc_city` VALUES ('1196', '金门县', '1187', '1', '福建,泉州市,金门县', null, null, '350527', 'j', 'jinmenxian', 'jmx');
INSERT INTO `yc_city` VALUES ('1197', '石狮市', '1187', '1', '福建,泉州市,石狮市', null, null, '350581', 's', 'shishishi', 'sss');
INSERT INTO `yc_city` VALUES ('1198', '晋江市', '1187', '1', '福建,泉州市,晋江市', null, null, '350582', 'j', 'jinjiangshi', 'jjs');
INSERT INTO `yc_city` VALUES ('1199', '南安市', '1187', '1', '福建,泉州市,南安市', null, null, '350583', 'n', 'nananshi', 'nas');
INSERT INTO `yc_city` VALUES ('1200', '漳州市', '1146', '1', '福建,漳州市', null, null, '350600', 'z', 'zhangzhoushi', 'zzs');
INSERT INTO `yc_city` VALUES ('1201', '芗城区', '1200', '1', '福建,漳州市,芗城区', null, null, '350602', 'x', 'xiangchengqu', 'cq');
INSERT INTO `yc_city` VALUES ('1202', '龙文区', '1200', '1', '福建,漳州市,龙文区', null, null, '350603', 'l', 'longwenqu', 'lwq');
INSERT INTO `yc_city` VALUES ('1203', '云霄县', '1200', '1', '福建,漳州市,云霄县', null, null, '350622', 'y', 'yunxiaoxian', 'yxx');
INSERT INTO `yc_city` VALUES ('1204', '漳浦县', '1200', '1', '福建,漳州市,漳浦县', null, null, '350623', 'z', 'zhangpuxian', 'zpx');
INSERT INTO `yc_city` VALUES ('1205', '诏安县', '1200', '1', '福建,漳州市,诏安县', null, null, '350624', 'z', 'zhaoanxian', 'ax');
INSERT INTO `yc_city` VALUES ('1206', '长泰县', '1200', '1', '福建,漳州市,长泰县', null, null, '350625', 'c', 'changtaixian', 'ctx');
INSERT INTO `yc_city` VALUES ('1207', '东山县', '1200', '1', '福建,漳州市,东山县', null, null, '350626', 'd', 'dongshanxian', 'dsx');
INSERT INTO `yc_city` VALUES ('1208', '南靖县', '1200', '1', '福建,漳州市,南靖县', null, null, '350627', 'n', 'nanjingxian', 'njx');
INSERT INTO `yc_city` VALUES ('1209', '平和县', '1200', '1', '福建,漳州市,平和县', null, null, '350628', 'p', 'pinghexian', 'phx');
INSERT INTO `yc_city` VALUES ('1210', '华安县', '1200', '1', '福建,漳州市,华安县', null, null, '350629', 'h', 'huaanxian', 'hax');
INSERT INTO `yc_city` VALUES ('1211', '龙海市', '1200', '1', '福建,漳州市,龙海市', null, null, '350681', 'l', 'longhaishi', 'lhs');
INSERT INTO `yc_city` VALUES ('1212', '南平市', '1146', '1', '福建,南平市', null, null, '350700', 'n', 'nanpingshi', 'nps');
INSERT INTO `yc_city` VALUES ('1213', '延平区', '1212', '1', '福建,南平市,延平区', null, null, '350702', 'y', 'yanpingqu', 'ypq');
INSERT INTO `yc_city` VALUES ('1214', '顺昌县', '1212', '1', '福建,南平市,顺昌县', null, null, '350721', 's', 'shunchangxian', 'scx');
INSERT INTO `yc_city` VALUES ('1215', '浦城县', '1212', '1', '福建,南平市,浦城县', null, null, '350722', 'p', 'puchengxian', 'pcx');
INSERT INTO `yc_city` VALUES ('1216', '光泽县', '1212', '1', '福建,南平市,光泽县', null, null, '350723', 'g', 'guangzexian', 'gzx');
INSERT INTO `yc_city` VALUES ('1217', '松溪县', '1212', '1', '福建,南平市,松溪县', null, null, '350724', 's', 'songxixian', 'sxx');
INSERT INTO `yc_city` VALUES ('1218', '政和县', '1212', '1', '福建,南平市,政和县', null, null, '350725', 'z', 'zhenghexian', 'zhx');
INSERT INTO `yc_city` VALUES ('1219', '邵武市', '1212', '1', '福建,南平市,邵武市', null, null, '350781', 's', 'shaowushi', 'sws');
INSERT INTO `yc_city` VALUES ('1220', '武夷山市', '1212', '1', '福建,南平市,武夷山市', null, null, '350782', 'w', 'wuyishanshi', 'wyss');
INSERT INTO `yc_city` VALUES ('1221', '建瓯市', '1212', '1', '福建,南平市,建瓯市', null, null, '350783', 'j', 'jianoushi', 'js');
INSERT INTO `yc_city` VALUES ('1222', '建阳市', '1212', '1', '福建,南平市,建阳市', null, null, '350784', 'j', 'jianyangshi', 'jys');
INSERT INTO `yc_city` VALUES ('1223', '龙岩市', '1146', '1', '福建,龙岩市', null, null, '350800', 'l', 'longyanshi', 'lys');
INSERT INTO `yc_city` VALUES ('1224', '新罗区', '1223', '1', '福建,龙岩市,新罗区', null, null, '350802', 'x', 'xinluoqu', 'xlq');
INSERT INTO `yc_city` VALUES ('1225', '长汀县', '1223', '1', '福建,龙岩市,长汀县', null, null, '350821', 'c', 'changtingxian', 'ctx');
INSERT INTO `yc_city` VALUES ('1226', '永定县', '1223', '1', '福建,龙岩市,永定县', null, null, '350822', 'y', 'yongdingxian', 'ydx');
INSERT INTO `yc_city` VALUES ('1227', '上杭县', '1223', '1', '福建,龙岩市,上杭县', null, null, '350823', 's', 'shanghangxian', 'shx');
INSERT INTO `yc_city` VALUES ('1228', '武平县', '1223', '1', '福建,龙岩市,武平县', null, null, '350824', 'w', 'wupingxian', 'wpx');
INSERT INTO `yc_city` VALUES ('1229', '连城县', '1223', '1', '福建,龙岩市,连城县', null, null, '350825', 'l', 'lianchengxian', 'lcx');
INSERT INTO `yc_city` VALUES ('1230', '漳平市', '1223', '1', '福建,龙岩市,漳平市', null, null, '350881', 'z', 'zhangpingshi', 'zps');
INSERT INTO `yc_city` VALUES ('1231', '宁德市', '1146', '1', '福建,宁德市', null, null, '350900', 'n', 'ningdeshi', 'nds');
INSERT INTO `yc_city` VALUES ('1232', '蕉城区', '1231', '1', '福建,宁德市,蕉城区', null, null, '350902', 'j', 'jiaochengqu', 'jcq');
INSERT INTO `yc_city` VALUES ('1233', '霞浦县', '1231', '1', '福建,宁德市,霞浦县', null, null, '350921', 'x', 'xiapuxian', 'xpx');
INSERT INTO `yc_city` VALUES ('1234', '古田县', '1231', '1', '福建,宁德市,古田县', null, null, '350922', 'g', 'gutianxian', 'gtx');
INSERT INTO `yc_city` VALUES ('1235', '屏南县', '1231', '1', '福建,宁德市,屏南县', null, null, '350923', 'p', 'pingnanxian', 'pnx');
INSERT INTO `yc_city` VALUES ('1236', '寿宁县', '1231', '1', '福建,宁德市,寿宁县', null, null, '350924', 's', 'shouningxian', 'snx');
INSERT INTO `yc_city` VALUES ('1237', '周宁县', '1231', '1', '福建,宁德市,周宁县', null, null, '350925', 'z', 'zhouningxian', 'znx');
INSERT INTO `yc_city` VALUES ('1238', '柘荣县', '1231', '1', '福建,宁德市,柘荣县', null, null, '350926', 'z', 'zherongxian', 'rx');
INSERT INTO `yc_city` VALUES ('1239', '福安市', '1231', '1', '福建,宁德市,福安市', null, null, '350981', 'f', 'fuanshi', 'fas');
INSERT INTO `yc_city` VALUES ('1240', '福鼎市', '1231', '1', '福建,宁德市,福鼎市', null, null, '350982', 'f', 'fudingshi', 'fds');
INSERT INTO `yc_city` VALUES ('1241', '江西', '1', '1', '江西', null, null, '360000', 'j', 'jiangxi', 'jx');
INSERT INTO `yc_city` VALUES ('1242', '南昌市', '1241', '1', '江西,南昌市', null, null, '360100', 'n', 'nanchangshi', 'ncs');
INSERT INTO `yc_city` VALUES ('1243', '东湖区', '1242', '1', '江西,南昌市,东湖区', null, null, '360102', 'd', 'donghuqu', 'dhq');
INSERT INTO `yc_city` VALUES ('1244', '西湖区', '1242', '1', '江西,南昌市,西湖区', null, null, '360103', 'x', 'xihuqu', 'xhq');
INSERT INTO `yc_city` VALUES ('1245', '青云谱区', '1242', '1', '江西,南昌市,青云谱区', null, null, '360104', 'q', 'qingyunpuqu', 'qypq');
INSERT INTO `yc_city` VALUES ('1246', '湾里区', '1242', '1', '江西,南昌市,湾里区', null, null, '360105', 'w', 'wanliqu', 'wlq');
INSERT INTO `yc_city` VALUES ('1247', '青山湖区', '1242', '1', '江西,南昌市,青山湖区', null, null, '360111', 'q', 'qingshanhuqu', 'qshq');
INSERT INTO `yc_city` VALUES ('1248', '南昌县', '1242', '1', '江西,南昌市,南昌县', null, null, '360121', 'n', 'nanchangxian', 'ncx');
INSERT INTO `yc_city` VALUES ('1249', '新建县', '1242', '1', '江西,南昌市,新建县', null, null, '360122', 'x', 'xinjianxian', 'xjx');
INSERT INTO `yc_city` VALUES ('1250', '安义县', '1242', '1', '江西,南昌市,安义县', null, null, '360123', 'a', 'anyixian', 'ayx');
INSERT INTO `yc_city` VALUES ('1251', '进贤县', '1242', '1', '江西,南昌市,进贤县', null, null, '360124', 'j', 'jinxianxian', 'jxx');
INSERT INTO `yc_city` VALUES ('1252', '景德镇市', '1241', '1', '江西,景德镇市', null, null, '360200', 'j', 'jingdezhenshi', 'jdzs');
INSERT INTO `yc_city` VALUES ('1253', '昌江区', '1252', '1', '江西,景德镇市,昌江区', null, null, '360202', 'c', 'changjiangqu', 'cjq');
INSERT INTO `yc_city` VALUES ('1254', '珠山区', '1252', '1', '江西,景德镇市,珠山区', null, null, '360203', 'z', 'zhushanqu', 'zsq');
INSERT INTO `yc_city` VALUES ('1255', '浮梁县', '1252', '1', '江西,景德镇市,浮梁县', null, null, '360222', 'f', 'fuliangxian', 'flx');
INSERT INTO `yc_city` VALUES ('1256', '乐平市', '1252', '1', '江西,景德镇市,乐平市', null, null, '360281', 'l', 'lepingshi', 'lps');
INSERT INTO `yc_city` VALUES ('1257', '萍乡市', '1241', '1', '江西,萍乡市', null, null, '360300', 'p', 'pingxiangshi', 'pxs');
INSERT INTO `yc_city` VALUES ('1258', '安源区', '1257', '1', '江西,萍乡市,安源区', null, null, '360302', 'a', 'anyuanqu', 'ayq');
INSERT INTO `yc_city` VALUES ('1259', '湘东区', '1257', '1', '江西,萍乡市,湘东区', null, null, '360313', 'x', 'xiangdongqu', 'xdq');
INSERT INTO `yc_city` VALUES ('1260', '莲花县', '1257', '1', '江西,萍乡市,莲花县', null, null, '360321', 'l', 'lianhuaxian', 'lhx');
INSERT INTO `yc_city` VALUES ('1261', '上栗县', '1257', '1', '江西,萍乡市,上栗县', null, null, '360322', 's', 'shanglixian', 'slx');
INSERT INTO `yc_city` VALUES ('1262', '芦溪县', '1257', '1', '江西,萍乡市,芦溪县', null, null, '360323', 'l', 'luxixian', 'lxx');
INSERT INTO `yc_city` VALUES ('1263', '九江市', '1241', '1', '江西,九江市', null, null, '360400', 'j', 'jiujiangshi', 'jjs');
INSERT INTO `yc_city` VALUES ('1264', '庐山区', '1263', '1', '江西,九江市,庐山区', null, null, '360402', 'l', 'lushanqu', 'lsq');
INSERT INTO `yc_city` VALUES ('1265', '浔阳区', '1263', '1', '江西,九江市,浔阳区', null, null, '360403', 'x', 'xunyangqu', 'yq');
INSERT INTO `yc_city` VALUES ('1266', '九江县', '1263', '1', '江西,九江市,九江县', null, null, '360421', 'j', 'jiujiangxian', 'jjx');
INSERT INTO `yc_city` VALUES ('1267', '武宁县', '1263', '1', '江西,九江市,武宁县', null, null, '360423', 'w', 'wuningxian', 'wnx');
INSERT INTO `yc_city` VALUES ('1268', '修水县', '1263', '1', '江西,九江市,修水县', null, null, '360424', 'x', 'xiushuixian', 'xsx');
INSERT INTO `yc_city` VALUES ('1269', '永修县', '1263', '1', '江西,九江市,永修县', null, null, '360425', 'y', 'yongxiuxian', 'yxx');
INSERT INTO `yc_city` VALUES ('1270', '德安县', '1263', '1', '江西,九江市,德安县', null, null, '360426', 'd', 'deanxian', 'dax');
INSERT INTO `yc_city` VALUES ('1271', '星子县', '1263', '1', '江西,九江市,星子县', null, null, '360427', 'x', 'xingzixian', 'xzx');
INSERT INTO `yc_city` VALUES ('1272', '都昌县', '1263', '1', '江西,九江市,都昌县', null, null, '360428', 'd', 'duchangxian', 'dcx');
INSERT INTO `yc_city` VALUES ('1273', '湖口县', '1263', '1', '江西,九江市,湖口县', null, null, '360429', 'h', 'hukouxian', 'hkx');
INSERT INTO `yc_city` VALUES ('1274', '彭泽县', '1263', '1', '江西,九江市,彭泽县', null, null, '360430', 'p', 'pengzexian', 'pzx');
INSERT INTO `yc_city` VALUES ('1275', '瑞昌市', '1263', '1', '江西,九江市,瑞昌市', null, null, '360481', 'r', 'ruichangshi', 'rcs');
INSERT INTO `yc_city` VALUES ('1276', '共青城市', '1263', '1', '江西,九江市,共青城市', null, null, '360482', 'g', 'gongqingchengshi', 'gqcs');
INSERT INTO `yc_city` VALUES ('1277', '新余市', '1241', '1', '江西,新余市', null, null, '360500', 'x', 'xinyushi', 'xys');
INSERT INTO `yc_city` VALUES ('1278', '渝水区', '1277', '1', '江西,新余市,渝水区', null, null, '360502', 'y', 'yushuiqu', 'ysq');
INSERT INTO `yc_city` VALUES ('1279', '分宜县', '1277', '1', '江西,新余市,分宜县', null, null, '360521', 'f', 'fenyixian', 'fyx');
INSERT INTO `yc_city` VALUES ('1280', '鹰潭市', '1241', '1', '江西,鹰潭市', null, null, '360600', 'y', 'yingtanshi', 'yts');
INSERT INTO `yc_city` VALUES ('1281', '月湖区', '1280', '1', '江西,鹰潭市,月湖区', null, null, '360602', 'y', 'yuehuqu', 'yhq');
INSERT INTO `yc_city` VALUES ('1282', '余江县', '1280', '1', '江西,鹰潭市,余江县', null, null, '360622', 'y', 'yujiangxian', 'yjx');
INSERT INTO `yc_city` VALUES ('1283', '贵溪市', '1280', '1', '江西,鹰潭市,贵溪市', null, null, '360681', 'g', 'guixishi', 'gxs');
INSERT INTO `yc_city` VALUES ('1284', '赣州市', '1241', '1', '江西,赣州市', null, null, '360700', 'g', 'ganzhoushi', 'gzs');
INSERT INTO `yc_city` VALUES ('1285', '章贡区', '1284', '1', '江西,赣州市,章贡区', null, null, '360702', 'z', 'zhanggongqu', 'zgq');
INSERT INTO `yc_city` VALUES ('1286', '南康区', '1284', '1', '江西,赣州市,南康区', null, null, '360782', 'n', 'nankangqu', 'nkq');
INSERT INTO `yc_city` VALUES ('1287', '赣县', '1284', '1', '江西,赣州市,赣县', null, null, '360721', 'g', 'ganxian', 'gx');
INSERT INTO `yc_city` VALUES ('1288', '信丰县', '1284', '1', '江西,赣州市,信丰县', null, null, '360722', 'x', 'xinfengxian', 'xfx');
INSERT INTO `yc_city` VALUES ('1289', '大余县', '1284', '1', '江西,赣州市,大余县', null, null, '360723', 'd', 'dayuxian', 'dyx');
INSERT INTO `yc_city` VALUES ('1290', '上犹县', '1284', '1', '江西,赣州市,上犹县', null, null, '360724', 's', 'shangyouxian', 'syx');
INSERT INTO `yc_city` VALUES ('1291', '崇义县', '1284', '1', '江西,赣州市,崇义县', null, null, '360725', 'c', 'chongyixian', 'cyx');
INSERT INTO `yc_city` VALUES ('1292', '安远县', '1284', '1', '江西,赣州市,安远县', null, null, '360726', 'a', 'anyuanxian', 'ayx');
INSERT INTO `yc_city` VALUES ('1293', '龙南县', '1284', '1', '江西,赣州市,龙南县', null, null, '360727', 'l', 'longnanxian', 'lnx');
INSERT INTO `yc_city` VALUES ('1294', '定南县', '1284', '1', '江西,赣州市,定南县', null, null, '360728', 'd', 'dingnanxian', 'dnx');
INSERT INTO `yc_city` VALUES ('1295', '全南县', '1284', '1', '江西,赣州市,全南县', null, null, '360729', 'q', 'quannanxian', 'qnx');
INSERT INTO `yc_city` VALUES ('1296', '宁都县', '1284', '1', '江西,赣州市,宁都县', null, null, '360730', 'n', 'ningduxian', 'ndx');
INSERT INTO `yc_city` VALUES ('1297', '于都县', '1284', '1', '江西,赣州市,于都县', null, null, '360731', 'y', 'yuduxian', 'ydx');
INSERT INTO `yc_city` VALUES ('1298', '兴国县', '1284', '1', '江西,赣州市,兴国县', null, null, '360732', 'x', 'xingguoxian', 'xgx');
INSERT INTO `yc_city` VALUES ('1299', '会昌县', '1284', '1', '江西,赣州市,会昌县', null, null, '360733', 'h', 'huichangxian', 'hcx');
INSERT INTO `yc_city` VALUES ('1300', '寻乌县', '1284', '1', '江西,赣州市,寻乌县', null, null, '360734', 'x', 'xunwuxian', 'xwx');
INSERT INTO `yc_city` VALUES ('1301', '石城县', '1284', '1', '江西,赣州市,石城县', null, null, '360735', 's', 'shichengxian', 'scx');
INSERT INTO `yc_city` VALUES ('1302', '瑞金市', '1284', '1', '江西,赣州市,瑞金市', null, null, '360781', 'r', 'ruijinshi', 'rjs');
INSERT INTO `yc_city` VALUES ('1303', '吉安市', '1241', '1', '江西,吉安市', null, null, '360800', 'j', 'jianshi', 'jas');
INSERT INTO `yc_city` VALUES ('1304', '吉州区', '1303', '1', '江西,吉安市,吉州区', null, null, '360802', 'j', 'jizhouqu', 'jzq');
INSERT INTO `yc_city` VALUES ('1305', '青原区', '1303', '1', '江西,吉安市,青原区', null, null, '360803', 'q', 'qingyuanqu', 'qyq');
INSERT INTO `yc_city` VALUES ('1306', '吉安县', '1303', '1', '江西,吉安市,吉安县', null, null, '360821', 'j', 'jianxian', 'jax');
INSERT INTO `yc_city` VALUES ('1307', '吉水县', '1303', '1', '江西,吉安市,吉水县', null, null, '360822', 'j', 'jishuixian', 'jsx');
INSERT INTO `yc_city` VALUES ('1308', '峡江县', '1303', '1', '江西,吉安市,峡江县', null, null, '360823', 'x', 'xiajiangxian', 'xjx');
INSERT INTO `yc_city` VALUES ('1309', '新干县', '1303', '1', '江西,吉安市,新干县', null, null, '360824', 'x', 'xinganxian', 'xgx');
INSERT INTO `yc_city` VALUES ('1310', '永丰县', '1303', '1', '江西,吉安市,永丰县', null, null, '360825', 'y', 'yongfengxian', 'yfx');
INSERT INTO `yc_city` VALUES ('1311', '泰和县', '1303', '1', '江西,吉安市,泰和县', null, null, '360826', 't', 'taihexian', 'thx');
INSERT INTO `yc_city` VALUES ('1312', '遂川县', '1303', '1', '江西,吉安市,遂川县', null, null, '360827', 's', 'suichuanxian', 'scx');
INSERT INTO `yc_city` VALUES ('1313', '万安县', '1303', '1', '江西,吉安市,万安县', null, null, '360828', 'w', 'wananxian', 'wax');
INSERT INTO `yc_city` VALUES ('1314', '安福县', '1303', '1', '江西,吉安市,安福县', null, null, '360829', 'a', 'anfuxian', 'afx');
INSERT INTO `yc_city` VALUES ('1315', '永新县', '1303', '1', '江西,吉安市,永新县', null, null, '360830', 'y', 'yongxinxian', 'yxx');
INSERT INTO `yc_city` VALUES ('1316', '井冈山市', '1303', '1', '江西,吉安市,井冈山市', null, null, '360881', 'j', 'jinggangshanshi', 'jgss');
INSERT INTO `yc_city` VALUES ('1317', '宜春市', '1241', '1', '江西,宜春市', null, null, '360900', 'y', 'yichunshi', 'ycs');
INSERT INTO `yc_city` VALUES ('1318', '袁州区', '1317', '1', '江西,宜春市,袁州区', null, null, '360902', 'y', 'yuanzhouqu', 'yzq');
INSERT INTO `yc_city` VALUES ('1319', '奉新县', '1317', '1', '江西,宜春市,奉新县', null, null, '360921', 'f', 'fengxinxian', 'fxx');
INSERT INTO `yc_city` VALUES ('1320', '万载县', '1317', '1', '江西,宜春市,万载县', null, null, '360922', 'w', 'wanzaixian', 'wzx');
INSERT INTO `yc_city` VALUES ('1321', '上高县', '1317', '1', '江西,宜春市,上高县', null, null, '360923', 's', 'shanggaoxian', 'sgx');
INSERT INTO `yc_city` VALUES ('1322', '宜丰县', '1317', '1', '江西,宜春市,宜丰县', null, null, '360924', 'y', 'yifengxian', 'yfx');
INSERT INTO `yc_city` VALUES ('1323', '靖安县', '1317', '1', '江西,宜春市,靖安县', null, null, '360925', 'j', 'jinganxian', 'jax');
INSERT INTO `yc_city` VALUES ('1324', '铜鼓县', '1317', '1', '江西,宜春市,铜鼓县', null, null, '360926', 't', 'tongguxian', 'tgx');
INSERT INTO `yc_city` VALUES ('1325', '丰城市', '1317', '1', '江西,宜春市,丰城市', null, null, '360981', 'f', 'fengchengshi', 'fcs');
INSERT INTO `yc_city` VALUES ('1326', '樟树市', '1317', '1', '江西,宜春市,樟树市', null, null, '360982', 'z', 'zhangshushi', 'zss');
INSERT INTO `yc_city` VALUES ('1327', '高安市', '1317', '1', '江西,宜春市,高安市', null, null, '360983', 'g', 'gaoanshi', 'gas');
INSERT INTO `yc_city` VALUES ('1328', '抚州市', '1241', '1', '江西,抚州市', null, null, '361000', 'f', 'fuzhoushi', 'fzs');
INSERT INTO `yc_city` VALUES ('1329', '临川区', '1328', '1', '江西,抚州市,临川区', null, null, '361002', 'l', 'linchuanqu', 'lcq');
INSERT INTO `yc_city` VALUES ('1330', '南城县', '1328', '1', '江西,抚州市,南城县', null, null, '361021', 'n', 'nanchengxian', 'ncx');
INSERT INTO `yc_city` VALUES ('1331', '黎川县', '1328', '1', '江西,抚州市,黎川县', null, null, '361022', 'l', 'lichuanxian', 'lcx');
INSERT INTO `yc_city` VALUES ('1332', '南丰县', '1328', '1', '江西,抚州市,南丰县', null, null, '361023', 'n', 'nanfengxian', 'nfx');
INSERT INTO `yc_city` VALUES ('1333', '崇仁县', '1328', '1', '江西,抚州市,崇仁县', null, null, '361024', 'c', 'chongrenxian', 'crx');
INSERT INTO `yc_city` VALUES ('1334', '乐安县', '1328', '1', '江西,抚州市,乐安县', null, null, '361025', 'l', 'leanxian', 'lax');
INSERT INTO `yc_city` VALUES ('1335', '宜黄县', '1328', '1', '江西,抚州市,宜黄县', null, null, '361026', 'y', 'yihuangxian', 'yhx');
INSERT INTO `yc_city` VALUES ('1336', '金溪县', '1328', '1', '江西,抚州市,金溪县', null, null, '361027', 'j', 'jinxixian', 'jxx');
INSERT INTO `yc_city` VALUES ('1337', '资溪县', '1328', '1', '江西,抚州市,资溪县', null, null, '361028', 'z', 'zixixian', 'zxx');
INSERT INTO `yc_city` VALUES ('1338', '东乡县', '1328', '1', '江西,抚州市,东乡县', null, null, '361029', 'd', 'dongxiangxian', 'dxx');
INSERT INTO `yc_city` VALUES ('1339', '广昌县', '1328', '1', '江西,抚州市,广昌县', null, null, '361030', 'g', 'guangchangxian', 'gcx');
INSERT INTO `yc_city` VALUES ('1340', '上饶市', '1241', '1', '江西,上饶市', null, null, '361100', 's', 'shangraoshi', 'srs');
INSERT INTO `yc_city` VALUES ('1341', '信州区', '1340', '1', '江西,上饶市,信州区', null, null, '361102', 'x', 'xinzhouqu', 'xzq');
INSERT INTO `yc_city` VALUES ('1342', '上饶县', '1340', '1', '江西,上饶市,上饶县', null, null, '361121', 's', 'shangraoxian', 'srx');
INSERT INTO `yc_city` VALUES ('1343', '广丰县', '1340', '1', '江西,上饶市,广丰县', null, null, '361122', 'g', 'guangfengxian', 'gfx');
INSERT INTO `yc_city` VALUES ('1344', '玉山县', '1340', '1', '江西,上饶市,玉山县', null, null, '361123', 'y', 'yushanxian', 'ysx');
INSERT INTO `yc_city` VALUES ('1345', '铅山县', '1340', '1', '江西,上饶市,铅山县', null, null, '361124', 'y', 'yanshanxian', 'qsx');
INSERT INTO `yc_city` VALUES ('1346', '横峰县', '1340', '1', '江西,上饶市,横峰县', null, null, '361125', 'h', 'hengfengxian', 'hfx');
INSERT INTO `yc_city` VALUES ('1347', '弋阳县', '1340', '1', '江西,上饶市,弋阳县', null, null, '361126', 'y', 'yiyangxian', 'yx');
INSERT INTO `yc_city` VALUES ('1348', '余干县', '1340', '1', '江西,上饶市,余干县', null, null, '361127', 'y', 'yuganxian', 'ygx');
INSERT INTO `yc_city` VALUES ('1349', '鄱阳县', '1340', '1', '江西,上饶市,鄱阳县', null, null, '361128', 'p', 'poyangxian', 'yx');
INSERT INTO `yc_city` VALUES ('1350', '万年县', '1340', '1', '江西,上饶市,万年县', null, null, '361129', 'w', 'wannianxian', 'wnx');
INSERT INTO `yc_city` VALUES ('1351', '婺源县', '1340', '1', '江西,上饶市,婺源县', null, null, '361130', 'w', 'wuyuanxian', 'yx');
INSERT INTO `yc_city` VALUES ('1352', '德兴市', '1340', '1', '江西,上饶市,德兴市', null, null, '361181', 'd', 'dexingshi', 'dxs');
INSERT INTO `yc_city` VALUES ('1353', '山东', '1', '1', '山东', null, null, '370000', 's', 'shandong', 'sd');
INSERT INTO `yc_city` VALUES ('1354', '济南市', '1353', '1', '山东,济南市', null, null, '370100', 'j', 'jinanshi', 'jns');
INSERT INTO `yc_city` VALUES ('1355', '历下区', '1354', '1', '山东,济南市,历下区', null, null, '370102', 'l', 'lixiaqu', 'lxq');
INSERT INTO `yc_city` VALUES ('1356', '市中区', '1354', '1', '山东,济南市,市中区', null, null, '370103', 's', 'shizhongqu', 'szq');
INSERT INTO `yc_city` VALUES ('1357', '槐荫区', '1354', '1', '山东,济南市,槐荫区', null, null, '370104', 'h', 'huaiyinqu', 'hyq');
INSERT INTO `yc_city` VALUES ('1358', '天桥区', '1354', '1', '山东,济南市,天桥区', null, null, '370105', 't', 'tianqiaoqu', 'tqq');
INSERT INTO `yc_city` VALUES ('1359', '历城区', '1354', '1', '山东,济南市,历城区', null, null, '370112', 'l', 'lichengqu', 'lcq');
INSERT INTO `yc_city` VALUES ('1360', '长清区', '1354', '1', '山东,济南市,长清区', null, null, '370113', 'c', 'changqingqu', 'cqq');
INSERT INTO `yc_city` VALUES ('1361', '平阴县', '1354', '1', '山东,济南市,平阴县', null, null, '370124', 'p', 'pingyinxian', 'pyx');
INSERT INTO `yc_city` VALUES ('1362', '济阳县', '1354', '1', '山东,济南市,济阳县', null, null, '370125', 'j', 'jiyangxian', 'jyx');
INSERT INTO `yc_city` VALUES ('1363', '商河县', '1354', '1', '山东,济南市,商河县', null, null, '370126', 's', 'shanghexian', 'shx');
INSERT INTO `yc_city` VALUES ('1364', '章丘市', '1354', '1', '山东,济南市,章丘市', null, null, '370181', 'z', 'zhangqiushi', 'zqs');
INSERT INTO `yc_city` VALUES ('1365', '青岛市', '1353', '1', '山东,青岛市', null, null, '370200', 'q', 'qingdaoshi', 'qds');
INSERT INTO `yc_city` VALUES ('1366', '市南区', '1365', '1', '山东,青岛市,市南区', null, null, '370202', 's', 'shinanqu', 'snq');
INSERT INTO `yc_city` VALUES ('1367', '市北区', '1365', '1', '山东,青岛市,市北区', null, null, '370203', 's', 'shibeiqu', 'sbq');
INSERT INTO `yc_city` VALUES ('1368', '黄岛区', '1365', '1', '山东,青岛市,黄岛区', null, null, '370211', 'h', 'huangdaoqu', 'hdq');
INSERT INTO `yc_city` VALUES ('1369', '崂山区', '1365', '1', '山东,青岛市,崂山区', null, null, '370212', 'l', 'laoshanqu', 'sq');
INSERT INTO `yc_city` VALUES ('1370', '李沧区', '1365', '1', '山东,青岛市,李沧区', null, null, '370213', 'l', 'licangqu', 'lcq');
INSERT INTO `yc_city` VALUES ('1371', '城阳区', '1365', '1', '山东,青岛市,城阳区', null, null, '370214', 'c', 'chengyangqu', 'cyq');
INSERT INTO `yc_city` VALUES ('1372', '胶州市', '1365', '1', '山东,青岛市,胶州市', null, null, '370281', 'j', 'jiaozhoushi', 'jzs');
INSERT INTO `yc_city` VALUES ('1373', '即墨市', '1365', '1', '山东,青岛市,即墨市', null, null, '370282', 'j', 'jimoshi', 'jms');
INSERT INTO `yc_city` VALUES ('1374', '平度市', '1365', '1', '山东,青岛市,平度市', null, null, '370283', 'p', 'pingdushi', 'pds');
INSERT INTO `yc_city` VALUES ('1375', '莱西市', '1365', '1', '山东,青岛市,莱西市', null, null, '370285', 'l', 'laixishi', 'lxs');
INSERT INTO `yc_city` VALUES ('1376', '淄博市', '1353', '1', '山东,淄博市', null, null, '370300', 'z', 'ziboshi', 'zbs');
INSERT INTO `yc_city` VALUES ('1377', '淄川区', '1376', '1', '山东,淄博市,淄川区', null, null, '370302', 'z', 'zichuanqu', 'zcq');
INSERT INTO `yc_city` VALUES ('1378', '张店区', '1376', '1', '山东,淄博市,张店区', null, null, '370303', 'z', 'zhangdianqu', 'zdq');
INSERT INTO `yc_city` VALUES ('1379', '博山区', '1376', '1', '山东,淄博市,博山区', null, null, '370304', 'b', 'boshanqu', 'bsq');
INSERT INTO `yc_city` VALUES ('1380', '临淄区', '1376', '1', '山东,淄博市,临淄区', null, null, '370305', 'l', 'linziqu', 'lzq');
INSERT INTO `yc_city` VALUES ('1381', '周村区', '1376', '1', '山东,淄博市,周村区', null, null, '370306', 'z', 'zhoucunqu', 'zcq');
INSERT INTO `yc_city` VALUES ('1382', '桓台县', '1376', '1', '山东,淄博市,桓台县', null, null, '370321', 'h', 'huantaixian', 'htx');
INSERT INTO `yc_city` VALUES ('1383', '高青县', '1376', '1', '山东,淄博市,高青县', null, null, '370322', 'g', 'gaoqingxian', 'gqx');
INSERT INTO `yc_city` VALUES ('1384', '沂源县', '1376', '1', '山东,淄博市,沂源县', null, null, '370323', 'y', 'yiyuanxian', 'yyx');
INSERT INTO `yc_city` VALUES ('1385', '枣庄市', '1353', '1', '山东,枣庄市', null, null, '370400', 'z', 'zaozhuangshi', 'zzs');
INSERT INTO `yc_city` VALUES ('1386', '市中区', '1385', '1', '山东,枣庄市,市中区', null, null, '370402', 's', 'shizhongqu', 'szq');
INSERT INTO `yc_city` VALUES ('1387', '薛城区', '1385', '1', '山东,枣庄市,薛城区', null, null, '370403', 'x', 'xuechengqu', 'xcq');
INSERT INTO `yc_city` VALUES ('1388', '峄城区', '1385', '1', '山东,枣庄市,峄城区', null, null, '370404', 'y', 'yichengqu', 'cq');
INSERT INTO `yc_city` VALUES ('1389', '台儿庄区', '1385', '1', '山东,枣庄市,台儿庄区', null, null, '370405', 't', 'taierzhuangqu', 'tezq');
INSERT INTO `yc_city` VALUES ('1390', '山亭区', '1385', '1', '山东,枣庄市,山亭区', null, null, '370406', 's', 'shantingqu', 'stq');
INSERT INTO `yc_city` VALUES ('1391', '滕州市', '1385', '1', '山东,枣庄市,滕州市', null, null, '370481', 't', 'tengzhoushi', 'zs');
INSERT INTO `yc_city` VALUES ('1392', '东营市', '1353', '1', '山东,东营市', null, null, '370500', 'd', 'dongyingshi', 'dys');
INSERT INTO `yc_city` VALUES ('1393', '东营区', '1392', '1', '山东,东营市,东营区', null, null, '370502', 'd', 'dongyingqu', 'dyq');
INSERT INTO `yc_city` VALUES ('1394', '河口区', '1392', '1', '山东,东营市,河口区', null, null, '370503', 'h', 'hekouqu', 'hkq');
INSERT INTO `yc_city` VALUES ('1395', '垦利县', '1392', '1', '山东,东营市,垦利县', null, null, '370521', 'k', 'kenlixian', 'klx');
INSERT INTO `yc_city` VALUES ('1396', '利津县', '1392', '1', '山东,东营市,利津县', null, null, '370522', 'l', 'lijinxian', 'ljx');
INSERT INTO `yc_city` VALUES ('1397', '广饶县', '1392', '1', '山东,东营市,广饶县', null, null, '370523', 'g', 'guangraoxian', 'grx');
INSERT INTO `yc_city` VALUES ('1398', '烟台市', '1353', '1', '山东,烟台市', null, null, '370600', 'y', 'yantaishi', 'yts');
INSERT INTO `yc_city` VALUES ('1399', '芝罘区', '1398', '1', '山东,烟台市,芝罘区', null, null, '370602', 'z', 'zhifuqu', 'zq');
INSERT INTO `yc_city` VALUES ('1400', '福山区', '1398', '1', '山东,烟台市,福山区', null, null, '370611', 'f', 'fushanqu', 'fsq');
INSERT INTO `yc_city` VALUES ('1401', '牟平区', '1398', '1', '山东,烟台市,牟平区', null, null, '370612', 'm', 'mupingqu', 'mpq');
INSERT INTO `yc_city` VALUES ('1402', '莱山区', '1398', '1', '山东,烟台市,莱山区', null, null, '370613', 'l', 'laishanqu', 'lsq');
INSERT INTO `yc_city` VALUES ('1403', '长岛县', '1398', '1', '山东,烟台市,长岛县', null, null, '370634', 'c', 'changdaoxian', 'cdx');
INSERT INTO `yc_city` VALUES ('1404', '龙口市', '1398', '1', '山东,烟台市,龙口市', null, null, '370681', 'l', 'longkoushi', 'lks');
INSERT INTO `yc_city` VALUES ('1405', '莱阳市', '1398', '1', '山东,烟台市,莱阳市', null, null, '370682', 'l', 'laiyangshi', 'lys');
INSERT INTO `yc_city` VALUES ('1406', '莱州市', '1398', '1', '山东,烟台市,莱州市', null, null, '370683', 'l', 'laizhoushi', 'lzs');
INSERT INTO `yc_city` VALUES ('1407', '蓬莱市', '1398', '1', '山东,烟台市,蓬莱市', null, null, '370684', 'p', 'penglaishi', 'pls');
INSERT INTO `yc_city` VALUES ('1408', '招远市', '1398', '1', '山东,烟台市,招远市', null, null, '370685', 'z', 'zhaoyuanshi', 'zys');
INSERT INTO `yc_city` VALUES ('1409', '栖霞市', '1398', '1', '山东,烟台市,栖霞市', null, null, '370686', 'x', 'xixiashi', 'qxs');
INSERT INTO `yc_city` VALUES ('1410', '海阳市', '1398', '1', '山东,烟台市,海阳市', null, null, '370687', 'h', 'haiyangshi', 'hys');
INSERT INTO `yc_city` VALUES ('1411', '潍坊市', '1353', '1', '山东,潍坊市', null, null, '370700', 'w', 'weifangshi', 'wfs');
INSERT INTO `yc_city` VALUES ('1412', '潍城区', '1411', '1', '山东,潍坊市,潍城区', null, null, '370702', 'w', 'weichengqu', 'wcq');
INSERT INTO `yc_city` VALUES ('1413', '寒亭区', '1411', '1', '山东,潍坊市,寒亭区', null, null, '370703', 'h', 'hantingqu', 'htq');
INSERT INTO `yc_city` VALUES ('1414', '坊子区', '1411', '1', '山东,潍坊市,坊子区', null, null, '370704', 'f', 'fangziqu', 'fzq');
INSERT INTO `yc_city` VALUES ('1415', '奎文区', '1411', '1', '山东,潍坊市,奎文区', null, null, '370705', 'k', 'kuiwenqu', 'kwq');
INSERT INTO `yc_city` VALUES ('1416', '临朐县', '1411', '1', '山东,潍坊市,临朐县', null, null, '370724', 'l', 'linquxian', 'lx');
INSERT INTO `yc_city` VALUES ('1417', '昌乐县', '1411', '1', '山东,潍坊市,昌乐县', null, null, '370725', 'c', 'changlexian', 'clx');
INSERT INTO `yc_city` VALUES ('1418', '青州市', '1411', '1', '山东,潍坊市,青州市', null, null, '370781', 'q', 'qingzhoushi', 'qzs');
INSERT INTO `yc_city` VALUES ('1419', '诸城市', '1411', '1', '山东,潍坊市,诸城市', null, null, '370782', 'z', 'zhuchengshi', 'zcs');
INSERT INTO `yc_city` VALUES ('1420', '寿光市', '1411', '1', '山东,潍坊市,寿光市', null, null, '370783', 's', 'shouguangshi', 'sgs');
INSERT INTO `yc_city` VALUES ('1421', '安丘市', '1411', '1', '山东,潍坊市,安丘市', null, null, '370784', 'a', 'anqiushi', 'aqs');
INSERT INTO `yc_city` VALUES ('1422', '高密市', '1411', '1', '山东,潍坊市,高密市', null, null, '370785', 'g', 'gaomishi', 'gms');
INSERT INTO `yc_city` VALUES ('1423', '昌邑市', '1411', '1', '山东,潍坊市,昌邑市', null, null, '370786', 'c', 'changyishi', 'cys');
INSERT INTO `yc_city` VALUES ('1424', '济宁市', '1353', '1', '山东,济宁市', null, null, '370800', 'j', 'jiningshi', 'jns');
INSERT INTO `yc_city` VALUES ('1425', '任城区', '1424', '1', '山东,济宁市,任城区', null, null, '370811', 'r', 'renchengqu', 'rcq');
INSERT INTO `yc_city` VALUES ('1426', '兖州区', '1424', '1', '山东,济宁市,兖州区', null, null, '370882', 'y', 'yanzhouqu', 'zq');
INSERT INTO `yc_city` VALUES ('1427', '微山县', '1424', '1', '山东,济宁市,微山县', null, null, '370826', 'w', 'weishanxian', 'wsx');
INSERT INTO `yc_city` VALUES ('1428', '鱼台县', '1424', '1', '山东,济宁市,鱼台县', null, null, '370827', 'y', 'yutaixian', 'ytx');
INSERT INTO `yc_city` VALUES ('1429', '金乡县', '1424', '1', '山东,济宁市,金乡县', null, null, '370828', 'j', 'jinxiangxian', 'jxx');
INSERT INTO `yc_city` VALUES ('1430', '嘉祥县', '1424', '1', '山东,济宁市,嘉祥县', null, null, '370829', 'j', 'jiaxiangxian', 'jxx');
INSERT INTO `yc_city` VALUES ('1431', '汶上县', '1424', '1', '山东,济宁市,汶上县', null, null, '370830', 'w', 'wenshangxian', 'sx');
INSERT INTO `yc_city` VALUES ('1432', '泗水县', '1424', '1', '山东,济宁市,泗水县', null, null, '370831', 's', 'sishuixian', 'sx');
INSERT INTO `yc_city` VALUES ('1433', '梁山县', '1424', '1', '山东,济宁市,梁山县', null, null, '370832', 'l', 'liangshanxian', 'lsx');
INSERT INTO `yc_city` VALUES ('1434', '曲阜市', '1424', '1', '山东,济宁市,曲阜市', null, null, '370881', 'q', 'qufushi', 'qfs');
INSERT INTO `yc_city` VALUES ('1435', '邹城市', '1424', '1', '山东,济宁市,邹城市', null, null, '370883', 'z', 'zouchengshi', 'zcs');
INSERT INTO `yc_city` VALUES ('1436', '泰安市', '1353', '1', '山东,泰安市', null, null, '370900', 't', 'taianshi', 'tas');
INSERT INTO `yc_city` VALUES ('1437', '泰山区', '1436', '1', '山东,泰安市,泰山区', null, null, '370902', 't', 'taishanqu', 'tsq');
INSERT INTO `yc_city` VALUES ('1438', '岱岳区', '1436', '1', '山东,泰安市,岱岳区', null, null, '370911', 'd', 'daiyuequ', 'yq');
INSERT INTO `yc_city` VALUES ('1439', '宁阳县', '1436', '1', '山东,泰安市,宁阳县', null, null, '370921', 'n', 'ningyangxian', 'nyx');
INSERT INTO `yc_city` VALUES ('1440', '东平县', '1436', '1', '山东,泰安市,东平县', null, null, '370923', 'd', 'dongpingxian', 'dpx');
INSERT INTO `yc_city` VALUES ('1441', '新泰市', '1436', '1', '山东,泰安市,新泰市', null, null, '370982', 'x', 'xintaishi', 'xts');
INSERT INTO `yc_city` VALUES ('1442', '肥城市', '1436', '1', '山东,泰安市,肥城市', null, null, '370983', 'f', 'feichengshi', 'fcs');
INSERT INTO `yc_city` VALUES ('1443', '威海市', '1353', '1', '山东,威海市', null, null, '371000', 'w', 'weihaishi', 'whs');
INSERT INTO `yc_city` VALUES ('1444', '环翠区', '1443', '1', '山东,威海市,环翠区', null, null, '371002', 'h', 'huancuiqu', 'hcq');
INSERT INTO `yc_city` VALUES ('1445', '文登区', '1443', '1', '山东,威海市,文登区', null, null, '371081', 'w', 'wendengqu', 'wdq');
INSERT INTO `yc_city` VALUES ('1446', '荣成市', '1443', '1', '山东,威海市,荣成市', null, null, '371082', 'r', 'rongchengshi', 'rcs');
INSERT INTO `yc_city` VALUES ('1447', '乳山市', '1443', '1', '山东,威海市,乳山市', null, null, '371083', 'r', 'rushanshi', 'rss');
INSERT INTO `yc_city` VALUES ('1448', '日照市', '1353', '1', '山东,日照市', null, null, '371100', 'r', 'rizhaoshi', 'rzs');
INSERT INTO `yc_city` VALUES ('1449', '东港区', '1448', '1', '山东,日照市,东港区', null, null, '371102', 'd', 'donggangqu', 'dgq');
INSERT INTO `yc_city` VALUES ('1450', '岚山区', '1448', '1', '山东,日照市,岚山区', null, null, '371103', 'l', 'lanshanqu', 'sq');
INSERT INTO `yc_city` VALUES ('1451', '五莲县', '1448', '1', '山东,日照市,五莲县', null, null, '371121', 'w', 'wulianxian', 'wlx');
INSERT INTO `yc_city` VALUES ('1452', '莒县', '1448', '1', '山东,日照市,莒县', null, null, '371122', 'j', 'juxian', 'x');
INSERT INTO `yc_city` VALUES ('1453', '莱芜市', '1353', '1', '山东,莱芜市', null, null, '371200', 'l', 'laiwushi', 'lws');
INSERT INTO `yc_city` VALUES ('1454', '莱城区', '1453', '1', '山东,莱芜市,莱城区', null, null, '371202', 'l', 'laichengqu', 'lcq');
INSERT INTO `yc_city` VALUES ('1455', '钢城区', '1453', '1', '山东,莱芜市,钢城区', null, null, '371203', 'g', 'gangchengqu', 'gcq');
INSERT INTO `yc_city` VALUES ('1456', '临沂市', '1353', '1', '山东,临沂市', null, null, '371300', 'l', 'linyishi', 'lys');
INSERT INTO `yc_city` VALUES ('1457', '兰山区', '1456', '1', '山东,临沂市,兰山区', null, null, '371302', 'l', 'lanshanqu', 'lsq');
INSERT INTO `yc_city` VALUES ('1458', '罗庄区', '1456', '1', '山东,临沂市,罗庄区', null, null, '371311', 'l', 'luozhuangqu', 'lzq');
INSERT INTO `yc_city` VALUES ('1459', '河东区', '1456', '1', '山东,临沂市,河东区', null, null, '371312', 'h', 'hedongqu', 'hdq');
INSERT INTO `yc_city` VALUES ('1460', '沂南县', '1456', '1', '山东,临沂市,沂南县', null, null, '371321', 'y', 'yinanxian', 'ynx');
INSERT INTO `yc_city` VALUES ('1461', '郯城县', '1456', '1', '山东,临沂市,郯城县', null, null, '371322', 't', 'tanchengxian', 'cx');
INSERT INTO `yc_city` VALUES ('1462', '沂水县', '1456', '1', '山东,临沂市,沂水县', null, null, '371323', 'y', 'yishuixian', 'ysx');
INSERT INTO `yc_city` VALUES ('1463', '兰陵县', '1456', '1', '山东,临沂市,兰陵县', null, null, null, 'l', 'lanlingxian', 'llx');
INSERT INTO `yc_city` VALUES ('1464', '费县', '1456', '1', '山东,临沂市,费县', null, null, '371325', 'f', 'feixian', 'fx');
INSERT INTO `yc_city` VALUES ('1465', '平邑县', '1456', '1', '山东,临沂市,平邑县', null, null, '371326', 'p', 'pingyixian', 'pyx');
INSERT INTO `yc_city` VALUES ('1466', '莒南县', '1456', '1', '山东,临沂市,莒南县', null, null, '371327', 'j', 'junanxian', 'nx');
INSERT INTO `yc_city` VALUES ('1467', '蒙阴县', '1456', '1', '山东,临沂市,蒙阴县', null, null, '371328', 'm', 'mengyinxian', 'myx');
INSERT INTO `yc_city` VALUES ('1468', '临沭县', '1456', '1', '山东,临沂市,临沭县', null, null, '371329', 'l', 'linshuxian', 'lx');
INSERT INTO `yc_city` VALUES ('1469', '德州市', '1353', '1', '山东,德州市', null, null, '371400', 'd', 'dezhoushi', 'dzs');
INSERT INTO `yc_city` VALUES ('1470', '德城区', '1469', '1', '山东,德州市,德城区', null, null, '371402', 'd', 'dechengqu', 'dcq');
INSERT INTO `yc_city` VALUES ('1471', '陵城区', '1469', '1', '山东,德州市,陵城区', null, null, null, 'l', 'lingchengqu', 'lcq');
INSERT INTO `yc_city` VALUES ('1472', '宁津县', '1469', '1', '山东,德州市,宁津县', null, null, '371422', 'n', 'ningjinxian', 'njx');
INSERT INTO `yc_city` VALUES ('1473', '庆云县', '1469', '1', '山东,德州市,庆云县', null, null, '371423', 'q', 'qingyunxian', 'qyx');
INSERT INTO `yc_city` VALUES ('1474', '临邑县', '1469', '1', '山东,德州市,临邑县', null, null, '371424', 'l', 'linyixian', 'lyx');
INSERT INTO `yc_city` VALUES ('1475', '齐河县', '1469', '1', '山东,德州市,齐河县', null, null, '371425', 'q', 'qihexian', 'qhx');
INSERT INTO `yc_city` VALUES ('1476', '平原县', '1469', '1', '山东,德州市,平原县', null, null, '371426', 'p', 'pingyuanxian', 'pyx');
INSERT INTO `yc_city` VALUES ('1477', '夏津县', '1469', '1', '山东,德州市,夏津县', null, null, '371427', 'x', 'xiajinxian', 'xjx');
INSERT INTO `yc_city` VALUES ('1478', '武城县', '1469', '1', '山东,德州市,武城县', null, null, '371428', 'w', 'wuchengxian', 'wcx');
INSERT INTO `yc_city` VALUES ('1479', '乐陵市', '1469', '1', '山东,德州市,乐陵市', null, null, '371481', 'l', 'lelingshi', 'lls');
INSERT INTO `yc_city` VALUES ('1480', '禹城市', '1469', '1', '山东,德州市,禹城市', null, null, '371482', 'y', 'yuchengshi', 'ycs');
INSERT INTO `yc_city` VALUES ('1481', '聊城市', '1353', '1', '山东,聊城市', null, null, '371500', 'l', 'liaochengshi', 'lcs');
INSERT INTO `yc_city` VALUES ('1482', '东昌府区', '1481', '1', '山东,聊城市,东昌府区', null, null, '371502', 'd', 'dongchangfuqu', 'dcfq');
INSERT INTO `yc_city` VALUES ('1483', '阳谷县', '1481', '1', '山东,聊城市,阳谷县', null, null, '371521', 'y', 'yangguxian', 'ygx');
INSERT INTO `yc_city` VALUES ('1484', '莘县', '1481', '1', '山东,聊城市,莘县', null, null, '371522', 's', 'shenxian', 'x');
INSERT INTO `yc_city` VALUES ('1485', '茌平县', '1481', '1', '山东,聊城市,茌平县', null, null, '371523', 'c', 'chipingxian', 'px');
INSERT INTO `yc_city` VALUES ('1486', '东阿县', '1481', '1', '山东,聊城市,东阿县', null, null, '371524', 'd', 'dongexian', 'dax');
INSERT INTO `yc_city` VALUES ('1487', '冠县', '1481', '1', '山东,聊城市,冠县', null, null, '371525', 'g', 'guanxian', 'gx');
INSERT INTO `yc_city` VALUES ('1488', '高唐县', '1481', '1', '山东,聊城市,高唐县', null, null, '371526', 'g', 'gaotangxian', 'gtx');
INSERT INTO `yc_city` VALUES ('1489', '临清市', '1481', '1', '山东,聊城市,临清市', null, null, '371581', 'l', 'linqingshi', 'lqs');
INSERT INTO `yc_city` VALUES ('1490', '滨州市', '1353', '1', '山东,滨州市', null, null, '371600', 'b', 'binzhoushi', 'bzs');
INSERT INTO `yc_city` VALUES ('1491', '滨城区', '1490', '1', '山东,滨州市,滨城区', null, null, '371602', 'b', 'binchengqu', 'bcq');
INSERT INTO `yc_city` VALUES ('1492', '沾化区', '1490', '1', '山东,滨州市,沾化区', null, null, null, 'z', 'zhanhuaqu', 'zhq');
INSERT INTO `yc_city` VALUES ('1493', '惠民县', '1490', '1', '山东,滨州市,惠民县', null, null, '371621', 'h', 'huiminxian', 'hmx');
INSERT INTO `yc_city` VALUES ('1494', '阳信县', '1490', '1', '山东,滨州市,阳信县', null, null, '371622', 'y', 'yangxinxian', 'yxx');
INSERT INTO `yc_city` VALUES ('1495', '无棣县', '1490', '1', '山东,滨州市,无棣县', null, null, '371623', 'w', 'wudixian', 'wx');
INSERT INTO `yc_city` VALUES ('1496', '博兴县', '1490', '1', '山东,滨州市,博兴县', null, null, '371625', 'b', 'boxingxian', 'bxx');
INSERT INTO `yc_city` VALUES ('1497', '邹平县', '1490', '1', '山东,滨州市,邹平县', null, null, '371626', 'z', 'zoupingxian', 'zpx');
INSERT INTO `yc_city` VALUES ('1498', '菏泽市', '1353', '1', '山东,菏泽市', null, null, '371700', 'h', 'hezeshi', 'hzs');
INSERT INTO `yc_city` VALUES ('1499', '牡丹区', '1498', '1', '山东,菏泽市,牡丹区', null, null, '371702', 'm', 'mudanqu', 'mdq');
INSERT INTO `yc_city` VALUES ('1500', '曹县', '1498', '1', '山东,菏泽市,曹县', null, null, '371721', 'c', 'caoxian', 'cx');
INSERT INTO `yc_city` VALUES ('1501', '单县', '1498', '1', '山东,菏泽市,单县', null, null, '371722', 's', 'shanxian', 'dx');
INSERT INTO `yc_city` VALUES ('1502', '成武县', '1498', '1', '山东,菏泽市,成武县', null, null, '371723', 'c', 'chengwuxian', 'cwx');
INSERT INTO `yc_city` VALUES ('1503', '巨野县', '1498', '1', '山东,菏泽市,巨野县', null, null, '371724', 'j', 'juyexian', 'jyx');
INSERT INTO `yc_city` VALUES ('1504', '郓城县', '1498', '1', '山东,菏泽市,郓城县', null, null, '371725', 'y', 'yunchengxian', 'cx');
INSERT INTO `yc_city` VALUES ('1505', '鄄城县', '1498', '1', '山东,菏泽市,鄄城县', null, null, '371726', 'j', 'juanchengxian', 'cx');
INSERT INTO `yc_city` VALUES ('1506', '定陶县', '1498', '1', '山东,菏泽市,定陶县', null, null, '371727', 'd', 'dingtaoxian', 'dtx');
INSERT INTO `yc_city` VALUES ('1507', '东明县', '1498', '1', '山东,菏泽市,东明县', null, null, '371728', 'd', 'dongmingxian', 'dmx');
INSERT INTO `yc_city` VALUES ('1508', '河南', '1', '1', '河南', null, null, '410000', 'h', 'henan', 'hn');
INSERT INTO `yc_city` VALUES ('1509', '郑州市', '1508', '1', '河南,郑州市', null, null, '410100', 'z', 'zhengzhoushi', 'zzs');
INSERT INTO `yc_city` VALUES ('1510', '中原区', '1509', '1', '河南,郑州市,中原区', null, null, '410102', 'z', 'zhongyuanqu', 'zyq');
INSERT INTO `yc_city` VALUES ('1511', '二七区', '1509', '1', '河南,郑州市,二七区', null, null, '410103', 'e', 'erqiqu', 'eqq');
INSERT INTO `yc_city` VALUES ('1512', '管城回族区', '1509', '1', '河南,郑州市,管城回族区', null, null, '410104', 'g', 'guanchenghuizuqu', 'gchzq');
INSERT INTO `yc_city` VALUES ('1513', '金水区', '1509', '1', '河南,郑州市,金水区', null, null, '410105', 'j', 'jinshuiqu', 'jsq');
INSERT INTO `yc_city` VALUES ('1514', '上街区', '1509', '1', '河南,郑州市,上街区', null, null, '410106', 's', 'shangjiequ', 'sjq');
INSERT INTO `yc_city` VALUES ('1515', '惠济区', '1509', '1', '河南,郑州市,惠济区', null, null, '410108', 'h', 'huijiqu', 'hjq');
INSERT INTO `yc_city` VALUES ('1516', '中牟县', '1509', '1', '河南,郑州市,中牟县', null, null, '410122', 'z', 'zhongmuxian', 'zmx');
INSERT INTO `yc_city` VALUES ('1517', '巩义市', '1509', '1', '河南,郑州市,巩义市', null, null, '410181', 'g', 'gongyishi', 'gys');
INSERT INTO `yc_city` VALUES ('1518', '荥阳市', '1509', '1', '河南,郑州市,荥阳市', null, null, '410182', 'x', 'xingyangshi', 'ys');
INSERT INTO `yc_city` VALUES ('1519', '新密市', '1509', '1', '河南,郑州市,新密市', null, null, '410183', 'x', 'xinmishi', 'xms');
INSERT INTO `yc_city` VALUES ('1520', '新郑市', '1509', '1', '河南,郑州市,新郑市', null, null, '410184', 'x', 'xinzhengshi', 'xzs');
INSERT INTO `yc_city` VALUES ('1521', '登封市', '1509', '1', '河南,郑州市,登封市', null, null, '410185', 'd', 'dengfengshi', 'dfs');
INSERT INTO `yc_city` VALUES ('1522', '开封市', '1508', '1', '河南,开封市', null, null, '410200', 'k', 'kaifengshi', 'kfs');
INSERT INTO `yc_city` VALUES ('1523', '龙亭区', '1522', '1', '河南,开封市,龙亭区', null, null, '410202', 'l', 'longtingqu', 'ltq');
INSERT INTO `yc_city` VALUES ('1524', '顺河回族区', '1522', '1', '河南,开封市,顺河回族区', null, null, '410203', 's', 'shunhehuizuqu', 'shhzq');
INSERT INTO `yc_city` VALUES ('1525', '鼓楼区', '1522', '1', '河南,开封市,鼓楼区', null, null, '410204', 'g', 'gulouqu', 'glq');
INSERT INTO `yc_city` VALUES ('1526', '禹王台区', '1522', '1', '河南,开封市,禹王台区', null, null, '410205', 'y', 'yuwangtaiqu', 'ywtq');
INSERT INTO `yc_city` VALUES ('1527', '金明区', '1522', '1', '河南,开封市,金明区', null, null, '410211', 'j', 'jinmingqu', 'jmq');
INSERT INTO `yc_city` VALUES ('1528', '杞县', '1522', '1', '河南,开封市,杞县', null, null, '410221', 'q', 'qixian', 'x');
INSERT INTO `yc_city` VALUES ('1529', '通许县', '1522', '1', '河南,开封市,通许县', null, null, '410222', 't', 'tongxuxian', 'txx');
INSERT INTO `yc_city` VALUES ('1530', '尉氏县', '1522', '1', '河南,开封市,尉氏县', null, null, '410223', 'w', 'weishixian', 'wsx');
INSERT INTO `yc_city` VALUES ('1531', '开封县', '1522', '1', '河南,开封市,开封县', null, null, '410224', 'k', 'kaifengxian', 'kfx');
INSERT INTO `yc_city` VALUES ('1532', '兰考县', '1522', '1', '河南,开封市,兰考县', null, null, '410225', 'l', 'lankaoxian', 'lkx');
INSERT INTO `yc_city` VALUES ('1533', '洛阳市', '1508', '1', '河南,洛阳市', null, null, '410300', 'l', 'luoyangshi', 'lys');
INSERT INTO `yc_city` VALUES ('1534', '老城区', '1533', '1', '河南,洛阳市,老城区', null, null, '410302', 'l', 'laochengqu', 'lcq');
INSERT INTO `yc_city` VALUES ('1535', '西工区', '1533', '1', '河南,洛阳市,西工区', null, null, '410303', 'x', 'xigongqu', 'xgq');
INSERT INTO `yc_city` VALUES ('1536', '瀍河回族区', '1533', '1', '河南,洛阳市,瀍河回族区', null, null, '410304', 'c', 'chanhehuizuqu', '');
INSERT INTO `yc_city` VALUES ('1537', '涧西区', '1533', '1', '河南,洛阳市,涧西区', null, null, '410305', 'j', 'jianxiqu', 'jxq');
INSERT INTO `yc_city` VALUES ('1538', '吉利区', '1533', '1', '河南,洛阳市,吉利区', null, null, '410306', 'j', 'jiliqu', 'jlq');
INSERT INTO `yc_city` VALUES ('1539', '洛龙区', '1533', '1', '河南,洛阳市,洛龙区', null, null, '410311', 'l', 'luolongqu', 'llq');
INSERT INTO `yc_city` VALUES ('1540', '孟津县', '1533', '1', '河南,洛阳市,孟津县', null, null, '410322', 'm', 'mengjinxian', 'mjx');
INSERT INTO `yc_city` VALUES ('1541', '新安县', '1533', '1', '河南,洛阳市,新安县', null, null, '410323', 'x', 'xinanxian', 'xax');
INSERT INTO `yc_city` VALUES ('1542', '栾川县', '1533', '1', '河南,洛阳市,栾川县', null, null, '410324', 'l', 'luanchuanxian', 'cx');
INSERT INTO `yc_city` VALUES ('1543', '嵩县', '1533', '1', '河南,洛阳市,嵩县', null, null, '410325', 's', 'songxian', 'x');
INSERT INTO `yc_city` VALUES ('1544', '汝阳县', '1533', '1', '河南,洛阳市,汝阳县', null, null, '410326', 'r', 'ruyangxian', 'ryx');
INSERT INTO `yc_city` VALUES ('1545', '宜阳县', '1533', '1', '河南,洛阳市,宜阳县', null, null, '410327', 'y', 'yiyangxian', 'yyx');
INSERT INTO `yc_city` VALUES ('1546', '洛宁县', '1533', '1', '河南,洛阳市,洛宁县', null, null, '410328', 'l', 'luoningxian', 'lnx');
INSERT INTO `yc_city` VALUES ('1547', '伊川县', '1533', '1', '河南,洛阳市,伊川县', null, null, '410329', 'y', 'yichuanxian', 'ycx');
INSERT INTO `yc_city` VALUES ('1548', '偃师市', '1533', '1', '河南,洛阳市,偃师市', null, null, '410381', 'y', 'yanshishi', 'ss');
INSERT INTO `yc_city` VALUES ('1549', '平顶山市', '1508', '1', '河南,平顶山市', null, null, '410400', 'p', 'pingdingshanshi', 'pdss');
INSERT INTO `yc_city` VALUES ('1550', '新华区', '1549', '1', '河南,平顶山市,新华区', null, null, '410402', 'x', 'xinhuaqu', 'xhq');
INSERT INTO `yc_city` VALUES ('1551', '卫东区', '1549', '1', '河南,平顶山市,卫东区', null, null, '410403', 'w', 'weidongqu', 'wdq');
INSERT INTO `yc_city` VALUES ('1552', '石龙区', '1549', '1', '河南,平顶山市,石龙区', null, null, '410404', 's', 'shilongqu', 'slq');
INSERT INTO `yc_city` VALUES ('1553', '湛河区', '1549', '1', '河南,平顶山市,湛河区', null, null, '410411', 'z', 'zhanhequ', 'zhq');
INSERT INTO `yc_city` VALUES ('1554', '宝丰县', '1549', '1', '河南,平顶山市,宝丰县', null, null, '410421', 'b', 'baofengxian', 'bfx');
INSERT INTO `yc_city` VALUES ('1555', '叶县', '1549', '1', '河南,平顶山市,叶县', null, null, '410422', 'y', 'yexian', 'yx');
INSERT INTO `yc_city` VALUES ('1556', '鲁山县', '1549', '1', '河南,平顶山市,鲁山县', null, null, '410423', 'l', 'lushanxian', 'lsx');
INSERT INTO `yc_city` VALUES ('1557', '郏县', '1549', '1', '河南,平顶山市,郏县', null, null, '410425', 'j', 'jiaxian', 'x');
INSERT INTO `yc_city` VALUES ('1558', '舞钢市', '1549', '1', '河南,平顶山市,舞钢市', null, null, '410481', 'w', 'wugangshi', 'wgs');
INSERT INTO `yc_city` VALUES ('1559', '汝州市', '1549', '1', '河南,平顶山市,汝州市', null, null, '410482', 'r', 'ruzhoushi', 'rzs');
INSERT INTO `yc_city` VALUES ('1560', '安阳市', '1508', '1', '河南,安阳市', null, null, '410500', 'a', 'anyangshi', 'ays');
INSERT INTO `yc_city` VALUES ('1561', '文峰区', '1560', '1', '河南,安阳市,文峰区', null, null, '410502', 'w', 'wenfengqu', 'wfq');
INSERT INTO `yc_city` VALUES ('1562', '北关区', '1560', '1', '河南,安阳市,北关区', null, null, '410503', 'b', 'beiguanqu', 'bgq');
INSERT INTO `yc_city` VALUES ('1563', '殷都区', '1560', '1', '河南,安阳市,殷都区', null, null, '410505', 'y', 'yinduqu', 'ydq');
INSERT INTO `yc_city` VALUES ('1564', '龙安区', '1560', '1', '河南,安阳市,龙安区', null, null, '410506', 'l', 'longanqu', 'laq');
INSERT INTO `yc_city` VALUES ('1565', '安阳县', '1560', '1', '河南,安阳市,安阳县', null, null, '410522', 'a', 'anyangxian', 'ayx');
INSERT INTO `yc_city` VALUES ('1566', '汤阴县', '1560', '1', '河南,安阳市,汤阴县', null, null, '410523', 't', 'tangyinxian', 'tyx');
INSERT INTO `yc_city` VALUES ('1567', '滑县', '1560', '1', '河南,安阳市,滑县', null, null, '410526', 'h', 'huaxian', 'hx');
INSERT INTO `yc_city` VALUES ('1568', '内黄县', '1560', '1', '河南,安阳市,内黄县', null, null, '410527', 'n', 'neihuangxian', 'nhx');
INSERT INTO `yc_city` VALUES ('1569', '林州市', '1560', '1', '河南,安阳市,林州市', null, null, '410581', 'l', 'linzhoushi', 'lzs');
INSERT INTO `yc_city` VALUES ('1570', '鹤壁市', '1508', '1', '河南,鹤壁市', null, null, '410600', 'h', 'hebishi', 'hbs');
INSERT INTO `yc_city` VALUES ('1571', '鹤山区', '1570', '1', '河南,鹤壁市,鹤山区', null, null, '410602', 'h', 'heshanqu', 'hsq');
INSERT INTO `yc_city` VALUES ('1572', '山城区', '1570', '1', '河南,鹤壁市,山城区', null, null, '410603', 's', 'shanchengqu', 'scq');
INSERT INTO `yc_city` VALUES ('1573', '淇滨区', '1570', '1', '河南,鹤壁市,淇滨区', null, null, '410611', 'q', 'qibinqu', 'bq');
INSERT INTO `yc_city` VALUES ('1574', '浚县', '1570', '1', '河南,鹤壁市,浚县', null, null, '410621', 'j', 'junxian', 'jx');
INSERT INTO `yc_city` VALUES ('1575', '淇县', '1570', '1', '河南,鹤壁市,淇县', null, null, '410622', 'q', 'qixian', 'x');
INSERT INTO `yc_city` VALUES ('1576', '新乡市', '1508', '1', '河南,新乡市', null, null, '410700', 'x', 'xinxiangshi', 'xxs');
INSERT INTO `yc_city` VALUES ('1577', '红旗区', '1576', '1', '河南,新乡市,红旗区', null, null, '410702', 'h', 'hongqiqu', 'hqq');
INSERT INTO `yc_city` VALUES ('1578', '卫滨区', '1576', '1', '河南,新乡市,卫滨区', null, null, '410703', 'w', 'weibinqu', 'wbq');
INSERT INTO `yc_city` VALUES ('1579', '凤泉区', '1576', '1', '河南,新乡市,凤泉区', null, null, '410704', 'f', 'fengquanqu', 'fqq');
INSERT INTO `yc_city` VALUES ('1580', '牧野区', '1576', '1', '河南,新乡市,牧野区', null, null, '410711', 'm', 'muyequ', 'myq');
INSERT INTO `yc_city` VALUES ('1581', '新乡县', '1576', '1', '河南,新乡市,新乡县', null, null, '410721', 'x', 'xinxiangxian', 'xxx');
INSERT INTO `yc_city` VALUES ('1582', '获嘉县', '1576', '1', '河南,新乡市,获嘉县', null, null, '410724', 'h', 'huojiaxian', 'hjx');
INSERT INTO `yc_city` VALUES ('1583', '原阳县', '1576', '1', '河南,新乡市,原阳县', null, null, '410725', 'y', 'yuanyangxian', 'yyx');
INSERT INTO `yc_city` VALUES ('1584', '延津县', '1576', '1', '河南,新乡市,延津县', null, null, '410726', 'y', 'yanjinxian', 'yjx');
INSERT INTO `yc_city` VALUES ('1585', '封丘县', '1576', '1', '河南,新乡市,封丘县', null, null, '410727', 'f', 'fengqiuxian', 'fqx');
INSERT INTO `yc_city` VALUES ('1586', '长垣县', '1576', '1', '河南,新乡市,长垣县', null, null, '410728', 'c', 'changyuanxian', 'cyx');
INSERT INTO `yc_city` VALUES ('1587', '卫辉市', '1576', '1', '河南,新乡市,卫辉市', null, null, '410781', 'w', 'weihuishi', 'whs');
INSERT INTO `yc_city` VALUES ('1588', '辉县市', '1576', '1', '河南,新乡市,辉县市', null, null, '410782', 'h', 'huixianshi', 'hxs');
INSERT INTO `yc_city` VALUES ('1589', '焦作市', '1508', '1', '河南,焦作市', null, null, '410800', 'j', 'jiaozuoshi', 'jzs');
INSERT INTO `yc_city` VALUES ('1590', '解放区', '1589', '1', '河南,焦作市,解放区', null, null, '410802', 'j', 'jiefangqu', 'jfq');
INSERT INTO `yc_city` VALUES ('1591', '中站区', '1589', '1', '河南,焦作市,中站区', null, null, '410803', 'z', 'zhongzhanqu', 'zzq');
INSERT INTO `yc_city` VALUES ('1592', '马村区', '1589', '1', '河南,焦作市,马村区', null, null, '410804', 'm', 'macunqu', 'mcq');
INSERT INTO `yc_city` VALUES ('1593', '山阳区', '1589', '1', '河南,焦作市,山阳区', null, null, '410811', 's', 'shanyangqu', 'syq');
INSERT INTO `yc_city` VALUES ('1594', '修武县', '1589', '1', '河南,焦作市,修武县', null, null, '410821', 'x', 'xiuwuxian', 'xwx');
INSERT INTO `yc_city` VALUES ('1595', '博爱县', '1589', '1', '河南,焦作市,博爱县', null, null, '410822', 'b', 'boaixian', 'bax');
INSERT INTO `yc_city` VALUES ('1596', '武陟县', '1589', '1', '河南,焦作市,武陟县', null, null, '410823', 'w', 'wuzhixian', 'wx');
INSERT INTO `yc_city` VALUES ('1597', '温县', '1589', '1', '河南,焦作市,温县', null, null, '410825', 'w', 'wenxian', 'wx');
INSERT INTO `yc_city` VALUES ('1598', '沁阳市', '1589', '1', '河南,焦作市,沁阳市', null, null, '410882', 'q', 'qinyangshi', 'qys');
INSERT INTO `yc_city` VALUES ('1599', '孟州市', '1589', '1', '河南,焦作市,孟州市', null, null, '410883', 'm', 'mengzhoushi', 'mzs');
INSERT INTO `yc_city` VALUES ('1600', '濮阳市', '1508', '1', '河南,濮阳市', null, null, '410900', 'p', 'puyangshi', 'ys');
INSERT INTO `yc_city` VALUES ('1601', '华龙区', '1600', '1', '河南,濮阳市,华龙区', null, null, '410902', 'h', 'hualongqu', 'hlq');
INSERT INTO `yc_city` VALUES ('1602', '清丰县', '1600', '1', '河南,濮阳市,清丰县', null, null, '410922', 'q', 'qingfengxian', 'qfx');
INSERT INTO `yc_city` VALUES ('1603', '南乐县', '1600', '1', '河南,濮阳市,南乐县', null, null, '410923', 'n', 'nanlexian', 'nlx');
INSERT INTO `yc_city` VALUES ('1604', '范县', '1600', '1', '河南,濮阳市,范县', null, null, '410926', 'f', 'fanxian', 'fx');
INSERT INTO `yc_city` VALUES ('1605', '台前县', '1600', '1', '河南,濮阳市,台前县', null, null, '410927', 't', 'taiqianxian', 'tqx');
INSERT INTO `yc_city` VALUES ('1606', '濮阳县', '1600', '1', '河南,濮阳市,濮阳县', null, null, '410928', 'p', 'puyangxian', 'yx');
INSERT INTO `yc_city` VALUES ('1607', '许昌市', '1508', '1', '河南,许昌市', null, null, '411000', 'x', 'xuchangshi', 'xcs');
INSERT INTO `yc_city` VALUES ('1608', '魏都区', '1607', '1', '河南,许昌市,魏都区', null, null, '411002', 'w', 'weiduqu', 'wdq');
INSERT INTO `yc_city` VALUES ('1609', '许昌县', '1607', '1', '河南,许昌市,许昌县', null, null, '411023', 'x', 'xuchangxian', 'xcx');
INSERT INTO `yc_city` VALUES ('1610', '鄢陵县', '1607', '1', '河南,许昌市,鄢陵县', null, null, '411024', 'y', 'yanlingxian', 'lx');
INSERT INTO `yc_city` VALUES ('1611', '襄城县', '1607', '1', '河南,许昌市,襄城县', null, null, '411025', 'x', 'xiangchengxian', 'xcx');
INSERT INTO `yc_city` VALUES ('1612', '禹州市', '1607', '1', '河南,许昌市,禹州市', null, null, '411081', 'y', 'yuzhoushi', 'yzs');
INSERT INTO `yc_city` VALUES ('1613', '长葛市', '1607', '1', '河南,许昌市,长葛市', null, null, '411082', 'c', 'changgeshi', 'cgs');
INSERT INTO `yc_city` VALUES ('1614', '源汇区', '1607', '1', '河南,许昌市,源汇区', null, null, null, 'y', 'yuanhuiqu', 'yhq');
INSERT INTO `yc_city` VALUES ('1615', '郾城区', '1607', '1', '河南,许昌市,郾城区', null, null, null, 'y', 'yanchengqu', 'cq');
INSERT INTO `yc_city` VALUES ('1616', '召陵区', '1607', '1', '河南,许昌市,召陵区', null, null, null, 's', 'shaolingqu', 'zlq');
INSERT INTO `yc_city` VALUES ('1617', '舞阳县', '1607', '1', '河南,许昌市,舞阳县', null, null, null, 'w', 'wuyangxian', 'wyx');
INSERT INTO `yc_city` VALUES ('1618', '临颍县', '1607', '1', '河南,许昌市,临颍县', null, null, null, 'l', 'linyingxian', 'lx');
INSERT INTO `yc_city` VALUES ('1619', '三门峡市', '1508', '1', '河南,三门峡市', null, null, '411200', 's', 'sanmenxiashi', 'smxs');
INSERT INTO `yc_city` VALUES ('1620', '湖滨区', '1619', '1', '河南,三门峡市,湖滨区', null, null, '411202', 'h', 'hubinqu', 'hbq');
INSERT INTO `yc_city` VALUES ('1621', '渑池县', '1619', '1', '河南,三门峡市,渑池县', null, null, '411221', 'm', 'mianchixian', 'cx');
INSERT INTO `yc_city` VALUES ('1622', '陕县', '1619', '1', '河南,三门峡市,陕县', null, null, '411222', 's', 'shanxian', 'sx');
INSERT INTO `yc_city` VALUES ('1623', '卢氏县', '1619', '1', '河南,三门峡市,卢氏县', null, null, '411224', 'l', 'lushixian', 'lsx');
INSERT INTO `yc_city` VALUES ('1624', '义马市', '1619', '1', '河南,三门峡市,义马市', null, null, '411281', 'y', 'yimashi', 'yms');
INSERT INTO `yc_city` VALUES ('1625', '灵宝市', '1619', '1', '河南,三门峡市,灵宝市', null, null, '411282', 'l', 'lingbaoshi', 'lbs');
INSERT INTO `yc_city` VALUES ('1626', '南阳市', '1508', '1', '河南,南阳市', null, null, '411300', 'n', 'nanyangshi', 'nys');
INSERT INTO `yc_city` VALUES ('1627', '宛城区', '1626', '1', '河南,南阳市,宛城区', null, null, '411302', 'w', 'wanchengqu', 'wcq');
INSERT INTO `yc_city` VALUES ('1628', '卧龙区', '1626', '1', '河南,南阳市,卧龙区', null, null, '411303', 'w', 'wolongqu', 'wlq');
INSERT INTO `yc_city` VALUES ('1629', '南召县', '1626', '1', '河南,南阳市,南召县', null, null, '411321', 'n', 'nanzhaoxian', 'nzx');
INSERT INTO `yc_city` VALUES ('1630', '方城县', '1626', '1', '河南,南阳市,方城县', null, null, '411322', 'f', 'fangchengxian', 'fcx');
INSERT INTO `yc_city` VALUES ('1631', '西峡县', '1626', '1', '河南,南阳市,西峡县', null, null, '411323', 'x', 'xixiaxian', 'xxx');
INSERT INTO `yc_city` VALUES ('1632', '镇平县', '1626', '1', '河南,南阳市,镇平县', null, null, '411324', 'z', 'zhenpingxian', 'zpx');
INSERT INTO `yc_city` VALUES ('1633', '内乡县', '1626', '1', '河南,南阳市,内乡县', null, null, '411325', 'n', 'neixiangxian', 'nxx');
INSERT INTO `yc_city` VALUES ('1634', '淅川县', '1626', '1', '河南,南阳市,淅川县', null, null, '411326', 'x', 'xichuanxian', 'cx');
INSERT INTO `yc_city` VALUES ('1635', '社旗县', '1626', '1', '河南,南阳市,社旗县', null, null, '411327', 's', 'sheqixian', 'sqx');
INSERT INTO `yc_city` VALUES ('1636', '唐河县', '1626', '1', '河南,南阳市,唐河县', null, null, '411328', 't', 'tanghexian', 'thx');
INSERT INTO `yc_city` VALUES ('1637', '新野县', '1626', '1', '河南,南阳市,新野县', null, null, '411329', 'x', 'xinyexian', 'xyx');
INSERT INTO `yc_city` VALUES ('1638', '桐柏县', '1626', '1', '河南,南阳市,桐柏县', null, null, '411330', 't', 'tongbaixian', 'tbx');
INSERT INTO `yc_city` VALUES ('1639', '邓州市', '1626', '1', '河南,南阳市,邓州市', null, null, '411381', 'd', 'dengzhoushi', 'dzs');
INSERT INTO `yc_city` VALUES ('1640', '商丘市', '1508', '1', '河南,商丘市', null, null, '411400', 's', 'shangqiushi', 'sqs');
INSERT INTO `yc_city` VALUES ('1641', '梁园区', '1640', '1', '河南,商丘市,梁园区', null, null, '411402', 'l', 'liangyuanqu', 'lyq');
INSERT INTO `yc_city` VALUES ('1642', '睢阳区', '1640', '1', '河南,商丘市,睢阳区', null, null, '411403', 's', 'suiyangqu', 'yq');
INSERT INTO `yc_city` VALUES ('1643', '民权县', '1640', '1', '河南,商丘市,民权县', null, null, '411421', 'm', 'minquanxian', 'mqx');
INSERT INTO `yc_city` VALUES ('1644', '睢县', '1640', '1', '河南,商丘市,睢县', null, null, '411422', 's', 'suixian', 'x');
INSERT INTO `yc_city` VALUES ('1645', '宁陵县', '1640', '1', '河南,商丘市,宁陵县', null, null, '411423', 'n', 'ninglingxian', 'nlx');
INSERT INTO `yc_city` VALUES ('1646', '柘城县', '1640', '1', '河南,商丘市,柘城县', null, null, '411424', 'z', 'zhechengxian', 'cx');
INSERT INTO `yc_city` VALUES ('1647', '虞城县', '1640', '1', '河南,商丘市,虞城县', null, null, '411425', 'y', 'yuchengxian', 'ycx');
INSERT INTO `yc_city` VALUES ('1648', '夏邑县', '1640', '1', '河南,商丘市,夏邑县', null, null, '411426', 'x', 'xiayixian', 'xyx');
INSERT INTO `yc_city` VALUES ('1649', '永城市', '1640', '1', '河南,商丘市,永城市', null, null, '411481', 'y', 'yongchengshi', 'ycs');
INSERT INTO `yc_city` VALUES ('1650', '信阳市', '1508', '1', '河南,信阳市', null, null, '411500', 'x', 'xinyangshi', 'xys');
INSERT INTO `yc_city` VALUES ('1651', '浉河区', '1650', '1', '河南,信阳市,浉河区', null, null, '411502', 's', 'shihequ', '');
INSERT INTO `yc_city` VALUES ('1652', '平桥区', '1650', '1', '河南,信阳市,平桥区', null, null, '411503', 'p', 'pingqiaoqu', 'pqq');
INSERT INTO `yc_city` VALUES ('1653', '罗山县', '1650', '1', '河南,信阳市,罗山县', null, null, '411521', 'l', 'luoshanxian', 'lsx');
INSERT INTO `yc_city` VALUES ('1654', '光山县', '1650', '1', '河南,信阳市,光山县', null, null, '411522', 'g', 'guangshanxian', 'gsx');
INSERT INTO `yc_city` VALUES ('1655', '新县', '1650', '1', '河南,信阳市,新县', null, null, '411523', 'x', 'xinxian', 'xx');
INSERT INTO `yc_city` VALUES ('1656', '商城县', '1650', '1', '河南,信阳市,商城县', null, null, '411524', 's', 'shangchengxian', 'scx');
INSERT INTO `yc_city` VALUES ('1657', '固始县', '1650', '1', '河南,信阳市,固始县', null, null, '411525', 'g', 'gushixian', 'gsx');
INSERT INTO `yc_city` VALUES ('1658', '潢川县', '1650', '1', '河南,信阳市,潢川县', null, null, '411526', 'h', 'huangchuanxian', 'cx');
INSERT INTO `yc_city` VALUES ('1659', '淮滨县', '1650', '1', '河南,信阳市,淮滨县', null, null, '411527', 'h', 'huaibinxian', 'hbx');
INSERT INTO `yc_city` VALUES ('1660', '息县', '1650', '1', '河南,信阳市,息县', null, null, '411528', 'x', 'xixian', 'xx');
INSERT INTO `yc_city` VALUES ('1661', '周口市', '1508', '1', '河南,周口市', null, null, '411600', 'z', 'zhoukoushi', 'zks');
INSERT INTO `yc_city` VALUES ('1662', '川汇区', '1661', '1', '河南,周口市,川汇区', null, null, '411602', 'c', 'chuanhuiqu', 'chq');
INSERT INTO `yc_city` VALUES ('1663', '扶沟县', '1661', '1', '河南,周口市,扶沟县', null, null, '411621', 'f', 'fugouxian', 'fgx');
INSERT INTO `yc_city` VALUES ('1664', '西华县', '1661', '1', '河南,周口市,西华县', null, null, '411622', 'x', 'xihuaxian', 'xhx');
INSERT INTO `yc_city` VALUES ('1665', '商水县', '1661', '1', '河南,周口市,商水县', null, null, '411623', 's', 'shangshuixian', 'ssx');
INSERT INTO `yc_city` VALUES ('1666', '沈丘县', '1661', '1', '河南,周口市,沈丘县', null, null, '411624', 's', 'shenqiuxian', 'sqx');
INSERT INTO `yc_city` VALUES ('1667', '郸城县', '1661', '1', '河南,周口市,郸城县', null, null, '411625', 'd', 'danchengxian', 'dcx');
INSERT INTO `yc_city` VALUES ('1668', '淮阳县', '1661', '1', '河南,周口市,淮阳县', null, null, '411626', 'h', 'huaiyangxian', 'hyx');
INSERT INTO `yc_city` VALUES ('1669', '太康县', '1661', '1', '河南,周口市,太康县', null, null, '411627', 't', 'taikangxian', 'tkx');
INSERT INTO `yc_city` VALUES ('1670', '鹿邑县', '1661', '1', '河南,周口市,鹿邑县', null, null, '411628', 'l', 'luyixian', 'lyx');
INSERT INTO `yc_city` VALUES ('1671', '项城市', '1661', '1', '河南,周口市,项城市', null, null, '411681', 'x', 'xiangchengshi', 'xcs');
INSERT INTO `yc_city` VALUES ('1672', '驻马店市', '1508', '1', '河南,驻马店市', null, null, '411700', 'z', 'zhumadianshi', 'zmds');
INSERT INTO `yc_city` VALUES ('1673', '驿城区', '1672', '1', '河南,驻马店市,驿城区', null, null, '411702', 'y', 'yichengqu', 'cq');
INSERT INTO `yc_city` VALUES ('1674', '西平县', '1672', '1', '河南,驻马店市,西平县', null, null, '411721', 'x', 'xipingxian', 'xpx');
INSERT INTO `yc_city` VALUES ('1675', '上蔡县', '1672', '1', '河南,驻马店市,上蔡县', null, null, '411722', 's', 'shangcaixian', 'scx');
INSERT INTO `yc_city` VALUES ('1676', '平舆县', '1672', '1', '河南,驻马店市,平舆县', null, null, '411723', 'p', 'pingyuxian', 'pyx');
INSERT INTO `yc_city` VALUES ('1677', '正阳县', '1672', '1', '河南,驻马店市,正阳县', null, null, '411724', 'z', 'zhengyangxian', 'zyx');
INSERT INTO `yc_city` VALUES ('1678', '确山县', '1672', '1', '河南,驻马店市,确山县', null, null, '411725', 'q', 'queshanxian', 'qsx');
INSERT INTO `yc_city` VALUES ('1679', '泌阳县', '1672', '1', '河南,驻马店市,泌阳县', null, null, '411726', 'b', 'biyangxian', 'myx');
INSERT INTO `yc_city` VALUES ('1680', '汝南县', '1672', '1', '河南,驻马店市,汝南县', null, null, '411727', 'r', 'runanxian', 'rnx');
INSERT INTO `yc_city` VALUES ('1681', '遂平县', '1672', '1', '河南,驻马店市,遂平县', null, null, '411728', 's', 'suipingxian', 'spx');
INSERT INTO `yc_city` VALUES ('1682', '新蔡县', '1672', '1', '河南,驻马店市,新蔡县', null, null, '411729', 'x', 'xincaixian', 'xcx');
INSERT INTO `yc_city` VALUES ('1683', '济源市', '1508', '1', '河南,济源市', null, null, null, 'j', 'jiyuanshi', 'jys');
INSERT INTO `yc_city` VALUES ('1684', '湖北', '1', '1', '湖北', null, null, '420000', 'h', 'hubei', 'hb');
INSERT INTO `yc_city` VALUES ('1685', '武汉市', '1684', '1', '湖北,武汉市', null, null, '420100', 'w', 'wuhanshi', 'whs');
INSERT INTO `yc_city` VALUES ('1686', '江岸区', '1685', '1', '湖北,武汉市,江岸区', null, null, '420102', 'j', 'jianganqu', 'jaq');
INSERT INTO `yc_city` VALUES ('1687', '江汉区', '1685', '1', '湖北,武汉市,江汉区', null, null, '420103', 'j', 'jianghanqu', 'jhq');
INSERT INTO `yc_city` VALUES ('1688', '硚口区', '1685', '1', '湖北,武汉市,硚口区', null, null, '420104', 'q', 'qiaokouqu', 'ckq');
INSERT INTO `yc_city` VALUES ('1689', '汉阳区', '1685', '1', '湖北,武汉市,汉阳区', null, null, '420105', 'h', 'hanyangqu', 'hyq');
INSERT INTO `yc_city` VALUES ('1690', '武昌区', '1685', '1', '湖北,武汉市,武昌区', null, null, '420106', 'w', 'wuchangqu', 'wcq');
INSERT INTO `yc_city` VALUES ('1691', '青山区', '1685', '1', '湖北,武汉市,青山区', null, null, '420107', 'q', 'qingshanqu', 'qsq');
INSERT INTO `yc_city` VALUES ('1692', '洪山区', '1685', '1', '湖北,武汉市,洪山区', null, null, '420111', 'h', 'hongshanqu', 'hsq');
INSERT INTO `yc_city` VALUES ('1693', '东西湖区', '1685', '1', '湖北,武汉市,东西湖区', null, null, '420112', 'd', 'dongxihuqu', 'dxhq');
INSERT INTO `yc_city` VALUES ('1694', '汉南区', '1685', '1', '湖北,武汉市,汉南区', null, null, '420113', 'h', 'hannanqu', 'hnq');
INSERT INTO `yc_city` VALUES ('1695', '蔡甸区', '1685', '1', '湖北,武汉市,蔡甸区', null, null, '420114', 'c', 'caidianqu', 'cdq');
INSERT INTO `yc_city` VALUES ('1696', '江夏区', '1685', '1', '湖北,武汉市,江夏区', null, null, '420115', 'j', 'jiangxiaqu', 'jxq');
INSERT INTO `yc_city` VALUES ('1697', '黄陂区', '1685', '1', '湖北,武汉市,黄陂区', null, null, '420116', 'h', 'huangpiqu', 'hq');
INSERT INTO `yc_city` VALUES ('1698', '新洲区', '1685', '1', '湖北,武汉市,新洲区', null, null, '420117', 'x', 'xinzhouqu', 'xzq');
INSERT INTO `yc_city` VALUES ('1699', '黄石市', '1684', '1', '湖北,黄石市', null, null, '420200', 'h', 'huangshishi', 'hss');
INSERT INTO `yc_city` VALUES ('1700', '黄石港区', '1699', '1', '湖北,黄石市,黄石港区', null, null, '420202', 'h', 'huangshigangqu', 'hsgq');
INSERT INTO `yc_city` VALUES ('1701', '西塞山区', '1699', '1', '湖北,黄石市,西塞山区', null, null, '420203', 'x', 'xisaishanqu', 'xssq');
INSERT INTO `yc_city` VALUES ('1702', '下陆区', '1699', '1', '湖北,黄石市,下陆区', null, null, '420204', 'x', 'xialuqu', 'xlq');
INSERT INTO `yc_city` VALUES ('1703', '铁山区', '1699', '1', '湖北,黄石市,铁山区', null, null, '420205', 't', 'tieshanqu', 'tsq');
INSERT INTO `yc_city` VALUES ('1704', '阳新县', '1699', '1', '湖北,黄石市,阳新县', null, null, '420222', 'y', 'yangxinxian', 'yxx');
INSERT INTO `yc_city` VALUES ('1705', '大冶市', '1699', '1', '湖北,黄石市,大冶市', null, null, '420281', 'd', 'dayeshi', 'dys');
INSERT INTO `yc_city` VALUES ('1706', '十堰市', '1684', '1', '湖北,十堰市', null, null, '420300', 's', 'shiyanshi', 'sys');
INSERT INTO `yc_city` VALUES ('1707', '茅箭区', '1706', '1', '湖北,十堰市,茅箭区', null, null, '420302', 'm', 'maojianqu', 'mjq');
INSERT INTO `yc_city` VALUES ('1708', '张湾区', '1706', '1', '湖北,十堰市,张湾区', null, null, '420303', 'z', 'zhangwanqu', 'zwq');
INSERT INTO `yc_city` VALUES ('1709', '郧阳区', '1706', '1', '湖北,十堰市,郧阳区', null, null, null, 'y', 'yunyangqu', 'yyq');
INSERT INTO `yc_city` VALUES ('1710', '郧西县', '1706', '1', '湖北,十堰市,郧西县', null, null, '420322', 'y', 'yunxixian', 'yxx');
INSERT INTO `yc_city` VALUES ('1711', '竹山县', '1706', '1', '湖北,十堰市,竹山县', null, null, '420323', 'z', 'zhushanxian', 'zsx');
INSERT INTO `yc_city` VALUES ('1712', '竹溪县', '1706', '1', '湖北,十堰市,竹溪县', null, null, '420324', 'z', 'zhuxixian', 'zxx');
INSERT INTO `yc_city` VALUES ('1713', '房县', '1706', '1', '湖北,十堰市,房县', null, null, '420325', 'f', 'fangxian', 'fx');
INSERT INTO `yc_city` VALUES ('1714', '丹江口市', '1706', '1', '湖北,十堰市,丹江口市', null, null, '420381', 'd', 'danjiangkoushi', 'djks');
INSERT INTO `yc_city` VALUES ('1715', '宜昌市', '1684', '1', '湖北,宜昌市', null, null, '420500', 'y', 'yichangshi', 'ycs');
INSERT INTO `yc_city` VALUES ('1716', '西陵区', '1715', '1', '湖北,宜昌市,西陵区', null, null, '420502', 'x', 'xilingqu', 'xlq');
INSERT INTO `yc_city` VALUES ('1717', '伍家岗区', '1715', '1', '湖北,宜昌市,伍家岗区', null, null, '420503', 'w', 'wujiagangqu', 'wjgq');
INSERT INTO `yc_city` VALUES ('1718', '点军区', '1715', '1', '湖北,宜昌市,点军区', null, null, '420504', 'd', 'dianjunqu', 'djq');
INSERT INTO `yc_city` VALUES ('1719', '猇亭区', '1715', '1', '湖北,宜昌市,猇亭区', null, null, '420505', 'x', 'xiaotingqu', 'tq');
INSERT INTO `yc_city` VALUES ('1720', '夷陵区', '1715', '1', '湖北,宜昌市,夷陵区', null, null, '420506', 'y', 'yilingqu', 'ylq');
INSERT INTO `yc_city` VALUES ('1721', '远安县', '1715', '1', '湖北,宜昌市,远安县', null, null, '420525', 'y', 'yuananxian', 'yax');
INSERT INTO `yc_city` VALUES ('1722', '兴山县', '1715', '1', '湖北,宜昌市,兴山县', null, null, '420526', 'x', 'xingshanxian', 'xsx');
INSERT INTO `yc_city` VALUES ('1723', '秭归县', '1715', '1', '湖北,宜昌市,秭归县', null, null, '420527', 'z', 'ziguixian', 'gx');
INSERT INTO `yc_city` VALUES ('1724', '长阳土家族自治县', '1715', '1', '湖北,宜昌市,长阳土家族自治县', null, null, '420528', 'z', 'zhangyangtujiazuzizhixian', 'cytjzzzx');
INSERT INTO `yc_city` VALUES ('1725', '五峰土家族自治县', '1715', '1', '湖北,宜昌市,五峰土家族自治县', null, null, '420529', 'w', 'wufengtujiazuzizhixian', 'wftjzzzx');
INSERT INTO `yc_city` VALUES ('1726', '宜都市', '1715', '1', '湖北,宜昌市,宜都市', null, null, '420581', 'y', 'yidushi', 'yds');
INSERT INTO `yc_city` VALUES ('1727', '当阳市', '1715', '1', '湖北,宜昌市,当阳市', null, null, '420582', 'd', 'dangyangshi', 'dys');
INSERT INTO `yc_city` VALUES ('1728', '枝江市', '1715', '1', '湖北,宜昌市,枝江市', null, null, '420583', 'z', 'zhijiangshi', 'zjs');
INSERT INTO `yc_city` VALUES ('1729', '襄阳市', '1684', '1', '湖北,襄阳市', null, null, null, 'x', 'xiangyangshi', 'xys');
INSERT INTO `yc_city` VALUES ('1730', '襄城区', '1729', '1', '湖北,襄阳市,襄城区', null, null, null, 'x', 'xiangchengqu', 'xcq');
INSERT INTO `yc_city` VALUES ('1731', '樊城区', '1729', '1', '湖北,襄阳市,樊城区', null, null, null, 'f', 'fanchengqu', 'fcq');
INSERT INTO `yc_city` VALUES ('1732', '襄州区', '1729', '1', '湖北,襄阳市,襄州区', null, null, null, 'x', 'xiangzhouqu', 'xzq');
INSERT INTO `yc_city` VALUES ('1733', '南漳县', '1729', '1', '湖北,襄阳市,南漳县', null, null, null, 'n', 'nanzhangxian', 'nzx');
INSERT INTO `yc_city` VALUES ('1734', '谷城县', '1729', '1', '湖北,襄阳市,谷城县', null, null, null, 'g', 'guchengxian', 'gcx');
INSERT INTO `yc_city` VALUES ('1735', '保康县', '1729', '1', '湖北,襄阳市,保康县', null, null, null, 'b', 'baokangxian', 'bkx');
INSERT INTO `yc_city` VALUES ('1736', '老河口市', '1729', '1', '湖北,襄阳市,老河口市', null, null, null, 'l', 'laohekoushi', 'lhks');
INSERT INTO `yc_city` VALUES ('1737', '枣阳市', '1729', '1', '湖北,襄阳市,枣阳市', null, null, null, 'z', 'zaoyangshi', 'zys');
INSERT INTO `yc_city` VALUES ('1738', '宜城市', '1729', '1', '湖北,襄阳市,宜城市', null, null, null, 'y', 'yichengshi', 'ycs');
INSERT INTO `yc_city` VALUES ('1739', '鄂州市', '1684', '1', '湖北,鄂州市', null, null, '420700', 'e', 'ezhoushi', 'ezs');
INSERT INTO `yc_city` VALUES ('1740', '梁子湖区', '1739', '1', '湖北,鄂州市,梁子湖区', null, null, '420702', 'l', 'liangzihuqu', 'lzhq');
INSERT INTO `yc_city` VALUES ('1741', '华容区', '1739', '1', '湖北,鄂州市,华容区', null, null, '420703', 'h', 'huarongqu', 'hrq');
INSERT INTO `yc_city` VALUES ('1742', '鄂城区', '1739', '1', '湖北,鄂州市,鄂城区', null, null, '420704', 'e', 'echengqu', 'ecq');
INSERT INTO `yc_city` VALUES ('1743', '荆门市', '1684', '1', '湖北,荆门市', null, null, '420800', 'j', 'jingmenshi', 'jms');
INSERT INTO `yc_city` VALUES ('1744', '东宝区', '1743', '1', '湖北,荆门市,东宝区', null, null, '420802', 'd', 'dongbaoqu', 'dbq');
INSERT INTO `yc_city` VALUES ('1745', '掇刀区', '1743', '1', '湖北,荆门市,掇刀区', null, null, '420804', 'd', 'duodaoqu', 'ddq');
INSERT INTO `yc_city` VALUES ('1746', '京山县', '1743', '1', '湖北,荆门市,京山县', null, null, '420821', 'j', 'jingshanxian', 'jsx');
INSERT INTO `yc_city` VALUES ('1747', '沙洋县', '1743', '1', '湖北,荆门市,沙洋县', null, null, '420822', 's', 'shayangxian', 'syx');
INSERT INTO `yc_city` VALUES ('1748', '钟祥市', '1743', '1', '湖北,荆门市,钟祥市', null, null, '420881', 'z', 'zhongxiangshi', 'zxs');
INSERT INTO `yc_city` VALUES ('1749', '孝感市', '1684', '1', '湖北,孝感市', null, null, '420900', 'x', 'xiaoganshi', 'xgs');
INSERT INTO `yc_city` VALUES ('1750', '孝南区', '1749', '1', '湖北,孝感市,孝南区', null, null, '420902', 'x', 'xiaonanqu', 'xnq');
INSERT INTO `yc_city` VALUES ('1751', '孝昌县', '1749', '1', '湖北,孝感市,孝昌县', null, null, '420921', 'x', 'xiaochangxian', 'xcx');
INSERT INTO `yc_city` VALUES ('1752', '大悟县', '1749', '1', '湖北,孝感市,大悟县', null, null, '420922', 'd', 'dawuxian', 'dwx');
INSERT INTO `yc_city` VALUES ('1753', '云梦县', '1749', '1', '湖北,孝感市,云梦县', null, null, '420923', 'y', 'yunmengxian', 'ymx');
INSERT INTO `yc_city` VALUES ('1754', '应城市', '1749', '1', '湖北,孝感市,应城市', null, null, '420981', 'y', 'yingchengshi', 'ycs');
INSERT INTO `yc_city` VALUES ('1755', '安陆市', '1749', '1', '湖北,孝感市,安陆市', null, null, '420982', 'a', 'anlushi', 'als');
INSERT INTO `yc_city` VALUES ('1756', '汉川市', '1749', '1', '湖北,孝感市,汉川市', null, null, '420984', 'h', 'hanchuanshi', 'hcs');
INSERT INTO `yc_city` VALUES ('1757', '荆州市', '1684', '1', '湖北,荆州市', null, null, '421000', 'j', 'jingzhoushi', 'jzs');
INSERT INTO `yc_city` VALUES ('1758', '沙市区', '1757', '1', '湖北,荆州市,沙市区', null, null, '421002', 's', 'shashiqu', 'ssq');
INSERT INTO `yc_city` VALUES ('1759', '荆州区', '1757', '1', '湖北,荆州市,荆州区', null, null, '421003', 'j', 'jingzhouqu', 'jzq');
INSERT INTO `yc_city` VALUES ('1760', '公安县', '1757', '1', '湖北,荆州市,公安县', null, null, '421022', 'g', 'gonganxian', 'gax');
INSERT INTO `yc_city` VALUES ('1761', '监利县', '1757', '1', '湖北,荆州市,监利县', null, null, '421023', 'j', 'jianlixian', 'jlx');
INSERT INTO `yc_city` VALUES ('1762', '江陵县', '1757', '1', '湖北,荆州市,江陵县', null, null, '421024', 'j', 'jianglingxian', 'jlx');
INSERT INTO `yc_city` VALUES ('1763', '石首市', '1757', '1', '湖北,荆州市,石首市', null, null, '421081', 's', 'shishoushi', 'sss');
INSERT INTO `yc_city` VALUES ('1764', '洪湖市', '1757', '1', '湖北,荆州市,洪湖市', null, null, '421083', 'h', 'honghushi', 'hhs');
INSERT INTO `yc_city` VALUES ('1765', '松滋市', '1757', '1', '湖北,荆州市,松滋市', null, null, '421087', 's', 'songzishi', 'szs');
INSERT INTO `yc_city` VALUES ('1766', '黄冈市', '1684', '1', '湖北,黄冈市', null, null, '421100', 'h', 'huanggangshi', 'hgs');
INSERT INTO `yc_city` VALUES ('1767', '黄州区', '1766', '1', '湖北,黄冈市,黄州区', null, null, '421102', 'h', 'huangzhouqu', 'hzq');
INSERT INTO `yc_city` VALUES ('1768', '团风县', '1766', '1', '湖北,黄冈市,团风县', null, null, '421121', 't', 'tuanfengxian', 'tfx');
INSERT INTO `yc_city` VALUES ('1769', '红安县', '1766', '1', '湖北,黄冈市,红安县', null, null, '421122', 'h', 'honganxian', 'hax');
INSERT INTO `yc_city` VALUES ('1770', '罗田县', '1766', '1', '湖北,黄冈市,罗田县', null, null, '421123', 'l', 'luotianxian', 'ltx');
INSERT INTO `yc_city` VALUES ('1771', '英山县', '1766', '1', '湖北,黄冈市,英山县', null, null, '421124', 'y', 'yingshanxian', 'ysx');
INSERT INTO `yc_city` VALUES ('1772', '浠水县', '1766', '1', '湖北,黄冈市,浠水县', null, null, '421125', 'x', 'xishuixian', 'sx');
INSERT INTO `yc_city` VALUES ('1773', '蕲春县', '1766', '1', '湖北,黄冈市,蕲春县', null, null, '421126', 'q', 'qichunxian', 'cx');
INSERT INTO `yc_city` VALUES ('1774', '黄梅县', '1766', '1', '湖北,黄冈市,黄梅县', null, null, '421127', 'h', 'huangmeixian', 'hmx');
INSERT INTO `yc_city` VALUES ('1775', '麻城市', '1766', '1', '湖北,黄冈市,麻城市', null, null, '421181', 'm', 'machengshi', 'mcs');
INSERT INTO `yc_city` VALUES ('1776', '武穴市', '1766', '1', '湖北,黄冈市,武穴市', null, null, '421182', 'w', 'wuxueshi', 'wxs');
INSERT INTO `yc_city` VALUES ('1777', '咸宁市', '1684', '1', '湖北,咸宁市', null, null, '421200', 'x', 'xianningshi', 'xns');
INSERT INTO `yc_city` VALUES ('1778', '咸安区', '1777', '1', '湖北,咸宁市,咸安区', null, null, '421202', 'x', 'xiananqu', 'xaq');
INSERT INTO `yc_city` VALUES ('1779', '嘉鱼县', '1777', '1', '湖北,咸宁市,嘉鱼县', null, null, '421221', 'j', 'jiayuxian', 'jyx');
INSERT INTO `yc_city` VALUES ('1780', '通城县', '1777', '1', '湖北,咸宁市,通城县', null, null, '421222', 't', 'tongchengxian', 'tcx');
INSERT INTO `yc_city` VALUES ('1781', '崇阳县', '1777', '1', '湖北,咸宁市,崇阳县', null, null, '421223', 'c', 'chongyangxian', 'cyx');
INSERT INTO `yc_city` VALUES ('1782', '通山县', '1777', '1', '湖北,咸宁市,通山县', null, null, '421224', 't', 'tongshanxian', 'tsx');
INSERT INTO `yc_city` VALUES ('1783', '赤壁市', '1777', '1', '湖北,咸宁市,赤壁市', null, null, '421281', 'c', 'chibishi', 'cbs');
INSERT INTO `yc_city` VALUES ('1784', '随州市', '1684', '1', '湖北,随州市', null, null, '421300', 's', 'suizhoushi', 'szs');
INSERT INTO `yc_city` VALUES ('1785', '曾都区', '1784', '1', '湖北,随州市,曾都区', null, null, '421302', 'z', 'zengduqu', 'zdq');
INSERT INTO `yc_city` VALUES ('1786', '随县', '1784', '1', '湖北,随州市,随县', null, null, null, 's', 'suixian', 'sx');
INSERT INTO `yc_city` VALUES ('1787', '广水市', '1784', '1', '湖北,随州市,广水市', null, null, '421381', 'g', 'guangshuishi', 'gss');
INSERT INTO `yc_city` VALUES ('1788', '恩施土家族苗族自治州', '1684', '1', '湖北,恩施土家族苗族自治州', null, null, '422800', 'e', 'enshitujiazumiaozuzizhizhou', 'estjzmzzzz');
INSERT INTO `yc_city` VALUES ('1789', '恩施市', '1788', '1', '湖北,恩施土家族苗族自治州,恩施市', null, null, '422801', 'e', 'enshishi', 'ess');
INSERT INTO `yc_city` VALUES ('1790', '利川市', '1788', '1', '湖北,恩施土家族苗族自治州,利川市', null, null, '422802', 'l', 'lichuanshi', 'lcs');
INSERT INTO `yc_city` VALUES ('1791', '建始县', '1788', '1', '湖北,恩施土家族苗族自治州,建始县', null, null, '422822', 'j', 'jianshixian', 'jsx');
INSERT INTO `yc_city` VALUES ('1792', '巴东县', '1788', '1', '湖北,恩施土家族苗族自治州,巴东县', null, null, '422823', 'b', 'badongxian', 'bdx');
INSERT INTO `yc_city` VALUES ('1793', '宣恩县', '1788', '1', '湖北,恩施土家族苗族自治州,宣恩县', null, null, '422825', 'x', 'xuanenxian', 'xex');
INSERT INTO `yc_city` VALUES ('1794', '咸丰县', '1788', '1', '湖北,恩施土家族苗族自治州,咸丰县', null, null, '422826', 'x', 'xianfengxian', 'xfx');
INSERT INTO `yc_city` VALUES ('1795', '来凤县', '1788', '1', '湖北,恩施土家族苗族自治州,来凤县', null, null, '422827', 'l', 'laifengxian', 'lfx');
INSERT INTO `yc_city` VALUES ('1796', '鹤峰县', '1788', '1', '湖北,恩施土家族苗族自治州,鹤峰县', null, null, '422828', 'h', 'hefengxian', 'hfx');
INSERT INTO `yc_city` VALUES ('1797', '仙桃市', '1684', '1', '湖北,仙桃市', null, null, null, 'x', 'xiantaoshi', 'xts');
INSERT INTO `yc_city` VALUES ('1798', '潜江市', '1684', '1', '湖北,潜江市', null, null, null, 'q', 'qianjiangshi', 'qjs');
INSERT INTO `yc_city` VALUES ('1799', '天门市', '1684', '1', '湖北,天门市', null, null, null, 't', 'tianmenshi', 'tms');
INSERT INTO `yc_city` VALUES ('1800', '神农架林区', '1684', '1', '湖北,神农架林区', null, null, null, 's', 'shennongjialinqu', 'snjlq');
INSERT INTO `yc_city` VALUES ('1801', '湖南', '1', '1', '湖南', null, null, '430000', 'h', 'hunan', 'hn');
INSERT INTO `yc_city` VALUES ('1802', '长沙市', '1801', '1', '湖南,长沙市', null, null, '430100', 'c', 'changshashi', 'css');
INSERT INTO `yc_city` VALUES ('1803', '芙蓉区', '1802', '1', '湖南,长沙市,芙蓉区', null, null, '430102', 'f', 'furongqu', 'rq');
INSERT INTO `yc_city` VALUES ('1804', '天心区', '1802', '1', '湖南,长沙市,天心区', null, null, '430103', 't', 'tianxinqu', 'txq');
INSERT INTO `yc_city` VALUES ('1805', '岳麓区', '1802', '1', '湖南,长沙市,岳麓区', null, null, '430104', 'y', 'yueluqu', 'ylq');
INSERT INTO `yc_city` VALUES ('1806', '开福区', '1802', '1', '湖南,长沙市,开福区', null, null, '430105', 'k', 'kaifuqu', 'kfq');
INSERT INTO `yc_city` VALUES ('1807', '雨花区', '1802', '1', '湖南,长沙市,雨花区', null, null, '430111', 'y', 'yuhuaqu', 'yhq');
INSERT INTO `yc_city` VALUES ('1808', '望城区', '1802', '1', '湖南,长沙市,望城区', null, null, null, 'w', 'wangchengqu', 'wcq');
INSERT INTO `yc_city` VALUES ('1809', '长沙县', '1802', '1', '湖南,长沙市,长沙县', null, null, '430121', 'c', 'changshaxian', 'csx');
INSERT INTO `yc_city` VALUES ('1810', '宁乡县', '1802', '1', '湖南,长沙市,宁乡县', null, null, '430124', 'n', 'ningxiangxian', 'nxx');
INSERT INTO `yc_city` VALUES ('1811', '浏阳市', '1802', '1', '湖南,长沙市,浏阳市', null, null, '430181', 'l', 'liuyangshi', 'ys');
INSERT INTO `yc_city` VALUES ('1812', '株洲市', '1801', '1', '湖南,株洲市', null, null, '430200', 'z', 'zhuzhoushi', 'zzs');
INSERT INTO `yc_city` VALUES ('1813', '荷塘区', '1812', '1', '湖南,株洲市,荷塘区', null, null, '430202', 'h', 'hetangqu', 'htq');
INSERT INTO `yc_city` VALUES ('1814', '芦淞区', '1812', '1', '湖南,株洲市,芦淞区', null, null, '430203', 'l', 'lusongqu', 'lq');
INSERT INTO `yc_city` VALUES ('1815', '石峰区', '1812', '1', '湖南,株洲市,石峰区', null, null, '430204', 's', 'shifengqu', 'sfq');
INSERT INTO `yc_city` VALUES ('1816', '天元区', '1812', '1', '湖南,株洲市,天元区', null, null, '430211', 't', 'tianyuanqu', 'tyq');
INSERT INTO `yc_city` VALUES ('1817', '株洲县', '1812', '1', '湖南,株洲市,株洲县', null, null, '430221', 'z', 'zhuzhouxian', 'zzx');
INSERT INTO `yc_city` VALUES ('1818', '攸县', '1812', '1', '湖南,株洲市,攸县', null, null, '430223', 'y', 'youxian', 'x');
INSERT INTO `yc_city` VALUES ('1819', '茶陵县', '1812', '1', '湖南,株洲市,茶陵县', null, null, '430224', 'c', 'chalingxian', 'clx');
INSERT INTO `yc_city` VALUES ('1820', '炎陵县', '1812', '1', '湖南,株洲市,炎陵县', null, null, '430225', 'y', 'yanlingxian', 'ylx');
INSERT INTO `yc_city` VALUES ('1821', '醴陵市', '1812', '1', '湖南,株洲市,醴陵市', null, null, '430281', 'l', 'lilingshi', 'ls');
INSERT INTO `yc_city` VALUES ('1822', '湘潭市', '1801', '1', '湖南,湘潭市', null, null, '430300', 'x', 'xiangtanshi', 'xts');
INSERT INTO `yc_city` VALUES ('1823', '雨湖区', '1822', '1', '湖南,湘潭市,雨湖区', null, null, '430302', 'y', 'yuhuqu', 'yhq');
INSERT INTO `yc_city` VALUES ('1824', '岳塘区', '1822', '1', '湖南,湘潭市,岳塘区', null, null, '430304', 'y', 'yuetangqu', 'ytq');
INSERT INTO `yc_city` VALUES ('1825', '湘潭县', '1822', '1', '湖南,湘潭市,湘潭县', null, null, '430321', 'x', 'xiangtanxian', 'xtx');
INSERT INTO `yc_city` VALUES ('1826', '湘乡市', '1822', '1', '湖南,湘潭市,湘乡市', null, null, '430381', 'x', 'xiangxiangshi', 'xxs');
INSERT INTO `yc_city` VALUES ('1827', '韶山市', '1822', '1', '湖南,湘潭市,韶山市', null, null, '430382', 's', 'shaoshanshi', 'sss');
INSERT INTO `yc_city` VALUES ('1828', '衡阳市', '1801', '1', '湖南,衡阳市', null, null, '430400', 'h', 'hengyangshi', 'hys');
INSERT INTO `yc_city` VALUES ('1829', '珠晖区', '1828', '1', '湖南,衡阳市,珠晖区', null, null, '430405', 'z', 'zhuhuiqu', 'zq');
INSERT INTO `yc_city` VALUES ('1830', '雁峰区', '1828', '1', '湖南,衡阳市,雁峰区', null, null, '430406', 'y', 'yanfengqu', 'yfq');
INSERT INTO `yc_city` VALUES ('1831', '石鼓区', '1828', '1', '湖南,衡阳市,石鼓区', null, null, '430407', 'd', 'danguqu', 'sgq');
INSERT INTO `yc_city` VALUES ('1832', '蒸湘区', '1828', '1', '湖南,衡阳市,蒸湘区', null, null, '430408', 'z', 'zhengxiangqu', 'zxq');
INSERT INTO `yc_city` VALUES ('1833', '南岳区', '1828', '1', '湖南,衡阳市,南岳区', null, null, '430412', 'n', 'nanyuequ', 'nyq');
INSERT INTO `yc_city` VALUES ('1834', '衡阳县', '1828', '1', '湖南,衡阳市,衡阳县', null, null, '430421', 'h', 'hengyangxian', 'hyx');
INSERT INTO `yc_city` VALUES ('1835', '衡南县', '1828', '1', '湖南,衡阳市,衡南县', null, null, '430422', 'h', 'hengnanxian', 'hnx');
INSERT INTO `yc_city` VALUES ('1836', '衡山县', '1828', '1', '湖南,衡阳市,衡山县', null, null, '430423', 'h', 'hengshanxian', 'hsx');
INSERT INTO `yc_city` VALUES ('1837', '衡东县', '1828', '1', '湖南,衡阳市,衡东县', null, null, '430424', 'h', 'hengdongxian', 'hdx');
INSERT INTO `yc_city` VALUES ('1838', '祁东县', '1828', '1', '湖南,衡阳市,祁东县', null, null, '430426', 'q', 'qidongxian', 'qdx');
INSERT INTO `yc_city` VALUES ('1839', '耒阳市', '1828', '1', '湖南,衡阳市,耒阳市', null, null, '430481', 'l', 'leiyangshi', 'ys');
INSERT INTO `yc_city` VALUES ('1840', '常宁市', '1828', '1', '湖南,衡阳市,常宁市', null, null, '430482', 'c', 'changningshi', 'cns');
INSERT INTO `yc_city` VALUES ('1841', '邵阳市', '1801', '1', '湖南,邵阳市', null, null, '430500', 's', 'shaoyangshi', 'sys');
INSERT INTO `yc_city` VALUES ('1842', '双清区', '1841', '1', '湖南,邵阳市,双清区', null, null, '430502', 's', 'shuangqingqu', 'sqq');
INSERT INTO `yc_city` VALUES ('1843', '大祥区', '1841', '1', '湖南,邵阳市,大祥区', null, null, '430503', 'd', 'daxiangqu', 'dxq');
INSERT INTO `yc_city` VALUES ('1844', '北塔区', '1841', '1', '湖南,邵阳市,北塔区', null, null, '430511', 'b', 'beitaqu', 'btq');
INSERT INTO `yc_city` VALUES ('1845', '邵东县', '1841', '1', '湖南,邵阳市,邵东县', null, null, '430521', 's', 'shaodongxian', 'sdx');
INSERT INTO `yc_city` VALUES ('1846', '新邵县', '1841', '1', '湖南,邵阳市,新邵县', null, null, '430522', 'x', 'xinshaoxian', 'xsx');
INSERT INTO `yc_city` VALUES ('1847', '邵阳县', '1841', '1', '湖南,邵阳市,邵阳县', null, null, '430523', 's', 'shaoyangxian', 'syx');
INSERT INTO `yc_city` VALUES ('1848', '隆回县', '1841', '1', '湖南,邵阳市,隆回县', null, null, '430524', 'l', 'longhuixian', 'lhx');
INSERT INTO `yc_city` VALUES ('1849', '洞口县', '1841', '1', '湖南,邵阳市,洞口县', null, null, '430525', 'd', 'dongkouxian', 'dkx');
INSERT INTO `yc_city` VALUES ('1850', '绥宁县', '1841', '1', '湖南,邵阳市,绥宁县', null, null, '430527', 's', 'suiningxian', 'snx');
INSERT INTO `yc_city` VALUES ('1851', '新宁县', '1841', '1', '湖南,邵阳市,新宁县', null, null, '430528', 'x', 'xinningxian', 'xnx');
INSERT INTO `yc_city` VALUES ('1852', '城步苗族自治县', '1841', '1', '湖南,邵阳市,城步苗族自治县', null, null, '430529', 'c', 'chengbumiaozuzizhixian', 'cbmzzzx');
INSERT INTO `yc_city` VALUES ('1853', '武冈市', '1841', '1', '湖南,邵阳市,武冈市', null, null, '430581', 'w', 'wugangshi', 'wgs');
INSERT INTO `yc_city` VALUES ('1854', '岳阳市', '1801', '1', '湖南,岳阳市', null, null, '430600', 'y', 'yueyangshi', 'yys');
INSERT INTO `yc_city` VALUES ('1855', '岳阳楼区', '1854', '1', '湖南,岳阳市,岳阳楼区', null, null, '430602', 'y', 'yueyanglouqu', 'yylq');
INSERT INTO `yc_city` VALUES ('1856', '云溪区', '1854', '1', '湖南,岳阳市,云溪区', null, null, '430603', 'y', 'yunxiqu', 'yxq');
INSERT INTO `yc_city` VALUES ('1857', '君山区', '1854', '1', '湖南,岳阳市,君山区', null, null, '430611', 'j', 'junshanqu', 'jsq');
INSERT INTO `yc_city` VALUES ('1858', '岳阳县', '1854', '1', '湖南,岳阳市,岳阳县', null, null, '430621', 'y', 'yueyangxian', 'yyx');
INSERT INTO `yc_city` VALUES ('1859', '华容县', '1854', '1', '湖南,岳阳市,华容县', null, null, '430623', 'h', 'huarongxian', 'hrx');
INSERT INTO `yc_city` VALUES ('1860', '湘阴县', '1854', '1', '湖南,岳阳市,湘阴县', null, null, '430624', 'x', 'xiangyinxian', 'xyx');
INSERT INTO `yc_city` VALUES ('1861', '平江县', '1854', '1', '湖南,岳阳市,平江县', null, null, '430626', 'p', 'pingjiangxian', 'pjx');
INSERT INTO `yc_city` VALUES ('1862', '汨罗市', '1854', '1', '湖南,岳阳市,汨罗市', null, null, '430681', 'm', 'miluoshi', 'ls');
INSERT INTO `yc_city` VALUES ('1863', '临湘市', '1854', '1', '湖南,岳阳市,临湘市', null, null, '430682', 'l', 'linxiangshi', 'lxs');
INSERT INTO `yc_city` VALUES ('1864', '常德市', '1801', '1', '湖南,常德市', null, null, '430700', 'c', 'changdeshi', 'cds');
INSERT INTO `yc_city` VALUES ('1865', '武陵区', '1864', '1', '湖南,常德市,武陵区', null, null, '430702', 'w', 'wulingqu', 'wlq');
INSERT INTO `yc_city` VALUES ('1866', '鼎城区', '1864', '1', '湖南,常德市,鼎城区', null, null, '430703', 'd', 'dingchengqu', 'dcq');
INSERT INTO `yc_city` VALUES ('1867', '安乡县', '1864', '1', '湖南,常德市,安乡县', null, null, '430721', 'a', 'anxiangxian', 'axx');
INSERT INTO `yc_city` VALUES ('1868', '汉寿县', '1864', '1', '湖南,常德市,汉寿县', null, null, '430722', 'h', 'hanshouxian', 'hsx');
INSERT INTO `yc_city` VALUES ('1869', '澧县', '1864', '1', '湖南,常德市,澧县', null, null, '430723', 'l', 'lixian', 'x');
INSERT INTO `yc_city` VALUES ('1870', '临澧县', '1864', '1', '湖南,常德市,临澧县', null, null, '430724', 'l', 'linlixian', 'lx');
INSERT INTO `yc_city` VALUES ('1871', '桃源县', '1864', '1', '湖南,常德市,桃源县', null, null, '430725', 't', 'taoyuanxian', 'tyx');
INSERT INTO `yc_city` VALUES ('1872', '石门县', '1864', '1', '湖南,常德市,石门县', null, null, '430726', 's', 'shimenxian', 'smx');
INSERT INTO `yc_city` VALUES ('1873', '津市市', '1864', '1', '湖南,常德市,津市市', null, null, '430781', 'j', 'jinshishi', 'jss');
INSERT INTO `yc_city` VALUES ('1874', '张家界市', '1801', '1', '湖南,张家界市', null, null, '430800', 'z', 'zhangjiajieshi', 'zjjs');
INSERT INTO `yc_city` VALUES ('1875', '永定区', '1874', '1', '湖南,张家界市,永定区', null, null, '430802', 'y', 'yongdingqu', 'ydq');
INSERT INTO `yc_city` VALUES ('1876', '武陵源区', '1874', '1', '湖南,张家界市,武陵源区', null, null, '430811', 'w', 'wulingyuanqu', 'wlyq');
INSERT INTO `yc_city` VALUES ('1877', '慈利县', '1874', '1', '湖南,张家界市,慈利县', null, null, '430821', 'c', 'cilixian', 'clx');
INSERT INTO `yc_city` VALUES ('1878', '桑植县', '1874', '1', '湖南,张家界市,桑植县', null, null, '430822', 's', 'sangzhixian', 'szx');
INSERT INTO `yc_city` VALUES ('1879', '益阳市', '1801', '1', '湖南,益阳市', null, null, '430900', 'y', 'yiyangshi', 'yys');
INSERT INTO `yc_city` VALUES ('1880', '资阳区', '1879', '1', '湖南,益阳市,资阳区', null, null, '430902', 'z', 'ziyangqu', 'zyq');
INSERT INTO `yc_city` VALUES ('1881', '赫山区', '1879', '1', '湖南,益阳市,赫山区', null, null, '430903', 'h', 'heshanqu', 'hsq');
INSERT INTO `yc_city` VALUES ('1882', '南县', '1879', '1', '湖南,益阳市,南县', null, null, '430921', 'n', 'nanxian', 'nx');
INSERT INTO `yc_city` VALUES ('1883', '桃江县', '1879', '1', '湖南,益阳市,桃江县', null, null, '430922', 't', 'taojiangxian', 'tjx');
INSERT INTO `yc_city` VALUES ('1884', '安化县', '1879', '1', '湖南,益阳市,安化县', null, null, '430923', 'a', 'anhuaxian', 'ahx');
INSERT INTO `yc_city` VALUES ('1885', '沅江市', '1879', '1', '湖南,益阳市,沅江市', null, null, '430981', 'y', 'yuanjiangshi', 'js');
INSERT INTO `yc_city` VALUES ('1886', '郴州市', '1801', '1', '湖南,郴州市', null, null, '431000', 'c', 'chenzhoushi', 'czs');
INSERT INTO `yc_city` VALUES ('1887', '北湖区', '1886', '1', '湖南,郴州市,北湖区', null, null, '431002', 'b', 'beihuqu', 'bhq');
INSERT INTO `yc_city` VALUES ('1888', '苏仙区', '1886', '1', '湖南,郴州市,苏仙区', null, null, '431003', 's', 'suxianqu', 'sxq');
INSERT INTO `yc_city` VALUES ('1889', '桂阳县', '1886', '1', '湖南,郴州市,桂阳县', null, null, '431021', 'g', 'guiyangxian', 'gyx');
INSERT INTO `yc_city` VALUES ('1890', '宜章县', '1886', '1', '湖南,郴州市,宜章县', null, null, '431022', 'y', 'yizhangxian', 'yzx');
INSERT INTO `yc_city` VALUES ('1891', '永兴县', '1886', '1', '湖南,郴州市,永兴县', null, null, '431023', 'y', 'yongxingxian', 'yxx');
INSERT INTO `yc_city` VALUES ('1892', '嘉禾县', '1886', '1', '湖南,郴州市,嘉禾县', null, null, '431024', 'j', 'jiahexian', 'jhx');
INSERT INTO `yc_city` VALUES ('1893', '临武县', '1886', '1', '湖南,郴州市,临武县', null, null, '431025', 'l', 'linwuxian', 'lwx');
INSERT INTO `yc_city` VALUES ('1894', '汝城县', '1886', '1', '湖南,郴州市,汝城县', null, null, '431026', 'r', 'ruchengxian', 'rcx');
INSERT INTO `yc_city` VALUES ('1895', '桂东县', '1886', '1', '湖南,郴州市,桂东县', null, null, '431027', 'g', 'guidongxian', 'gdx');
INSERT INTO `yc_city` VALUES ('1896', '安仁县', '1886', '1', '湖南,郴州市,安仁县', null, null, '431028', 'a', 'anrenxian', 'arx');
INSERT INTO `yc_city` VALUES ('1897', '资兴市', '1886', '1', '湖南,郴州市,资兴市', null, null, '431081', 'z', 'zixingshi', 'zxs');
INSERT INTO `yc_city` VALUES ('1898', '永州市', '1801', '1', '湖南,永州市', null, null, '431100', 'y', 'yongzhoushi', 'yzs');
INSERT INTO `yc_city` VALUES ('1899', '零陵区', '1898', '1', '湖南,永州市,零陵区', null, null, '431102', 'l', 'linglingqu', 'llq');
INSERT INTO `yc_city` VALUES ('1900', '冷水滩区', '1898', '1', '湖南,永州市,冷水滩区', null, null, '431103', 'l', 'lengshuitanqu', 'lstq');
INSERT INTO `yc_city` VALUES ('1901', '祁阳县', '1898', '1', '湖南,永州市,祁阳县', null, null, '431121', 'q', 'qiyangxian', 'qyx');
INSERT INTO `yc_city` VALUES ('1902', '东安县', '1898', '1', '湖南,永州市,东安县', null, null, '431122', 'd', 'donganxian', 'dax');
INSERT INTO `yc_city` VALUES ('1903', '双牌县', '1898', '1', '湖南,永州市,双牌县', null, null, '431123', 's', 'shuangpaixian', 'spx');
INSERT INTO `yc_city` VALUES ('1904', '道县', '1898', '1', '湖南,永州市,道县', null, null, '431124', 'd', 'daoxian', 'dx');
INSERT INTO `yc_city` VALUES ('1905', '江永县', '1898', '1', '湖南,永州市,江永县', null, null, '431125', 'j', 'jiangyongxian', 'jyx');
INSERT INTO `yc_city` VALUES ('1906', '宁远县', '1898', '1', '湖南,永州市,宁远县', null, null, '431126', 'n', 'ningyuanxian', 'nyx');
INSERT INTO `yc_city` VALUES ('1907', '蓝山县', '1898', '1', '湖南,永州市,蓝山县', null, null, '431127', 'l', 'lanshanxian', 'lsx');
INSERT INTO `yc_city` VALUES ('1908', '新田县', '1898', '1', '湖南,永州市,新田县', null, null, '431128', 'x', 'xintianxian', 'xtx');
INSERT INTO `yc_city` VALUES ('1909', '江华瑶族自治县', '1898', '1', '湖南,永州市,江华瑶族自治县', null, null, '431129', 'j', 'jianghuayaozuzizhixian', 'jhyzzzx');
INSERT INTO `yc_city` VALUES ('1910', '怀化市', '1801', '1', '湖南,怀化市', null, null, '431200', 'h', 'huaihuashi', 'hhs');
INSERT INTO `yc_city` VALUES ('1911', '鹤城区', '1910', '1', '湖南,怀化市,鹤城区', null, null, '431202', 'h', 'hechengqu', 'hcq');
INSERT INTO `yc_city` VALUES ('1912', '中方县', '1910', '1', '湖南,怀化市,中方县', null, null, '431221', 'z', 'zhongfangxian', 'zfx');
INSERT INTO `yc_city` VALUES ('1913', '沅陵县', '1910', '1', '湖南,怀化市,沅陵县', null, null, '431222', 'y', 'yuanlingxian', 'lx');
INSERT INTO `yc_city` VALUES ('1914', '辰溪县', '1910', '1', '湖南,怀化市,辰溪县', null, null, '431223', 'c', 'chenxixian', 'cxx');
INSERT INTO `yc_city` VALUES ('1915', '溆浦县', '1910', '1', '湖南,怀化市,溆浦县', null, null, '431224', 'x', 'xupuxian', 'px');
INSERT INTO `yc_city` VALUES ('1916', '会同县', '1910', '1', '湖南,怀化市,会同县', null, null, '431225', 'h', 'huitongxian', 'htx');
INSERT INTO `yc_city` VALUES ('1917', '麻阳苗族自治县', '1910', '1', '湖南,怀化市,麻阳苗族自治县', null, null, '431226', 'm', 'mayangmiaozuzizhixian', 'mymzzzx');
INSERT INTO `yc_city` VALUES ('1918', '新晃侗族自治县', '1910', '1', '湖南,怀化市,新晃侗族自治县', null, null, '431227', 'x', 'xinhuangdongzuzizhixian', 'xhdzzzx');
INSERT INTO `yc_city` VALUES ('1919', '芷江侗族自治县', '1910', '1', '湖南,怀化市,芷江侗族自治县', null, null, '431228', 'z', 'zhijiangdongzuzizhixian', 'jdzzzx');
INSERT INTO `yc_city` VALUES ('1920', '靖州苗族侗族自治县', '1910', '1', '湖南,怀化市,靖州苗族侗族自治县', null, null, '431229', 'j', 'jingzhoumiaozudongzuzizhixian', 'jzmzdzzzx');
INSERT INTO `yc_city` VALUES ('1921', '通道侗族自治县', '1910', '1', '湖南,怀化市,通道侗族自治县', null, null, '431230', 't', 'tongdaodongzuzizhixian', 'tddzzzx');
INSERT INTO `yc_city` VALUES ('1922', '洪江市', '1910', '1', '湖南,怀化市,洪江市', null, null, '431281', 'h', 'hongjiangshi', 'hjs');
INSERT INTO `yc_city` VALUES ('1923', '娄底市', '1801', '1', '湖南,娄底市', null, null, '431300', 'l', 'loudishi', 'lds');
INSERT INTO `yc_city` VALUES ('1924', '娄星区', '1923', '1', '湖南,娄底市,娄星区', null, null, '431302', 'l', 'louxingqu', 'lxq');
INSERT INTO `yc_city` VALUES ('1925', '双峰县', '1923', '1', '湖南,娄底市,双峰县', null, null, '431321', 's', 'shuangfengxian', 'sfx');
INSERT INTO `yc_city` VALUES ('1926', '新化县', '1923', '1', '湖南,娄底市,新化县', null, null, '431322', 'x', 'xinhuaxian', 'xhx');
INSERT INTO `yc_city` VALUES ('1927', '冷水江市', '1923', '1', '湖南,娄底市,冷水江市', null, null, '431381', 'l', 'lengshuijiangshi', 'lsjs');
INSERT INTO `yc_city` VALUES ('1928', '涟源市', '1923', '1', '湖南,娄底市,涟源市', null, null, '431382', 'l', 'lianyuanshi', 'lys');
INSERT INTO `yc_city` VALUES ('1929', '湘西土家族苗族自治州', '1801', '1', '湖南,湘西土家族苗族自治州', null, null, '433100', 'x', 'xiangxitujiazumiaozuzizhizhou', 'xxtjzmzzzz');
INSERT INTO `yc_city` VALUES ('1930', '吉首市', '1929', '1', '湖南,湘西土家族苗族自治州,吉首市', null, null, '433101', 'j', 'jishoushi', 'jss');
INSERT INTO `yc_city` VALUES ('1931', '泸溪县', '1929', '1', '湖南,湘西土家族苗族自治州,泸溪县', null, null, '433122', 'l', 'luxixian', 'xx');
INSERT INTO `yc_city` VALUES ('1932', '凤凰县', '1929', '1', '湖南,湘西土家族苗族自治州,凤凰县', null, null, '433123', 'f', 'fenghuangxian', 'fhx');
INSERT INTO `yc_city` VALUES ('1933', '花垣县', '1929', '1', '湖南,湘西土家族苗族自治州,花垣县', null, null, '433124', 'h', 'huayuanxian', 'hyx');
INSERT INTO `yc_city` VALUES ('1934', '保靖县', '1929', '1', '湖南,湘西土家族苗族自治州,保靖县', null, null, '433125', 'b', 'baojingxian', 'bjx');
INSERT INTO `yc_city` VALUES ('1935', '古丈县', '1929', '1', '湖南,湘西土家族苗族自治州,古丈县', null, null, '433126', 'g', 'guzhangxian', 'gzx');
INSERT INTO `yc_city` VALUES ('1936', '永顺县', '1929', '1', '湖南,湘西土家族苗族自治州,永顺县', null, null, '433127', 'y', 'yongshunxian', 'ysx');
INSERT INTO `yc_city` VALUES ('1937', '龙山县', '1929', '1', '湖南,湘西土家族苗族自治州,龙山县', null, null, '433130', 'l', 'longshanxian', 'lsx');
INSERT INTO `yc_city` VALUES ('1938', '广东', '1', '1', '广东', null, null, '440000', 'g', 'guangdong', 'gd');
INSERT INTO `yc_city` VALUES ('1939', '广州市', '1938', '1', '广东,广州市', null, null, '440100', 'g', 'guangzhoushi', 'gzs');
INSERT INTO `yc_city` VALUES ('1940', '荔湾区', '1939', '1', '广东,广州市,荔湾区', null, null, '440103', 'l', 'liwanqu', 'lwq');
INSERT INTO `yc_city` VALUES ('1941', '越秀区', '1939', '1', '广东,广州市,越秀区', null, null, '440104', 'y', 'yuexiuqu', 'yxq');
INSERT INTO `yc_city` VALUES ('1942', '海珠区', '1939', '1', '广东,广州市,海珠区', null, null, '440105', 'h', 'haizhuqu', 'hzq');
INSERT INTO `yc_city` VALUES ('1943', '天河区', '1939', '1', '广东,广州市,天河区', null, null, '440106', 't', 'tianhequ', 'thq');
INSERT INTO `yc_city` VALUES ('1944', '白云区', '1939', '1', '广东,广州市,白云区', null, null, '440111', 'b', 'baiyunqu', 'byq');
INSERT INTO `yc_city` VALUES ('1945', '黄埔区', '1939', '1', '广东,广州市,黄埔区', null, null, '440112', 'h', 'huangpuqu', 'hpq');
INSERT INTO `yc_city` VALUES ('1946', '番禺区', '1939', '1', '广东,广州市,番禺区', null, null, '440113', 'p', 'panyuqu', 'fq');
INSERT INTO `yc_city` VALUES ('1947', '花都区', '1939', '1', '广东,广州市,花都区', null, null, '440114', 'h', 'huaduqu', 'hdq');
INSERT INTO `yc_city` VALUES ('1948', '南沙区', '1939', '1', '广东,广州市,南沙区', null, null, '440115', 'n', 'nanshaqu', 'nsq');
INSERT INTO `yc_city` VALUES ('1949', '萝岗区', '1939', '1', '广东,广州市,萝岗区', null, null, '440116', 'l', 'luogangqu', 'lgq');
INSERT INTO `yc_city` VALUES ('1950', '从化区', '1939', '1', '广东,广州市,从化区', null, null, '440184', 'c', 'conghuaqu', 'chq');
INSERT INTO `yc_city` VALUES ('1951', '增城区', '1939', '1', '广东,广州市,增城区', null, null, '440183', 'z', 'zengchengqu', 'zcq');
INSERT INTO `yc_city` VALUES ('1952', '韶关市', '1938', '1', '广东,韶关市', null, null, '440200', 's', 'shaoguanshi', 'sgs');
INSERT INTO `yc_city` VALUES ('1953', '武江区', '1952', '1', '广东,韶关市,武江区', null, null, '440203', 'w', 'wujiangqu', 'wjq');
INSERT INTO `yc_city` VALUES ('1954', '浈江区', '1952', '1', '广东,韶关市,浈江区', null, null, '440204', 'z', 'zhenjiangqu', 'jq');
INSERT INTO `yc_city` VALUES ('1955', '曲江区', '1952', '1', '广东,韶关市,曲江区', null, null, '440205', 'q', 'qujiangqu', 'qjq');
INSERT INTO `yc_city` VALUES ('1956', '始兴县', '1952', '1', '广东,韶关市,始兴县', null, null, '440222', 's', 'shixingxian', 'sxx');
INSERT INTO `yc_city` VALUES ('1957', '仁化县', '1952', '1', '广东,韶关市,仁化县', null, null, '440224', 'r', 'renhuaxian', 'rhx');
INSERT INTO `yc_city` VALUES ('1958', '翁源县', '1952', '1', '广东,韶关市,翁源县', null, null, '440229', 'w', 'wengyuanxian', 'wyx');
INSERT INTO `yc_city` VALUES ('1959', '乳源瑶族自治县', '1952', '1', '广东,韶关市,乳源瑶族自治县', null, null, '440232', 'r', 'ruyuanyaozuzizhixian', 'ryyzzzx');
INSERT INTO `yc_city` VALUES ('1960', '新丰县', '1952', '1', '广东,韶关市,新丰县', null, null, '440233', 'x', 'xinfengxian', 'xfx');
INSERT INTO `yc_city` VALUES ('1961', '乐昌市', '1952', '1', '广东,韶关市,乐昌市', null, null, '440281', 'l', 'lechangshi', 'lcs');
INSERT INTO `yc_city` VALUES ('1962', '南雄市', '1952', '1', '广东,韶关市,南雄市', null, null, '440282', 'n', 'nanxiongshi', 'nxs');
INSERT INTO `yc_city` VALUES ('1963', '深圳市', '1938', '1', '广东,深圳市', null, null, '440300', 's', 'shenzhenshi', 'ss');
INSERT INTO `yc_city` VALUES ('1964', '罗湖区', '1963', '1', '广东,深圳市,罗湖区', null, null, '440303', 'l', 'luohuqu', 'lhq');
INSERT INTO `yc_city` VALUES ('1965', '福田区', '1963', '1', '广东,深圳市,福田区', null, null, '440304', 'f', 'futianqu', 'ftq');
INSERT INTO `yc_city` VALUES ('1966', '南山区', '1963', '1', '广东,深圳市,南山区', null, null, '440305', 'n', 'nanshanqu', 'nsq');
INSERT INTO `yc_city` VALUES ('1967', '宝安区', '1963', '1', '广东,深圳市,宝安区', null, null, '440306', 'b', 'baoanqu', 'baq');
INSERT INTO `yc_city` VALUES ('1968', '龙岗区', '1963', '1', '广东,深圳市,龙岗区', null, null, '440307', 'l', 'longgangqu', 'lgq');
INSERT INTO `yc_city` VALUES ('1969', '盐田区', '1963', '1', '广东,深圳市,盐田区', null, null, '440308', 'y', 'yantianqu', 'ytq');
INSERT INTO `yc_city` VALUES ('1970', '珠海市', '1938', '1', '广东,珠海市', null, null, '440400', 'z', 'zhuhaishi', 'zhs');
INSERT INTO `yc_city` VALUES ('1971', '香洲区', '1970', '1', '广东,珠海市,香洲区', null, null, '440402', 'x', 'xiangzhouqu', 'xzq');
INSERT INTO `yc_city` VALUES ('1972', '斗门区', '1970', '1', '广东,珠海市,斗门区', null, null, '440403', 'd', 'doumenqu', 'dmq');
INSERT INTO `yc_city` VALUES ('1973', '金湾区', '1970', '1', '广东,珠海市,金湾区', null, null, '440404', 'j', 'jinwanqu', 'jwq');
INSERT INTO `yc_city` VALUES ('1974', '汕头市', '1938', '1', '广东,汕头市', null, null, '440500', 's', 'shantoushi', 'sts');
INSERT INTO `yc_city` VALUES ('1975', '龙湖区', '1974', '1', '广东,汕头市,龙湖区', null, null, '440507', 'l', 'longhuqu', 'lhq');
INSERT INTO `yc_city` VALUES ('1976', '金平区', '1974', '1', '广东,汕头市,金平区', null, null, '440511', 'j', 'jinpingqu', 'jpq');
INSERT INTO `yc_city` VALUES ('1977', '濠江区', '1974', '1', '广东,汕头市,濠江区', null, null, '440512', 'h', 'haojiangqu', 'jq');
INSERT INTO `yc_city` VALUES ('1978', '潮阳区', '1974', '1', '广东,汕头市,潮阳区', null, null, '440513', 'c', 'chaoyangqu', 'cyq');
INSERT INTO `yc_city` VALUES ('1979', '潮南区', '1974', '1', '广东,汕头市,潮南区', null, null, '440514', 'c', 'chaonanqu', 'cnq');
INSERT INTO `yc_city` VALUES ('1980', '澄海区', '1974', '1', '广东,汕头市,澄海区', null, null, '440515', 'c', 'chenghaiqu', 'chq');
INSERT INTO `yc_city` VALUES ('1981', '南澳县', '1974', '1', '广东,汕头市,南澳县', null, null, '440523', 'n', 'nanaoxian', 'nax');
INSERT INTO `yc_city` VALUES ('1982', '佛山市', '1938', '1', '广东,佛山市', null, null, '440600', 'f', 'foshanshi', 'fss');
INSERT INTO `yc_city` VALUES ('1983', '禅城区', '1982', '1', '广东,佛山市,禅城区', null, null, '440604', 'c', 'chanchengqu', 'cq');
INSERT INTO `yc_city` VALUES ('1984', '南海区', '1982', '1', '广东,佛山市,南海区', null, null, '440605', 'n', 'nanhaiqu', 'nhq');
INSERT INTO `yc_city` VALUES ('1985', '顺德区', '1982', '1', '广东,佛山市,顺德区', null, null, '440606', 's', 'shundequ', 'sdq');
INSERT INTO `yc_city` VALUES ('1986', '三水区', '1982', '1', '广东,佛山市,三水区', null, null, '440607', 's', 'sanshuiqu', 'ssq');
INSERT INTO `yc_city` VALUES ('1987', '高明区', '1982', '1', '广东,佛山市,高明区', null, null, '440608', 'g', 'gaomingqu', 'gmq');
INSERT INTO `yc_city` VALUES ('1988', '江门市', '1938', '1', '广东,江门市', null, null, '440700', 'j', 'jiangmenshi', 'jms');
INSERT INTO `yc_city` VALUES ('1989', '蓬江区', '1988', '1', '广东,江门市,蓬江区', null, null, '440703', 'p', 'pengjiangqu', 'pjq');
INSERT INTO `yc_city` VALUES ('1990', '江海区', '1988', '1', '广东,江门市,江海区', null, null, '440704', 'j', 'jianghaiqu', 'jhq');
INSERT INTO `yc_city` VALUES ('1991', '新会区', '1988', '1', '广东,江门市,新会区', null, null, '440705', 'x', 'xinhuiqu', 'xhq');
INSERT INTO `yc_city` VALUES ('1992', '台山市', '1988', '1', '广东,江门市,台山市', null, null, '440781', 't', 'taishanshi', 'tss');
INSERT INTO `yc_city` VALUES ('1993', '开平市', '1988', '1', '广东,江门市,开平市', null, null, '440783', 'k', 'kaipingshi', 'kps');
INSERT INTO `yc_city` VALUES ('1994', '鹤山市', '1988', '1', '广东,江门市,鹤山市', null, null, '440784', 'h', 'heshanshi', 'hss');
INSERT INTO `yc_city` VALUES ('1995', '恩平市', '1988', '1', '广东,江门市,恩平市', null, null, '440785', 'e', 'enpingshi', 'eps');
INSERT INTO `yc_city` VALUES ('1996', '湛江市', '1938', '1', '广东,湛江市', null, null, '440800', 'z', 'zhanjiangshi', 'zjs');
INSERT INTO `yc_city` VALUES ('1997', '赤坎区', '1996', '1', '广东,湛江市,赤坎区', null, null, '440802', 'c', 'chikanqu', 'ckq');
INSERT INTO `yc_city` VALUES ('1998', '霞山区', '1996', '1', '广东,湛江市,霞山区', null, null, '440803', 'x', 'xiashanqu', 'xsq');
INSERT INTO `yc_city` VALUES ('1999', '坡头区', '1996', '1', '广东,湛江市,坡头区', null, null, '440804', 'p', 'potouqu', 'ptq');
INSERT INTO `yc_city` VALUES ('2000', '麻章区', '1996', '1', '广东,湛江市,麻章区', null, null, '440811', 'm', 'mazhangqu', 'mzq');
INSERT INTO `yc_city` VALUES ('2001', '遂溪县', '1996', '1', '广东,湛江市,遂溪县', null, null, '440823', 's', 'suixixian', 'sxx');
INSERT INTO `yc_city` VALUES ('2002', '徐闻县', '1996', '1', '广东,湛江市,徐闻县', null, null, '440825', 'x', 'xuwenxian', 'xwx');
INSERT INTO `yc_city` VALUES ('2003', '廉江市', '1996', '1', '广东,湛江市,廉江市', null, null, '440881', 'l', 'lianjiangshi', 'ljs');
INSERT INTO `yc_city` VALUES ('2004', '雷州市', '1996', '1', '广东,湛江市,雷州市', null, null, '440882', 'l', 'leizhoushi', 'lzs');
INSERT INTO `yc_city` VALUES ('2005', '吴川市', '1996', '1', '广东,湛江市,吴川市', null, null, '440883', 'w', 'wuchuanshi', 'wcs');
INSERT INTO `yc_city` VALUES ('2006', '茂名市', '1938', '1', '广东,茂名市', null, null, '440900', 'm', 'maomingshi', 'mms');
INSERT INTO `yc_city` VALUES ('2007', '茂南区', '2006', '1', '广东,茂名市,茂南区', null, null, '440902', 'm', 'maonanqu', 'mnq');
INSERT INTO `yc_city` VALUES ('2008', '电白区', '2006', '1', '广东,茂名市,电白区', null, null, null, 'd', 'dianbaiqu', 'dbq');
INSERT INTO `yc_city` VALUES ('2009', '高州市', '2006', '1', '广东,茂名市,高州市', null, null, '440981', 'g', 'gaozhoushi', 'gzs');
INSERT INTO `yc_city` VALUES ('2010', '化州市', '2006', '1', '广东,茂名市,化州市', null, null, '440982', 'h', 'huazhoushi', 'hzs');
INSERT INTO `yc_city` VALUES ('2011', '信宜市', '2006', '1', '广东,茂名市,信宜市', null, null, '440983', 'x', 'xinyishi', 'xys');
INSERT INTO `yc_city` VALUES ('2012', '肇庆市', '1938', '1', '广东,肇庆市', null, null, '441200', 'z', 'zhaoqingshi', 'zqs');
INSERT INTO `yc_city` VALUES ('2013', '端州区', '2012', '1', '广东,肇庆市,端州区', null, null, '441202', 'd', 'duanzhouqu', 'dzq');
INSERT INTO `yc_city` VALUES ('2014', '鼎湖区', '2012', '1', '广东,肇庆市,鼎湖区', null, null, '441203', 'd', 'dinghuqu', 'dhq');
INSERT INTO `yc_city` VALUES ('2015', '广宁县', '2012', '1', '广东,肇庆市,广宁县', null, null, '441223', 'g', 'guangningxian', 'gnx');
INSERT INTO `yc_city` VALUES ('2016', '怀集县', '2012', '1', '广东,肇庆市,怀集县', null, null, '441224', 'h', 'huaijixian', 'hjx');
INSERT INTO `yc_city` VALUES ('2017', '封开县', '2012', '1', '广东,肇庆市,封开县', null, null, '441225', 'f', 'fengkaixian', 'fkx');
INSERT INTO `yc_city` VALUES ('2018', '德庆县', '2012', '1', '广东,肇庆市,德庆县', null, null, '441226', 'd', 'deqingxian', 'dqx');
INSERT INTO `yc_city` VALUES ('2019', '高要市', '2012', '1', '广东,肇庆市,高要市', null, null, '441283', 'g', 'gaoyaoshi', 'gys');
INSERT INTO `yc_city` VALUES ('2020', '四会市', '2012', '1', '广东,肇庆市,四会市', null, null, '441284', 's', 'sihuishi', 'shs');
INSERT INTO `yc_city` VALUES ('2021', '惠州市', '1938', '1', '广东,惠州市', null, null, '441300', 'h', 'huizhoushi', 'hzs');
INSERT INTO `yc_city` VALUES ('2022', '惠城区', '2021', '1', '广东,惠州市,惠城区', null, null, '441302', 'h', 'huichengqu', 'hcq');
INSERT INTO `yc_city` VALUES ('2023', '惠阳区', '2021', '1', '广东,惠州市,惠阳区', null, null, '441303', 'h', 'huiyangqu', 'hyq');
INSERT INTO `yc_city` VALUES ('2024', '博罗县', '2021', '1', '广东,惠州市,博罗县', null, null, '441322', 'b', 'boluoxian', 'blx');
INSERT INTO `yc_city` VALUES ('2025', '惠东县', '2021', '1', '广东,惠州市,惠东县', null, null, '441323', 'h', 'huidongxian', 'hdx');
INSERT INTO `yc_city` VALUES ('2026', '龙门县', '2021', '1', '广东,惠州市,龙门县', null, null, '441324', 'l', 'longmenxian', 'lmx');
INSERT INTO `yc_city` VALUES ('2027', '梅州市', '1938', '1', '广东,梅州市', null, null, '441400', 'm', 'meizhoushi', 'mzs');
INSERT INTO `yc_city` VALUES ('2028', '梅江区', '2027', '1', '广东,梅州市,梅江区', null, null, '441402', 'm', 'meijiangqu', 'mjq');
INSERT INTO `yc_city` VALUES ('2029', '梅县区', '2027', '1', '广东,梅州市,梅县区', null, null, null, 'm', 'meixianqu', 'mxq');
INSERT INTO `yc_city` VALUES ('2030', '大埔县', '2027', '1', '广东,梅州市,大埔县', null, null, '441422', 'd', 'dabuxian', 'dpx');
INSERT INTO `yc_city` VALUES ('2031', '丰顺县', '2027', '1', '广东,梅州市,丰顺县', null, null, '441423', 'f', 'fengshunxian', 'fsx');
INSERT INTO `yc_city` VALUES ('2032', '五华县', '2027', '1', '广东,梅州市,五华县', null, null, '441424', 'w', 'wuhuaxian', 'whx');
INSERT INTO `yc_city` VALUES ('2033', '平远县', '2027', '1', '广东,梅州市,平远县', null, null, '441426', 'p', 'pingyuanxian', 'pyx');
INSERT INTO `yc_city` VALUES ('2034', '蕉岭县', '2027', '1', '广东,梅州市,蕉岭县', null, null, '441427', 'j', 'jiaolingxian', 'jlx');
INSERT INTO `yc_city` VALUES ('2035', '兴宁市', '2027', '1', '广东,梅州市,兴宁市', null, null, '441481', 'x', 'xingningshi', 'xns');
INSERT INTO `yc_city` VALUES ('2036', '汕尾市', '1938', '1', '广东,汕尾市', null, null, '441500', 's', 'shanweishi', 'sws');
INSERT INTO `yc_city` VALUES ('2037', '城区', '2036', '1', '广东,汕尾市,城区', null, null, '441502', 'c', 'chengqu', 'cq');
INSERT INTO `yc_city` VALUES ('2038', '海丰县', '2036', '1', '广东,汕尾市,海丰县', null, null, '441521', 'h', 'haifengxian', 'hfx');
INSERT INTO `yc_city` VALUES ('2039', '陆河县', '2036', '1', '广东,汕尾市,陆河县', null, null, '441523', 'l', 'luhexian', 'lhx');
INSERT INTO `yc_city` VALUES ('2040', '陆丰市', '2036', '1', '广东,汕尾市,陆丰市', null, null, '441581', 'l', 'lufengshi', 'lfs');
INSERT INTO `yc_city` VALUES ('2041', '河源市', '1938', '1', '广东,河源市', null, null, '441600', 'h', 'heyuanshi', 'hys');
INSERT INTO `yc_city` VALUES ('2042', '源城区', '2041', '1', '广东,河源市,源城区', null, null, '441602', 'y', 'yuanchengqu', 'ycq');
INSERT INTO `yc_city` VALUES ('2043', '紫金县', '2041', '1', '广东,河源市,紫金县', null, null, '441621', 'z', 'zijinxian', 'zjx');
INSERT INTO `yc_city` VALUES ('2044', '龙川县', '2041', '1', '广东,河源市,龙川县', null, null, '441622', 'l', 'longchuanxian', 'lcx');
INSERT INTO `yc_city` VALUES ('2045', '连平县', '2041', '1', '广东,河源市,连平县', null, null, '441623', 'l', 'lianpingxian', 'lpx');
INSERT INTO `yc_city` VALUES ('2046', '和平县', '2041', '1', '广东,河源市,和平县', null, null, '441624', 'h', 'hepingxian', 'hpx');
INSERT INTO `yc_city` VALUES ('2047', '东源县', '2041', '1', '广东,河源市,东源县', null, null, '441625', 'd', 'dongyuanxian', 'dyx');
INSERT INTO `yc_city` VALUES ('2048', '阳江市', '1938', '1', '广东,阳江市', null, null, '441700', 'y', 'yangjiangshi', 'yjs');
INSERT INTO `yc_city` VALUES ('2049', '江城区', '2048', '1', '广东,阳江市,江城区', null, null, '441702', 'j', 'jiangchengqu', 'jcq');
INSERT INTO `yc_city` VALUES ('2050', '阳西县', '2048', '1', '广东,阳江市,阳西县', null, null, '441721', 'y', 'yangxixian', 'yxx');
INSERT INTO `yc_city` VALUES ('2051', '阳东县', '2048', '1', '广东,阳江市,阳东县', null, null, '441723', 'y', 'yangdongxian', 'ydx');
INSERT INTO `yc_city` VALUES ('2052', '阳春市', '2048', '1', '广东,阳江市,阳春市', null, null, '441781', 'y', 'yangchunshi', 'ycs');
INSERT INTO `yc_city` VALUES ('2053', '清远市', '1938', '1', '广东,清远市', null, null, '441800', 'q', 'qingyuanshi', 'qys');
INSERT INTO `yc_city` VALUES ('2054', '清城区', '2053', '1', '广东,清远市,清城区', null, null, '441802', 'q', 'qingchengqu', 'qcq');
INSERT INTO `yc_city` VALUES ('2055', '清新区', '2053', '1', '广东,清远市,清新区', null, null, null, 'q', 'qingxinqu', 'qxq');
INSERT INTO `yc_city` VALUES ('2056', '佛冈县', '2053', '1', '广东,清远市,佛冈县', null, null, '441821', 'f', 'fogangxian', 'fgx');
INSERT INTO `yc_city` VALUES ('2057', '阳山县', '2053', '1', '广东,清远市,阳山县', null, null, '441823', 'y', 'yangshanxian', 'ysx');
INSERT INTO `yc_city` VALUES ('2058', '连山壮族瑶族自治县', '2053', '1', '广东,清远市,连山壮族瑶族自治县', null, null, '441825', 'l', 'lianshanzhuangzuyaozuzizhixian', 'lszzyzzzx');
INSERT INTO `yc_city` VALUES ('2059', '连南瑶族自治县', '2053', '1', '广东,清远市,连南瑶族自治县', null, null, '441826', 'l', 'liannanyaozuzizhixian', 'lnyzzzx');
INSERT INTO `yc_city` VALUES ('2060', '英德市', '2053', '1', '广东,清远市,英德市', null, null, '441881', 'y', 'yingdeshi', 'yds');
INSERT INTO `yc_city` VALUES ('2061', '连州市', '2053', '1', '广东,清远市,连州市', null, null, '441882', 'l', 'lianzhoushi', 'lzs');
INSERT INTO `yc_city` VALUES ('2062', '东莞市', '1938', '1', '广东,东莞市', null, null, '441900', 'd', 'dongguanshi', 'ds');
INSERT INTO `yc_city` VALUES ('2063', '中山市', '1938', '1', '广东,中山市', null, null, '442000', 'z', 'zhongshanshi', 'zss');
INSERT INTO `yc_city` VALUES ('2064', '潮州市', '1938', '1', '广东,潮州市', null, null, '445100', 'c', 'chaozhoushi', 'czs');
INSERT INTO `yc_city` VALUES ('2065', '湘桥区', '2064', '1', '广东,潮州市,湘桥区', null, null, '445102', 'x', 'xiangqiaoqu', 'xqq');
INSERT INTO `yc_city` VALUES ('2066', '潮安区', '2064', '1', '广东,潮州市,潮安区', null, null, null, 'c', 'chaoanqu', 'caq');
INSERT INTO `yc_city` VALUES ('2067', '饶平县', '2064', '1', '广东,潮州市,饶平县', null, null, '445122', 'r', 'raopingxian', 'rpx');
INSERT INTO `yc_city` VALUES ('2068', '揭阳市', '1938', '1', '广东,揭阳市', null, null, '445200', 'j', 'jieyangshi', 'jys');
INSERT INTO `yc_city` VALUES ('2069', '榕城区', '2068', '1', '广东,揭阳市,榕城区', null, null, '445202', 'r', 'rongchengqu', 'cq');
INSERT INTO `yc_city` VALUES ('2070', '揭东区', '2068', '1', '广东,揭阳市,揭东区', null, null, null, 'j', 'jiedongqu', 'jdq');
INSERT INTO `yc_city` VALUES ('2071', '揭西县', '2068', '1', '广东,揭阳市,揭西县', null, null, '445222', 'j', 'jiexixian', 'jxx');
INSERT INTO `yc_city` VALUES ('2072', '惠来县', '2068', '1', '广东,揭阳市,惠来县', null, null, '445224', 'h', 'huilaixian', 'hlx');
INSERT INTO `yc_city` VALUES ('2073', '普宁市', '2068', '1', '广东,揭阳市,普宁市', null, null, '445281', 'p', 'puningshi', 'pns');
INSERT INTO `yc_city` VALUES ('2074', '云浮市', '1938', '1', '广东,云浮市', null, null, '445300', 'y', 'yunfushi', 'yfs');
INSERT INTO `yc_city` VALUES ('2075', '云城区', '2074', '1', '广东,云浮市,云城区', null, null, '445302', 'y', 'yunchengqu', 'ycq');
INSERT INTO `yc_city` VALUES ('2076', '云安区', '2074', '1', '广东,云浮市,云安区', null, null, null, 'y', 'yunanqu', 'yaq');
INSERT INTO `yc_city` VALUES ('2077', '新兴县', '2074', '1', '广东,云浮市,新兴县', null, null, '445321', 'x', 'xinxingxian', 'xxx');
INSERT INTO `yc_city` VALUES ('2078', '郁南县', '2074', '1', '广东,云浮市,郁南县', null, null, '445322', 'y', 'yunanxian', 'ynx');
INSERT INTO `yc_city` VALUES ('2079', '罗定市', '2074', '1', '广东,云浮市,罗定市', null, null, '445381', 'l', 'luodingshi', 'lds');
INSERT INTO `yc_city` VALUES ('2080', '广西', '1', '1', '广西', null, null, '450000', 'g', 'guangxi', 'gx');
INSERT INTO `yc_city` VALUES ('2081', '南宁市', '2080', '1', '广西,南宁市', null, null, '450100', 'n', 'nanningshi', 'nns');
INSERT INTO `yc_city` VALUES ('2082', '兴宁区', '2081', '1', '广西,南宁市,兴宁区', null, null, '450102', 'x', 'xingningqu', 'xnq');
INSERT INTO `yc_city` VALUES ('2083', '青秀区', '2081', '1', '广西,南宁市,青秀区', null, null, '450103', 'q', 'qingxiuqu', 'qxq');
INSERT INTO `yc_city` VALUES ('2084', '江南区', '2081', '1', '广西,南宁市,江南区', null, null, '450105', 'j', 'jiangnanqu', 'jnq');
INSERT INTO `yc_city` VALUES ('2085', '西乡塘区', '2081', '1', '广西,南宁市,西乡塘区', null, null, '450107', 'x', 'xixiangtangqu', 'xxtq');
INSERT INTO `yc_city` VALUES ('2086', '良庆区', '2081', '1', '广西,南宁市,良庆区', null, null, '450108', 'l', 'liangqingqu', 'lqq');
INSERT INTO `yc_city` VALUES ('2087', '邕宁区', '2081', '1', '广西,南宁市,邕宁区', null, null, '450109', 'y', 'yongningqu', 'nq');
INSERT INTO `yc_city` VALUES ('2088', '武鸣县', '2081', '1', '广西,南宁市,武鸣县', null, null, '450122', 'w', 'wumingxian', 'wmx');
INSERT INTO `yc_city` VALUES ('2089', '隆安县', '2081', '1', '广西,南宁市,隆安县', null, null, '450123', 'l', 'longanxian', 'lax');
INSERT INTO `yc_city` VALUES ('2090', '马山县', '2081', '1', '广西,南宁市,马山县', null, null, '450124', 'm', 'mashanxian', 'msx');
INSERT INTO `yc_city` VALUES ('2091', '上林县', '2081', '1', '广西,南宁市,上林县', null, null, '450125', 's', 'shanglinxian', 'slx');
INSERT INTO `yc_city` VALUES ('2092', '宾阳县', '2081', '1', '广西,南宁市,宾阳县', null, null, '450126', 'b', 'binyangxian', 'byx');
INSERT INTO `yc_city` VALUES ('2093', '横县', '2081', '1', '广西,南宁市,横县', null, null, '450127', 'h', 'hengxian', 'hx');
INSERT INTO `yc_city` VALUES ('2094', '柳州市', '2080', '1', '广西,柳州市', null, null, '450200', 'l', 'liuzhoushi', 'lzs');
INSERT INTO `yc_city` VALUES ('2095', '城中区', '2094', '1', '广西,柳州市,城中区', null, null, '450202', 'c', 'chengzhongqu', 'czq');
INSERT INTO `yc_city` VALUES ('2096', '鱼峰区', '2094', '1', '广西,柳州市,鱼峰区', null, null, '450203', 'y', 'yufengqu', 'yfq');
INSERT INTO `yc_city` VALUES ('2097', '柳南区', '2094', '1', '广西,柳州市,柳南区', null, null, '450204', 'l', 'liunanqu', 'lnq');
INSERT INTO `yc_city` VALUES ('2098', '柳北区', '2094', '1', '广西,柳州市,柳北区', null, null, '450205', 'l', 'liubeiqu', 'lbq');
INSERT INTO `yc_city` VALUES ('2099', '柳江县', '2094', '1', '广西,柳州市,柳江县', null, null, '450221', 'l', 'liujiangxian', 'ljx');
INSERT INTO `yc_city` VALUES ('2100', '柳城县', '2094', '1', '广西,柳州市,柳城县', null, null, '450222', 'l', 'liuchengxian', 'lcx');
INSERT INTO `yc_city` VALUES ('2101', '鹿寨县', '2094', '1', '广西,柳州市,鹿寨县', null, null, '450223', 'l', 'luzhaixian', 'lzx');
INSERT INTO `yc_city` VALUES ('2102', '融安县', '2094', '1', '广西,柳州市,融安县', null, null, '450224', 'r', 'ronganxian', 'rax');
INSERT INTO `yc_city` VALUES ('2103', '融水苗族自治县', '2094', '1', '广西,柳州市,融水苗族自治县', null, null, '450225', 'r', 'rongshuimiaozuzizhixian', 'rsmzzzx');
INSERT INTO `yc_city` VALUES ('2104', '三江侗族自治县', '2094', '1', '广西,柳州市,三江侗族自治县', null, null, '450226', 's', 'sanjiangdongzuzizhixian', 'sjdzzzx');
INSERT INTO `yc_city` VALUES ('2105', '桂林市', '2080', '1', '广西,桂林市', null, null, '450300', 'g', 'guilinshi', 'gls');
INSERT INTO `yc_city` VALUES ('2106', '秀峰区', '2105', '1', '广西,桂林市,秀峰区', null, null, '450302', 'x', 'xiufengqu', 'xfq');
INSERT INTO `yc_city` VALUES ('2107', '叠彩区', '2105', '1', '广西,桂林市,叠彩区', null, null, '450303', 'd', 'diecaiqu', 'dcq');
INSERT INTO `yc_city` VALUES ('2108', '象山区', '2105', '1', '广西,桂林市,象山区', null, null, '450304', 'x', 'xiangshanqu', 'xsq');
INSERT INTO `yc_city` VALUES ('2109', '七星区', '2105', '1', '广西,桂林市,七星区', null, null, '450305', 'q', 'qixingqu', 'qxq');
INSERT INTO `yc_city` VALUES ('2110', '雁山区', '2105', '1', '广西,桂林市,雁山区', null, null, '450311', 'y', 'yanshanqu', 'ysq');
INSERT INTO `yc_city` VALUES ('2111', '临桂区', '2105', '1', '广西,桂林市,临桂区', null, null, null, 'l', 'linguiqu', 'lgq');
INSERT INTO `yc_city` VALUES ('2112', '阳朔县', '2105', '1', '广西,桂林市,阳朔县', null, null, '450321', 'y', 'yangshuoxian', 'ysx');
INSERT INTO `yc_city` VALUES ('2113', '灵川县', '2105', '1', '广西,桂林市,灵川县', null, null, '450323', 'l', 'lingchuanxian', 'lcx');
INSERT INTO `yc_city` VALUES ('2114', '全州县', '2105', '1', '广西,桂林市,全州县', null, null, '450324', 'q', 'quanzhouxian', 'qzx');
INSERT INTO `yc_city` VALUES ('2115', '兴安县', '2105', '1', '广西,桂林市,兴安县', null, null, '450325', 'x', 'xinganxian', 'xax');
INSERT INTO `yc_city` VALUES ('2116', '永福县', '2105', '1', '广西,桂林市,永福县', null, null, '450326', 'y', 'yongfuxian', 'yfx');
INSERT INTO `yc_city` VALUES ('2117', '灌阳县', '2105', '1', '广西,桂林市,灌阳县', null, null, '450327', 'g', 'guanyangxian', 'gyx');
INSERT INTO `yc_city` VALUES ('2118', '龙胜各族自治县', '2105', '1', '广西,桂林市,龙胜各族自治县', null, null, '450328', 'l', 'longshenggezuzizhixian', 'lsgzzzx');
INSERT INTO `yc_city` VALUES ('2119', '资源县', '2105', '1', '广西,桂林市,资源县', null, null, '450329', 'z', 'ziyuanxian', 'zyx');
INSERT INTO `yc_city` VALUES ('2120', '平乐县', '2105', '1', '广西,桂林市,平乐县', null, null, '450330', 'p', 'pinglexian', 'plx');
INSERT INTO `yc_city` VALUES ('2121', '荔浦县', '2105', '1', '广西,桂林市,荔浦县', null, null, null, 'l', 'lipuxian', 'lpx');
INSERT INTO `yc_city` VALUES ('2122', '恭城瑶族自治县', '2105', '1', '广西,桂林市,恭城瑶族自治县', null, null, '450332', 'g', 'gongchengyaozuzizhixian', 'gcyzzzx');
INSERT INTO `yc_city` VALUES ('2123', '梧州市', '2080', '1', '广西,梧州市', null, null, '450400', 'w', 'wuzhoushi', 'wzs');
INSERT INTO `yc_city` VALUES ('2124', '万秀区', '2123', '1', '广西,梧州市,万秀区', null, null, '450403', 'w', 'wanxiuqu', 'wxq');
INSERT INTO `yc_city` VALUES ('2125', '长洲区', '2123', '1', '广西,梧州市,长洲区', null, null, '450405', 'c', 'changzhouqu', 'czq');
INSERT INTO `yc_city` VALUES ('2126', '龙圩区', '2123', '1', '广西,梧州市,龙圩区', null, null, null, 'l', 'longweiqu', 'lq');
INSERT INTO `yc_city` VALUES ('2127', '苍梧县', '2123', '1', '广西,梧州市,苍梧县', null, null, '450421', 'c', 'cangwuxian', 'cwx');
INSERT INTO `yc_city` VALUES ('2128', '藤县', '2123', '1', '广西,梧州市,藤县', null, null, '450422', 't', 'tengxian', 'tx');
INSERT INTO `yc_city` VALUES ('2129', '蒙山县', '2123', '1', '广西,梧州市,蒙山县', null, null, '450423', 'm', 'mengshanxian', 'msx');
INSERT INTO `yc_city` VALUES ('2130', '岑溪市', '2123', '1', '广西,梧州市,岑溪市', null, null, '450481', 'c', 'cenxishi', 'xs');
INSERT INTO `yc_city` VALUES ('2131', '北海市', '2080', '1', '广西,北海市', null, null, '450500', 'b', 'beihaishi', 'bhs');
INSERT INTO `yc_city` VALUES ('2132', '海城区', '2131', '1', '广西,北海市,海城区', null, null, '450502', 'h', 'haichengqu', 'hcq');
INSERT INTO `yc_city` VALUES ('2133', '银海区', '2131', '1', '广西,北海市,银海区', null, null, '450503', 'y', 'yinhaiqu', 'yhq');
INSERT INTO `yc_city` VALUES ('2134', '铁山港区', '2131', '1', '广西,北海市,铁山港区', null, null, '450512', 't', 'tieshangangqu', 'tsgq');
INSERT INTO `yc_city` VALUES ('2135', '合浦县', '2131', '1', '广西,北海市,合浦县', null, null, '450521', 'h', 'hepuxian', 'hpx');
INSERT INTO `yc_city` VALUES ('2136', '防城港市', '2080', '1', '广西,防城港市', null, null, '450600', 'f', 'fangchenggangshi', 'fcgs');
INSERT INTO `yc_city` VALUES ('2137', '港口区', '2136', '1', '广西,防城港市,港口区', null, null, '450602', 'g', 'gangkouqu', 'gkq');
INSERT INTO `yc_city` VALUES ('2138', '防城区', '2136', '1', '广西,防城港市,防城区', null, null, '450603', 'f', 'fangchengqu', 'fcq');
INSERT INTO `yc_city` VALUES ('2139', '上思县', '2136', '1', '广西,防城港市,上思县', null, null, '450621', 's', 'shangsixian', 'ssx');
INSERT INTO `yc_city` VALUES ('2140', '东兴市', '2136', '1', '广西,防城港市,东兴市', null, null, '450681', 'd', 'dongxingshi', 'dxs');
INSERT INTO `yc_city` VALUES ('2141', '钦州市', '2080', '1', '广西,钦州市', null, null, '450700', 'q', 'qinzhoushi', 'qzs');
INSERT INTO `yc_city` VALUES ('2142', '钦南区', '2141', '1', '广西,钦州市,钦南区', null, null, '450702', 'q', 'qinnanqu', 'qnq');
INSERT INTO `yc_city` VALUES ('2143', '钦北区', '2141', '1', '广西,钦州市,钦北区', null, null, '450703', 'q', 'qinbeiqu', 'qbq');
INSERT INTO `yc_city` VALUES ('2144', '灵山县', '2141', '1', '广西,钦州市,灵山县', null, null, '450721', 'l', 'lingshanxian', 'lsx');
INSERT INTO `yc_city` VALUES ('2145', '浦北县', '2141', '1', '广西,钦州市,浦北县', null, null, '450722', 'p', 'pubeixian', 'pbx');
INSERT INTO `yc_city` VALUES ('2146', '贵港市', '2080', '1', '广西,贵港市', null, null, '450800', 'g', 'guigangshi', 'ggs');
INSERT INTO `yc_city` VALUES ('2147', '港北区', '2146', '1', '广西,贵港市,港北区', null, null, '450802', 'g', 'gangbeiqu', 'gbq');
INSERT INTO `yc_city` VALUES ('2148', '港南区', '2146', '1', '广西,贵港市,港南区', null, null, '450803', 'g', 'gangnanqu', 'gnq');
INSERT INTO `yc_city` VALUES ('2149', '覃塘区', '2146', '1', '广西,贵港市,覃塘区', null, null, '450804', 't', 'tantangqu', 'tq');
INSERT INTO `yc_city` VALUES ('2150', '平南县', '2146', '1', '广西,贵港市,平南县', null, null, '450821', 'p', 'pingnanxian', 'pnx');
INSERT INTO `yc_city` VALUES ('2151', '桂平市', '2146', '1', '广西,贵港市,桂平市', null, null, '450881', 'g', 'guipingshi', 'gps');
INSERT INTO `yc_city` VALUES ('2152', '玉林市', '2080', '1', '广西,玉林市', null, null, '450900', 'y', 'yulinshi', 'yls');
INSERT INTO `yc_city` VALUES ('2153', '玉州区', '2152', '1', '广西,玉林市,玉州区', null, null, '450902', 'y', 'yuzhouqu', 'yzq');
INSERT INTO `yc_city` VALUES ('2154', '福绵区', '2152', '1', '广西,玉林市,福绵区', null, null, null, 'f', 'fumianqu', 'fmq');
INSERT INTO `yc_city` VALUES ('2155', '容县', '2152', '1', '广西,玉林市,容县', null, null, '450921', 'r', 'rongxian', 'rx');
INSERT INTO `yc_city` VALUES ('2156', '陆川县', '2152', '1', '广西,玉林市,陆川县', null, null, '450922', 'l', 'luchuanxian', 'lcx');
INSERT INTO `yc_city` VALUES ('2157', '博白县', '2152', '1', '广西,玉林市,博白县', null, null, '450923', 'b', 'bobaixian', 'bbx');
INSERT INTO `yc_city` VALUES ('2158', '兴业县', '2152', '1', '广西,玉林市,兴业县', null, null, '450924', 'x', 'xingyexian', 'xyx');
INSERT INTO `yc_city` VALUES ('2159', '北流市', '2152', '1', '广西,玉林市,北流市', null, null, '450981', 'b', 'beiliushi', 'bls');
INSERT INTO `yc_city` VALUES ('2160', '百色市', '2080', '1', '广西,百色市', null, null, '451000', 'b', 'boseshi', 'bss');
INSERT INTO `yc_city` VALUES ('2161', '右江区', '2160', '1', '广西,百色市,右江区', null, null, '451002', 'y', 'youjiangqu', 'yjq');
INSERT INTO `yc_city` VALUES ('2162', '田阳县', '2160', '1', '广西,百色市,田阳县', null, null, '451021', 't', 'tianyangxian', 'tyx');
INSERT INTO `yc_city` VALUES ('2163', '田东县', '2160', '1', '广西,百色市,田东县', null, null, '451022', 't', 'tiandongxian', 'tdx');
INSERT INTO `yc_city` VALUES ('2164', '平果县', '2160', '1', '广西,百色市,平果县', null, null, '451023', 'p', 'pingguoxian', 'pgx');
INSERT INTO `yc_city` VALUES ('2165', '德保县', '2160', '1', '广西,百色市,德保县', null, null, '451024', 'd', 'debaoxian', 'dbx');
INSERT INTO `yc_city` VALUES ('2166', '靖西县', '2160', '1', '广西,百色市,靖西县', null, null, '451025', 'j', 'jingxixian', 'jxx');
INSERT INTO `yc_city` VALUES ('2167', '那坡县', '2160', '1', '广西,百色市,那坡县', null, null, '451026', 'n', 'napoxian', 'npx');
INSERT INTO `yc_city` VALUES ('2168', '凌云县', '2160', '1', '广西,百色市,凌云县', null, null, '451027', 'l', 'lingyunxian', 'lyx');
INSERT INTO `yc_city` VALUES ('2169', '乐业县', '2160', '1', '广西,百色市,乐业县', null, null, '451028', 'l', 'leyexian', 'lyx');
INSERT INTO `yc_city` VALUES ('2170', '田林县', '2160', '1', '广西,百色市,田林县', null, null, '451029', 't', 'tianlinxian', 'tlx');
INSERT INTO `yc_city` VALUES ('2171', '西林县', '2160', '1', '广西,百色市,西林县', null, null, '451030', 'x', 'xilinxian', 'xlx');
INSERT INTO `yc_city` VALUES ('2172', '隆林各族自治县', '2160', '1', '广西,百色市,隆林各族自治县', null, null, '451031', 'l', 'longlingezuzizhixian', 'llgzzzx');
INSERT INTO `yc_city` VALUES ('2173', '贺州市', '2080', '1', '广西,贺州市', null, null, '451100', 'h', 'hezhoushi', 'hzs');
INSERT INTO `yc_city` VALUES ('2174', '八步区', '2173', '1', '广西,贺州市,八步区', null, null, '451102', 'b', 'babuqu', 'bbq');
INSERT INTO `yc_city` VALUES ('2175', '昭平县', '2173', '1', '广西,贺州市,昭平县', null, null, '451121', 'z', 'zhaopingxian', 'zpx');
INSERT INTO `yc_city` VALUES ('2176', '钟山县', '2173', '1', '广西,贺州市,钟山县', null, null, '451122', 'z', 'zhongshanxian', 'zsx');
INSERT INTO `yc_city` VALUES ('2177', '富川瑶族自治县', '2173', '1', '广西,贺州市,富川瑶族自治县', null, null, '451123', 'f', 'fuchuanyaozuzizhixian', 'fcyzzzx');
INSERT INTO `yc_city` VALUES ('2178', '河池市', '2080', '1', '广西,河池市', null, null, '451200', 'h', 'hechishi', 'hcs');
INSERT INTO `yc_city` VALUES ('2179', '金城江区', '2178', '1', '广西,河池市,金城江区', null, null, '451202', 'j', 'jinchengjiangqu', 'jcjq');
INSERT INTO `yc_city` VALUES ('2180', '南丹县', '2178', '1', '广西,河池市,南丹县', null, null, '451221', 'n', 'nandanxian', 'ndx');
INSERT INTO `yc_city` VALUES ('2181', '天峨县', '2178', '1', '广西,河池市,天峨县', null, null, '451222', 't', 'tianexian', 'tex');
INSERT INTO `yc_city` VALUES ('2182', '凤山县', '2178', '1', '广西,河池市,凤山县', null, null, '451223', 'f', 'fengshanxian', 'fsx');
INSERT INTO `yc_city` VALUES ('2183', '东兰县', '2178', '1', '广西,河池市,东兰县', null, null, '451224', 'd', 'donglanxian', 'dlx');
INSERT INTO `yc_city` VALUES ('2184', '罗城仫佬族自治县', '2178', '1', '广西,河池市,罗城仫佬族自治县', null, null, '451225', 'l', 'luochengmulaozuzizhixian', 'lclzzzx');
INSERT INTO `yc_city` VALUES ('2185', '环江毛南族自治县', '2178', '1', '广西,河池市,环江毛南族自治县', null, null, '451226', 'h', 'huanjiangmaonanzuzizhixian', 'hjmnzzzx');
INSERT INTO `yc_city` VALUES ('2186', '巴马瑶族自治县', '2178', '1', '广西,河池市,巴马瑶族自治县', null, null, '451227', 'b', 'bamayaozuzizhixian', 'bmyzzzx');
INSERT INTO `yc_city` VALUES ('2187', '都安瑶族自治县', '2178', '1', '广西,河池市,都安瑶族自治县', null, null, '451228', 'd', 'douanyaozuzizhixian', 'dayzzzx');
INSERT INTO `yc_city` VALUES ('2188', '大化瑶族自治县', '2178', '1', '广西,河池市,大化瑶族自治县', null, null, '451229', 'd', 'dahuayaozuzizhixian', 'dhyzzzx');
INSERT INTO `yc_city` VALUES ('2189', '宜州市', '2178', '1', '广西,河池市,宜州市', null, null, '451281', 'y', 'yizhoushi', 'yzs');
INSERT INTO `yc_city` VALUES ('2190', '来宾市', '2080', '1', '广西,来宾市', null, null, '451300', 'l', 'laibinshi', 'lbs');
INSERT INTO `yc_city` VALUES ('2191', '兴宾区', '2190', '1', '广西,来宾市,兴宾区', null, null, '451302', 'x', 'xingbinqu', 'xbq');
INSERT INTO `yc_city` VALUES ('2192', '忻城县', '2190', '1', '广西,来宾市,忻城县', null, null, '451321', 'x', 'xinchengxian', 'xcx');
INSERT INTO `yc_city` VALUES ('2193', '象州县', '2190', '1', '广西,来宾市,象州县', null, null, '451322', 'x', 'xiangzhouxian', 'xzx');
INSERT INTO `yc_city` VALUES ('2194', '武宣县', '2190', '1', '广西,来宾市,武宣县', null, null, '451323', 'w', 'wuxuanxian', 'wxx');
INSERT INTO `yc_city` VALUES ('2195', '金秀瑶族自治县', '2190', '1', '广西,来宾市,金秀瑶族自治县', null, null, '451324', 'j', 'jinxiuyaozuzizhixian', 'jxyzzzx');
INSERT INTO `yc_city` VALUES ('2196', '合山市', '2190', '1', '广西,来宾市,合山市', null, null, '451381', 'h', 'heshanshi', 'hss');
INSERT INTO `yc_city` VALUES ('2197', '崇左市', '2080', '1', '广西,崇左市', null, null, '451400', 'c', 'chongzuoshi', 'czs');
INSERT INTO `yc_city` VALUES ('2198', '江州区', '2197', '1', '广西,崇左市,江州区', null, null, null, 'j', 'jiangzhouqu', 'jzq');
INSERT INTO `yc_city` VALUES ('2199', '扶绥县', '2197', '1', '广西,崇左市,扶绥县', null, null, '451421', 'f', 'fusuixian', 'fsx');
INSERT INTO `yc_city` VALUES ('2200', '宁明县', '2197', '1', '广西,崇左市,宁明县', null, null, '451422', 'n', 'ningmingxian', 'nmx');
INSERT INTO `yc_city` VALUES ('2201', '龙州县', '2197', '1', '广西,崇左市,龙州县', null, null, '451423', 'l', 'longzhouxian', 'lzx');
INSERT INTO `yc_city` VALUES ('2202', '大新县', '2197', '1', '广西,崇左市,大新县', null, null, '451424', 'd', 'daxinxian', 'dxx');
INSERT INTO `yc_city` VALUES ('2203', '天等县', '2197', '1', '广西,崇左市,天等县', null, null, '451425', 't', 'tiandengxian', 'tdx');
INSERT INTO `yc_city` VALUES ('2204', '凭祥市', '2197', '1', '广西,崇左市,凭祥市', null, null, '451481', 'p', 'pingxiangshi', 'pxs');
INSERT INTO `yc_city` VALUES ('2205', '海南', '1', '1', '海南', null, null, '460000', 'h', 'hainan', 'hn');
INSERT INTO `yc_city` VALUES ('2206', '海口市', '2205', '1', '海南,海口市', null, null, '460100', 'h', 'haikoushi', 'hks');
INSERT INTO `yc_city` VALUES ('2207', '秀英区', '2206', '1', '海南,海口市,秀英区', null, null, '460105', 'x', 'xiuyingqu', 'xyq');
INSERT INTO `yc_city` VALUES ('2208', '龙华区', '2206', '1', '海南,海口市,龙华区', null, null, '460106', 'l', 'longhuaqu', 'lhq');
INSERT INTO `yc_city` VALUES ('2209', '琼山区', '2206', '1', '海南,海口市,琼山区', null, null, '460107', 'q', 'qiongshanqu', 'qsq');
INSERT INTO `yc_city` VALUES ('2210', '美兰区', '2206', '1', '海南,海口市,美兰区', null, null, '460108', 'm', 'meilanqu', 'mlq');
INSERT INTO `yc_city` VALUES ('2211', '三亚市', '2205', '1', '海南,三亚市', null, null, '460200', 's', 'sanyashi', 'sys');
INSERT INTO `yc_city` VALUES ('2212', '海棠区', '2211', '1', '海南,三亚市,海棠区', null, null, null, 'h', 'haitangqu', 'htq');
INSERT INTO `yc_city` VALUES ('2213', '吉阳区', '2211', '1', '海南,三亚市,吉阳区', null, null, null, 'j', 'jiyangqu', 'jyq');
INSERT INTO `yc_city` VALUES ('2214', '天涯区', '2211', '1', '海南,三亚市,天涯区', null, null, null, 't', 'tianyaqu', 'tyq');
INSERT INTO `yc_city` VALUES ('2215', '崖州区', '2211', '1', '海南,三亚市,崖州区', null, null, null, 'y', 'yazhouqu', 'yzq');
INSERT INTO `yc_city` VALUES ('2216', '三沙市', '2205', '1', '海南,三沙市', null, null, null, 's', 'sanshashi', 'sss');
INSERT INTO `yc_city` VALUES ('2217', '五指山市', '2205', '1', '海南,五指山市', null, null, null, 'w', 'wuzhishanshi', 'wzss');
INSERT INTO `yc_city` VALUES ('2218', '琼海市', '2205', '1', '海南,琼海市', null, null, null, 'q', 'qionghaishi', 'qhs');
INSERT INTO `yc_city` VALUES ('2219', '儋州市', '2205', '1', '海南,儋州市', null, null, null, 'd', 'danzhoushi', 'zs');
INSERT INTO `yc_city` VALUES ('2220', '文昌市', '2205', '1', '海南,文昌市', null, null, null, 'w', 'wenchangshi', 'wcs');
INSERT INTO `yc_city` VALUES ('2221', '万宁市', '2205', '1', '海南,万宁市', null, null, null, 'w', 'wanningshi', 'wns');
INSERT INTO `yc_city` VALUES ('2222', '东方市', '2205', '1', '海南,东方市', null, null, null, 'd', 'dongfangshi', 'dfs');
INSERT INTO `yc_city` VALUES ('2223', '定安县', '2205', '1', '海南,定安县', null, null, null, 'd', 'dinganxian', 'dax');
INSERT INTO `yc_city` VALUES ('2224', '屯昌县', '2205', '1', '海南,屯昌县', null, null, null, 't', 'tunchangxian', 'tcx');
INSERT INTO `yc_city` VALUES ('2225', '澄迈县', '2205', '1', '海南,澄迈县', null, null, null, 'c', 'chengmaixian', 'cmx');
INSERT INTO `yc_city` VALUES ('2226', '临高县', '2205', '1', '海南,临高县', null, null, null, 'l', 'lingaoxian', 'lgx');
INSERT INTO `yc_city` VALUES ('2227', '白沙黎族自治县', '2205', '1', '海南,白沙黎族自治县', null, null, null, 'b', 'baishalizuzizhixian', 'bslzzzx');
INSERT INTO `yc_city` VALUES ('2228', '昌江黎族自治县', '2205', '1', '海南,昌江黎族自治县', null, null, null, 'c', 'changjianglizuzizhixian', 'cjlzzzx');
INSERT INTO `yc_city` VALUES ('2229', '乐东黎族自治县', '2205', '1', '海南,乐东黎族自治县', null, null, null, 'l', 'ledonglizuzizhixian', 'ldlzzzx');
INSERT INTO `yc_city` VALUES ('2230', '陵水黎族自治县', '2205', '1', '海南,陵水黎族自治县', null, null, null, 'l', 'lingshuilizuzizhixian', 'lslzzzx');
INSERT INTO `yc_city` VALUES ('2231', '保亭黎族苗族自治县', '2205', '1', '海南,保亭黎族苗族自治县', null, null, null, 'b', 'baotinglizumiaozuzizhixian', 'btlzmzzzx');
INSERT INTO `yc_city` VALUES ('2232', '琼中黎族苗族自治县', '2205', '1', '海南,琼中黎族苗族自治县', null, null, null, 'q', 'qiongzhonglizumiaozuzizhixian', 'qzlzmzzzx');
INSERT INTO `yc_city` VALUES ('2233', '重庆', '1', '1', '重庆', null, null, '500000', 'c', 'chongqing', 'zq');
INSERT INTO `yc_city` VALUES ('2234', '万州区', '2233', '1', '重庆,万州区', null, null, '500101', 'w', 'wanzhouqu', 'wzq');
INSERT INTO `yc_city` VALUES ('2235', '涪陵区', '2233', '1', '重庆,涪陵区', null, null, '500102', 'f', 'fulingqu', 'flq');
INSERT INTO `yc_city` VALUES ('2236', '渝中区', '2233', '1', '重庆,渝中区', null, null, '500103', 'y', 'yuzhongqu', 'yzq');
INSERT INTO `yc_city` VALUES ('2237', '大渡口区', '2233', '1', '重庆,大渡口区', null, null, '500104', 'd', 'dadukouqu', 'ddkq');
INSERT INTO `yc_city` VALUES ('2238', '江北区', '2233', '1', '重庆,江北区', null, null, '500105', 'j', 'jiangbeiqu', 'jbq');
INSERT INTO `yc_city` VALUES ('2239', '沙坪坝区', '2233', '1', '重庆,沙坪坝区', null, null, '500106', 's', 'shapingbaqu', 'spbq');
INSERT INTO `yc_city` VALUES ('2240', '九龙坡区', '2233', '1', '重庆,九龙坡区', null, null, '500107', 'j', 'jiulongpoqu', 'jlpq');
INSERT INTO `yc_city` VALUES ('2241', '南岸区', '2233', '1', '重庆,南岸区', null, null, '500108', 'n', 'nananqu', 'naq');
INSERT INTO `yc_city` VALUES ('2242', '北碚区', '2233', '1', '重庆,北碚区', null, null, '500109', 'b', 'beibeiqu', 'bq');
INSERT INTO `yc_city` VALUES ('2243', '綦江区', '2233', '1', '重庆,綦江区', null, null, null, 'q', 'qijiangqu', 'jq');
INSERT INTO `yc_city` VALUES ('2244', '大足区', '2233', '1', '重庆,大足区', null, null, null, 'd', 'dazuqu', 'dzq');
INSERT INTO `yc_city` VALUES ('2245', '渝北区', '2233', '1', '重庆,渝北区', null, null, '500112', 'y', 'yubeiqu', 'ybq');
INSERT INTO `yc_city` VALUES ('2246', '巴南区', '2233', '1', '重庆,巴南区', null, null, '500113', 'b', 'bananqu', 'bnq');
INSERT INTO `yc_city` VALUES ('2247', '黔江区', '2233', '1', '重庆,黔江区', null, null, '500114', 'q', 'qianjiangqu', 'qjq');
INSERT INTO `yc_city` VALUES ('2248', '长寿区', '2233', '1', '重庆,长寿区', null, null, '500115', 'c', 'changshouqu', 'csq');
INSERT INTO `yc_city` VALUES ('2249', '江津区', '2233', '1', '重庆,江津区', null, null, '500116', 'j', 'jiangjinqu', 'jjq');
INSERT INTO `yc_city` VALUES ('2250', '合川区', '2233', '1', '重庆,合川区', null, null, '500117', 'h', 'hechuanqu', 'hcq');
INSERT INTO `yc_city` VALUES ('2251', '永川区', '2233', '1', '重庆,永川区', null, null, '500118', 'y', 'yongchuanqu', 'ycq');
INSERT INTO `yc_city` VALUES ('2252', '南川区', '2233', '1', '重庆,南川区', null, null, '500119', 'n', 'nanchuanqu', 'ncq');
INSERT INTO `yc_city` VALUES ('2253', '璧山区', '2233', '1', '重庆,璧山区', null, null, null, 'b', 'bishanqu', 'sq');
INSERT INTO `yc_city` VALUES ('2254', '铜梁区', '2233', '1', '重庆,铜梁区', null, null, null, 't', 'tongliangqu', 'tlq');
INSERT INTO `yc_city` VALUES ('2255', '潼南县', '2233', '1', '重庆,潼南县', null, null, '500223', 't', 'tongnanxian', 'nx');
INSERT INTO `yc_city` VALUES ('2256', '荣昌县', '2233', '1', '重庆,荣昌县', null, null, '500226', 'r', 'rongchangxian', 'rcx');
INSERT INTO `yc_city` VALUES ('2257', '梁平县', '2233', '1', '重庆,梁平县', null, null, '500228', 'l', 'liangpingxian', 'lpx');
INSERT INTO `yc_city` VALUES ('2258', '城口县', '2233', '1', '重庆,城口县', null, null, '500229', 'c', 'chengkouxian', 'ckx');
INSERT INTO `yc_city` VALUES ('2259', '丰都县', '2233', '1', '重庆,丰都县', null, null, '500230', 'f', 'fengduxian', 'fdx');
INSERT INTO `yc_city` VALUES ('2260', '垫江县', '2233', '1', '重庆,垫江县', null, null, '500231', 'd', 'dianjiangxian', 'djx');
INSERT INTO `yc_city` VALUES ('2261', '武隆县', '2233', '1', '重庆,武隆县', null, null, '500232', 'w', 'wulongxian', 'wlx');
INSERT INTO `yc_city` VALUES ('2262', '忠县', '2233', '1', '重庆,忠县', null, null, '500233', 'z', 'zhongxian', 'zx');
INSERT INTO `yc_city` VALUES ('2263', '开县', '2233', '1', '重庆,开县', null, null, '500234', 'k', 'kaixian', 'kx');
INSERT INTO `yc_city` VALUES ('2264', '云阳县', '2233', '1', '重庆,云阳县', null, null, '500235', 'y', 'yunyangxian', 'yyx');
INSERT INTO `yc_city` VALUES ('2265', '奉节县', '2233', '1', '重庆,奉节县', null, null, '500236', 'f', 'fengjiexian', 'fjx');
INSERT INTO `yc_city` VALUES ('2266', '巫山县', '2233', '1', '重庆,巫山县', null, null, '500237', 'w', 'wushanxian', 'wsx');
INSERT INTO `yc_city` VALUES ('2267', '巫溪县', '2233', '1', '重庆,巫溪县', null, null, '500238', 'w', 'wuxixian', 'wxx');
INSERT INTO `yc_city` VALUES ('2268', '石柱土家族自治县', '2233', '1', '重庆,石柱土家族自治县', null, null, '500240', 's', 'shizhutujiazuzizhixian', 'sztjzzzx');
INSERT INTO `yc_city` VALUES ('2269', '秀山土家族苗族自治县', '2233', '1', '重庆,秀山土家族苗族自治县', null, null, '500241', 'x', 'xiushantujiazumiaozuzizhixian', 'xstjzmzzzx');
INSERT INTO `yc_city` VALUES ('2270', '酉阳土家族苗族自治县', '2233', '1', '重庆,酉阳土家族苗族自治县', null, null, '500242', 'y', 'youyangtujiazumiaozuzizhixian', 'yytjzmzzzx');
INSERT INTO `yc_city` VALUES ('2271', '彭水苗族土家族自治县', '2233', '1', '重庆,彭水苗族土家族自治县', null, null, '500243', 'p', 'pengshuimiaozutujiazuzizhixian', 'psmztjzzzx');
INSERT INTO `yc_city` VALUES ('2272', '四川', '1', '1', '四川', null, null, '510000', 's', 'sichuan', 'sc');
INSERT INTO `yc_city` VALUES ('2273', '成都市', '2272', '1', '四川,成都市', null, null, '510100', 'c', 'chengdushi', 'cds');
INSERT INTO `yc_city` VALUES ('2274', '锦江区', '2273', '1', '四川,成都市,锦江区', null, null, '510104', 'j', 'jinjiangqu', 'jjq');
INSERT INTO `yc_city` VALUES ('2275', '青羊区', '2273', '1', '四川,成都市,青羊区', null, null, '510105', 'q', 'qingyangqu', 'qyq');
INSERT INTO `yc_city` VALUES ('2276', '金牛区', '2273', '1', '四川,成都市,金牛区', null, null, '510106', 'j', 'jinniuqu', 'jnq');
INSERT INTO `yc_city` VALUES ('2277', '武侯区', '2273', '1', '四川,成都市,武侯区', null, null, '510107', 'w', 'wuhouqu', 'whq');
INSERT INTO `yc_city` VALUES ('2278', '成华区', '2273', '1', '四川,成都市,成华区', null, null, '510108', 'c', 'chenghuaqu', 'chq');
INSERT INTO `yc_city` VALUES ('2279', '龙泉驿区', '2273', '1', '四川,成都市,龙泉驿区', null, null, '510112', 'l', 'longquanyiqu', 'lqq');
INSERT INTO `yc_city` VALUES ('2280', '青白江区', '2273', '1', '四川,成都市,青白江区', null, null, '510113', 'q', 'qingbaijiangqu', 'qbjq');
INSERT INTO `yc_city` VALUES ('2281', '新都区', '2273', '1', '四川,成都市,新都区', null, null, '510114', 'x', 'xinduqu', 'xdq');
INSERT INTO `yc_city` VALUES ('2282', '温江区', '2273', '1', '四川,成都市,温江区', null, null, '510115', 'w', 'wenjiangqu', 'wjq');
INSERT INTO `yc_city` VALUES ('2283', '金堂县', '2273', '1', '四川,成都市,金堂县', null, null, '510121', 'j', 'jintangxian', 'jtx');
INSERT INTO `yc_city` VALUES ('2284', '双流区', '2273', '1', '四川,成都市,双流区', null, null, '510122', 's', 'shuangliuqu', 'slq');
INSERT INTO `yc_city` VALUES ('2285', '郫都区', '2273', '1', '四川,成都市,郫都区', null, null, '510124', 'p', 'pixian', 'x');
INSERT INTO `yc_city` VALUES ('2286', '大邑县', '2273', '1', '四川,成都市,大邑县', null, null, '510129', 'd', 'dayixian', 'dyx');
INSERT INTO `yc_city` VALUES ('2287', '蒲江县', '2273', '1', '四川,成都市,蒲江县', null, null, '510131', 'p', 'pujiangxian', 'pjx');
INSERT INTO `yc_city` VALUES ('2288', '新津县', '2273', '1', '四川,成都市,新津县', null, null, '510132', 'x', 'xinjinxian', 'xjx');
INSERT INTO `yc_city` VALUES ('2289', '都江堰市', '2273', '1', '四川,成都市,都江堰市', null, null, '510181', 'd', 'dujiangyanshi', 'djys');
INSERT INTO `yc_city` VALUES ('2290', '彭州市', '2273', '1', '四川,成都市,彭州市', null, null, '510182', 'p', 'pengzhoushi', 'pzs');
INSERT INTO `yc_city` VALUES ('2291', '邛崃市', '2273', '1', '四川,成都市,邛崃市', null, null, '510183', 'q', 'qionglaishi', 's');
INSERT INTO `yc_city` VALUES ('2292', '崇州市', '2273', '1', '四川,成都市,崇州市', null, null, '510184', 'c', 'chongzhoushi', 'czs');
INSERT INTO `yc_city` VALUES ('2293', '自贡市', '2272', '1', '四川,自贡市', null, null, '510300', 'z', 'zigongshi', 'zgs');
INSERT INTO `yc_city` VALUES ('2294', '自流井区', '2293', '1', '四川,自贡市,自流井区', null, null, '510302', 'z', 'ziliujingqu', 'zljq');
INSERT INTO `yc_city` VALUES ('2295', '贡井区', '2293', '1', '四川,自贡市,贡井区', null, null, '510303', 'g', 'gongjingqu', 'gjq');
INSERT INTO `yc_city` VALUES ('2296', '大安区', '2293', '1', '四川,自贡市,大安区', null, null, '510304', 'd', 'daanqu', 'daq');
INSERT INTO `yc_city` VALUES ('2297', '沿滩区', '2293', '1', '四川,自贡市,沿滩区', null, null, '510311', 'y', 'yantanqu', 'ytq');
INSERT INTO `yc_city` VALUES ('2298', '荣县', '2293', '1', '四川,自贡市,荣县', null, null, '510321', 'r', 'rongxian', 'rx');
INSERT INTO `yc_city` VALUES ('2299', '富顺县', '2293', '1', '四川,自贡市,富顺县', null, null, '510322', 'f', 'fushunxian', 'fsx');
INSERT INTO `yc_city` VALUES ('2300', '攀枝花市', '2272', '1', '四川,攀枝花市', null, null, '510400', 'p', 'panzhihuashi', 'pzhs');
INSERT INTO `yc_city` VALUES ('2301', '东区', '2300', '1', '四川,攀枝花市,东区', null, null, '510402', 'd', 'dongqu', 'dq');
INSERT INTO `yc_city` VALUES ('2302', '西区', '2300', '1', '四川,攀枝花市,西区', null, null, '510403', 'x', 'xiqu', 'xq');
INSERT INTO `yc_city` VALUES ('2303', '仁和区', '2300', '1', '四川,攀枝花市,仁和区', null, null, '510411', 'r', 'renhequ', 'rhq');
INSERT INTO `yc_city` VALUES ('2304', '米易县', '2300', '1', '四川,攀枝花市,米易县', null, null, '510421', 'm', 'miyixian', 'myx');
INSERT INTO `yc_city` VALUES ('2305', '盐边县', '2300', '1', '四川,攀枝花市,盐边县', null, null, '510422', 'y', 'yanbianxian', 'ybx');
INSERT INTO `yc_city` VALUES ('2306', '泸州市', '2272', '1', '四川,泸州市', null, null, '510500', 'l', 'luzhoushi', 'zs');
INSERT INTO `yc_city` VALUES ('2307', '江阳区', '2306', '1', '四川,泸州市,江阳区', null, null, '510502', 'j', 'jiangyangqu', 'jyq');
INSERT INTO `yc_city` VALUES ('2308', '纳溪区', '2306', '1', '四川,泸州市,纳溪区', null, null, '510503', 'n', 'naxiqu', 'nxq');
INSERT INTO `yc_city` VALUES ('2309', '龙马潭区', '2306', '1', '四川,泸州市,龙马潭区', null, null, '510504', 'l', 'longmatanqu', 'lmtq');
INSERT INTO `yc_city` VALUES ('2310', '泸县', '2306', '1', '四川,泸州市,泸县', null, null, '510521', 'l', 'luxian', 'x');
INSERT INTO `yc_city` VALUES ('2311', '合江县', '2306', '1', '四川,泸州市,合江县', null, null, '510522', 'h', 'hejiangxian', 'hjx');
INSERT INTO `yc_city` VALUES ('2312', '叙永县', '2306', '1', '四川,泸州市,叙永县', null, null, '510524', 'x', 'xuyongxian', 'xyx');
INSERT INTO `yc_city` VALUES ('2313', '古蔺县', '2306', '1', '四川,泸州市,古蔺县', null, null, '510525', 'g', 'gulinxian', 'gx');
INSERT INTO `yc_city` VALUES ('2314', '德阳市', '2272', '1', '四川,德阳市', null, null, '510600', 'd', 'deyangshi', 'dys');
INSERT INTO `yc_city` VALUES ('2315', '旌阳区', '2314', '1', '四川,德阳市,旌阳区', null, null, '510603', 'j', 'jingyangqu', 'yq');
INSERT INTO `yc_city` VALUES ('2316', '中江县', '2314', '1', '四川,德阳市,中江县', null, null, '510623', 'z', 'zhongjiangxian', 'zjx');
INSERT INTO `yc_city` VALUES ('2317', '罗江县', '2314', '1', '四川,德阳市,罗江县', null, null, '510626', 'l', 'luojiangxian', 'ljx');
INSERT INTO `yc_city` VALUES ('2318', '广汉市', '2314', '1', '四川,德阳市,广汉市', null, null, '510681', 'g', 'guanghanshi', 'ghs');
INSERT INTO `yc_city` VALUES ('2319', '什邡市', '2314', '1', '四川,德阳市,什邡市', null, null, '510682', 's', 'shifangshi', 'ss');
INSERT INTO `yc_city` VALUES ('2320', '绵竹市', '2314', '1', '四川,德阳市,绵竹市', null, null, '510683', 'm', 'mianzhushi', 'mzs');
INSERT INTO `yc_city` VALUES ('2321', '绵阳市', '2272', '1', '四川,绵阳市', null, null, '510700', 'm', 'mianyangshi', 'mys');
INSERT INTO `yc_city` VALUES ('2322', '涪城区', '2321', '1', '四川,绵阳市,涪城区', null, null, '510703', 'f', 'fuchengqu', 'fcq');
INSERT INTO `yc_city` VALUES ('2323', '游仙区', '2321', '1', '四川,绵阳市,游仙区', null, null, '510704', 'y', 'youxianqu', 'yxq');
INSERT INTO `yc_city` VALUES ('2324', '三台县', '2321', '1', '四川,绵阳市,三台县', null, null, '510722', 's', 'santaixian', 'stx');
INSERT INTO `yc_city` VALUES ('2325', '盐亭县', '2321', '1', '四川,绵阳市,盐亭县', null, null, '510723', 'y', 'yantingxian', 'ytx');
INSERT INTO `yc_city` VALUES ('2326', '安县', '2321', '1', '四川,绵阳市,安县', null, null, '510724', 'a', 'anxian', 'ax');
INSERT INTO `yc_city` VALUES ('2327', '梓潼县', '2321', '1', '四川,绵阳市,梓潼县', null, null, '510725', 'z', 'zitongxian', 'x');
INSERT INTO `yc_city` VALUES ('2328', '北川羌族自治县', '2321', '1', '四川,绵阳市,北川羌族自治县', null, null, '510726', 'b', 'beichuanqiangzuzizhixian', 'bcqzzzx');
INSERT INTO `yc_city` VALUES ('2329', '平武县', '2321', '1', '四川,绵阳市,平武县', null, null, '510727', 'p', 'pingwuxian', 'pwx');
INSERT INTO `yc_city` VALUES ('2330', '江油市', '2321', '1', '四川,绵阳市,江油市', null, null, '510781', 'j', 'jiangyoushi', 'jys');
INSERT INTO `yc_city` VALUES ('2331', '广元市', '2272', '1', '四川,广元市', null, null, '510800', 'g', 'guangyuanshi', 'gys');
INSERT INTO `yc_city` VALUES ('2332', '利州区', '2331', '1', '四川,广元市,利州区', null, null, null, 'l', 'lizhouqu', 'lzq');
INSERT INTO `yc_city` VALUES ('2333', '昭化区', '2331', '1', '四川,广元市,昭化区', null, null, null, 'z', 'zhaohuaqu', 'zhq');
INSERT INTO `yc_city` VALUES ('2334', '朝天区', '2331', '1', '四川,广元市,朝天区', null, null, '510812', 'c', 'chaotianqu', 'ctq');
INSERT INTO `yc_city` VALUES ('2335', '旺苍县', '2331', '1', '四川,广元市,旺苍县', null, null, '510821', 'w', 'wangcangxian', 'wcx');
INSERT INTO `yc_city` VALUES ('2336', '青川县', '2331', '1', '四川,广元市,青川县', null, null, '510822', 'q', 'qingchuanxian', 'qcx');
INSERT INTO `yc_city` VALUES ('2337', '剑阁县', '2331', '1', '四川,广元市,剑阁县', null, null, '510823', 'j', 'jiangexian', 'jgx');
INSERT INTO `yc_city` VALUES ('2338', '苍溪县', '2331', '1', '四川,广元市,苍溪县', null, null, '510824', 'c', 'cangxixian', 'cxx');
INSERT INTO `yc_city` VALUES ('2339', '遂宁市', '2272', '1', '四川,遂宁市', null, null, '510900', 's', 'suiningshi', 'sns');
INSERT INTO `yc_city` VALUES ('2340', '船山区', '2339', '1', '四川,遂宁市,船山区', null, null, '510903', 'c', 'chuanshanqu', 'csq');
INSERT INTO `yc_city` VALUES ('2341', '安居区', '2339', '1', '四川,遂宁市,安居区', null, null, '510904', 'a', 'anjuqu', 'ajq');
INSERT INTO `yc_city` VALUES ('2342', '蓬溪县', '2339', '1', '四川,遂宁市,蓬溪县', null, null, '510921', 'p', 'pengxixian', 'pxx');
INSERT INTO `yc_city` VALUES ('2343', '射洪县', '2339', '1', '四川,遂宁市,射洪县', null, null, '510922', 's', 'shehongxian', 'shx');
INSERT INTO `yc_city` VALUES ('2344', '大英县', '2339', '1', '四川,遂宁市,大英县', null, null, '510923', 'd', 'dayingxian', 'dyx');
INSERT INTO `yc_city` VALUES ('2345', '内江市', '2272', '1', '四川,内江市', null, null, '511000', 'n', 'neijiangshi', 'njs');
INSERT INTO `yc_city` VALUES ('2346', '市中区', '2345', '1', '四川,内江市,市中区', null, null, '511002', 's', 'shizhongqu', 'szq');
INSERT INTO `yc_city` VALUES ('2347', '东兴区', '2345', '1', '四川,内江市,东兴区', null, null, '511011', 'd', 'dongxingqu', 'dxq');
INSERT INTO `yc_city` VALUES ('2348', '威远县', '2345', '1', '四川,内江市,威远县', null, null, '511024', 'w', 'weiyuanxian', 'wyx');
INSERT INTO `yc_city` VALUES ('2349', '资中县', '2345', '1', '四川,内江市,资中县', null, null, '511025', 'z', 'zizhongxian', 'zzx');
INSERT INTO `yc_city` VALUES ('2350', '隆昌县', '2345', '1', '四川,内江市,隆昌县', null, null, '511028', 'l', 'longchangxian', 'lcx');
INSERT INTO `yc_city` VALUES ('2351', '市中区', '2345', '1', '四川,内江市,市中区', null, null, null, 's', 'shizhongqu', 'szq');
INSERT INTO `yc_city` VALUES ('2352', '沙湾区', '2345', '1', '四川,内江市,沙湾区', null, null, null, 's', 'shawanqu', 'swq');
INSERT INTO `yc_city` VALUES ('2353', '五通桥区', '2345', '1', '四川,内江市,五通桥区', null, null, null, 'w', 'wutongqiaoqu', 'wtqq');
INSERT INTO `yc_city` VALUES ('2354', '金口河区', '2345', '1', '四川,内江市,金口河区', null, null, null, 'j', 'jinkouhequ', 'jkhq');
INSERT INTO `yc_city` VALUES ('2355', '犍为县', '2345', '1', '四川,内江市,犍为县', null, null, null, 'q', 'qianweixian', 'wx');
INSERT INTO `yc_city` VALUES ('2356', '井研县', '2345', '1', '四川,内江市,井研县', null, null, null, 'j', 'jingyanxian', 'jyx');
INSERT INTO `yc_city` VALUES ('2357', '夹江县', '2345', '1', '四川,内江市,夹江县', null, null, null, 'j', 'jiajiangxian', 'jjx');
INSERT INTO `yc_city` VALUES ('2358', '沐川县', '2345', '1', '四川,内江市,沐川县', null, null, null, 'm', 'muchuanxian', 'cx');
INSERT INTO `yc_city` VALUES ('2359', '峨边彝族自治县', '2345', '1', '四川,内江市,峨边彝族自治县', null, null, null, 'e', 'ebianyizuzizhixian', 'ebyzzzx');
INSERT INTO `yc_city` VALUES ('2360', '马边彝族自治县', '2345', '1', '四川,内江市,马边彝族自治县', null, null, null, 'm', 'mabianyizuzizhixian', 'mbyzzzx');
INSERT INTO `yc_city` VALUES ('2361', '峨眉山市', '2345', '1', '四川,内江市,峨眉山市', null, null, null, 'e', 'emeishanshi', 'emss');
INSERT INTO `yc_city` VALUES ('2362', '南充市', '2272', '1', '四川,南充市', null, null, '511300', 'n', 'nanchongshi', 'ncs');
INSERT INTO `yc_city` VALUES ('2363', '顺庆区', '2362', '1', '四川,南充市,顺庆区', null, null, '511302', 's', 'shunqingqu', 'sqq');
INSERT INTO `yc_city` VALUES ('2364', '高坪区', '2362', '1', '四川,南充市,高坪区', null, null, '511303', 'g', 'gaopingqu', 'gpq');
INSERT INTO `yc_city` VALUES ('2365', '嘉陵区', '2362', '1', '四川,南充市,嘉陵区', null, null, '511304', 'j', 'jialingqu', 'jlq');
INSERT INTO `yc_city` VALUES ('2366', '南部县', '2362', '1', '四川,南充市,南部县', null, null, '511321', 'n', 'nanbuxian', 'nbx');
INSERT INTO `yc_city` VALUES ('2367', '营山县', '2362', '1', '四川,南充市,营山县', null, null, '511322', 'y', 'yingshanxian', 'ysx');
INSERT INTO `yc_city` VALUES ('2368', '蓬安县', '2362', '1', '四川,南充市,蓬安县', null, null, '511323', 'p', 'penganxian', 'pax');
INSERT INTO `yc_city` VALUES ('2369', '仪陇县', '2362', '1', '四川,南充市,仪陇县', null, null, '511324', 'y', 'yilongxian', 'ylx');
INSERT INTO `yc_city` VALUES ('2370', '西充县', '2362', '1', '四川,南充市,西充县', null, null, '511325', 'x', 'xichongxian', 'xcx');
INSERT INTO `yc_city` VALUES ('2371', '阆中市', '2362', '1', '四川,南充市,阆中市', null, null, '511381', 'l', 'langzhongshi', 'zs');
INSERT INTO `yc_city` VALUES ('2372', '眉山市', '2272', '1', '四川,眉山市', null, null, '511400', 'm', 'meishanshi', 'mss');
INSERT INTO `yc_city` VALUES ('2373', '东坡区', '2372', '1', '四川,眉山市,东坡区', null, null, '511402', 'd', 'dongpoqu', 'dpq');
INSERT INTO `yc_city` VALUES ('2374', '仁寿县', '2372', '1', '四川,眉山市,仁寿县', null, null, '511421', 'r', 'renshouxian', 'rsx');
INSERT INTO `yc_city` VALUES ('2375', '彭山县', '2372', '1', '四川,眉山市,彭山县', null, null, '511422', 'p', 'pengshanxian', 'psx');
INSERT INTO `yc_city` VALUES ('2376', '洪雅县', '2372', '1', '四川,眉山市,洪雅县', null, null, '511423', 'h', 'hongyaxian', 'hyx');
INSERT INTO `yc_city` VALUES ('2377', '丹棱县', '2372', '1', '四川,眉山市,丹棱县', null, null, '511424', 'd', 'danlengxian', 'dlx');
INSERT INTO `yc_city` VALUES ('2378', '青神县', '2372', '1', '四川,眉山市,青神县', null, null, '511425', 'q', 'qingshenxian', 'qsx');
INSERT INTO `yc_city` VALUES ('2379', '宜宾市', '2272', '1', '四川,宜宾市', null, null, '511500', 'y', 'yibinshi', 'ybs');
INSERT INTO `yc_city` VALUES ('2380', '翠屏区', '2379', '1', '四川,宜宾市,翠屏区', null, null, '511502', 'c', 'cuipingqu', 'cpq');
INSERT INTO `yc_city` VALUES ('2381', '南溪区', '2379', '1', '四川,宜宾市,南溪区', null, null, null, 'n', 'nanxiqu', 'nxq');
INSERT INTO `yc_city` VALUES ('2382', '宜宾县', '2379', '1', '四川,宜宾市,宜宾县', null, null, '511521', 'y', 'yibinxian', 'ybx');
INSERT INTO `yc_city` VALUES ('2383', '江安县', '2379', '1', '四川,宜宾市,江安县', null, null, '511523', 'j', 'jianganxian', 'jax');
INSERT INTO `yc_city` VALUES ('2384', '长宁县', '2379', '1', '四川,宜宾市,长宁县', null, null, '511524', 'c', 'changningxian', 'cnx');
INSERT INTO `yc_city` VALUES ('2385', '高县', '2379', '1', '四川,宜宾市,高县', null, null, '511525', 'g', 'gaoxian', 'gx');
INSERT INTO `yc_city` VALUES ('2386', '珙县', '2379', '1', '四川,宜宾市,珙县', null, null, '511526', 'g', 'gongxian', 'x');
INSERT INTO `yc_city` VALUES ('2387', '筠连县', '2379', '1', '四川,宜宾市,筠连县', null, null, '511527', 'j', 'junlianxian', 'lx');
INSERT INTO `yc_city` VALUES ('2388', '兴文县', '2379', '1', '四川,宜宾市,兴文县', null, null, '511528', 'x', 'xingwenxian', 'xwx');
INSERT INTO `yc_city` VALUES ('2389', '屏山县', '2379', '1', '四川,宜宾市,屏山县', null, null, '511529', 'p', 'pingshanxian', 'psx');
INSERT INTO `yc_city` VALUES ('2390', '广安市', '2272', '1', '四川,广安市', null, null, '511600', 'g', 'guanganshi', 'gas');
INSERT INTO `yc_city` VALUES ('2391', '广安区', '2390', '1', '四川,广安市,广安区', null, null, '511602', 'g', 'guanganqu', 'gaq');
INSERT INTO `yc_city` VALUES ('2392', '前锋区', '2390', '1', '四川,广安市,前锋区', null, null, null, 'q', 'qianfengqu', 'qfq');
INSERT INTO `yc_city` VALUES ('2393', '岳池县', '2390', '1', '四川,广安市,岳池县', null, null, '511621', 'y', 'yuechixian', 'ycx');
INSERT INTO `yc_city` VALUES ('2394', '武胜县', '2390', '1', '四川,广安市,武胜县', null, null, '511622', 'w', 'wushengxian', 'wsx');
INSERT INTO `yc_city` VALUES ('2395', '邻水县', '2390', '1', '四川,广安市,邻水县', null, null, '511623', 'l', 'linshuixian', 'lsx');
INSERT INTO `yc_city` VALUES ('2396', '华蓥市', '2390', '1', '四川,广安市,华蓥市', null, null, '511681', 'h', 'huayingshi', 'hs');
INSERT INTO `yc_city` VALUES ('2397', '达州市', '2272', '1', '四川,达州市', null, null, '511700', 'd', 'dazhoushi', 'dzs');
INSERT INTO `yc_city` VALUES ('2398', '通川区', '2397', '1', '四川,达州市,通川区', null, null, '511702', 't', 'tongchuanqu', 'tcq');
INSERT INTO `yc_city` VALUES ('2399', '达川区', '2397', '1', '四川,达州市,达川区', null, null, null, 'd', 'dachuanqu', 'dcq');
INSERT INTO `yc_city` VALUES ('2400', '宣汉县', '2397', '1', '四川,达州市,宣汉县', null, null, '511722', 'x', 'xuanhanxian', 'xhx');
INSERT INTO `yc_city` VALUES ('2401', '开江县', '2397', '1', '四川,达州市,开江县', null, null, '511723', 'k', 'kaijiangxian', 'kjx');
INSERT INTO `yc_city` VALUES ('2402', '大竹县', '2397', '1', '四川,达州市,大竹县', null, null, '511724', 'd', 'dazhuxian', 'dzx');
INSERT INTO `yc_city` VALUES ('2403', '渠县', '2397', '1', '四川,达州市,渠县', null, null, '511725', 'q', 'quxian', 'qx');
INSERT INTO `yc_city` VALUES ('2404', '万源市', '2397', '1', '四川,达州市,万源市', null, null, '511781', 'w', 'wanyuanshi', 'wys');
INSERT INTO `yc_city` VALUES ('2405', '雅安市', '2272', '1', '四川,雅安市', null, null, '511800', 'y', 'yaanshi', 'yas');
INSERT INTO `yc_city` VALUES ('2406', '雨城区', '2405', '1', '四川,雅安市,雨城区', null, null, '511802', 'y', 'yuchengqu', 'ycq');
INSERT INTO `yc_city` VALUES ('2407', '名山区', '2405', '1', '四川,雅安市,名山区', null, null, null, 'm', 'mingshanqu', 'msq');
INSERT INTO `yc_city` VALUES ('2408', '荥经县', '2405', '1', '四川,雅安市,荥经县', null, null, '511822', 'y', 'yingjingxian', 'jx');
INSERT INTO `yc_city` VALUES ('2409', '汉源县', '2405', '1', '四川,雅安市,汉源县', null, null, '511823', 'h', 'hanyuanxian', 'hyx');
INSERT INTO `yc_city` VALUES ('2410', '石棉县', '2405', '1', '四川,雅安市,石棉县', null, null, '511824', 's', 'shimianxian', 'smx');
INSERT INTO `yc_city` VALUES ('2411', '天全县', '2405', '1', '四川,雅安市,天全县', null, null, '511825', 't', 'tianquanxian', 'tqx');
INSERT INTO `yc_city` VALUES ('2412', '芦山县', '2405', '1', '四川,雅安市,芦山县', null, null, '511826', 'l', 'lushanxian', 'lsx');
INSERT INTO `yc_city` VALUES ('2413', '宝兴县', '2405', '1', '四川,雅安市,宝兴县', null, null, '511827', 'b', 'baoxingxian', 'bxx');
INSERT INTO `yc_city` VALUES ('2414', '巴中市', '2272', '1', '四川,巴中市', null, null, '511900', 'b', 'bazhongshi', 'bzs');
INSERT INTO `yc_city` VALUES ('2415', '巴州区', '2414', '1', '四川,巴中市,巴州区', null, null, '511902', 'b', 'bazhouqu', 'bzq');
INSERT INTO `yc_city` VALUES ('2416', '恩阳区', '2414', '1', '四川,巴中市,恩阳区', null, null, null, 'e', 'enyangqu', 'eyq');
INSERT INTO `yc_city` VALUES ('2417', '通江县', '2414', '1', '四川,巴中市,通江县', null, null, '511921', 't', 'tongjiangxian', 'tjx');
INSERT INTO `yc_city` VALUES ('2418', '南江县', '2414', '1', '四川,巴中市,南江县', null, null, '511922', 'n', 'nanjiangxian', 'njx');
INSERT INTO `yc_city` VALUES ('2419', '平昌县', '2414', '1', '四川,巴中市,平昌县', null, null, '511923', 'p', 'pingchangxian', 'pcx');
INSERT INTO `yc_city` VALUES ('2420', '资阳市', '2272', '1', '四川,资阳市', null, null, '512000', 'z', 'ziyangshi', 'zys');
INSERT INTO `yc_city` VALUES ('2421', '雁江区', '2420', '1', '四川,资阳市,雁江区', null, null, '512002', 'y', 'yanjiangqu', 'yjq');
INSERT INTO `yc_city` VALUES ('2422', '安岳县', '2420', '1', '四川,资阳市,安岳县', null, null, '512021', 'a', 'anyuexian', 'ayx');
INSERT INTO `yc_city` VALUES ('2423', '乐至县', '2420', '1', '四川,资阳市,乐至县', null, null, '512022', 'l', 'lezhixian', 'lzx');
INSERT INTO `yc_city` VALUES ('2424', '简阳市', '2273', '1', '四川,成都市,简阳市', null, null, '512081', 'j', 'jianyangshi', 'jys');
INSERT INTO `yc_city` VALUES ('2425', '阿坝藏族羌族自治州', '2272', '1', '四川,阿坝藏族羌族自治州', null, null, '513200', 'a', 'abazangzuqiangzuzizhizhou', 'abczqzzzz');
INSERT INTO `yc_city` VALUES ('2426', '汶川县', '2425', '1', '四川,阿坝藏族羌族自治州,汶川县', null, null, '513221', 'w', 'wenchuanxian', 'cx');
INSERT INTO `yc_city` VALUES ('2427', '理县', '2425', '1', '四川,阿坝藏族羌族自治州,理县', null, null, '513222', 'l', 'lixian', 'lx');
INSERT INTO `yc_city` VALUES ('2428', '茂县', '2425', '1', '四川,阿坝藏族羌族自治州,茂县', null, null, '513223', 'm', 'maoxian', 'mx');
INSERT INTO `yc_city` VALUES ('2429', '松潘县', '2425', '1', '四川,阿坝藏族羌族自治州,松潘县', null, null, '513224', 's', 'songpanxian', 'spx');
INSERT INTO `yc_city` VALUES ('2430', '九寨沟县', '2425', '1', '四川,阿坝藏族羌族自治州,九寨沟县', null, null, '513225', 'j', 'jiuzhaigouxian', 'jzgx');
INSERT INTO `yc_city` VALUES ('2431', '金川县', '2425', '1', '四川,阿坝藏族羌族自治州,金川县', null, null, '513226', 'j', 'jinchuanxian', 'jcx');
INSERT INTO `yc_city` VALUES ('2432', '小金县', '2425', '1', '四川,阿坝藏族羌族自治州,小金县', null, null, '513227', 'x', 'xiaojinxian', 'xjx');
INSERT INTO `yc_city` VALUES ('2433', '黑水县', '2425', '1', '四川,阿坝藏族羌族自治州,黑水县', null, null, '513228', 'h', 'heishuixian', 'hsx');
INSERT INTO `yc_city` VALUES ('2434', '马尔康县', '2425', '1', '四川,阿坝藏族羌族自治州,马尔康县', null, null, '513229', 'm', 'maerkangxian', 'mekx');
INSERT INTO `yc_city` VALUES ('2435', '壤塘县', '2425', '1', '四川,阿坝藏族羌族自治州,壤塘县', null, null, '513230', 'r', 'rangtangxian', 'rtx');
INSERT INTO `yc_city` VALUES ('2436', '阿坝县', '2425', '1', '四川,阿坝藏族羌族自治州,阿坝县', null, null, '513231', 'a', 'abaxian', 'abx');
INSERT INTO `yc_city` VALUES ('2437', '若尔盖县', '2425', '1', '四川,阿坝藏族羌族自治州,若尔盖县', null, null, '513232', 'r', 'ruoergaixian', 'regx');
INSERT INTO `yc_city` VALUES ('2438', '红原县', '2425', '1', '四川,阿坝藏族羌族自治州,红原县', null, null, '513233', 'h', 'hongyuanxian', 'hyx');
INSERT INTO `yc_city` VALUES ('2439', '甘孜藏族自治州', '2272', '1', '四川,甘孜藏族自治州', null, null, '513300', 'g', 'ganzizangzuzizhizhou', 'gzczzzz');
INSERT INTO `yc_city` VALUES ('2440', '康定县', '2439', '1', '四川,甘孜藏族自治州,康定县', null, null, '513321', 'k', 'kangdingxian', 'kdx');
INSERT INTO `yc_city` VALUES ('2441', '泸定县', '2439', '1', '四川,甘孜藏族自治州,泸定县', null, null, '513322', 'l', 'ludingxian', 'dx');
INSERT INTO `yc_city` VALUES ('2442', '丹巴县', '2439', '1', '四川,甘孜藏族自治州,丹巴县', null, null, '513323', 'd', 'danbaxian', 'dbx');
INSERT INTO `yc_city` VALUES ('2443', '九龙县', '2439', '1', '四川,甘孜藏族自治州,九龙县', null, null, '513324', 'j', 'jiulongxian', 'jlx');
INSERT INTO `yc_city` VALUES ('2444', '雅江县', '2439', '1', '四川,甘孜藏族自治州,雅江县', null, null, '513325', 'y', 'yajiangxian', 'yjx');
INSERT INTO `yc_city` VALUES ('2445', '道孚县', '2439', '1', '四川,甘孜藏族自治州,道孚县', null, null, '513326', 'd', 'daofuxian', 'dx');
INSERT INTO `yc_city` VALUES ('2446', '炉霍县', '2439', '1', '四川,甘孜藏族自治州,炉霍县', null, null, '513327', 'l', 'luhuoxian', 'lhx');
INSERT INTO `yc_city` VALUES ('2447', '甘孜县', '2439', '1', '四川,甘孜藏族自治州,甘孜县', null, null, '513328', 'g', 'ganzixian', 'gzx');
INSERT INTO `yc_city` VALUES ('2448', '新龙县', '2439', '1', '四川,甘孜藏族自治州,新龙县', null, null, '513329', 'x', 'xinlongxian', 'xlx');
INSERT INTO `yc_city` VALUES ('2449', '德格县', '2439', '1', '四川,甘孜藏族自治州,德格县', null, null, '513330', 'd', 'degexian', 'dgx');
INSERT INTO `yc_city` VALUES ('2450', '白玉县', '2439', '1', '四川,甘孜藏族自治州,白玉县', null, null, '513331', 'b', 'baiyuxian', 'byx');
INSERT INTO `yc_city` VALUES ('2451', '石渠县', '2439', '1', '四川,甘孜藏族自治州,石渠县', null, null, '513332', 's', 'shiquxian', 'sqx');
INSERT INTO `yc_city` VALUES ('2452', '色达县', '2439', '1', '四川,甘孜藏族自治州,色达县', null, null, '513333', 's', 'shaidaxian', 'sdx');
INSERT INTO `yc_city` VALUES ('2453', '理塘县', '2439', '1', '四川,甘孜藏族自治州,理塘县', null, null, '513334', 'l', 'litangxian', 'ltx');
INSERT INTO `yc_city` VALUES ('2454', '巴塘县', '2439', '1', '四川,甘孜藏族自治州,巴塘县', null, null, '513335', 'b', 'batangxian', 'btx');
INSERT INTO `yc_city` VALUES ('2455', '乡城县', '2439', '1', '四川,甘孜藏族自治州,乡城县', null, null, '513336', 'x', 'xiangchengxian', 'xcx');
INSERT INTO `yc_city` VALUES ('2456', '稻城县', '2439', '1', '四川,甘孜藏族自治州,稻城县', null, null, '513337', 'd', 'daochengxian', 'dcx');
INSERT INTO `yc_city` VALUES ('2457', '得荣县', '2439', '1', '四川,甘孜藏族自治州,得荣县', null, null, '513338', 'd', 'derongxian', 'drx');
INSERT INTO `yc_city` VALUES ('2458', '凉山彝族自治州', '2272', '1', '四川,凉山彝族自治州', null, null, '513400', 'l', 'liangshanyizuzizhizhou', 'lsyzzzz');
INSERT INTO `yc_city` VALUES ('2459', '西昌市', '2458', '1', '四川,凉山彝族自治州,西昌市', null, null, '513401', 'x', 'xichangshi', 'xcs');
INSERT INTO `yc_city` VALUES ('2460', '木里藏族自治县', '2458', '1', '四川,凉山彝族自治州,木里藏族自治县', null, null, '513422', 'm', 'mulizangzuzizhixian', 'mlczzzx');
INSERT INTO `yc_city` VALUES ('2461', '盐源县', '2458', '1', '四川,凉山彝族自治州,盐源县', null, null, '513423', 'y', 'yanyuanxian', 'yyx');
INSERT INTO `yc_city` VALUES ('2462', '德昌县', '2458', '1', '四川,凉山彝族自治州,德昌县', null, null, '513424', 'd', 'dechangxian', 'dcx');
INSERT INTO `yc_city` VALUES ('2463', '会理县', '2458', '1', '四川,凉山彝族自治州,会理县', null, null, '513425', 'h', 'huilixian', 'hlx');
INSERT INTO `yc_city` VALUES ('2464', '会东县', '2458', '1', '四川,凉山彝族自治州,会东县', null, null, '513426', 'h', 'huidongxian', 'hdx');
INSERT INTO `yc_city` VALUES ('2465', '宁南县', '2458', '1', '四川,凉山彝族自治州,宁南县', null, null, '513427', 'n', 'ningnanxian', 'nnx');
INSERT INTO `yc_city` VALUES ('2466', '普格县', '2458', '1', '四川,凉山彝族自治州,普格县', null, null, '513428', 'p', 'pugexian', 'pgx');
INSERT INTO `yc_city` VALUES ('2467', '布拖县', '2458', '1', '四川,凉山彝族自治州,布拖县', null, null, '513429', 'b', 'butuoxian', 'btx');
INSERT INTO `yc_city` VALUES ('2468', '金阳县', '2458', '1', '四川,凉山彝族自治州,金阳县', null, null, '513430', 'j', 'jinyangxian', 'jyx');
INSERT INTO `yc_city` VALUES ('2469', '昭觉县', '2458', '1', '四川,凉山彝族自治州,昭觉县', null, null, '513431', 'z', 'zhaojuexian', 'zjx');
INSERT INTO `yc_city` VALUES ('2470', '喜德县', '2458', '1', '四川,凉山彝族自治州,喜德县', null, null, '513432', 'x', 'xidexian', 'xdx');
INSERT INTO `yc_city` VALUES ('2471', '冕宁县', '2458', '1', '四川,凉山彝族自治州,冕宁县', null, null, '513433', 'm', 'mianningxian', 'mnx');
INSERT INTO `yc_city` VALUES ('2472', '越西县', '2458', '1', '四川,凉山彝族自治州,越西县', null, null, '513434', 'y', 'yuexixian', 'yxx');
INSERT INTO `yc_city` VALUES ('2473', '甘洛县', '2458', '1', '四川,凉山彝族自治州,甘洛县', null, null, '513435', 'g', 'ganluoxian', 'glx');
INSERT INTO `yc_city` VALUES ('2474', '美姑县', '2458', '1', '四川,凉山彝族自治州,美姑县', null, null, '513436', 'm', 'meiguxian', 'mgx');
INSERT INTO `yc_city` VALUES ('2475', '雷波县', '2458', '1', '四川,凉山彝族自治州,雷波县', null, null, '513437', 'l', 'leiboxian', 'lbx');
INSERT INTO `yc_city` VALUES ('2476', '贵州', '1', '1', '贵州', null, null, '520000', 'g', 'guizhou', 'gz');
INSERT INTO `yc_city` VALUES ('2477', '贵阳市', '2476', '1', '贵州,贵阳市', null, null, '520100', 'g', 'guiyangshi', 'gys');
INSERT INTO `yc_city` VALUES ('2478', '南明区', '2477', '1', '贵州,贵阳市,南明区', null, null, '520102', 'n', 'nanmingqu', 'nmq');
INSERT INTO `yc_city` VALUES ('2479', '云岩区', '2477', '1', '贵州,贵阳市,云岩区', null, null, '520103', 'y', 'yunyanqu', 'yyq');
INSERT INTO `yc_city` VALUES ('2480', '花溪区', '2477', '1', '贵州,贵阳市,花溪区', null, null, '520111', 'h', 'huaxiqu', 'hxq');
INSERT INTO `yc_city` VALUES ('2481', '乌当区', '2477', '1', '贵州,贵阳市,乌当区', null, null, '520112', 'w', 'wudangqu', 'wdq');
INSERT INTO `yc_city` VALUES ('2482', '白云区', '2477', '1', '贵州,贵阳市,白云区', null, null, '520113', 'b', 'baiyunqu', 'byq');
INSERT INTO `yc_city` VALUES ('2483', '观山湖区', '2477', '1', '贵州,贵阳市,观山湖区', null, null, null, 'g', 'guanshanhuqu', 'gshq');
INSERT INTO `yc_city` VALUES ('2484', '开阳县', '2477', '1', '贵州,贵阳市,开阳县', null, null, '520121', 'k', 'kaiyangxian', 'kyx');
INSERT INTO `yc_city` VALUES ('2485', '息烽县', '2477', '1', '贵州,贵阳市,息烽县', null, null, '520122', 'x', 'xifengxian', 'xfx');
INSERT INTO `yc_city` VALUES ('2486', '修文县', '2477', '1', '贵州,贵阳市,修文县', null, null, '520123', 'x', 'xiuwenxian', 'xwx');
INSERT INTO `yc_city` VALUES ('2487', '清镇市', '2477', '1', '贵州,贵阳市,清镇市', null, null, '520181', 'q', 'qingzhenshi', 'qzs');
INSERT INTO `yc_city` VALUES ('2488', '六盘水市', '2476', '1', '贵州,六盘水市', null, null, '520200', 'l', 'liupanshuishi', 'lpss');
INSERT INTO `yc_city` VALUES ('2489', '钟山区', '2488', '1', '贵州,六盘水市,钟山区', null, null, '520201', 'z', 'zhongshanqu', 'zsq');
INSERT INTO `yc_city` VALUES ('2490', '六枝特区', '2488', '1', '贵州,六盘水市,六枝特区', null, null, '520203', 'l', 'luzhitequ', 'lztq');
INSERT INTO `yc_city` VALUES ('2491', '水城县', '2488', '1', '贵州,六盘水市,水城县', null, null, '520221', 's', 'shuichengxian', 'scx');
INSERT INTO `yc_city` VALUES ('2492', '盘县', '2488', '1', '贵州,六盘水市,盘县', null, null, '520222', 'p', 'panxian', 'px');
INSERT INTO `yc_city` VALUES ('2493', '遵义市', '2476', '1', '贵州,遵义市', null, null, '520300', 'z', 'zunyishi', 'zys');
INSERT INTO `yc_city` VALUES ('2494', '红花岗区', '2493', '1', '贵州,遵义市,红花岗区', null, null, '520302', 'h', 'honghuagangqu', 'hhgq');
INSERT INTO `yc_city` VALUES ('2495', '汇川区', '2493', '1', '贵州,遵义市,汇川区', null, null, '520303', 'h', 'huichuanqu', 'hcq');
INSERT INTO `yc_city` VALUES ('2496', '遵义县', '2493', '1', '贵州,遵义市,遵义县', null, null, '520321', 'z', 'zunyixian', 'zyx');
INSERT INTO `yc_city` VALUES ('2497', '桐梓县', '2493', '1', '贵州,遵义市,桐梓县', null, null, '520322', 't', 'tongzixian', 'tx');
INSERT INTO `yc_city` VALUES ('2498', '绥阳县', '2493', '1', '贵州,遵义市,绥阳县', null, null, '520323', 's', 'suiyangxian', 'syx');
INSERT INTO `yc_city` VALUES ('2499', '正安县', '2493', '1', '贵州,遵义市,正安县', null, null, '520324', 'z', 'zhenganxian', 'zax');
INSERT INTO `yc_city` VALUES ('2500', '道真仡佬族苗族自治县', '2493', '1', '贵州,遵义市,道真仡佬族苗族自治县', null, null, '520325', 'd', 'daozhengelaozumiaozuzizhixian', 'dzlzmzzzx');
INSERT INTO `yc_city` VALUES ('2501', '务川仡佬族苗族自治县', '2493', '1', '贵州,遵义市,务川仡佬族苗族自治县', null, null, '520326', 'w', 'wuchuangelaozumiaozuzizhixian', 'wclzmzzzx');
INSERT INTO `yc_city` VALUES ('2502', '凤冈县', '2493', '1', '贵州,遵义市,凤冈县', null, null, '520327', 'f', 'fenggangxian', 'fgx');
INSERT INTO `yc_city` VALUES ('2503', '湄潭县', '2493', '1', '贵州,遵义市,湄潭县', null, null, '520328', 'm', 'meitanxian', 'tx');
INSERT INTO `yc_city` VALUES ('2504', '余庆县', '2493', '1', '贵州,遵义市,余庆县', null, null, '520329', 'y', 'yuqingxian', 'yqx');
INSERT INTO `yc_city` VALUES ('2505', '习水县', '2493', '1', '贵州,遵义市,习水县', null, null, '520330', 'x', 'xishuixian', 'xsx');
INSERT INTO `yc_city` VALUES ('2506', '赤水市', '2493', '1', '贵州,遵义市,赤水市', null, null, '520381', 'c', 'chishuishi', 'css');
INSERT INTO `yc_city` VALUES ('2507', '仁怀市', '2493', '1', '贵州,遵义市,仁怀市', null, null, '520382', 'r', 'renhuaishi', 'rhs');
INSERT INTO `yc_city` VALUES ('2508', '安顺市', '2476', '1', '贵州,安顺市', null, null, '520400', 'a', 'anshunshi', 'ass');
INSERT INTO `yc_city` VALUES ('2509', '西秀区', '2508', '1', '贵州,安顺市,西秀区', null, null, '520402', 'x', 'xixiuqu', 'xxq');
INSERT INTO `yc_city` VALUES ('2510', '平坝县', '2508', '1', '贵州,安顺市,平坝县', null, null, '520421', 'p', 'pingbaxian', 'pbx');
INSERT INTO `yc_city` VALUES ('2511', '普定县', '2508', '1', '贵州,安顺市,普定县', null, null, '520422', 'p', 'pudingxian', 'pdx');
INSERT INTO `yc_city` VALUES ('2512', '镇宁布依族苗族自治县', '2508', '1', '贵州,安顺市,镇宁布依族苗族自治县', null, null, '520423', 'z', 'zhenningbuyizumiaozuzizhixian', 'znbyzmzzzx');
INSERT INTO `yc_city` VALUES ('2513', '关岭布依族苗族自治县', '2508', '1', '贵州,安顺市,关岭布依族苗族自治县', null, null, '520424', 'g', 'guanlingbuyizumiaozuzizhixian', 'glbyzmzzzx');
INSERT INTO `yc_city` VALUES ('2514', '紫云苗族布依族自治县', '2508', '1', '贵州,安顺市,紫云苗族布依族自治县', null, null, '520425', 'z', 'ziyunmiaozubuyizuzizhixian', 'zymzbyzzzx');
INSERT INTO `yc_city` VALUES ('2515', '毕节市', '2476', '1', '贵州,毕节市', null, null, '522400', 'b', 'bijieshi', 'bjs');
INSERT INTO `yc_city` VALUES ('2516', '七星关区', '2515', '1', '贵州,毕节市,七星关区', null, null, '522401', 'q', 'qixingguanqu', 'qxgq');
INSERT INTO `yc_city` VALUES ('2517', '大方县', '2515', '1', '贵州,毕节市,大方县', null, null, '522422', 'd', 'dafangxian', 'dfx');
INSERT INTO `yc_city` VALUES ('2518', '黔西县', '2515', '1', '贵州,毕节市,黔西县', null, null, '522423', 'q', 'qianxixian', 'qxx');
INSERT INTO `yc_city` VALUES ('2519', '金沙县', '2515', '1', '贵州,毕节市,金沙县', null, null, '522424', 'j', 'jinshaxian', 'jsx');
INSERT INTO `yc_city` VALUES ('2520', '织金县', '2515', '1', '贵州,毕节市,织金县', null, null, '522425', 'z', 'zhijinxian', 'zjx');
INSERT INTO `yc_city` VALUES ('2521', '纳雍县', '2515', '1', '贵州,毕节市,纳雍县', null, null, '522426', 'n', 'nayongxian', 'nyx');
INSERT INTO `yc_city` VALUES ('2522', '威宁彝族回族苗族自治县', '2515', '1', '贵州,毕节市,威宁彝族回族苗族自治县', null, null, '522427', 'w', 'weiningyizuhuizumiaozuzizhixian', 'wnyzhzmzzzx');
INSERT INTO `yc_city` VALUES ('2523', '赫章县', '2515', '1', '贵州,毕节市,赫章县', null, null, '522428', 'h', 'hezhangxian', 'hzx');
INSERT INTO `yc_city` VALUES ('2524', '铜仁市', '2476', '1', '贵州,铜仁市', null, null, null, 't', 'tongrenshi', 'trs');
INSERT INTO `yc_city` VALUES ('2525', '碧江区', '2524', '1', '贵州,铜仁市,碧江区', null, null, null, 'b', 'bijiangqu', 'bjq');
INSERT INTO `yc_city` VALUES ('2526', '万山区', '2524', '1', '贵州,铜仁市,万山区', null, null, null, 'w', 'wanshanqu', 'wsq');
INSERT INTO `yc_city` VALUES ('2527', '江口县', '2524', '1', '贵州,铜仁市,江口县', null, null, null, 'j', 'jiangkouxian', 'jkx');
INSERT INTO `yc_city` VALUES ('2528', '玉屏侗族自治县', '2524', '1', '贵州,铜仁市,玉屏侗族自治县', null, null, null, 'y', 'yupingdongzuzizhixian', 'ypdzzzx');
INSERT INTO `yc_city` VALUES ('2529', '石阡县', '2524', '1', '贵州,铜仁市,石阡县', null, null, null, 's', 'shiqianxian', 'sx');
INSERT INTO `yc_city` VALUES ('2530', '思南县', '2524', '1', '贵州,铜仁市,思南县', null, null, null, 's', 'sinanxian', 'snx');
INSERT INTO `yc_city` VALUES ('2531', '印江土家族苗族自治县', '2524', '1', '贵州,铜仁市,印江土家族苗族自治县', null, null, null, 'y', 'yinjiangtujiazumiaozuzizhixian', 'yjtjzmzzzx');
INSERT INTO `yc_city` VALUES ('2532', '德江县', '2524', '1', '贵州,铜仁市,德江县', null, null, null, 'd', 'dejiangxian', 'djx');
INSERT INTO `yc_city` VALUES ('2533', '沿河土家族自治县', '2524', '1', '贵州,铜仁市,沿河土家族自治县', null, null, null, 'y', 'yanhetujiazuzizhixian', 'yhtjzzzx');
INSERT INTO `yc_city` VALUES ('2534', '松桃苗族自治县', '2524', '1', '贵州,铜仁市,松桃苗族自治县', null, null, null, 's', 'songtaomiaozuzizhixian', 'stmzzzx');
INSERT INTO `yc_city` VALUES ('2535', '黔西南布依族苗族自治州', '2476', '1', '贵州,黔西南布依族苗族自治州', null, null, '522300', 'q', 'qianxinanbuyizumiaozuzizhizhou', 'qxnbyzmzzzz');
INSERT INTO `yc_city` VALUES ('2536', '兴义市', '2535', '1', '贵州,黔西南布依族苗族自治州,兴义市', null, null, '522301', 'x', 'xingyishi', 'xys');
INSERT INTO `yc_city` VALUES ('2537', '兴仁县', '2535', '1', '贵州,黔西南布依族苗族自治州,兴仁县', null, null, '522322', 'x', 'xingrenxian', 'xrx');
INSERT INTO `yc_city` VALUES ('2538', '普安县', '2535', '1', '贵州,黔西南布依族苗族自治州,普安县', null, null, '522323', 'p', 'puanxian', 'pax');
INSERT INTO `yc_city` VALUES ('2539', '晴隆县', '2535', '1', '贵州,黔西南布依族苗族自治州,晴隆县', null, null, '522324', 'q', 'qinglongxian', 'qlx');
INSERT INTO `yc_city` VALUES ('2540', '贞丰县', '2535', '1', '贵州,黔西南布依族苗族自治州,贞丰县', null, null, '522325', 'z', 'zhenfengxian', 'zfx');
INSERT INTO `yc_city` VALUES ('2541', '望谟县', '2535', '1', '贵州,黔西南布依族苗族自治州,望谟县', null, null, '522326', 'w', 'wangmoxian', 'wx');
INSERT INTO `yc_city` VALUES ('2542', '册亨县', '2535', '1', '贵州,黔西南布依族苗族自治州,册亨县', null, null, '522327', 'c', 'cehengxian', 'chx');
INSERT INTO `yc_city` VALUES ('2543', '安龙县', '2535', '1', '贵州,黔西南布依族苗族自治州,安龙县', null, null, '522328', 'a', 'anlongxian', 'alx');
INSERT INTO `yc_city` VALUES ('2544', '黔东南苗族侗族自治州', '2476', '1', '贵州,黔东南苗族侗族自治州', null, null, '522600', 'q', 'qiandongnanmiaozudongzuzizhizhou', 'qdnmzdzzzz');
INSERT INTO `yc_city` VALUES ('2545', '凯里市', '2544', '1', '贵州,黔东南苗族侗族自治州,凯里市', null, null, '522601', 'k', 'kailishi', 'kls');
INSERT INTO `yc_city` VALUES ('2546', '黄平县', '2544', '1', '贵州,黔东南苗族侗族自治州,黄平县', null, null, '522622', 'h', 'huangpingxian', 'hpx');
INSERT INTO `yc_city` VALUES ('2547', '施秉县', '2544', '1', '贵州,黔东南苗族侗族自治州,施秉县', null, null, '522623', 's', 'shibingxian', 'sbx');
INSERT INTO `yc_city` VALUES ('2548', '三穗县', '2544', '1', '贵州,黔东南苗族侗族自治州,三穗县', null, null, '522624', 's', 'sansuixian', 'ssx');
INSERT INTO `yc_city` VALUES ('2549', '镇远县', '2544', '1', '贵州,黔东南苗族侗族自治州,镇远县', null, null, '522625', 'z', 'zhenyuanxian', 'zyx');
INSERT INTO `yc_city` VALUES ('2550', '岑巩县', '2544', '1', '贵州,黔东南苗族侗族自治州,岑巩县', null, null, '522626', 'c', 'cengongxian', 'gx');
INSERT INTO `yc_city` VALUES ('2551', '天柱县', '2544', '1', '贵州,黔东南苗族侗族自治州,天柱县', null, null, '522627', 't', 'tianzhuxian', 'tzx');
INSERT INTO `yc_city` VALUES ('2552', '锦屏县', '2544', '1', '贵州,黔东南苗族侗族自治州,锦屏县', null, null, '522628', 'j', 'jinpingxian', 'jpx');
INSERT INTO `yc_city` VALUES ('2553', '剑河县', '2544', '1', '贵州,黔东南苗族侗族自治州,剑河县', null, null, '522629', 'j', 'jianhexian', 'jhx');
INSERT INTO `yc_city` VALUES ('2554', '台江县', '2544', '1', '贵州,黔东南苗族侗族自治州,台江县', null, null, '522630', 't', 'taijiangxian', 'tjx');
INSERT INTO `yc_city` VALUES ('2555', '黎平县', '2544', '1', '贵州,黔东南苗族侗族自治州,黎平县', null, null, '522631', 'l', 'lipingxian', 'lpx');
INSERT INTO `yc_city` VALUES ('2556', '榕江县', '2544', '1', '贵州,黔东南苗族侗族自治州,榕江县', null, null, '522632', 'r', 'rongjiangxian', 'jx');
INSERT INTO `yc_city` VALUES ('2557', '从江县', '2544', '1', '贵州,黔东南苗族侗族自治州,从江县', null, null, '522633', 'c', 'congjiangxian', 'cjx');
INSERT INTO `yc_city` VALUES ('2558', '雷山县', '2544', '1', '贵州,黔东南苗族侗族自治州,雷山县', null, null, '522634', 'l', 'leishanxian', 'lsx');
INSERT INTO `yc_city` VALUES ('2559', '麻江县', '2544', '1', '贵州,黔东南苗族侗族自治州,麻江县', null, null, '522635', 'm', 'majiangxian', 'mjx');
INSERT INTO `yc_city` VALUES ('2560', '丹寨县', '2544', '1', '贵州,黔东南苗族侗族自治州,丹寨县', null, null, '522636', 'd', 'danzhaixian', 'dzx');
INSERT INTO `yc_city` VALUES ('2561', '黔南布依族苗族自治州', '2476', '1', '贵州,黔南布依族苗族自治州', null, null, '522700', 'q', 'qiannanbuyizumiaozuzizhizhou', 'qnbyzmzzzz');
INSERT INTO `yc_city` VALUES ('2562', '都匀市', '2561', '1', '贵州,黔南布依族苗族自治州,都匀市', null, null, '522701', 'd', 'duyunshi', 'dys');
INSERT INTO `yc_city` VALUES ('2563', '福泉市', '2561', '1', '贵州,黔南布依族苗族自治州,福泉市', null, null, '522702', 'f', 'fuquanshi', 'fqs');
INSERT INTO `yc_city` VALUES ('2564', '荔波县', '2561', '1', '贵州,黔南布依族苗族自治州,荔波县', null, null, '522722', 'l', 'liboxian', 'lbx');
INSERT INTO `yc_city` VALUES ('2565', '贵定县', '2561', '1', '贵州,黔南布依族苗族自治州,贵定县', null, null, '522723', 'g', 'guidingxian', 'gdx');
INSERT INTO `yc_city` VALUES ('2566', '瓮安县', '2561', '1', '贵州,黔南布依族苗族自治州,瓮安县', null, null, '522725', 'w', 'wenganxian', 'wax');
INSERT INTO `yc_city` VALUES ('2567', '独山县', '2561', '1', '贵州,黔南布依族苗族自治州,独山县', null, null, '522726', 'd', 'dushanxian', 'dsx');
INSERT INTO `yc_city` VALUES ('2568', '平塘县', '2561', '1', '贵州,黔南布依族苗族自治州,平塘县', null, null, '522727', 'p', 'pingtangxian', 'ptx');
INSERT INTO `yc_city` VALUES ('2569', '罗甸县', '2561', '1', '贵州,黔南布依族苗族自治州,罗甸县', null, null, '522728', 'l', 'luodianxian', 'ldx');
INSERT INTO `yc_city` VALUES ('2570', '长顺县', '2561', '1', '贵州,黔南布依族苗族自治州,长顺县', null, null, '522729', 'c', 'changshunxian', 'csx');
INSERT INTO `yc_city` VALUES ('2571', '龙里县', '2561', '1', '贵州,黔南布依族苗族自治州,龙里县', null, null, '522730', 'l', 'longlixian', 'llx');
INSERT INTO `yc_city` VALUES ('2572', '惠水县', '2561', '1', '贵州,黔南布依族苗族自治州,惠水县', null, null, '522731', 'h', 'huishuixian', 'hsx');
INSERT INTO `yc_city` VALUES ('2573', '三都水族自治县', '2561', '1', '贵州,黔南布依族苗族自治州,三都水族自治县', null, null, '522732', 's', 'sandoushuizuzizhixian', 'sdszzzx');
INSERT INTO `yc_city` VALUES ('2574', '云南', '1', '1', '云南', null, null, '530000', 'y', 'yunnan', 'yn');
INSERT INTO `yc_city` VALUES ('2575', '昆明市', '2574', '1', '云南,昆明市', null, null, '530100', 'k', 'kunmingshi', 'kms');
INSERT INTO `yc_city` VALUES ('2576', '五华区', '2575', '1', '云南,昆明市,五华区', null, null, '530102', 'w', 'wuhuaqu', 'whq');
INSERT INTO `yc_city` VALUES ('2577', '盘龙区', '2575', '1', '云南,昆明市,盘龙区', null, null, '530103', 'p', 'panlongqu', 'plq');
INSERT INTO `yc_city` VALUES ('2578', '官渡区', '2575', '1', '云南,昆明市,官渡区', null, null, '530111', 'g', 'guanduqu', 'gdq');
INSERT INTO `yc_city` VALUES ('2579', '西山区', '2575', '1', '云南,昆明市,西山区', null, null, '530112', 'x', 'xishanqu', 'xsq');
INSERT INTO `yc_city` VALUES ('2580', '东川区', '2575', '1', '云南,昆明市,东川区', null, null, '530113', 'd', 'dongchuanqu', 'dcq');
INSERT INTO `yc_city` VALUES ('2581', '呈贡区', '2575', '1', '云南,昆明市,呈贡区', null, null, null, 'c', 'chenggongqu', 'cgq');
INSERT INTO `yc_city` VALUES ('2582', '晋宁县', '2575', '1', '云南,昆明市,晋宁县', null, null, '530122', 'j', 'jinningxian', 'jnx');
INSERT INTO `yc_city` VALUES ('2583', '富民县', '2575', '1', '云南,昆明市,富民县', null, null, '530124', 'f', 'fuminxian', 'fmx');
INSERT INTO `yc_city` VALUES ('2584', '宜良县', '2575', '1', '云南,昆明市,宜良县', null, null, '530125', 'y', 'yiliangxian', 'ylx');
INSERT INTO `yc_city` VALUES ('2585', '石林彝族自治县', '2575', '1', '云南,昆明市,石林彝族自治县', null, null, '530126', 's', 'shilinyizuzizhixian', 'slyzzzx');
INSERT INTO `yc_city` VALUES ('2586', '嵩明县', '2575', '1', '云南,昆明市,嵩明县', null, null, '530127', 's', 'songmingxian', 'mx');
INSERT INTO `yc_city` VALUES ('2587', '禄劝彝族苗族自治县', '2575', '1', '云南,昆明市,禄劝彝族苗族自治县', null, null, '530128', 'l', 'luquanyizumiaozuzizhixian', 'lqyzmzzzx');
INSERT INTO `yc_city` VALUES ('2588', '寻甸回族彝族自治县', '2575', '1', '云南,昆明市,寻甸回族彝族自治县', null, null, '530129', 'x', 'xundianhuizuyizuzizhixian', 'xdhzyzzzx');
INSERT INTO `yc_city` VALUES ('2589', '安宁市', '2575', '1', '云南,昆明市,安宁市', null, null, '530181', 'a', 'anningshi', 'ans');
INSERT INTO `yc_city` VALUES ('2590', '曲靖市', '2574', '1', '云南,曲靖市', null, null, '530300', 'q', 'qujingshi', 'qjs');
INSERT INTO `yc_city` VALUES ('2591', '麒麟区', '2590', '1', '云南,曲靖市,麒麟区', null, null, '530302', 'q', 'qilinqu', 'q');
INSERT INTO `yc_city` VALUES ('2592', '马龙县', '2590', '1', '云南,曲靖市,马龙县', null, null, '530321', 'm', 'malongxian', 'mlx');
INSERT INTO `yc_city` VALUES ('2593', '陆良县', '2590', '1', '云南,曲靖市,陆良县', null, null, '530322', 'l', 'luliangxian', 'llx');
INSERT INTO `yc_city` VALUES ('2594', '师宗县', '2590', '1', '云南,曲靖市,师宗县', null, null, '530323', 's', 'shizongxian', 'szx');
INSERT INTO `yc_city` VALUES ('2595', '罗平县', '2590', '1', '云南,曲靖市,罗平县', null, null, '530324', 'l', 'luopingxian', 'lpx');
INSERT INTO `yc_city` VALUES ('2596', '富源县', '2590', '1', '云南,曲靖市,富源县', null, null, '530325', 'f', 'fuyuanxian', 'fyx');
INSERT INTO `yc_city` VALUES ('2597', '会泽县', '2590', '1', '云南,曲靖市,会泽县', null, null, '530326', 'h', 'huizexian', 'hzx');
INSERT INTO `yc_city` VALUES ('2598', '沾益县', '2590', '1', '云南,曲靖市,沾益县', null, null, '530328', 'z', 'zhanyixian', 'zyx');
INSERT INTO `yc_city` VALUES ('2599', '宣威市', '2590', '1', '云南,曲靖市,宣威市', null, null, '530381', 'x', 'xuanweishi', 'xws');
INSERT INTO `yc_city` VALUES ('2600', '玉溪市', '2574', '1', '云南,玉溪市', null, null, '530400', 'y', 'yuxishi', 'yxs');
INSERT INTO `yc_city` VALUES ('2601', '红塔区', '2600', '1', '云南,玉溪市,红塔区', null, null, '530402', 'h', 'hongtaqu', 'htq');
INSERT INTO `yc_city` VALUES ('2602', '江川县', '2600', '1', '云南,玉溪市,江川县', null, null, '530421', 'j', 'jiangchuanxian', 'jcx');
INSERT INTO `yc_city` VALUES ('2603', '澄江县', '2600', '1', '云南,玉溪市,澄江县', null, null, '530422', 'c', 'chengjiangxian', 'cjx');
INSERT INTO `yc_city` VALUES ('2604', '通海县', '2600', '1', '云南,玉溪市,通海县', null, null, '530423', 't', 'tonghaixian', 'thx');
INSERT INTO `yc_city` VALUES ('2605', '华宁县', '2600', '1', '云南,玉溪市,华宁县', null, null, '530424', 'h', 'huaningxian', 'hnx');
INSERT INTO `yc_city` VALUES ('2606', '易门县', '2600', '1', '云南,玉溪市,易门县', null, null, '530425', 'y', 'yimenxian', 'ymx');
INSERT INTO `yc_city` VALUES ('2607', '峨山彝族自治县', '2600', '1', '云南,玉溪市,峨山彝族自治县', null, null, '530426', 'e', 'eshanyizuzizhixian', 'esyzzzx');
INSERT INTO `yc_city` VALUES ('2608', '新平彝族傣族自治县', '2600', '1', '云南,玉溪市,新平彝族傣族自治县', null, null, '530427', 'x', 'xinpingyizudaizuzizhixian', 'xpyzdzzzx');
INSERT INTO `yc_city` VALUES ('2609', '元江哈尼族彝族傣族自治县', '2600', '1', '云南,玉溪市,元江哈尼族彝族傣族自治县', null, null, '530428', 'y', 'yuanjianghanizuyizudaizuzizhixian', 'yjhnzyzdzzzx');
INSERT INTO `yc_city` VALUES ('2610', '保山市', '2574', '1', '云南,保山市', null, null, '530500', 'b', 'baoshanshi', 'bss');
INSERT INTO `yc_city` VALUES ('2611', '隆阳区', '2610', '1', '云南,保山市,隆阳区', null, null, '530502', 'l', 'longyangqu', 'lyq');
INSERT INTO `yc_city` VALUES ('2612', '施甸县', '2610', '1', '云南,保山市,施甸县', null, null, '530521', 's', 'shidianxian', 'sdx');
INSERT INTO `yc_city` VALUES ('2613', '腾冲县', '2610', '1', '云南,保山市,腾冲县', null, null, '530522', 't', 'tengchongxian', 'tcx');
INSERT INTO `yc_city` VALUES ('2614', '龙陵县', '2610', '1', '云南,保山市,龙陵县', null, null, '530523', 'l', 'longlingxian', 'llx');
INSERT INTO `yc_city` VALUES ('2615', '昌宁县', '2610', '1', '云南,保山市,昌宁县', null, null, '530524', 'c', 'changningxian', 'cnx');
INSERT INTO `yc_city` VALUES ('2616', '昭通市', '2574', '1', '云南,昭通市', null, null, '530600', 'z', 'zhaotongshi', 'zts');
INSERT INTO `yc_city` VALUES ('2617', '昭阳区', '2616', '1', '云南,昭通市,昭阳区', null, null, '530602', 'z', 'zhaoyangqu', 'zyq');
INSERT INTO `yc_city` VALUES ('2618', '鲁甸县', '2616', '1', '云南,昭通市,鲁甸县', null, null, '530621', 'l', 'ludianxian', 'ldx');
INSERT INTO `yc_city` VALUES ('2619', '巧家县', '2616', '1', '云南,昭通市,巧家县', null, null, '530622', 'q', 'qiaojiaxian', 'qjx');
INSERT INTO `yc_city` VALUES ('2620', '盐津县', '2616', '1', '云南,昭通市,盐津县', null, null, '530623', 'y', 'yanjinxian', 'yjx');
INSERT INTO `yc_city` VALUES ('2621', '大关县', '2616', '1', '云南,昭通市,大关县', null, null, '530624', 'd', 'daguanxian', 'dgx');
INSERT INTO `yc_city` VALUES ('2622', '永善县', '2616', '1', '云南,昭通市,永善县', null, null, '530625', 'y', 'yongshanxian', 'ysx');
INSERT INTO `yc_city` VALUES ('2623', '绥江县', '2616', '1', '云南,昭通市,绥江县', null, null, '530626', 's', 'suijiangxian', 'sjx');
INSERT INTO `yc_city` VALUES ('2624', '镇雄县', '2616', '1', '云南,昭通市,镇雄县', null, null, '530627', 'z', 'zhenxiongxian', 'zxx');
INSERT INTO `yc_city` VALUES ('2625', '彝良县', '2616', '1', '云南,昭通市,彝良县', null, null, '530628', 'y', 'yiliangxian', 'ylx');
INSERT INTO `yc_city` VALUES ('2626', '威信县', '2616', '1', '云南,昭通市,威信县', null, null, '530629', 'w', 'weixinxian', 'wxx');
INSERT INTO `yc_city` VALUES ('2627', '水富县', '2616', '1', '云南,昭通市,水富县', null, null, '530630', 's', 'shuifuxian', 'sfx');
INSERT INTO `yc_city` VALUES ('2628', '丽江市', '2574', '1', '云南,丽江市', null, null, '530700', 'l', 'lijiangshi', 'ljs');
INSERT INTO `yc_city` VALUES ('2629', '古城区', '2628', '1', '云南,丽江市,古城区', null, null, '530702', 'g', 'guchengqu', 'gcq');
INSERT INTO `yc_city` VALUES ('2630', '玉龙纳西族自治县', '2628', '1', '云南,丽江市,玉龙纳西族自治县', null, null, '530721', 'y', 'yulongnaxizuzizhixian', 'ylnxzzzx');
INSERT INTO `yc_city` VALUES ('2631', '永胜县', '2628', '1', '云南,丽江市,永胜县', null, null, '530722', 'y', 'yongshengxian', 'ysx');
INSERT INTO `yc_city` VALUES ('2632', '华坪县', '2628', '1', '云南,丽江市,华坪县', null, null, '530723', 'h', 'huapingxian', 'hpx');
INSERT INTO `yc_city` VALUES ('2633', '宁蒗彝族自治县', '2628', '1', '云南,丽江市,宁蒗彝族自治县', null, null, '530724', 'n', 'ninglangyizuzizhixian', 'nyzzzx');
INSERT INTO `yc_city` VALUES ('2634', '普洱市', '2574', '1', '云南,普洱市', null, null, '530800', 'p', 'puershi', 'pes');
INSERT INTO `yc_city` VALUES ('2635', '思茅区', '2634', '1', '云南,普洱市,思茅区', null, null, '530802', 's', 'simaoqu', 'smq');
INSERT INTO `yc_city` VALUES ('2636', '宁洱哈尼族彝族自治县', '2634', '1', '云南,普洱市,宁洱哈尼族彝族自治县', null, null, '530821', 'n', 'ningerhanizuyizuzizhixian', 'nehnzyzzzx');
INSERT INTO `yc_city` VALUES ('2637', '墨江哈尼族自治县', '2634', '1', '云南,普洱市,墨江哈尼族自治县', null, null, '530822', 'm', 'mojianghanizuzizhixian', 'mjhnzzzx');
INSERT INTO `yc_city` VALUES ('2638', '景东彝族自治县', '2634', '1', '云南,普洱市,景东彝族自治县', null, null, '530823', 'j', 'jingdongyizuzizhixian', 'jdyzzzx');
INSERT INTO `yc_city` VALUES ('2639', '景谷傣族彝族自治县', '2634', '1', '云南,普洱市,景谷傣族彝族自治县', null, null, '530824', 'j', 'jinggudaizuyizuzizhixian', 'jgdzyzzzx');
INSERT INTO `yc_city` VALUES ('2640', '镇沅彝族哈尼族拉祜族自治县', '2634', '1', '云南,普洱市,镇沅彝族哈尼族拉祜族自治县', null, null, '530825', 'z', 'zhenyuanyizuhanizulahuzuzizhixian', 'zyzhnzlzzzx');
INSERT INTO `yc_city` VALUES ('2641', '江城哈尼族彝族自治县', '2634', '1', '云南,普洱市,江城哈尼族彝族自治县', null, null, '530826', 'j', 'jiangchenghanizuyizuzizhixian', 'jchnzyzzzx');
INSERT INTO `yc_city` VALUES ('2642', '孟连傣族拉祜族佤族自治县', '2634', '1', '云南,普洱市,孟连傣族拉祜族佤族自治县', null, null, '530827', 'm', 'mengliandaizulahuzuwazuzizhixian', 'mldzlzzzzx');
INSERT INTO `yc_city` VALUES ('2643', '澜沧拉祜族自治县', '2634', '1', '云南,普洱市,澜沧拉祜族自治县', null, null, '530828', 'l', 'lancanglahuzuzizhixian', 'lclzzzx');
INSERT INTO `yc_city` VALUES ('2644', '西盟佤族自治县', '2634', '1', '云南,普洱市,西盟佤族自治县', null, null, '530829', 'x', 'ximengwazuzizhixian', 'xmzzzx');
INSERT INTO `yc_city` VALUES ('2645', '临沧市', '2574', '1', '云南,临沧市', null, null, '530900', 'l', 'lincangshi', 'lcs');
INSERT INTO `yc_city` VALUES ('2646', '临翔区', '2645', '1', '云南,临沧市,临翔区', null, null, '530902', 'l', 'linxiangqu', 'lxq');
INSERT INTO `yc_city` VALUES ('2647', '凤庆县', '2645', '1', '云南,临沧市,凤庆县', null, null, '530921', 'f', 'fengqingxian', 'fqx');
INSERT INTO `yc_city` VALUES ('2648', '云县', '2645', '1', '云南,临沧市,云县', null, null, '530922', 'y', 'yunxian', 'yx');
INSERT INTO `yc_city` VALUES ('2649', '永德县', '2645', '1', '云南,临沧市,永德县', null, null, '530923', 'y', 'yongdexian', 'ydx');
INSERT INTO `yc_city` VALUES ('2650', '镇康县', '2645', '1', '云南,临沧市,镇康县', null, null, '530924', 'z', 'zhenkangxian', 'zkx');
INSERT INTO `yc_city` VALUES ('2651', '双江拉祜族佤族布朗族傣族自治县', '2645', '1', '云南,临沧市,双江拉祜族佤族布朗族傣族自治县', null, null, '530925', 's', 'shuangjianglahuzuwazubulangzudaizuzizhixian', 'sjlzzblzdzzzx');
INSERT INTO `yc_city` VALUES ('2652', '耿马傣族佤族自治县', '2645', '1', '云南,临沧市,耿马傣族佤族自治县', null, null, '530926', 'g', 'gengmadaizuwazuzizhixian', 'gmdzzzzx');
INSERT INTO `yc_city` VALUES ('2653', '沧源佤族自治县', '2645', '1', '云南,临沧市,沧源佤族自治县', null, null, '530927', 'c', 'cangyuanwazuzizhixian', 'cyzzzx');
INSERT INTO `yc_city` VALUES ('2654', '楚雄彝族自治州', '2574', '1', '云南,楚雄彝族自治州', null, null, '532300', 'c', 'chuxiongyizuzizhizhou', 'cxyzzzz');
INSERT INTO `yc_city` VALUES ('2655', '楚雄市', '2654', '1', '云南,楚雄彝族自治州,楚雄市', null, null, '532301', 'c', 'chuxiongshi', 'cxs');
INSERT INTO `yc_city` VALUES ('2656', '双柏县', '2654', '1', '云南,楚雄彝族自治州,双柏县', null, null, '532322', 's', 'shuangbaixian', 'sbx');
INSERT INTO `yc_city` VALUES ('2657', '牟定县', '2654', '1', '云南,楚雄彝族自治州,牟定县', null, null, '532323', 'm', 'moudingxian', 'mdx');
INSERT INTO `yc_city` VALUES ('2658', '南华县', '2654', '1', '云南,楚雄彝族自治州,南华县', null, null, '532324', 'n', 'nanhuaxian', 'nhx');
INSERT INTO `yc_city` VALUES ('2659', '姚安县', '2654', '1', '云南,楚雄彝族自治州,姚安县', null, null, '532325', 'y', 'yaoanxian', 'yax');
INSERT INTO `yc_city` VALUES ('2660', '大姚县', '2654', '1', '云南,楚雄彝族自治州,大姚县', null, null, '532326', 'd', 'dayaoxian', 'dyx');
INSERT INTO `yc_city` VALUES ('2661', '永仁县', '2654', '1', '云南,楚雄彝族自治州,永仁县', null, null, '532327', 'y', 'yongrenxian', 'yrx');
INSERT INTO `yc_city` VALUES ('2662', '元谋县', '2654', '1', '云南,楚雄彝族自治州,元谋县', null, null, '532328', 'y', 'yuanmouxian', 'ymx');
INSERT INTO `yc_city` VALUES ('2663', '武定县', '2654', '1', '云南,楚雄彝族自治州,武定县', null, null, '532329', 'w', 'wudingxian', 'wdx');
INSERT INTO `yc_city` VALUES ('2664', '禄丰县', '2654', '1', '云南,楚雄彝族自治州,禄丰县', null, null, '532331', 'l', 'lufengxian', 'lfx');
INSERT INTO `yc_city` VALUES ('2665', '红河哈尼族彝族自治州', '2574', '1', '云南,红河哈尼族彝族自治州', null, null, '532500', 'h', 'honghehanizuyizuzizhizhou', 'hhhnzyzzzz');
INSERT INTO `yc_city` VALUES ('2666', '个旧市', '2665', '1', '云南,红河哈尼族彝族自治州,个旧市', null, null, '532501', 'g', 'gejiushi', 'gjs');
INSERT INTO `yc_city` VALUES ('2667', '开远市', '2665', '1', '云南,红河哈尼族彝族自治州,开远市', null, null, '532502', 'k', 'kaiyuanshi', 'kys');
INSERT INTO `yc_city` VALUES ('2668', '蒙自市', '2665', '1', '云南,红河哈尼族彝族自治州,蒙自市', null, null, null, 'm', 'mengzishi', 'mzs');
INSERT INTO `yc_city` VALUES ('2669', '弥勒市', '2665', '1', '云南,红河哈尼族彝族自治州,弥勒市', null, null, null, 'm', 'mileshi', 'mls');
INSERT INTO `yc_city` VALUES ('2670', '屏边苗族自治县', '2665', '1', '云南,红河哈尼族彝族自治州,屏边苗族自治县', null, null, '532523', 'p', 'pingbianmiaozuzizhixian', 'pbmzzzx');
INSERT INTO `yc_city` VALUES ('2671', '建水县', '2665', '1', '云南,红河哈尼族彝族自治州,建水县', null, null, '532524', 'j', 'jianshuixian', 'jsx');
INSERT INTO `yc_city` VALUES ('2672', '石屏县', '2665', '1', '云南,红河哈尼族彝族自治州,石屏县', null, null, '532525', 's', 'shipingxian', 'spx');
INSERT INTO `yc_city` VALUES ('2673', '泸西县', '2665', '1', '云南,红河哈尼族彝族自治州,泸西县', null, null, '532527', 'l', 'luxixian', 'xx');
INSERT INTO `yc_city` VALUES ('2674', '元阳县', '2665', '1', '云南,红河哈尼族彝族自治州,元阳县', null, null, '532528', 'y', 'yuanyangxian', 'yyx');
INSERT INTO `yc_city` VALUES ('2675', '红河县', '2665', '1', '云南,红河哈尼族彝族自治州,红河县', null, null, '532529', 'h', 'honghexian', 'hhx');
INSERT INTO `yc_city` VALUES ('2676', '金平苗族瑶族傣族自治县', '2665', '1', '云南,红河哈尼族彝族自治州,金平苗族瑶族傣族自治县', null, null, '532530', 'j', 'jinpingmiaozuyaozudaizuzizhixian', 'jpmzyzdzzzx');
INSERT INTO `yc_city` VALUES ('2677', '绿春县', '2665', '1', '云南,红河哈尼族彝族自治州,绿春县', null, null, '532531', 'l', 'lvchunxian', 'lcx');
INSERT INTO `yc_city` VALUES ('2678', '河口瑶族自治县', '2665', '1', '云南,红河哈尼族彝族自治州,河口瑶族自治县', null, null, '532532', 'h', 'hekouyaozuzizhixian', 'hkyzzzx');
INSERT INTO `yc_city` VALUES ('2679', '文山壮族苗族自治州', '2574', '1', '云南,文山壮族苗族自治州', null, null, '532600', 'w', 'wenshanzhuangzumiaozuzizhizhou', 'wszzmzzzz');
INSERT INTO `yc_city` VALUES ('2680', '文山市', '2679', '1', '云南,文山壮族苗族自治州,文山市', null, null, null, 'w', 'wenshanshi', 'wss');
INSERT INTO `yc_city` VALUES ('2681', '砚山县', '2679', '1', '云南,文山壮族苗族自治州,砚山县', null, null, '532622', 'y', 'yanshanxian', 'ysx');
INSERT INTO `yc_city` VALUES ('2682', '西畴县', '2679', '1', '云南,文山壮族苗族自治州,西畴县', null, null, '532623', 'x', 'xichouxian', 'xcx');
INSERT INTO `yc_city` VALUES ('2683', '麻栗坡县', '2679', '1', '云南,文山壮族苗族自治州,麻栗坡县', null, null, '532624', 'm', 'malipoxian', 'mlpx');
INSERT INTO `yc_city` VALUES ('2684', '马关县', '2679', '1', '云南,文山壮族苗族自治州,马关县', null, null, '532625', 'm', 'maguanxian', 'mgx');
INSERT INTO `yc_city` VALUES ('2685', '丘北县', '2679', '1', '云南,文山壮族苗族自治州,丘北县', null, null, '532626', 'q', 'qiubeixian', 'qbx');
INSERT INTO `yc_city` VALUES ('2686', '广南县', '2679', '1', '云南,文山壮族苗族自治州,广南县', null, null, '532627', 'g', 'guangnanxian', 'gnx');
INSERT INTO `yc_city` VALUES ('2687', '富宁县', '2679', '1', '云南,文山壮族苗族自治州,富宁县', null, null, '532628', 'f', 'funingxian', 'fnx');
INSERT INTO `yc_city` VALUES ('2688', '西双版纳傣族自治州', '2574', '1', '云南,西双版纳傣族自治州', null, null, '532800', 'x', 'xishuangbannadaizuzizhizhou', 'xsbndzzzz');
INSERT INTO `yc_city` VALUES ('2689', '景洪市', '2688', '1', '云南,西双版纳傣族自治州,景洪市', null, null, '532801', 'j', 'jinghongshi', 'jhs');
INSERT INTO `yc_city` VALUES ('2690', '勐海县', '2688', '1', '云南,西双版纳傣族自治州,勐海县', null, null, '532822', 'm', 'menghaixian', 'hx');
INSERT INTO `yc_city` VALUES ('2691', '勐腊县', '2688', '1', '云南,西双版纳傣族自治州,勐腊县', null, null, '532823', 'm', 'menglaxian', 'lx');
INSERT INTO `yc_city` VALUES ('2692', '大理白族自治州', '2574', '1', '云南,大理白族自治州', null, null, '532900', 'd', 'dalibaizuzizhizhou', 'dlbzzzz');
INSERT INTO `yc_city` VALUES ('2693', '大理市', '2692', '1', '云南,大理白族自治州,大理市', null, null, '532901', 'd', 'dalishi', 'dls');
INSERT INTO `yc_city` VALUES ('2694', '漾濞彝族自治县', '2692', '1', '云南,大理白族自治州,漾濞彝族自治县', null, null, '532922', 'y', 'yangbiyizuzizhixian', 'yyzzzx');
INSERT INTO `yc_city` VALUES ('2695', '祥云县', '2692', '1', '云南,大理白族自治州,祥云县', null, null, '532923', 'x', 'xiangyunxian', 'xyx');
INSERT INTO `yc_city` VALUES ('2696', '宾川县', '2692', '1', '云南,大理白族自治州,宾川县', null, null, '532924', 'b', 'binchuanxian', 'bcx');
INSERT INTO `yc_city` VALUES ('2697', '弥渡县', '2692', '1', '云南,大理白族自治州,弥渡县', null, null, '532925', 'm', 'miduxian', 'mdx');
INSERT INTO `yc_city` VALUES ('2698', '南涧彝族自治县', '2692', '1', '云南,大理白族自治州,南涧彝族自治县', null, null, '532926', 'n', 'nanjianyizuzizhixian', 'njyzzzx');
INSERT INTO `yc_city` VALUES ('2699', '巍山彝族回族自治县', '2692', '1', '云南,大理白族自治州,巍山彝族回族自治县', null, null, '532927', 'w', 'weishanyizuhuizuzizhixian', 'wsyzhzzzx');
INSERT INTO `yc_city` VALUES ('2700', '永平县', '2692', '1', '云南,大理白族自治州,永平县', null, null, '532928', 'y', 'yongpingxian', 'ypx');
INSERT INTO `yc_city` VALUES ('2701', '云龙县', '2692', '1', '云南,大理白族自治州,云龙县', null, null, '532929', 'y', 'yunlongxian', 'ylx');
INSERT INTO `yc_city` VALUES ('2702', '洱源县', '2692', '1', '云南,大理白族自治州,洱源县', null, null, '532930', 'e', 'eryuanxian', 'eyx');
INSERT INTO `yc_city` VALUES ('2703', '剑川县', '2692', '1', '云南,大理白族自治州,剑川县', null, null, '532931', 'j', 'jianchuanxian', 'jcx');
INSERT INTO `yc_city` VALUES ('2704', '鹤庆县', '2692', '1', '云南,大理白族自治州,鹤庆县', null, null, '532932', 'h', 'heqingxian', 'hqx');
INSERT INTO `yc_city` VALUES ('2705', '德宏傣族景颇族自治州', '2574', '1', '云南,德宏傣族景颇族自治州', null, null, '533100', 'd', 'dehongdaizujingpozuzizhizhou', 'dhdzjpzzzz');
INSERT INTO `yc_city` VALUES ('2706', '瑞丽市', '2705', '1', '云南,德宏傣族景颇族自治州,瑞丽市', null, null, '533102', 'r', 'ruilishi', 'rls');
INSERT INTO `yc_city` VALUES ('2707', '芒市', '2705', '1', '云南,德宏傣族景颇族自治州,芒市', null, null, null, 'm', 'mangshi', 'ms');
INSERT INTO `yc_city` VALUES ('2708', '梁河县', '2705', '1', '云南,德宏傣族景颇族自治州,梁河县', null, null, '533122', 'l', 'lianghexian', 'lhx');
INSERT INTO `yc_city` VALUES ('2709', '盈江县', '2705', '1', '云南,德宏傣族景颇族自治州,盈江县', null, null, '533123', 'y', 'yingjiangxian', 'yjx');
INSERT INTO `yc_city` VALUES ('2710', '陇川县', '2705', '1', '云南,德宏傣族景颇族自治州,陇川县', null, null, '533124', 'l', 'longchuanxian', 'lcx');
INSERT INTO `yc_city` VALUES ('2711', '怒江傈僳族自治州', '2574', '1', '云南,怒江傈僳族自治州', null, null, '533300', 'n', 'nujianglisuzuzizhizhou', 'njlszzzz');
INSERT INTO `yc_city` VALUES ('2712', '泸水县', '2711', '1', '云南,怒江傈僳族自治州,泸水县', null, null, '533321', 'l', 'lushuixian', 'sx');
INSERT INTO `yc_city` VALUES ('2713', '福贡县', '2711', '1', '云南,怒江傈僳族自治州,福贡县', null, null, '533323', 'f', 'fugongxian', 'fgx');
INSERT INTO `yc_city` VALUES ('2714', '贡山独龙族怒族自治县', '2711', '1', '云南,怒江傈僳族自治州,贡山独龙族怒族自治县', null, null, '533324', 'g', 'gongshandulongzunuzuzizhixian', 'gsdlznzzzx');
INSERT INTO `yc_city` VALUES ('2715', '兰坪白族普米族自治县', '2711', '1', '云南,怒江傈僳族自治州,兰坪白族普米族自治县', null, null, '533325', 'l', 'lanpingbaizupumizuzizhixian', 'lpbzpmzzzx');
INSERT INTO `yc_city` VALUES ('2716', '迪庆藏族自治州', '2574', '1', '云南,迪庆藏族自治州', null, null, '533400', 'd', 'diqingzangzuzizhizhou', 'dqczzzz');
INSERT INTO `yc_city` VALUES ('2717', '香格里拉县', '2716', '1', '云南,迪庆藏族自治州,香格里拉县', null, null, '533421', 'x', 'xianggelilaxian', 'xgllx');
INSERT INTO `yc_city` VALUES ('2718', '德钦县', '2716', '1', '云南,迪庆藏族自治州,德钦县', null, null, '533422', 'd', 'deqinxian', 'dqx');
INSERT INTO `yc_city` VALUES ('2719', '维西傈僳族自治县', '2716', '1', '云南,迪庆藏族自治州,维西傈僳族自治县', null, null, '533423', 'w', 'weixilisuzuzizhixian', 'wxlszzzx');
INSERT INTO `yc_city` VALUES ('2720', '西藏', '1', '1', '西藏', null, null, '540000', 'x', 'xizang', 'xc');
INSERT INTO `yc_city` VALUES ('2721', '拉萨市', '2720', '1', '西藏,拉萨市', null, null, '540100', 'l', 'lasashi', 'lss');
INSERT INTO `yc_city` VALUES ('2722', '城关区', '2721', '1', '西藏,拉萨市,城关区', null, null, '540102', 'c', 'chengguanqu', 'cgq');
INSERT INTO `yc_city` VALUES ('2723', '林周县', '2721', '1', '西藏,拉萨市,林周县', null, null, '540121', 'l', 'linzhouxian', 'lzx');
INSERT INTO `yc_city` VALUES ('2724', '当雄县', '2721', '1', '西藏,拉萨市,当雄县', null, null, '540122', 'd', 'dangxiongxian', 'dxx');
INSERT INTO `yc_city` VALUES ('2725', '尼木县', '2721', '1', '西藏,拉萨市,尼木县', null, null, '540123', 'n', 'nimuxian', 'nmx');
INSERT INTO `yc_city` VALUES ('2726', '曲水县', '2721', '1', '西藏,拉萨市,曲水县', null, null, '540124', 'q', 'qushuixian', 'qsx');
INSERT INTO `yc_city` VALUES ('2727', '堆龙德庆县', '2721', '1', '西藏,拉萨市,堆龙德庆县', null, null, '540125', 'd', 'duilongdeqingxian', 'dldqx');
INSERT INTO `yc_city` VALUES ('2728', '达孜县', '2721', '1', '西藏,拉萨市,达孜县', null, null, '540126', 'd', 'dazixian', 'dzx');
INSERT INTO `yc_city` VALUES ('2729', '墨竹工卡县', '2721', '1', '西藏,拉萨市,墨竹工卡县', null, null, '540127', 'm', 'mozhugongkaxian', 'mzgkx');
INSERT INTO `yc_city` VALUES ('2730', '日喀则市', '2720', '1', '西藏,日喀则市', null, null, '542300', 'r', 'rikazeshi', 'rkzs');
INSERT INTO `yc_city` VALUES ('2731', '桑珠孜区', '2730', '1', '西藏,日喀则市,桑珠孜区', null, null, null, 's', 'sangzhuziqu', 'szzq');
INSERT INTO `yc_city` VALUES ('2732', '南木林县', '2730', '1', '西藏,日喀则市,南木林县', null, null, '542322', 'n', 'nanmulinxian', 'nmlx');
INSERT INTO `yc_city` VALUES ('2733', '江孜县', '2730', '1', '西藏,日喀则市,江孜县', null, null, '542323', 'j', 'jiangzixian', 'jzx');
INSERT INTO `yc_city` VALUES ('2734', '定日县', '2730', '1', '西藏,日喀则市,定日县', null, null, '542324', 'd', 'dingrixian', 'drx');
INSERT INTO `yc_city` VALUES ('2735', '萨迦县', '2730', '1', '西藏,日喀则市,萨迦县', null, null, '542325', 's', 'sajiaxian', 'sx');
INSERT INTO `yc_city` VALUES ('2736', '拉孜县', '2730', '1', '西藏,日喀则市,拉孜县', null, null, '542326', 'l', 'lazixian', 'lzx');
INSERT INTO `yc_city` VALUES ('2737', '昂仁县', '2730', '1', '西藏,日喀则市,昂仁县', null, null, '542327', 'a', 'angrenxian', 'arx');
INSERT INTO `yc_city` VALUES ('2738', '谢通门县', '2730', '1', '西藏,日喀则市,谢通门县', null, null, '542328', 'x', 'xietongmenxian', 'xtmx');
INSERT INTO `yc_city` VALUES ('2739', '白朗县', '2730', '1', '西藏,日喀则市,白朗县', null, null, '542329', 'b', 'bailangxian', 'blx');
INSERT INTO `yc_city` VALUES ('2740', '仁布县', '2730', '1', '西藏,日喀则市,仁布县', null, null, '542330', 'r', 'renbuxian', 'rbx');
INSERT INTO `yc_city` VALUES ('2741', '康马县', '2730', '1', '西藏,日喀则市,康马县', null, null, '542331', 'k', 'kangmaxian', 'kmx');
INSERT INTO `yc_city` VALUES ('2742', '定结县', '2730', '1', '西藏,日喀则市,定结县', null, null, '542332', 'd', 'dingjiexian', 'djx');
INSERT INTO `yc_city` VALUES ('2743', '仲巴县', '2730', '1', '西藏,日喀则市,仲巴县', null, null, '542333', 'z', 'zhongbaxian', 'zbx');
INSERT INTO `yc_city` VALUES ('2744', '亚东县', '2730', '1', '西藏,日喀则市,亚东县', null, null, '542334', 'y', 'yadongxian', 'ydx');
INSERT INTO `yc_city` VALUES ('2745', '吉隆县', '2730', '1', '西藏,日喀则市,吉隆县', null, null, '542335', 'j', 'jilongxian', 'jlx');
INSERT INTO `yc_city` VALUES ('2746', '聂拉木县', '2730', '1', '西藏,日喀则市,聂拉木县', null, null, '542336', 'n', 'nielamuxian', 'nlmx');
INSERT INTO `yc_city` VALUES ('2747', '萨嘎县', '2730', '1', '西藏,日喀则市,萨嘎县', null, null, '542337', 's', 'sagaxian', 'sgx');
INSERT INTO `yc_city` VALUES ('2748', '岗巴县', '2730', '1', '西藏,日喀则市,岗巴县', null, null, '542338', 'g', 'gangbaxian', 'gbx');
INSERT INTO `yc_city` VALUES ('2749', '昌都地区', '2720', '1', '西藏,昌都地区', null, null, '542100', 'c', 'changdudiqu', 'cddq');
INSERT INTO `yc_city` VALUES ('2750', '昌都县', '2749', '1', '西藏,昌都地区,昌都县', null, null, '542121', 'c', 'changduxian', 'cdx');
INSERT INTO `yc_city` VALUES ('2751', '江达县', '2749', '1', '西藏,昌都地区,江达县', null, null, '542122', 'j', 'jiangdaxian', 'jdx');
INSERT INTO `yc_city` VALUES ('2752', '贡觉县', '2749', '1', '西藏,昌都地区,贡觉县', null, null, '542123', 'g', 'gongjuexian', 'gjx');
INSERT INTO `yc_city` VALUES ('2753', '类乌齐县', '2749', '1', '西藏,昌都地区,类乌齐县', null, null, '542124', 'l', 'leiwuqixian', 'lwqx');
INSERT INTO `yc_city` VALUES ('2754', '丁青县', '2749', '1', '西藏,昌都地区,丁青县', null, null, '542125', 'd', 'dingqingxian', 'dqx');
INSERT INTO `yc_city` VALUES ('2755', '察雅县', '2749', '1', '西藏,昌都地区,察雅县', null, null, '542126', 'c', 'chayaxian', 'cyx');
INSERT INTO `yc_city` VALUES ('2756', '八宿县', '2749', '1', '西藏,昌都地区,八宿县', null, null, '542127', 'b', 'basuxian', 'bsx');
INSERT INTO `yc_city` VALUES ('2757', '左贡县', '2749', '1', '西藏,昌都地区,左贡县', null, null, '542128', 'z', 'zuogongxian', 'zgx');
INSERT INTO `yc_city` VALUES ('2758', '芒康县', '2749', '1', '西藏,昌都地区,芒康县', null, null, '542129', 'm', 'mangkangxian', 'mkx');
INSERT INTO `yc_city` VALUES ('2759', '洛隆县', '2749', '1', '西藏,昌都地区,洛隆县', null, null, '542132', 'l', 'luolongxian', 'llx');
INSERT INTO `yc_city` VALUES ('2760', '边坝县', '2749', '1', '西藏,昌都地区,边坝县', null, null, '542133', 'b', 'bianbaxian', 'bbx');
INSERT INTO `yc_city` VALUES ('2761', '山南地区', '2720', '1', '西藏,山南地区', null, null, '542200', 's', 'shannandiqu', 'sndq');
INSERT INTO `yc_city` VALUES ('2762', '乃东县', '2761', '1', '西藏,山南地区,乃东县', null, null, '542221', 'n', 'naidongxian', 'ndx');
INSERT INTO `yc_city` VALUES ('2763', '扎囊县', '2761', '1', '西藏,山南地区,扎囊县', null, null, '542222', 'z', 'zanangxian', 'znx');
INSERT INTO `yc_city` VALUES ('2764', '贡嘎县', '2761', '1', '西藏,山南地区,贡嘎县', null, null, '542223', 'g', 'gonggaxian', 'ggx');
INSERT INTO `yc_city` VALUES ('2765', '桑日县', '2761', '1', '西藏,山南地区,桑日县', null, null, '542224', 's', 'sangrixian', 'srx');
INSERT INTO `yc_city` VALUES ('2766', '琼结县', '2761', '1', '西藏,山南地区,琼结县', null, null, '542225', 'q', 'qiongjiexian', 'qjx');
INSERT INTO `yc_city` VALUES ('2767', '曲松县', '2761', '1', '西藏,山南地区,曲松县', null, null, '542226', 'q', 'qusongxian', 'qsx');
INSERT INTO `yc_city` VALUES ('2768', '措美县', '2761', '1', '西藏,山南地区,措美县', null, null, '542227', 'c', 'cuomeixian', 'cmx');
INSERT INTO `yc_city` VALUES ('2769', '洛扎县', '2761', '1', '西藏,山南地区,洛扎县', null, null, '542228', 'l', 'luozhaxian', 'lzx');
INSERT INTO `yc_city` VALUES ('2770', '加查县', '2761', '1', '西藏,山南地区,加查县', null, null, '542229', 'j', 'jiachaxian', 'jcx');
INSERT INTO `yc_city` VALUES ('2771', '隆子县', '2761', '1', '西藏,山南地区,隆子县', null, null, '542231', 'l', 'longzixian', 'lzx');
INSERT INTO `yc_city` VALUES ('2772', '错那县', '2761', '1', '西藏,山南地区,错那县', null, null, '542232', 'c', 'cuonaxian', 'cnx');
INSERT INTO `yc_city` VALUES ('2773', '浪卡子县', '2761', '1', '西藏,山南地区,浪卡子县', null, null, '542233', 'l', 'langkazixian', 'lkzx');
INSERT INTO `yc_city` VALUES ('2774', '那曲地区', '2720', '1', '西藏,那曲地区', null, null, '542400', 'n', 'naqudiqu', 'nqdq');
INSERT INTO `yc_city` VALUES ('2775', '那曲县', '2774', '1', '西藏,那曲地区,那曲县', null, null, '542421', 'n', 'naquxian', 'nqx');
INSERT INTO `yc_city` VALUES ('2776', '嘉黎县', '2774', '1', '西藏,那曲地区,嘉黎县', null, null, '542422', 'j', 'jialixian', 'jlx');
INSERT INTO `yc_city` VALUES ('2777', '比如县', '2774', '1', '西藏,那曲地区,比如县', null, null, '542423', 'b', 'biruxian', 'brx');
INSERT INTO `yc_city` VALUES ('2778', '聂荣县', '2774', '1', '西藏,那曲地区,聂荣县', null, null, '542424', 'n', 'nierongxian', 'nrx');
INSERT INTO `yc_city` VALUES ('2779', '安多县', '2774', '1', '西藏,那曲地区,安多县', null, null, '542425', 'a', 'anduoxian', 'adx');
INSERT INTO `yc_city` VALUES ('2780', '申扎县', '2774', '1', '西藏,那曲地区,申扎县', null, null, '542426', 's', 'shenzhaxian', 'szx');
INSERT INTO `yc_city` VALUES ('2781', '索县', '2774', '1', '西藏,那曲地区,索县', null, null, '542427', 's', 'suoxian', 'sx');
INSERT INTO `yc_city` VALUES ('2782', '班戈县', '2774', '1', '西藏,那曲地区,班戈县', null, null, '542428', 'b', 'bangexian', 'bgx');
INSERT INTO `yc_city` VALUES ('2783', '巴青县', '2774', '1', '西藏,那曲地区,巴青县', null, null, '542429', 'b', 'baqingxian', 'bqx');
INSERT INTO `yc_city` VALUES ('2784', '尼玛县', '2774', '1', '西藏,那曲地区,尼玛县', null, null, '542430', 'n', 'nimaxian', 'nmx');
INSERT INTO `yc_city` VALUES ('2785', '双湖县', '2774', '1', '西藏,那曲地区,双湖县', null, null, null, 's', 'shuanghuxian', 'shx');
INSERT INTO `yc_city` VALUES ('2786', '阿里地区', '2720', '1', '西藏,阿里地区', null, null, '542500', 'a', 'alidiqu', 'aldq');
INSERT INTO `yc_city` VALUES ('2787', '普兰县', '2786', '1', '西藏,阿里地区,普兰县', null, null, '542521', 'p', 'pulanxian', 'plx');
INSERT INTO `yc_city` VALUES ('2788', '札达县', '2786', '1', '西藏,阿里地区,札达县', null, null, '542522', 'z', 'zhadaxian', 'zdx');
INSERT INTO `yc_city` VALUES ('2789', '噶尔县', '2786', '1', '西藏,阿里地区,噶尔县', null, null, '542523', 'g', 'gaerxian', 'gex');
INSERT INTO `yc_city` VALUES ('2790', '日土县', '2786', '1', '西藏,阿里地区,日土县', null, null, '542524', 'r', 'rituxian', 'rtx');
INSERT INTO `yc_city` VALUES ('2791', '革吉县', '2786', '1', '西藏,阿里地区,革吉县', null, null, '542525', 'g', 'gejixian', 'gjx');
INSERT INTO `yc_city` VALUES ('2792', '改则县', '2786', '1', '西藏,阿里地区,改则县', null, null, '542526', 'g', 'gaizexian', 'gzx');
INSERT INTO `yc_city` VALUES ('2793', '措勤县', '2786', '1', '西藏,阿里地区,措勤县', null, null, '542527', 'c', 'cuoqinxian', 'cqx');
INSERT INTO `yc_city` VALUES ('2794', '林芝地区', '2720', '1', '西藏,林芝地区', null, null, '542600', 'l', 'linzhidiqu', 'lzdq');
INSERT INTO `yc_city` VALUES ('2795', '林芝县', '2794', '1', '西藏,林芝地区,林芝县', null, null, '542621', 'l', 'linzhixian', 'lzx');
INSERT INTO `yc_city` VALUES ('2796', '工布江达县', '2794', '1', '西藏,林芝地区,工布江达县', null, null, '542622', 'g', 'gongbujiangdaxian', 'gbjdx');
INSERT INTO `yc_city` VALUES ('2797', '米林县', '2794', '1', '西藏,林芝地区,米林县', null, null, '542623', 'm', 'milinxian', 'mlx');
INSERT INTO `yc_city` VALUES ('2798', '墨脱县', '2794', '1', '西藏,林芝地区,墨脱县', null, null, '542624', 'm', 'motuoxian', 'mtx');
INSERT INTO `yc_city` VALUES ('2799', '波密县', '2794', '1', '西藏,林芝地区,波密县', null, null, '542625', 'b', 'bomixian', 'bmx');
INSERT INTO `yc_city` VALUES ('2800', '察隅县', '2794', '1', '西藏,林芝地区,察隅县', null, null, '542626', 'c', 'chayuxian', 'cyx');
INSERT INTO `yc_city` VALUES ('2801', '朗县', '2794', '1', '西藏,林芝地区,朗县', null, null, '542627', 'l', 'langxian', 'lx');
INSERT INTO `yc_city` VALUES ('2802', '陕西', '1', '1', '陕西', null, null, '610000', 's', 'shanxi1', 'sx');
INSERT INTO `yc_city` VALUES ('2803', '西安市', '2802', '1', '陕西,西安市', null, null, '610100', 'x', 'xianshi', 'xas');
INSERT INTO `yc_city` VALUES ('2804', '新城区', '2803', '1', '陕西,西安市,新城区', null, null, '610102', 'x', 'xinchengqu', 'xcq');
INSERT INTO `yc_city` VALUES ('2805', '碑林区', '2803', '1', '陕西,西安市,碑林区', null, null, '610103', 'b', 'beilinqu', 'blq');
INSERT INTO `yc_city` VALUES ('2806', '莲湖区', '2803', '1', '陕西,西安市,莲湖区', null, null, '610104', 'l', 'lianhuqu', 'lhq');
INSERT INTO `yc_city` VALUES ('2807', '灞桥区', '2803', '1', '陕西,西安市,灞桥区', null, null, '610111', 'b', 'baqiaoqu', 'qq');
INSERT INTO `yc_city` VALUES ('2808', '未央区', '2803', '1', '陕西,西安市,未央区', null, null, '610112', 'w', 'weiyangqu', 'wyq');
INSERT INTO `yc_city` VALUES ('2809', '雁塔区', '2803', '1', '陕西,西安市,雁塔区', null, null, '610113', 'y', 'yantaqu', 'ytq');
INSERT INTO `yc_city` VALUES ('2810', '阎良区', '2803', '1', '陕西,西安市,阎良区', null, null, '610114', 'y', 'yanliangqu', 'ylq');
INSERT INTO `yc_city` VALUES ('2811', '临潼区', '2803', '1', '陕西,西安市,临潼区', null, null, '610115', 'l', 'lintongqu', 'lq');
INSERT INTO `yc_city` VALUES ('2812', '长安区', '2803', '1', '陕西,西安市,长安区', null, null, '610116', 'c', 'changanqu', 'caq');
INSERT INTO `yc_city` VALUES ('2813', '蓝田县', '2803', '1', '陕西,西安市,蓝田县', null, null, '610122', 'l', 'lantianxian', 'ltx');
INSERT INTO `yc_city` VALUES ('2814', '周至县', '2803', '1', '陕西,西安市,周至县', null, null, '610124', 'z', 'zhouzhixian', 'zzx');
INSERT INTO `yc_city` VALUES ('2815', '户县', '2803', '1', '陕西,西安市,户县', null, null, '610125', 'h', 'huxian', 'hx');
INSERT INTO `yc_city` VALUES ('2816', '高陵县', '2803', '1', '陕西,西安市,高陵县', null, null, '610126', 'g', 'gaolingxian', 'glx');
INSERT INTO `yc_city` VALUES ('2817', '铜川市', '2802', '1', '陕西,铜川市', null, null, '610200', 't', 'tongchuanshi', 'tcs');
INSERT INTO `yc_city` VALUES ('2818', '王益区', '2817', '1', '陕西,铜川市,王益区', null, null, '610202', 'w', 'wangyiqu', 'wyq');
INSERT INTO `yc_city` VALUES ('2819', '印台区', '2817', '1', '陕西,铜川市,印台区', null, null, '610203', 'y', 'yintaiqu', 'ytq');
INSERT INTO `yc_city` VALUES ('2820', '耀州区', '2817', '1', '陕西,铜川市,耀州区', null, null, '610204', 'y', 'yaozhouqu', 'yzq');
INSERT INTO `yc_city` VALUES ('2821', '宜君县', '2817', '1', '陕西,铜川市,宜君县', null, null, '610222', 'y', 'yijunxian', 'yjx');
INSERT INTO `yc_city` VALUES ('2822', '宝鸡市', '2802', '1', '陕西,宝鸡市', null, null, '610300', 'b', 'baojishi', 'bjs');
INSERT INTO `yc_city` VALUES ('2823', '渭滨区', '2822', '1', '陕西,宝鸡市,渭滨区', null, null, '610302', 'w', 'weibinqu', 'wbq');
INSERT INTO `yc_city` VALUES ('2824', '金台区', '2822', '1', '陕西,宝鸡市,金台区', null, null, '610303', 'j', 'jintaiqu', 'jtq');
INSERT INTO `yc_city` VALUES ('2825', '陈仓区', '2822', '1', '陕西,宝鸡市,陈仓区', null, null, '610304', 'c', 'chencangqu', 'ccq');
INSERT INTO `yc_city` VALUES ('2826', '凤翔县', '2822', '1', '陕西,宝鸡市,凤翔县', null, null, '610322', 'f', 'fengxiangxian', 'fxx');
INSERT INTO `yc_city` VALUES ('2827', '岐山县', '2822', '1', '陕西,宝鸡市,岐山县', null, null, '610323', 'q', 'qishanxian', 'sx');
INSERT INTO `yc_city` VALUES ('2828', '扶风县', '2822', '1', '陕西,宝鸡市,扶风县', null, null, '610324', 'f', 'fufengxian', 'ffx');
INSERT INTO `yc_city` VALUES ('2829', '眉县', '2822', '1', '陕西,宝鸡市,眉县', null, null, '610326', 'm', 'meixian', 'mx');
INSERT INTO `yc_city` VALUES ('2830', '陇县', '2822', '1', '陕西,宝鸡市,陇县', null, null, '610327', 'l', 'longxian', 'lx');
INSERT INTO `yc_city` VALUES ('2831', '千阳县', '2822', '1', '陕西,宝鸡市,千阳县', null, null, '610328', 'q', 'qianyangxian', 'qyx');
INSERT INTO `yc_city` VALUES ('2832', '麟游县', '2822', '1', '陕西,宝鸡市,麟游县', null, null, '610329', 'l', 'linyouxian', 'yx');
INSERT INTO `yc_city` VALUES ('2833', '凤县', '2822', '1', '陕西,宝鸡市,凤县', null, null, '610330', 'f', 'fengxian', 'fx');
INSERT INTO `yc_city` VALUES ('2834', '太白县', '2822', '1', '陕西,宝鸡市,太白县', null, null, '610331', 't', 'taibaixian', 'tbx');
INSERT INTO `yc_city` VALUES ('2835', '咸阳市', '2802', '1', '陕西,咸阳市', null, null, '610400', 'x', 'xianyangshi', 'xys');
INSERT INTO `yc_city` VALUES ('2836', '秦都区', '2835', '1', '陕西,咸阳市,秦都区', null, null, '610402', 'q', 'qinduqu', 'qdq');
INSERT INTO `yc_city` VALUES ('2837', '杨陵区', '2835', '1', '陕西,咸阳市,杨陵区', null, null, null, 'y', 'yanglingqu', 'ylq');
INSERT INTO `yc_city` VALUES ('2838', '渭城区', '2835', '1', '陕西,咸阳市,渭城区', null, null, '610404', 'w', 'weichengqu', 'wcq');
INSERT INTO `yc_city` VALUES ('2839', '三原县', '2835', '1', '陕西,咸阳市,三原县', null, null, '610422', 's', 'sanyuanxian', 'syx');
INSERT INTO `yc_city` VALUES ('2840', '泾阳县', '2835', '1', '陕西,咸阳市,泾阳县', null, null, '610423', 'j', 'jingyangxian', 'yx');
INSERT INTO `yc_city` VALUES ('2841', '乾县', '2835', '1', '陕西,咸阳市,乾县', null, null, '610424', 'q', 'qianxian', 'qx');
INSERT INTO `yc_city` VALUES ('2842', '礼泉县', '2835', '1', '陕西,咸阳市,礼泉县', null, null, '610425', 'l', 'liquanxian', 'lqx');
INSERT INTO `yc_city` VALUES ('2843', '永寿县', '2835', '1', '陕西,咸阳市,永寿县', null, null, '610426', 'y', 'yongshouxian', 'ysx');
INSERT INTO `yc_city` VALUES ('2844', '彬县', '2835', '1', '陕西,咸阳市,彬县', null, null, '610427', 'b', 'binxian', 'bx');
INSERT INTO `yc_city` VALUES ('2845', '长武县', '2835', '1', '陕西,咸阳市,长武县', null, null, '610428', 'c', 'changwuxian', 'cwx');
INSERT INTO `yc_city` VALUES ('2846', '旬邑县', '2835', '1', '陕西,咸阳市,旬邑县', null, null, '610429', 'x', 'xunyixian', 'xyx');
INSERT INTO `yc_city` VALUES ('2847', '淳化县', '2835', '1', '陕西,咸阳市,淳化县', null, null, '610430', 'c', 'chunhuaxian', 'chx');
INSERT INTO `yc_city` VALUES ('2848', '武功县', '2835', '1', '陕西,咸阳市,武功县', null, null, '610431', 'w', 'wugongxian', 'wgx');
INSERT INTO `yc_city` VALUES ('2849', '兴平市', '2835', '1', '陕西,咸阳市,兴平市', null, null, '610481', 'x', 'xingpingshi', 'xps');
INSERT INTO `yc_city` VALUES ('2850', '渭南市', '2802', '1', '陕西,渭南市', null, null, '610500', 'w', 'weinanshi', 'wns');
INSERT INTO `yc_city` VALUES ('2851', '临渭区', '2850', '1', '陕西,渭南市,临渭区', null, null, '610502', 'l', 'linweiqu', 'lwq');
INSERT INTO `yc_city` VALUES ('2852', '华县', '2850', '1', '陕西,渭南市,华县', null, null, '610521', 'h', 'huaxian', 'hx');
INSERT INTO `yc_city` VALUES ('2853', '潼关县', '2850', '1', '陕西,渭南市,潼关县', null, null, '610522', 't', 'tongguanxian', 'gx');
INSERT INTO `yc_city` VALUES ('2854', '大荔县', '2850', '1', '陕西,渭南市,大荔县', null, null, '610523', 'd', 'dalixian', 'dlx');
INSERT INTO `yc_city` VALUES ('2855', '合阳县', '2850', '1', '陕西,渭南市,合阳县', null, null, '610524', 'h', 'heyangxian', 'hyx');
INSERT INTO `yc_city` VALUES ('2856', '澄城县', '2850', '1', '陕西,渭南市,澄城县', null, null, '610525', 'c', 'chengchengxian', 'ccx');
INSERT INTO `yc_city` VALUES ('2857', '蒲城县', '2850', '1', '陕西,渭南市,蒲城县', null, null, '610526', 'p', 'puchengxian', 'pcx');
INSERT INTO `yc_city` VALUES ('2858', '白水县', '2850', '1', '陕西,渭南市,白水县', null, null, '610527', 'b', 'baishuixian', 'bsx');
INSERT INTO `yc_city` VALUES ('2859', '富平县', '2850', '1', '陕西,渭南市,富平县', null, null, '610528', 'f', 'fupingxian', 'fpx');
INSERT INTO `yc_city` VALUES ('2860', '韩城市', '2850', '1', '陕西,渭南市,韩城市', null, null, '610581', 'h', 'hanchengshi', 'hcs');
INSERT INTO `yc_city` VALUES ('2861', '华阴市', '2850', '1', '陕西,渭南市,华阴市', null, null, '610582', 'h', 'huayinshi', 'hys');
INSERT INTO `yc_city` VALUES ('2862', '延安市', '2802', '1', '陕西,延安市', null, null, '610600', 'y', 'yananshi', 'yas');
INSERT INTO `yc_city` VALUES ('2863', '宝塔区', '2862', '1', '陕西,延安市,宝塔区', null, null, '610602', 'b', 'baotaqu', 'btq');
INSERT INTO `yc_city` VALUES ('2864', '延长县', '2862', '1', '陕西,延安市,延长县', null, null, '610621', 'y', 'yanchangxian', 'ycx');
INSERT INTO `yc_city` VALUES ('2865', '延川县', '2862', '1', '陕西,延安市,延川县', null, null, '610622', 'y', 'yanchuanxian', 'ycx');
INSERT INTO `yc_city` VALUES ('2866', '子长县', '2862', '1', '陕西,延安市,子长县', null, null, '610623', 'z', 'zichangxian', 'zcx');
INSERT INTO `yc_city` VALUES ('2867', '安塞县', '2862', '1', '陕西,延安市,安塞县', null, null, '610624', 'a', 'ansaixian', 'asx');
INSERT INTO `yc_city` VALUES ('2868', '志丹县', '2862', '1', '陕西,延安市,志丹县', null, null, '610625', 'z', 'zhidanxian', 'zdx');
INSERT INTO `yc_city` VALUES ('2869', '吴起县', '2862', '1', '陕西,延安市,吴起县', null, null, '610626', 'w', 'wuqixian', 'wqx');
INSERT INTO `yc_city` VALUES ('2870', '甘泉县', '2862', '1', '陕西,延安市,甘泉县', null, null, '610627', 'g', 'ganquanxian', 'gqx');
INSERT INTO `yc_city` VALUES ('2871', '富县', '2862', '1', '陕西,延安市,富县', null, null, '610628', 'f', 'fuxian', 'fx');
INSERT INTO `yc_city` VALUES ('2872', '洛川县', '2862', '1', '陕西,延安市,洛川县', null, null, '610629', 'l', 'luochuanxian', 'lcx');
INSERT INTO `yc_city` VALUES ('2873', '宜川县', '2862', '1', '陕西,延安市,宜川县', null, null, '610630', 'y', 'yichuanxian', 'ycx');
INSERT INTO `yc_city` VALUES ('2874', '黄龙县', '2862', '1', '陕西,延安市,黄龙县', null, null, '610631', 'h', 'huanglongxian', 'hlx');
INSERT INTO `yc_city` VALUES ('2875', '黄陵县', '2862', '1', '陕西,延安市,黄陵县', null, null, '610632', 'h', 'huanglingxian', 'hlx');
INSERT INTO `yc_city` VALUES ('2876', '汉中市', '2802', '1', '陕西,汉中市', null, null, '610700', 'h', 'hanzhongshi', 'hzs');
INSERT INTO `yc_city` VALUES ('2877', '汉台区', '2876', '1', '陕西,汉中市,汉台区', null, null, '610702', 'h', 'hantaiqu', 'htq');
INSERT INTO `yc_city` VALUES ('2878', '南郑县', '2876', '1', '陕西,汉中市,南郑县', null, null, '610721', 'n', 'nanzhengxian', 'nzx');
INSERT INTO `yc_city` VALUES ('2879', '城固县', '2876', '1', '陕西,汉中市,城固县', null, null, '610722', 'c', 'chengguxian', 'cgx');
INSERT INTO `yc_city` VALUES ('2880', '洋县', '2876', '1', '陕西,汉中市,洋县', null, null, '610723', 'y', 'yangxian', 'yx');
INSERT INTO `yc_city` VALUES ('2881', '西乡县', '2876', '1', '陕西,汉中市,西乡县', null, null, '610724', 'x', 'xixiangxian', 'xxx');
INSERT INTO `yc_city` VALUES ('2882', '勉县', '2876', '1', '陕西,汉中市,勉县', null, null, '610725', 'm', 'mianxian', 'mx');
INSERT INTO `yc_city` VALUES ('2883', '宁强县', '2876', '1', '陕西,汉中市,宁强县', null, null, '610726', 'n', 'ningqiangxian', 'nqx');
INSERT INTO `yc_city` VALUES ('2884', '略阳县', '2876', '1', '陕西,汉中市,略阳县', null, null, '610727', 'l', 'lueyangxian', 'lyx');
INSERT INTO `yc_city` VALUES ('2885', '镇巴县', '2876', '1', '陕西,汉中市,镇巴县', null, null, '610728', 'z', 'zhenbaxian', 'zbx');
INSERT INTO `yc_city` VALUES ('2886', '留坝县', '2876', '1', '陕西,汉中市,留坝县', null, null, '610729', 'l', 'liubaxian', 'lbx');
INSERT INTO `yc_city` VALUES ('2887', '佛坪县', '2876', '1', '陕西,汉中市,佛坪县', null, null, '610730', 'f', 'fopingxian', 'fpx');
INSERT INTO `yc_city` VALUES ('2888', '榆林市', '2802', '1', '陕西,榆林市', null, null, '610800', 'y', 'yulinshi', 'yls');
INSERT INTO `yc_city` VALUES ('2889', '榆阳区', '2888', '1', '陕西,榆林市,榆阳区', null, null, '610802', 'y', 'yuyangqu', 'yyq');
INSERT INTO `yc_city` VALUES ('2890', '神木县', '2888', '1', '陕西,榆林市,神木县', null, null, '610821', 's', 'shenmuxian', 'smx');
INSERT INTO `yc_city` VALUES ('2891', '府谷县', '2888', '1', '陕西,榆林市,府谷县', null, null, '610822', 'f', 'fuguxian', 'fgx');
INSERT INTO `yc_city` VALUES ('2892', '横山县', '2888', '1', '陕西,榆林市,横山县', null, null, '610823', 'h', 'hengshanxian', 'hsx');
INSERT INTO `yc_city` VALUES ('2893', '靖边县', '2888', '1', '陕西,榆林市,靖边县', null, null, '610824', 'j', 'jingbianxian', 'jbx');
INSERT INTO `yc_city` VALUES ('2894', '定边县', '2888', '1', '陕西,榆林市,定边县', null, null, '610825', 'd', 'dingbianxian', 'dbx');
INSERT INTO `yc_city` VALUES ('2895', '绥德县', '2888', '1', '陕西,榆林市,绥德县', null, null, '610826', 's', 'suidexian', 'sdx');
INSERT INTO `yc_city` VALUES ('2896', '米脂县', '2888', '1', '陕西,榆林市,米脂县', null, null, '610827', 'm', 'mizhixian', 'mzx');
INSERT INTO `yc_city` VALUES ('2897', '佳县', '2888', '1', '陕西,榆林市,佳县', null, null, '610828', 'j', 'jiaxian', 'jx');
INSERT INTO `yc_city` VALUES ('2898', '吴堡县', '2888', '1', '陕西,榆林市,吴堡县', null, null, '610829', 'w', 'wubuxian', 'wbx');
INSERT INTO `yc_city` VALUES ('2899', '清涧县', '2888', '1', '陕西,榆林市,清涧县', null, null, '610830', 'q', 'qingjianxian', 'qjx');
INSERT INTO `yc_city` VALUES ('2900', '子洲县', '2888', '1', '陕西,榆林市,子洲县', null, null, '610831', 'z', 'zizhouxian', 'zzx');
INSERT INTO `yc_city` VALUES ('2901', '安康市', '2802', '1', '陕西,安康市', null, null, '610900', 'a', 'ankangshi', 'aks');
INSERT INTO `yc_city` VALUES ('2902', '汉滨区', '2901', '1', '陕西,安康市,汉滨区', null, null, '610902', 'h', 'hanbinqu', 'hbq');
INSERT INTO `yc_city` VALUES ('2903', '汉阴县', '2901', '1', '陕西,安康市,汉阴县', null, null, '610921', 'h', 'hanyinxian', 'hyx');
INSERT INTO `yc_city` VALUES ('2904', '石泉县', '2901', '1', '陕西,安康市,石泉县', null, null, '610922', 's', 'shiquanxian', 'sqx');
INSERT INTO `yc_city` VALUES ('2905', '宁陕县', '2901', '1', '陕西,安康市,宁陕县', null, null, '610923', 'n', 'ningshanxian', 'nsx');
INSERT INTO `yc_city` VALUES ('2906', '紫阳县', '2901', '1', '陕西,安康市,紫阳县', null, null, '610924', 'z', 'ziyangxian', 'zyx');
INSERT INTO `yc_city` VALUES ('2907', '岚皋县', '2901', '1', '陕西,安康市,岚皋县', null, null, '610925', 'l', 'langaoxian', 'gx');
INSERT INTO `yc_city` VALUES ('2908', '平利县', '2901', '1', '陕西,安康市,平利县', null, null, '610926', 'p', 'pinglixian', 'plx');
INSERT INTO `yc_city` VALUES ('2909', '镇坪县', '2901', '1', '陕西,安康市,镇坪县', null, null, '610927', 'z', 'zhenpingxian', 'zpx');
INSERT INTO `yc_city` VALUES ('2910', '旬阳县', '2901', '1', '陕西,安康市,旬阳县', null, null, '610928', 'x', 'xunyangxian', 'xyx');
INSERT INTO `yc_city` VALUES ('2911', '白河县', '2901', '1', '陕西,安康市,白河县', null, null, '610929', 'b', 'baihexian', 'bhx');
INSERT INTO `yc_city` VALUES ('2912', '商洛市', '2802', '1', '陕西,商洛市', null, null, '611000', 's', 'shangluoshi', 'sls');
INSERT INTO `yc_city` VALUES ('2913', '商州区', '2912', '1', '陕西,商洛市,商州区', null, null, '611002', 's', 'shangzhouqu', 'szq');
INSERT INTO `yc_city` VALUES ('2914', '洛南县', '2912', '1', '陕西,商洛市,洛南县', null, null, '611021', 'l', 'luonanxian', 'lnx');
INSERT INTO `yc_city` VALUES ('2915', '丹凤县', '2912', '1', '陕西,商洛市,丹凤县', null, null, '611022', 'd', 'danfengxian', 'dfx');
INSERT INTO `yc_city` VALUES ('2916', '商南县', '2912', '1', '陕西,商洛市,商南县', null, null, '611023', 's', 'shangnanxian', 'snx');
INSERT INTO `yc_city` VALUES ('2917', '山阳县', '2912', '1', '陕西,商洛市,山阳县', null, null, '611024', 's', 'shanyangxian', 'syx');
INSERT INTO `yc_city` VALUES ('2918', '镇安县', '2912', '1', '陕西,商洛市,镇安县', null, null, '611025', 'z', 'zhenanxian', 'zax');
INSERT INTO `yc_city` VALUES ('2919', '柞水县', '2912', '1', '陕西,商洛市,柞水县', null, null, '611026', 'z', 'zhashuixian', 'zsx');
INSERT INTO `yc_city` VALUES ('2920', '甘肃', '1', '1', '甘肃', null, null, '620000', 'g', 'gansu', 'gs');
INSERT INTO `yc_city` VALUES ('2921', '兰州市', '2920', '1', '甘肃,兰州市', null, null, '620100', 'l', 'lanzhoushi', 'lzs');
INSERT INTO `yc_city` VALUES ('2922', '城关区', '2921', '1', '甘肃,兰州市,城关区', null, null, '620102', 'c', 'chengguanqu', 'cgq');
INSERT INTO `yc_city` VALUES ('2923', '七里河区', '2921', '1', '甘肃,兰州市,七里河区', null, null, '620103', 'q', 'qilihequ', 'qlhq');
INSERT INTO `yc_city` VALUES ('2924', '西固区', '2921', '1', '甘肃,兰州市,西固区', null, null, '620104', 'x', 'xiguqu', 'xgq');
INSERT INTO `yc_city` VALUES ('2925', '安宁区', '2921', '1', '甘肃,兰州市,安宁区', null, null, '620105', 'a', 'anningqu', 'anq');
INSERT INTO `yc_city` VALUES ('2926', '红古区', '2921', '1', '甘肃,兰州市,红古区', null, null, '620111', 'h', 'hongguqu', 'hgq');
INSERT INTO `yc_city` VALUES ('2927', '永登县', '2921', '1', '甘肃,兰州市,永登县', null, null, '620121', 'y', 'yongdengxian', 'ydx');
INSERT INTO `yc_city` VALUES ('2928', '皋兰县', '2921', '1', '甘肃,兰州市,皋兰县', null, null, '620122', 'g', 'gaolanxian', 'glx');
INSERT INTO `yc_city` VALUES ('2929', '榆中县', '2921', '1', '甘肃,兰州市,榆中县', null, null, '620123', 'y', 'yuzhongxian', 'yzx');
INSERT INTO `yc_city` VALUES ('2930', '嘉峪关市', '2920', '1', '甘肃,嘉峪关市', null, null, '620200', 'j', 'jiayuguanshi', 'jygs');
INSERT INTO `yc_city` VALUES ('2931', '金昌市', '2920', '1', '甘肃,金昌市', null, null, '620300', 'j', 'jinchangshi', 'jcs');
INSERT INTO `yc_city` VALUES ('2932', '金川区', '2931', '1', '甘肃,金昌市,金川区', null, null, '620302', 'j', 'jinchuanqu', 'jcq');
INSERT INTO `yc_city` VALUES ('2933', '永昌县', '2931', '1', '甘肃,金昌市,永昌县', null, null, '620321', 'y', 'yongchangxian', 'ycx');
INSERT INTO `yc_city` VALUES ('2934', '白银市', '2920', '1', '甘肃,白银市', null, null, '620400', 'b', 'baiyinshi', 'bys');
INSERT INTO `yc_city` VALUES ('2935', '白银区', '2934', '1', '甘肃,白银市,白银区', null, null, '620402', 'b', 'baiyinqu', 'byq');
INSERT INTO `yc_city` VALUES ('2936', '平川区', '2934', '1', '甘肃,白银市,平川区', null, null, '620403', 'p', 'pingchuanqu', 'pcq');
INSERT INTO `yc_city` VALUES ('2937', '靖远县', '2934', '1', '甘肃,白银市,靖远县', null, null, '620421', 'j', 'jingyuanxian', 'jyx');
INSERT INTO `yc_city` VALUES ('2938', '会宁县', '2934', '1', '甘肃,白银市,会宁县', null, null, '620422', 'h', 'huiningxian', 'hnx');
INSERT INTO `yc_city` VALUES ('2939', '景泰县', '2934', '1', '甘肃,白银市,景泰县', null, null, '620423', 'j', 'jingtaixian', 'jtx');
INSERT INTO `yc_city` VALUES ('2940', '天水市', '2920', '1', '甘肃,天水市', null, null, '620500', 't', 'tianshuishi', 'tss');
INSERT INTO `yc_city` VALUES ('2941', '秦州区', '2940', '1', '甘肃,天水市,秦州区', null, null, '620502', 'q', 'qinzhouqu', 'qzq');
INSERT INTO `yc_city` VALUES ('2942', '麦积区', '2940', '1', '甘肃,天水市,麦积区', null, null, '620503', 'm', 'maijiqu', 'mjq');
INSERT INTO `yc_city` VALUES ('2943', '清水县', '2940', '1', '甘肃,天水市,清水县', null, null, '620521', 'q', 'qingshuixian', 'qsx');
INSERT INTO `yc_city` VALUES ('2944', '秦安县', '2940', '1', '甘肃,天水市,秦安县', null, null, '620522', 'q', 'qinanxian', 'qax');
INSERT INTO `yc_city` VALUES ('2945', '甘谷县', '2940', '1', '甘肃,天水市,甘谷县', null, null, '620523', 'g', 'ganguxian', 'ggx');
INSERT INTO `yc_city` VALUES ('2946', '武山县', '2940', '1', '甘肃,天水市,武山县', null, null, '620524', 'w', 'wushanxian', 'wsx');
INSERT INTO `yc_city` VALUES ('2947', '张家川回族自治县', '2940', '1', '甘肃,天水市,张家川回族自治县', null, null, '620525', 'z', 'zhangjiachuanhuizuzizhixian', 'zjchzzzx');
INSERT INTO `yc_city` VALUES ('2948', '武威市', '2920', '1', '甘肃,武威市', null, null, '620600', 'w', 'wuweishi', 'wws');
INSERT INTO `yc_city` VALUES ('2949', '凉州区', '2948', '1', '甘肃,武威市,凉州区', null, null, '620602', 'l', 'liangzhouqu', 'lzq');
INSERT INTO `yc_city` VALUES ('2950', '民勤县', '2948', '1', '甘肃,武威市,民勤县', null, null, '620621', 'm', 'minqinxian', 'mqx');
INSERT INTO `yc_city` VALUES ('2951', '古浪县', '2948', '1', '甘肃,武威市,古浪县', null, null, '620622', 'g', 'gulangxian', 'glx');
INSERT INTO `yc_city` VALUES ('2952', '天祝藏族自治县', '2948', '1', '甘肃,武威市,天祝藏族自治县', null, null, '620623', 't', 'tianzhuzangzuzizhixian', 'tzczzzx');
INSERT INTO `yc_city` VALUES ('2953', '张掖市', '2920', '1', '甘肃,张掖市', null, null, '620700', 'z', 'zhangyeshi', 'zys');
INSERT INTO `yc_city` VALUES ('2954', '甘州区', '2953', '1', '甘肃,张掖市,甘州区', null, null, '620702', 'g', 'ganzhouqu', 'gzq');
INSERT INTO `yc_city` VALUES ('2955', '肃南裕固族自治县', '2953', '1', '甘肃,张掖市,肃南裕固族自治县', null, null, '620721', 's', 'sunanyuguzuzizhixian', 'snygzzzx');
INSERT INTO `yc_city` VALUES ('2956', '民乐县', '2953', '1', '甘肃,张掖市,民乐县', null, null, '620722', 'm', 'minyuexian', 'mlx');
INSERT INTO `yc_city` VALUES ('2957', '临泽县', '2953', '1', '甘肃,张掖市,临泽县', null, null, '620723', 'l', 'linzexian', 'lzx');
INSERT INTO `yc_city` VALUES ('2958', '高台县', '2953', '1', '甘肃,张掖市,高台县', null, null, '620724', 'g', 'gaotaixian', 'gtx');
INSERT INTO `yc_city` VALUES ('2959', '山丹县', '2953', '1', '甘肃,张掖市,山丹县', null, null, '620725', 's', 'shandanxian', 'sdx');
INSERT INTO `yc_city` VALUES ('2960', '平凉市', '2920', '1', '甘肃,平凉市', null, null, '620800', 'p', 'pingliangshi', 'pls');
INSERT INTO `yc_city` VALUES ('2961', '崆峒区', '2960', '1', '甘肃,平凉市,崆峒区', null, null, '620802', 'k', 'kongtongqu', 'q');
INSERT INTO `yc_city` VALUES ('2962', '泾川县', '2960', '1', '甘肃,平凉市,泾川县', null, null, '620821', 'j', 'jingchuanxian', 'cx');
INSERT INTO `yc_city` VALUES ('2963', '灵台县', '2960', '1', '甘肃,平凉市,灵台县', null, null, '620822', 'l', 'lingtaixian', 'ltx');
INSERT INTO `yc_city` VALUES ('2964', '崇信县', '2960', '1', '甘肃,平凉市,崇信县', null, null, '620823', 'c', 'chongxinxian', 'cxx');
INSERT INTO `yc_city` VALUES ('2965', '华亭县', '2960', '1', '甘肃,平凉市,华亭县', null, null, '620824', 'h', 'huatingxian', 'htx');
INSERT INTO `yc_city` VALUES ('2966', '庄浪县', '2960', '1', '甘肃,平凉市,庄浪县', null, null, '620825', 'z', 'zhuanglangxian', 'zlx');
INSERT INTO `yc_city` VALUES ('2967', '静宁县', '2960', '1', '甘肃,平凉市,静宁县', null, null, '620826', 'j', 'jingningxian', 'jnx');
INSERT INTO `yc_city` VALUES ('2968', '酒泉市', '2920', '1', '甘肃,酒泉市', null, null, '620900', 'j', 'jiuquanshi', 'jqs');
INSERT INTO `yc_city` VALUES ('2969', '肃州区', '2968', '1', '甘肃,酒泉市,肃州区', null, null, '620902', 's', 'suzhouqu', 'szq');
INSERT INTO `yc_city` VALUES ('2970', '金塔县', '2968', '1', '甘肃,酒泉市,金塔县', null, null, '620921', 'j', 'jintaxian', 'jtx');
INSERT INTO `yc_city` VALUES ('2971', '瓜州县', '2968', '1', '甘肃,酒泉市,瓜州县', null, null, '620922', 'g', 'guazhouxian', 'gzx');
INSERT INTO `yc_city` VALUES ('2972', '肃北蒙古族自治县', '2968', '1', '甘肃,酒泉市,肃北蒙古族自治县', null, null, '620923', 's', 'subeimengguzuzizhixian', 'sbmgzzzx');
INSERT INTO `yc_city` VALUES ('2973', '阿克塞哈萨克族自治县', '2968', '1', '甘肃,酒泉市,阿克塞哈萨克族自治县', null, null, '620924', 'a', 'akesaihasakezuzizhixian', 'akshskzzzx');
INSERT INTO `yc_city` VALUES ('2974', '玉门市', '2968', '1', '甘肃,酒泉市,玉门市', null, null, '620981', 'y', 'yumenshi', 'yms');
INSERT INTO `yc_city` VALUES ('2975', '敦煌市', '2968', '1', '甘肃,酒泉市,敦煌市', null, null, '620982', 'd', 'dunhuangshi', 'dhs');
INSERT INTO `yc_city` VALUES ('2976', '庆阳市', '2920', '1', '甘肃,庆阳市', null, null, '621000', 'q', 'qingyangshi', 'qys');
INSERT INTO `yc_city` VALUES ('2977', '西峰区', '2976', '1', '甘肃,庆阳市,西峰区', null, null, '621002', 'x', 'xifengqu', 'xfq');
INSERT INTO `yc_city` VALUES ('2978', '庆城县', '2976', '1', '甘肃,庆阳市,庆城县', null, null, '621021', 'q', 'qingchengxian', 'qcx');
INSERT INTO `yc_city` VALUES ('2979', '环县', '2976', '1', '甘肃,庆阳市,环县', null, null, '621022', 'h', 'huanxian', 'hx');
INSERT INTO `yc_city` VALUES ('2980', '华池县', '2976', '1', '甘肃,庆阳市,华池县', null, null, '621023', 'h', 'huachixian', 'hcx');
INSERT INTO `yc_city` VALUES ('2981', '合水县', '2976', '1', '甘肃,庆阳市,合水县', null, null, '621024', 'h', 'heshuixian', 'hsx');
INSERT INTO `yc_city` VALUES ('2982', '正宁县', '2976', '1', '甘肃,庆阳市,正宁县', null, null, '621025', 'z', 'zhengningxian', 'znx');
INSERT INTO `yc_city` VALUES ('2983', '宁县', '2976', '1', '甘肃,庆阳市,宁县', null, null, '621026', 'n', 'ningxian', 'nx');
INSERT INTO `yc_city` VALUES ('2984', '镇原县', '2976', '1', '甘肃,庆阳市,镇原县', null, null, '621027', 'z', 'zhenyuanxian', 'zyx');
INSERT INTO `yc_city` VALUES ('2985', '定西市', '2920', '1', '甘肃,定西市', null, null, '621100', 'd', 'dingxishi', 'dxs');
INSERT INTO `yc_city` VALUES ('2986', '安定区', '2985', '1', '甘肃,定西市,安定区', null, null, '621102', 'a', 'andingqu', 'adq');
INSERT INTO `yc_city` VALUES ('2987', '通渭县', '2985', '1', '甘肃,定西市,通渭县', null, null, '621121', 't', 'tongweixian', 'twx');
INSERT INTO `yc_city` VALUES ('2988', '陇西县', '2985', '1', '甘肃,定西市,陇西县', null, null, '621122', 'l', 'longxixian', 'lxx');
INSERT INTO `yc_city` VALUES ('2989', '渭源县', '2985', '1', '甘肃,定西市,渭源县', null, null, '621123', 'w', 'weiyuanxian', 'wyx');
INSERT INTO `yc_city` VALUES ('2990', '临洮县', '2985', '1', '甘肃,定西市,临洮县', null, null, '621124', 'l', 'lintaoxian', 'lx');
INSERT INTO `yc_city` VALUES ('2991', '漳县', '2985', '1', '甘肃,定西市,漳县', null, null, '621125', 'z', 'zhangxian', 'zx');
INSERT INTO `yc_city` VALUES ('2992', '岷县', '2985', '1', '甘肃,定西市,岷县', null, null, '621126', 'm', 'minxian', 'x');
INSERT INTO `yc_city` VALUES ('2993', '陇南市', '2920', '1', '甘肃,陇南市', null, null, '621200', 'l', 'longnanshi', 'lns');
INSERT INTO `yc_city` VALUES ('2994', '武都区', '2993', '1', '甘肃,陇南市,武都区', null, null, '621202', 'w', 'wuduqu', 'wdq');
INSERT INTO `yc_city` VALUES ('2995', '成县', '2993', '1', '甘肃,陇南市,成县', null, null, '621221', 'c', 'chengxian', 'cx');
INSERT INTO `yc_city` VALUES ('2996', '文县', '2993', '1', '甘肃,陇南市,文县', null, null, '621222', 'w', 'wenxian', 'wx');
INSERT INTO `yc_city` VALUES ('2997', '宕昌县', '2993', '1', '甘肃,陇南市,宕昌县', null, null, '621223', 'd', 'dangchangxian', 'cx');
INSERT INTO `yc_city` VALUES ('2998', '康县', '2993', '1', '甘肃,陇南市,康县', null, null, '621224', 'k', 'kangxian', 'kx');
INSERT INTO `yc_city` VALUES ('2999', '西和县', '2993', '1', '甘肃,陇南市,西和县', null, null, '621225', 'x', 'xihexian', 'xhx');
INSERT INTO `yc_city` VALUES ('3000', '礼县', '2993', '1', '甘肃,陇南市,礼县', null, null, '621226', 'l', 'lixian', 'lx');
INSERT INTO `yc_city` VALUES ('3001', '徽县', '2993', '1', '甘肃,陇南市,徽县', null, null, '621227', 'h', 'huixian', 'hx');
INSERT INTO `yc_city` VALUES ('3002', '两当县', '2993', '1', '甘肃,陇南市,两当县', null, null, '621228', 'l', 'liangdangxian', 'ldx');
INSERT INTO `yc_city` VALUES ('3003', '临夏回族自治州', '2920', '1', '甘肃,临夏回族自治州', null, null, '622900', 'l', 'linxiahuizuzizhizhou', 'lxhzzzz');
INSERT INTO `yc_city` VALUES ('3004', '临夏市', '3003', '1', '甘肃,临夏回族自治州,临夏市', null, null, '622901', 'l', 'linxiashi', 'lxs');
INSERT INTO `yc_city` VALUES ('3005', '临夏县', '3003', '1', '甘肃,临夏回族自治州,临夏县', null, null, '622921', 'l', 'linxiaxian', 'lxx');
INSERT INTO `yc_city` VALUES ('3006', '康乐县', '3003', '1', '甘肃,临夏回族自治州,康乐县', null, null, '622922', 'k', 'kanglexian', 'klx');
INSERT INTO `yc_city` VALUES ('3007', '永靖县', '3003', '1', '甘肃,临夏回族自治州,永靖县', null, null, '622923', 'y', 'yongjingxian', 'yjx');
INSERT INTO `yc_city` VALUES ('3008', '广河县', '3003', '1', '甘肃,临夏回族自治州,广河县', null, null, '622924', 'g', 'guanghexian', 'ghx');
INSERT INTO `yc_city` VALUES ('3009', '和政县', '3003', '1', '甘肃,临夏回族自治州,和政县', null, null, '622925', 'h', 'hezhengxian', 'hzx');
INSERT INTO `yc_city` VALUES ('3010', '东乡族自治县', '3003', '1', '甘肃,临夏回族自治州,东乡族自治县', null, null, '622926', 'd', 'dongxiangzuzizhixian', 'dxzzzx');
INSERT INTO `yc_city` VALUES ('3011', '积石山保安族东乡族撒拉族自治县', '3003', '1', '甘肃,临夏回族自治州,积石山保安族东乡族撒拉族自治县', null, null, '622927', 'j', 'jishishanbaoanzudongxiangzusalazuzizhixian', 'jssbazdxzslzzzx');
INSERT INTO `yc_city` VALUES ('3012', '甘南藏族自治州', '2920', '1', '甘肃,甘南藏族自治州', null, null, '623000', 'g', 'gannanzangzuzizhizhou', 'gnczzzz');
INSERT INTO `yc_city` VALUES ('3013', '合作市', '3012', '1', '甘肃,甘南藏族自治州,合作市', null, null, '623001', 'h', 'hezuoshi', 'hzs');
INSERT INTO `yc_city` VALUES ('3014', '临潭县', '3012', '1', '甘肃,甘南藏族自治州,临潭县', null, null, '623021', 'l', 'lintanxian', 'ltx');
INSERT INTO `yc_city` VALUES ('3015', '卓尼县', '3012', '1', '甘肃,甘南藏族自治州,卓尼县', null, null, '623022', 'z', 'zhuonixian', 'znx');
INSERT INTO `yc_city` VALUES ('3016', '舟曲县', '3012', '1', '甘肃,甘南藏族自治州,舟曲县', null, null, '623023', 'z', 'zhouquxian', 'zqx');
INSERT INTO `yc_city` VALUES ('3017', '迭部县', '3012', '1', '甘肃,甘南藏族自治州,迭部县', null, null, '623024', 'd', 'diebuxian', 'dbx');
INSERT INTO `yc_city` VALUES ('3018', '玛曲县', '3012', '1', '甘肃,甘南藏族自治州,玛曲县', null, null, '623025', 'm', 'maquxian', 'mqx');
INSERT INTO `yc_city` VALUES ('3019', '碌曲县', '3012', '1', '甘肃,甘南藏族自治州,碌曲县', null, null, '623026', 'l', 'luquxian', 'lqx');
INSERT INTO `yc_city` VALUES ('3020', '夏河县', '3012', '1', '甘肃,甘南藏族自治州,夏河县', null, null, '623027', 'x', 'xiahexian', 'xhx');
INSERT INTO `yc_city` VALUES ('3021', '青海', '1', '1', '青海', null, null, '630000', 'q', 'qinghai', 'qh');
INSERT INTO `yc_city` VALUES ('3022', '西宁市', '3021', '1', '青海,西宁市', null, null, '630100', 'x', 'xiningshi', 'xns');
INSERT INTO `yc_city` VALUES ('3023', '城东区', '3022', '1', '青海,西宁市,城东区', null, null, '630102', 'c', 'chengdongqu', 'cdq');
INSERT INTO `yc_city` VALUES ('3024', '城中区', '3022', '1', '青海,西宁市,城中区', null, null, '630103', 'c', 'chengzhongqu', 'czq');
INSERT INTO `yc_city` VALUES ('3025', '城西区', '3022', '1', '青海,西宁市,城西区', null, null, '630104', 'c', 'chengxiqu', 'cxq');
INSERT INTO `yc_city` VALUES ('3026', '城北区', '3022', '1', '青海,西宁市,城北区', null, null, '630105', 'c', 'chengbeiqu', 'cbq');
INSERT INTO `yc_city` VALUES ('3027', '大通回族土族自治县', '3022', '1', '青海,西宁市,大通回族土族自治县', null, null, '630121', 'd', 'datonghuizutuzuzizhixian', 'dthztzzzx');
INSERT INTO `yc_city` VALUES ('3028', '湟中县', '3022', '1', '青海,西宁市,湟中县', null, null, '630122', 'h', 'huangzhongxian', 'zx');
INSERT INTO `yc_city` VALUES ('3029', '湟源县', '3022', '1', '青海,西宁市,湟源县', null, null, '630123', 'h', 'huangyuanxian', 'yx');
INSERT INTO `yc_city` VALUES ('3030', '海东市', '3021', '1', '青海,海东市', null, null, null, 'h', 'haidongshi', 'hds');
INSERT INTO `yc_city` VALUES ('3031', '乐都区', '3030', '1', '青海,海东市,乐都区', null, null, null, 'l', 'ledouqu', 'ldq');
INSERT INTO `yc_city` VALUES ('3032', '平安县', '3030', '1', '青海,海东市,平安县', null, null, null, 'p', 'pinganxian', 'pax');
INSERT INTO `yc_city` VALUES ('3033', '民和回族土族自治县', '3030', '1', '青海,海东市,民和回族土族自治县', null, null, null, 'm', 'minhehuizutuzuzizhixian', 'mhhztzzzx');
INSERT INTO `yc_city` VALUES ('3034', '互助土族自治县', '3030', '1', '青海,海东市,互助土族自治县', null, null, null, 'h', 'huzhutuzuzizhixian', 'hztzzzx');
INSERT INTO `yc_city` VALUES ('3035', '化隆回族自治县', '3030', '1', '青海,海东市,化隆回族自治县', null, null, null, 'h', 'hualonghuizuzizhixian', 'hlhzzzx');
INSERT INTO `yc_city` VALUES ('3036', '循化撒拉族自治县', '3030', '1', '青海,海东市,循化撒拉族自治县', null, null, null, 'x', 'xunhuasalazuzizhixian', 'xhslzzzx');
INSERT INTO `yc_city` VALUES ('3037', '海北藏族自治州', '3021', '1', '青海,海北藏族自治州', null, null, '632200', 'h', 'haibeizangzuzizhizhou', 'hbczzzz');
INSERT INTO `yc_city` VALUES ('3038', '门源回族自治县', '3037', '1', '青海,海北藏族自治州,门源回族自治县', null, null, '632221', 'm', 'menyuanhuizuzizhixian', 'myhzzzx');
INSERT INTO `yc_city` VALUES ('3039', '祁连县', '3037', '1', '青海,海北藏族自治州,祁连县', null, null, '632222', 'q', 'qilianxian', 'qlx');
INSERT INTO `yc_city` VALUES ('3040', '海晏县', '3037', '1', '青海,海北藏族自治州,海晏县', null, null, '632223', 'h', 'haiyanxian', 'hx');
INSERT INTO `yc_city` VALUES ('3041', '刚察县', '3037', '1', '青海,海北藏族自治州,刚察县', null, null, '632224', 'g', 'gangchaxian', 'gcx');
INSERT INTO `yc_city` VALUES ('3042', '黄南藏族自治州', '3021', '1', '青海,黄南藏族自治州', null, null, '632300', 'h', 'huangnanzangzuzizhizhou', 'hnczzzz');
INSERT INTO `yc_city` VALUES ('3043', '同仁县', '3042', '1', '青海,黄南藏族自治州,同仁县', null, null, '632321', 't', 'tongrenxian', 'trx');
INSERT INTO `yc_city` VALUES ('3044', '尖扎县', '3042', '1', '青海,黄南藏族自治州,尖扎县', null, null, '632322', 'j', 'jianzhaxian', 'jzx');
INSERT INTO `yc_city` VALUES ('3045', '泽库县', '3042', '1', '青海,黄南藏族自治州,泽库县', null, null, '632323', 'z', 'zekuxian', 'zkx');
INSERT INTO `yc_city` VALUES ('3046', '河南蒙古族自治县', '3042', '1', '青海,黄南藏族自治州,河南蒙古族自治县', null, null, '632324', 'h', 'henanmengguzuzizhixian', 'hnmgzzzx');
INSERT INTO `yc_city` VALUES ('3047', '海南藏族自治州', '3021', '1', '青海,海南藏族自治州', null, null, '632500', 'h', 'hainanzangzuzizhizhou', 'hnczzzz');
INSERT INTO `yc_city` VALUES ('3048', '共和县', '3047', '1', '青海,海南藏族自治州,共和县', null, null, '632521', 'g', 'gonghexian', 'ghx');
INSERT INTO `yc_city` VALUES ('3049', '同德县', '3047', '1', '青海,海南藏族自治州,同德县', null, null, '632522', 't', 'tongdexian', 'tdx');
INSERT INTO `yc_city` VALUES ('3050', '贵德县', '3047', '1', '青海,海南藏族自治州,贵德县', null, null, '632523', 'g', 'guidexian', 'gdx');
INSERT INTO `yc_city` VALUES ('3051', '兴海县', '3047', '1', '青海,海南藏族自治州,兴海县', null, null, '632524', 'x', 'xinghaixian', 'xhx');
INSERT INTO `yc_city` VALUES ('3052', '贵南县', '3047', '1', '青海,海南藏族自治州,贵南县', null, null, '632525', 'g', 'guinanxian', 'gnx');
INSERT INTO `yc_city` VALUES ('3053', '果洛藏族自治州', '3021', '1', '青海,果洛藏族自治州', null, null, '632600', 'g', 'guoluozangzuzizhizhou', 'glczzzz');
INSERT INTO `yc_city` VALUES ('3054', '玛沁县', '3053', '1', '青海,果洛藏族自治州,玛沁县', null, null, '632621', 'm', 'maqinxian', 'mqx');
INSERT INTO `yc_city` VALUES ('3055', '班玛县', '3053', '1', '青海,果洛藏族自治州,班玛县', null, null, '632622', 'b', 'banmaxian', 'bmx');
INSERT INTO `yc_city` VALUES ('3056', '甘德县', '3053', '1', '青海,果洛藏族自治州,甘德县', null, null, '632623', 'g', 'gandexian', 'gdx');
INSERT INTO `yc_city` VALUES ('3057', '达日县', '3053', '1', '青海,果洛藏族自治州,达日县', null, null, '632624', 'd', 'darixian', 'drx');
INSERT INTO `yc_city` VALUES ('3058', '久治县', '3053', '1', '青海,果洛藏族自治州,久治县', null, null, '632625', 'j', 'jiuzhixian', 'jzx');
INSERT INTO `yc_city` VALUES ('3059', '玛多县', '3053', '1', '青海,果洛藏族自治州,玛多县', null, null, '632626', 'm', 'maduoxian', 'mdx');
INSERT INTO `yc_city` VALUES ('3060', '玉树藏族自治州', '3021', '1', '青海,玉树藏族自治州', null, null, '632700', 'y', 'yushuzangzuzizhizhou', 'ysczzzz');
INSERT INTO `yc_city` VALUES ('3061', '玉树市', '3060', '1', '青海,玉树藏族自治州,玉树市', null, null, null, 'y', 'yushushi', 'yss');
INSERT INTO `yc_city` VALUES ('3062', '杂多县', '3060', '1', '青海,玉树藏族自治州,杂多县', null, null, '632722', 'z', 'zaduoxian', 'zdx');
INSERT INTO `yc_city` VALUES ('3063', '称多县', '3060', '1', '青海,玉树藏族自治州,称多县', null, null, '632723', 'c', 'chenduoxian', 'cdx');
INSERT INTO `yc_city` VALUES ('3064', '治多县', '3060', '1', '青海,玉树藏族自治州,治多县', null, null, '632724', 'z', 'zhiduoxian', 'zdx');
INSERT INTO `yc_city` VALUES ('3065', '囊谦县', '3060', '1', '青海,玉树藏族自治州,囊谦县', null, null, '632725', 'n', 'nangqianxian', 'nqx');
INSERT INTO `yc_city` VALUES ('3066', '曲麻莱县', '3060', '1', '青海,玉树藏族自治州,曲麻莱县', null, null, '632726', 'q', 'qumalaixian', 'qmlx');
INSERT INTO `yc_city` VALUES ('3067', '海西蒙古族藏族自治州', '3021', '1', '青海,海西蒙古族藏族自治州', null, null, '632800', 'h', 'haiximengguzuzangzuzizhizhou', 'hxmgzczzzz');
INSERT INTO `yc_city` VALUES ('3068', '格尔木市', '3067', '1', '青海,海西蒙古族藏族自治州,格尔木市', null, null, '632801', 'g', 'geermushi', 'gems');
INSERT INTO `yc_city` VALUES ('3069', '德令哈市', '3067', '1', '青海,海西蒙古族藏族自治州,德令哈市', null, null, '632802', 'd', 'delinghashi', 'dlhs');
INSERT INTO `yc_city` VALUES ('3070', '乌兰县', '3067', '1', '青海,海西蒙古族藏族自治州,乌兰县', null, null, '632821', 'w', 'wulanxian', 'wlx');
INSERT INTO `yc_city` VALUES ('3071', '都兰县', '3067', '1', '青海,海西蒙古族藏族自治州,都兰县', null, null, '632822', 'd', 'dulanxian', 'dlx');
INSERT INTO `yc_city` VALUES ('3072', '天峻县', '3067', '1', '青海,海西蒙古族藏族自治州,天峻县', null, null, '632823', 't', 'tianjunxian', 'tjx');
INSERT INTO `yc_city` VALUES ('3073', '宁夏', '1', '1', '宁夏', null, null, '640000', 'n', 'ningxia', 'nx');
INSERT INTO `yc_city` VALUES ('3074', '银川市', '3073', '1', '宁夏,银川市', null, null, '640100', 'y', 'yinchuanshi', 'ycs');
INSERT INTO `yc_city` VALUES ('3075', '兴庆区', '3074', '1', '宁夏,银川市,兴庆区', null, null, '640104', 'x', 'xingqingqu', 'xqq');
INSERT INTO `yc_city` VALUES ('3076', '西夏区', '3074', '1', '宁夏,银川市,西夏区', null, null, '640105', 'x', 'xixiaqu', 'xxq');
INSERT INTO `yc_city` VALUES ('3077', '金凤区', '3074', '1', '宁夏,银川市,金凤区', null, null, '640106', 'j', 'jinfengqu', 'jfq');
INSERT INTO `yc_city` VALUES ('3078', '永宁县', '3074', '1', '宁夏,银川市,永宁县', null, null, '640121', 'y', 'yongningxian', 'ynx');
INSERT INTO `yc_city` VALUES ('3079', '贺兰县', '3074', '1', '宁夏,银川市,贺兰县', null, null, '640122', 'h', 'helanxian', 'hlx');
INSERT INTO `yc_city` VALUES ('3080', '灵武市', '3074', '1', '宁夏,银川市,灵武市', null, null, '640181', 'l', 'lingwushi', 'lws');
INSERT INTO `yc_city` VALUES ('3081', '石嘴山市', '3073', '1', '宁夏,石嘴山市', null, null, '640200', 's', 'shizuishanshi', 'szss');
INSERT INTO `yc_city` VALUES ('3082', '大武口区', '3081', '1', '宁夏,石嘴山市,大武口区', null, null, '640202', 'd', 'dawukouqu', 'dwkq');
INSERT INTO `yc_city` VALUES ('3083', '惠农区', '3081', '1', '宁夏,石嘴山市,惠农区', null, null, '640205', 'h', 'huinongqu', 'hnq');
INSERT INTO `yc_city` VALUES ('3084', '平罗县', '3081', '1', '宁夏,石嘴山市,平罗县', null, null, '640221', 'p', 'pingluoxian', 'plx');
INSERT INTO `yc_city` VALUES ('3085', '吴忠市', '3073', '1', '宁夏,吴忠市', null, null, '640300', 'w', 'wuzhongshi', 'wzs');
INSERT INTO `yc_city` VALUES ('3086', '利通区', '3085', '1', '宁夏,吴忠市,利通区', null, null, '640302', 'l', 'litongqu', 'ltq');
INSERT INTO `yc_city` VALUES ('3087', '红寺堡区', '3085', '1', '宁夏,吴忠市,红寺堡区', null, null, null, 'h', 'hongsibaoqu', 'hsbq');
INSERT INTO `yc_city` VALUES ('3088', '盐池县', '3085', '1', '宁夏,吴忠市,盐池县', null, null, '640323', 'y', 'yanchixian', 'ycx');
INSERT INTO `yc_city` VALUES ('3089', '同心县', '3085', '1', '宁夏,吴忠市,同心县', null, null, '640324', 't', 'tongxinxian', 'txx');
INSERT INTO `yc_city` VALUES ('3090', '青铜峡市', '3085', '1', '宁夏,吴忠市,青铜峡市', null, null, '640381', 'q', 'qingtongxiashi', 'qtxs');
INSERT INTO `yc_city` VALUES ('3091', '固原市', '3073', '1', '宁夏,固原市', null, null, '640400', 'g', 'guyuanshi', 'gys');
INSERT INTO `yc_city` VALUES ('3092', '原州区', '3091', '1', '宁夏,固原市,原州区', null, null, '640402', 'y', 'yuanzhouqu', 'yzq');
INSERT INTO `yc_city` VALUES ('3093', '西吉县', '3091', '1', '宁夏,固原市,西吉县', null, null, '640422', 'x', 'xijixian', 'xjx');
INSERT INTO `yc_city` VALUES ('3094', '隆德县', '3091', '1', '宁夏,固原市,隆德县', null, null, '640423', 'l', 'longdexian', 'ldx');
INSERT INTO `yc_city` VALUES ('3095', '泾源县', '3091', '1', '宁夏,固原市,泾源县', null, null, '640424', 'j', 'jingyuanxian', 'yx');
INSERT INTO `yc_city` VALUES ('3096', '彭阳县', '3091', '1', '宁夏,固原市,彭阳县', null, null, '640425', 'p', 'pengyangxian', 'pyx');
INSERT INTO `yc_city` VALUES ('3097', '中卫市', '3073', '1', '宁夏,中卫市', null, null, '640500', 'z', 'zhongweishi', 'zws');
INSERT INTO `yc_city` VALUES ('3098', '沙坡头区', '3097', '1', '宁夏,中卫市,沙坡头区', null, null, '640502', 's', 'shapotouqu', 'sptq');
INSERT INTO `yc_city` VALUES ('3099', '中宁县', '3097', '1', '宁夏,中卫市,中宁县', null, null, '640521', 'z', 'zhongningxian', 'znx');
INSERT INTO `yc_city` VALUES ('3100', '海原县', '3097', '1', '宁夏,中卫市,海原县', null, null, '640522', 'h', 'haiyuanxian', 'hyx');
INSERT INTO `yc_city` VALUES ('3101', '新疆', '1', '1', '新疆', null, null, '650000', 'x', 'xinjiang', 'xj');
INSERT INTO `yc_city` VALUES ('3102', '乌鲁木齐市', '3101', '1', '新疆,乌鲁木齐市', null, null, '650100', 'w', 'wulumuqishi', 'wlmqs');
INSERT INTO `yc_city` VALUES ('3103', '天山区', '3102', '1', '新疆,乌鲁木齐市,天山区', null, null, '650102', 't', 'tianshanqu', 'tsq');
INSERT INTO `yc_city` VALUES ('3104', '沙依巴克区', '3102', '1', '新疆,乌鲁木齐市,沙依巴克区', null, null, '650103', 's', 'shayibakequ', 'sybkq');
INSERT INTO `yc_city` VALUES ('3105', '新市区', '3102', '1', '新疆,乌鲁木齐市,新市区', null, null, '650104', 'x', 'xinshiqu', 'xsq');
INSERT INTO `yc_city` VALUES ('3106', '水磨沟区', '3102', '1', '新疆,乌鲁木齐市,水磨沟区', null, null, '650105', 's', 'shuimogouqu', 'smgq');
INSERT INTO `yc_city` VALUES ('3107', '头屯河区', '3102', '1', '新疆,乌鲁木齐市,头屯河区', null, null, '650106', 't', 'toutunhequ', 'tthq');
INSERT INTO `yc_city` VALUES ('3108', '达坂城区', '3102', '1', '新疆,乌鲁木齐市,达坂城区', null, null, '650107', 'd', 'dabanchengqu', 'dcq');
INSERT INTO `yc_city` VALUES ('3109', '米东区', '3102', '1', '新疆,乌鲁木齐市,米东区', null, null, '650109', 'm', 'midongqu', 'mdq');
INSERT INTO `yc_city` VALUES ('3110', '乌鲁木齐县', '3102', '1', '新疆,乌鲁木齐市,乌鲁木齐县', null, null, '650121', 'w', 'wulumuqixian', 'wlmqx');
INSERT INTO `yc_city` VALUES ('3111', '克拉玛依市', '3101', '1', '新疆,克拉玛依市', null, null, '650200', 'k', 'kelamayishi', 'klmys');
INSERT INTO `yc_city` VALUES ('3112', '独山子区', '3111', '1', '新疆,克拉玛依市,独山子区', null, null, '650202', 'd', 'dushanziqu', 'dszq');
INSERT INTO `yc_city` VALUES ('3113', '克拉玛依区', '3111', '1', '新疆,克拉玛依市,克拉玛依区', null, null, '650203', 'k', 'kelamayiqu', 'klmyq');
INSERT INTO `yc_city` VALUES ('3114', '白碱滩区', '3111', '1', '新疆,克拉玛依市,白碱滩区', null, null, '650204', 'b', 'baijiantanqu', 'bjtq');
INSERT INTO `yc_city` VALUES ('3115', '乌尔禾区', '3111', '1', '新疆,克拉玛依市,乌尔禾区', null, null, '650205', 'w', 'wuerhequ', 'wehq');
INSERT INTO `yc_city` VALUES ('3116', '吐鲁番地区', '3101', '1', '新疆,吐鲁番地区', null, null, '652100', 't', 'tulufandiqu', 'tlfdq');
INSERT INTO `yc_city` VALUES ('3117', '吐鲁番市', '3116', '1', '新疆,吐鲁番地区,吐鲁番市', null, null, '652101', 't', 'tulufanshi', 'tlfs');
INSERT INTO `yc_city` VALUES ('3118', '鄯善县', '3116', '1', '新疆,吐鲁番地区,鄯善县', null, null, '652122', 's', 'shanshanxian', 'sx');
INSERT INTO `yc_city` VALUES ('3119', '托克逊县', '3116', '1', '新疆,吐鲁番地区,托克逊县', null, null, '652123', 't', 'tuokexunxian', 'tkxx');
INSERT INTO `yc_city` VALUES ('3120', '哈密地区', '3101', '1', '新疆,哈密地区', null, null, '652200', 'h', 'hamidiqu', 'hmdq');
INSERT INTO `yc_city` VALUES ('3121', '哈密市', '3120', '1', '新疆,哈密地区,哈密市', null, null, '652201', 'h', 'hamishi', 'hms');
INSERT INTO `yc_city` VALUES ('3122', '巴里坤哈萨克自治县', '3120', '1', '新疆,哈密地区,巴里坤哈萨克自治县', null, null, '652222', 'b', 'balikunhasakezizhixian', 'blkhskzzx');
INSERT INTO `yc_city` VALUES ('3123', '伊吾县', '3120', '1', '新疆,哈密地区,伊吾县', null, null, '652223', 'y', 'yiwuxian', 'ywx');
INSERT INTO `yc_city` VALUES ('3124', '昌吉回族自治州', '3101', '1', '新疆,昌吉回族自治州', null, null, '652300', 'c', 'changjihuizuzizhizhou', 'cjhzzzz');
INSERT INTO `yc_city` VALUES ('3125', '昌吉市', '3124', '1', '新疆,昌吉回族自治州,昌吉市', null, null, '652301', 'c', 'changjishi', 'cjs');
INSERT INTO `yc_city` VALUES ('3126', '阜康市', '3124', '1', '新疆,昌吉回族自治州,阜康市', null, null, '652302', 'f', 'fukangshi', 'fks');
INSERT INTO `yc_city` VALUES ('3127', '呼图壁县', '3124', '1', '新疆,昌吉回族自治州,呼图壁县', null, null, '652323', 'h', 'hutubixian', 'htbx');
INSERT INTO `yc_city` VALUES ('3128', '玛纳斯县', '3124', '1', '新疆,昌吉回族自治州,玛纳斯县', null, null, '652324', 'm', 'manasixian', 'mnsx');
INSERT INTO `yc_city` VALUES ('3129', '奇台县', '3124', '1', '新疆,昌吉回族自治州,奇台县', null, null, '652325', 'q', 'qitaixian', 'qtx');
INSERT INTO `yc_city` VALUES ('3130', '吉木萨尔县', '3124', '1', '新疆,昌吉回族自治州,吉木萨尔县', null, null, '652327', 'j', 'jimusaerxian', 'jmsex');
INSERT INTO `yc_city` VALUES ('3131', '木垒哈萨克自治县', '3124', '1', '新疆,昌吉回族自治州,木垒哈萨克自治县', null, null, '652328', 'm', 'muleihasakezizhixian', 'mlhskzzx');
INSERT INTO `yc_city` VALUES ('3132', '博尔塔拉蒙古自治州', '3101', '1', '新疆,博尔塔拉蒙古自治州', null, null, '652700', 'b', 'boertalamengguzizhizhou', 'betlmgzzz');
INSERT INTO `yc_city` VALUES ('3133', '博乐市', '3132', '1', '新疆,博尔塔拉蒙古自治州,博乐市', null, null, '652701', 'b', 'boleshi', 'bls');
INSERT INTO `yc_city` VALUES ('3134', '阿拉山口市', '3132', '1', '新疆,博尔塔拉蒙古自治州,阿拉山口市', null, null, null, 'a', 'alashankoushi', 'alsks');
INSERT INTO `yc_city` VALUES ('3135', '精河县', '3132', '1', '新疆,博尔塔拉蒙古自治州,精河县', null, null, '652722', 'j', 'jinghexian', 'jhx');
INSERT INTO `yc_city` VALUES ('3136', '温泉县', '3132', '1', '新疆,博尔塔拉蒙古自治州,温泉县', null, null, '652723', 'w', 'wenquanxian', 'wqx');
INSERT INTO `yc_city` VALUES ('3137', '巴音郭楞蒙古自治州', '3101', '1', '新疆,巴音郭楞蒙古自治州', null, null, '652800', 'b', 'bayinguolengmengguzizhizhou', 'byglmgzzz');
INSERT INTO `yc_city` VALUES ('3138', '库尔勒市', '3137', '1', '新疆,巴音郭楞蒙古自治州,库尔勒市', null, null, '652801', 'k', 'kuerleshi', 'kels');
INSERT INTO `yc_city` VALUES ('3139', '轮台县', '3137', '1', '新疆,巴音郭楞蒙古自治州,轮台县', null, null, '652822', 'l', 'luntaixian', 'ltx');
INSERT INTO `yc_city` VALUES ('3140', '尉犁县', '3137', '1', '新疆,巴音郭楞蒙古自治州,尉犁县', null, null, '652823', 'y', 'yulixian', 'wlx');
INSERT INTO `yc_city` VALUES ('3141', '若羌县', '3137', '1', '新疆,巴音郭楞蒙古自治州,若羌县', null, null, '652824', 'r', 'ruoqiangxian', 'rqx');
INSERT INTO `yc_city` VALUES ('3142', '且末县', '3137', '1', '新疆,巴音郭楞蒙古自治州,且末县', null, null, '652825', 'q', 'qiemoxian', 'qmx');
INSERT INTO `yc_city` VALUES ('3143', '焉耆回族自治县', '3137', '1', '新疆,巴音郭楞蒙古自治州,焉耆回族自治县', null, null, '652826', 'y', 'yanqihuizuzizhixian', 'yhzzzx');
INSERT INTO `yc_city` VALUES ('3144', '和静县', '3137', '1', '新疆,巴音郭楞蒙古自治州,和静县', null, null, '652827', 'h', 'hejingxian', 'hjx');
INSERT INTO `yc_city` VALUES ('3145', '和硕县', '3137', '1', '新疆,巴音郭楞蒙古自治州,和硕县', null, null, '652828', 'h', 'heshuoxian', 'hsx');
INSERT INTO `yc_city` VALUES ('3146', '博湖县', '3137', '1', '新疆,巴音郭楞蒙古自治州,博湖县', null, null, '652829', 'b', 'bohuxian', 'bhx');
INSERT INTO `yc_city` VALUES ('3147', '阿克苏地区', '3101', '1', '新疆,阿克苏地区', null, null, '652900', 'a', 'akesudiqu', 'aksdq');
INSERT INTO `yc_city` VALUES ('3148', '阿克苏市', '3147', '1', '新疆,阿克苏地区,阿克苏市', null, null, '652901', 'a', 'akesushi', 'akss');
INSERT INTO `yc_city` VALUES ('3149', '温宿县', '3147', '1', '新疆,阿克苏地区,温宿县', null, null, '652922', 'w', 'wensuxian', 'wsx');
INSERT INTO `yc_city` VALUES ('3150', '库车县', '3147', '1', '新疆,阿克苏地区,库车县', null, null, '652923', 'k', 'kuchexian', 'kcx');
INSERT INTO `yc_city` VALUES ('3151', '沙雅县', '3147', '1', '新疆,阿克苏地区,沙雅县', null, null, '652924', 's', 'shayaxian', 'syx');
INSERT INTO `yc_city` VALUES ('3152', '新和县', '3147', '1', '新疆,阿克苏地区,新和县', null, null, '652925', 'x', 'xinhexian', 'xhx');
INSERT INTO `yc_city` VALUES ('3153', '拜城县', '3147', '1', '新疆,阿克苏地区,拜城县', null, null, '652926', 'b', 'baichengxian', 'bcx');
INSERT INTO `yc_city` VALUES ('3154', '乌什县', '3147', '1', '新疆,阿克苏地区,乌什县', null, null, '652927', 'w', 'wushixian', 'wsx');
INSERT INTO `yc_city` VALUES ('3155', '阿瓦提县', '3147', '1', '新疆,阿克苏地区,阿瓦提县', null, null, '652928', 'a', 'awatixian', 'awtx');
INSERT INTO `yc_city` VALUES ('3156', '柯坪县', '3147', '1', '新疆,阿克苏地区,柯坪县', null, null, '652929', 'k', 'kepingxian', 'kpx');
INSERT INTO `yc_city` VALUES ('3157', '克孜勒苏柯尔克孜自治州', '3101', '1', '新疆,克孜勒苏柯尔克孜自治州', null, null, '653000', 'k', 'kezilesukeerkezizizhizhou', 'kzlskekzzzz');
INSERT INTO `yc_city` VALUES ('3158', '阿图什市', '3157', '1', '新疆,克孜勒苏柯尔克孜自治州,阿图什市', null, null, '653001', 'a', 'atushishi', 'atss');
INSERT INTO `yc_city` VALUES ('3159', '阿克陶县', '3157', '1', '新疆,克孜勒苏柯尔克孜自治州,阿克陶县', null, null, '653022', 'a', 'aketaoxian', 'aktx');
INSERT INTO `yc_city` VALUES ('3160', '阿合奇县', '3157', '1', '新疆,克孜勒苏柯尔克孜自治州,阿合奇县', null, null, '653023', 'a', 'aheqixian', 'ahqx');
INSERT INTO `yc_city` VALUES ('3161', '乌恰县', '3157', '1', '新疆,克孜勒苏柯尔克孜自治州,乌恰县', null, null, '653024', 'w', 'wuqiaxian', 'wqx');
INSERT INTO `yc_city` VALUES ('3162', '喀什地区', '3101', '1', '新疆,喀什地区', null, null, '653100', 'k', 'kashidiqu', 'ksdq');
INSERT INTO `yc_city` VALUES ('3163', '喀什市', '3162', '1', '新疆,喀什地区,喀什市', null, null, '653101', 'k', 'kashishi', 'kss');
INSERT INTO `yc_city` VALUES ('3164', '疏附县', '3162', '1', '新疆,喀什地区,疏附县', null, null, '653121', 's', 'shufuxian', 'sfx');
INSERT INTO `yc_city` VALUES ('3165', '疏勒县', '3162', '1', '新疆,喀什地区,疏勒县', null, null, '653122', 's', 'shulexian', 'slx');
INSERT INTO `yc_city` VALUES ('3166', '英吉沙县', '3162', '1', '新疆,喀什地区,英吉沙县', null, null, '653123', 'y', 'yingjishaxian', 'yjsx');
INSERT INTO `yc_city` VALUES ('3167', '泽普县', '3162', '1', '新疆,喀什地区,泽普县', null, null, '653124', 'z', 'zepuxian', 'zpx');
INSERT INTO `yc_city` VALUES ('3168', '莎车县', '3162', '1', '新疆,喀什地区,莎车县', null, null, '653125', 's', 'shachexian', 'scx');
INSERT INTO `yc_city` VALUES ('3169', '叶城县', '3162', '1', '新疆,喀什地区,叶城县', null, null, '653126', 'y', 'yechengxian', 'ycx');
INSERT INTO `yc_city` VALUES ('3170', '麦盖提县', '3162', '1', '新疆,喀什地区,麦盖提县', null, null, '653127', 'm', 'maigetixian', 'mgtx');
INSERT INTO `yc_city` VALUES ('3171', '岳普湖县', '3162', '1', '新疆,喀什地区,岳普湖县', null, null, '653128', 'y', 'yuepuhuxian', 'yphx');
INSERT INTO `yc_city` VALUES ('3172', '伽师县', '3162', '1', '新疆,喀什地区,伽师县', null, null, '653129', 'j', 'jiashixian', 'sx');
INSERT INTO `yc_city` VALUES ('3173', '巴楚县', '3162', '1', '新疆,喀什地区,巴楚县', null, null, '653130', 'b', 'bachuxian', 'bcx');
INSERT INTO `yc_city` VALUES ('3174', '塔什库尔干塔吉克自治县', '3162', '1', '新疆,喀什地区,塔什库尔干塔吉克自治县', null, null, '653131', 't', 'tashenkuergantajikezizhixian', 'tskegtjkzzx');
INSERT INTO `yc_city` VALUES ('3175', '和田地区', '3101', '1', '新疆,和田地区', null, null, '653200', 'h', 'hetiandiqu', 'htdq');
INSERT INTO `yc_city` VALUES ('3176', '和田市', '3175', '1', '新疆,和田地区,和田市', null, null, '653201', 'h', 'hetianshi', 'hts');
INSERT INTO `yc_city` VALUES ('3177', '和田县', '3175', '1', '新疆,和田地区,和田县', null, null, '653221', 'h', 'hetianxian', 'htx');
INSERT INTO `yc_city` VALUES ('3178', '墨玉县', '3175', '1', '新疆,和田地区,墨玉县', null, null, '653222', 'm', 'moyuxian', 'myx');
INSERT INTO `yc_city` VALUES ('3179', '皮山县', '3175', '1', '新疆,和田地区,皮山县', null, null, '653223', 'p', 'pishanxian', 'psx');
INSERT INTO `yc_city` VALUES ('3180', '洛浦县', '3175', '1', '新疆,和田地区,洛浦县', null, null, '653224', 'l', 'luopuxian', 'lpx');
INSERT INTO `yc_city` VALUES ('3181', '策勒县', '3175', '1', '新疆,和田地区,策勒县', null, null, '653225', 'c', 'celexian', 'clx');
INSERT INTO `yc_city` VALUES ('3182', '于田县', '3175', '1', '新疆,和田地区,于田县', null, null, '653226', 'y', 'yutianxian', 'ytx');
INSERT INTO `yc_city` VALUES ('3183', '民丰县', '3175', '1', '新疆,和田地区,民丰县', null, null, '653227', 'm', 'minfengxian', 'mfx');
INSERT INTO `yc_city` VALUES ('3184', '伊犁哈萨克自治州', '3101', '1', '新疆,伊犁哈萨克自治州', null, null, '654000', 'y', 'yilihasakezizhizhou', 'ylhskzzz');
INSERT INTO `yc_city` VALUES ('3185', '伊宁市', '3184', '1', '新疆,伊犁哈萨克自治州,伊宁市', null, null, '654002', 'y', 'yiningshi', 'yns');
INSERT INTO `yc_city` VALUES ('3186', '奎屯市', '3184', '1', '新疆,伊犁哈萨克自治州,奎屯市', null, null, '654003', 'k', 'kuitunshi', 'kts');
INSERT INTO `yc_city` VALUES ('3187', '伊宁县', '3184', '1', '新疆,伊犁哈萨克自治州,伊宁县', null, null, '654021', 'y', 'yiningxian', 'ynx');
INSERT INTO `yc_city` VALUES ('3188', '察布查尔锡伯自治县', '3184', '1', '新疆,伊犁哈萨克自治州,察布查尔锡伯自治县', null, null, '654022', 'c', 'chabuchaerxibozizhixian', 'cbcexbzzx');
INSERT INTO `yc_city` VALUES ('3189', '霍城县', '3184', '1', '新疆,伊犁哈萨克自治州,霍城县', null, null, '654023', 'h', 'huochengxian', 'hcx');
INSERT INTO `yc_city` VALUES ('3190', '巩留县', '3184', '1', '新疆,伊犁哈萨克自治州,巩留县', null, null, '654024', 'g', 'gongliuxian', 'glx');
INSERT INTO `yc_city` VALUES ('3191', '新源县', '3184', '1', '新疆,伊犁哈萨克自治州,新源县', null, null, '654025', 'x', 'xinyuanxian', 'xyx');
INSERT INTO `yc_city` VALUES ('3192', '昭苏县', '3184', '1', '新疆,伊犁哈萨克自治州,昭苏县', null, null, '654026', 'z', 'zhaosuxian', 'zsx');
INSERT INTO `yc_city` VALUES ('3193', '特克斯县', '3184', '1', '新疆,伊犁哈萨克自治州,特克斯县', null, null, '654027', 't', 'tekesixian', 'tksx');
INSERT INTO `yc_city` VALUES ('3194', '尼勒克县', '3184', '1', '新疆,伊犁哈萨克自治州,尼勒克县', null, null, '654028', 'n', 'nilekexian', 'nlkx');
INSERT INTO `yc_city` VALUES ('3195', '塔城地区', '3101', '1', '新疆,塔城地区', null, null, '654200', 't', 'tachengdiqu', 'tcdq');
INSERT INTO `yc_city` VALUES ('3196', '塔城市', '3195', '1', '新疆,塔城地区,塔城市', null, null, '654201', 't', 'tachengshi', 'tcs');
INSERT INTO `yc_city` VALUES ('3197', '乌苏市', '3195', '1', '新疆,塔城地区,乌苏市', null, null, '654202', 'w', 'wusushi', 'wss');
INSERT INTO `yc_city` VALUES ('3198', '额敏县', '3195', '1', '新疆,塔城地区,额敏县', null, null, '654221', 'e', 'eminxian', 'emx');
INSERT INTO `yc_city` VALUES ('3199', '沙湾县', '3195', '1', '新疆,塔城地区,沙湾县', null, null, '654223', 's', 'shawanxian', 'swx');
INSERT INTO `yc_city` VALUES ('3200', '托里县', '3195', '1', '新疆,塔城地区,托里县', null, null, '654224', 't', 'tuolixian', 'tlx');
INSERT INTO `yc_city` VALUES ('3201', '裕民县', '3195', '1', '新疆,塔城地区,裕民县', null, null, '654225', 'y', 'yuminxian', 'ymx');
INSERT INTO `yc_city` VALUES ('3202', '和布克赛尔蒙古自治县', '3195', '1', '新疆,塔城地区,和布克赛尔蒙古自治县', null, null, '654226', 'h', 'hebukesaiermengguzizhixian', 'hbksemgzzx');
INSERT INTO `yc_city` VALUES ('3203', '阿勒泰地区', '3101', '1', '新疆,阿勒泰地区', null, null, '654300', 'a', 'aletaidiqu', 'altdq');
INSERT INTO `yc_city` VALUES ('3204', '阿勒泰市', '3203', '1', '新疆,阿勒泰地区,阿勒泰市', null, null, '654301', 'a', 'aletaishi', 'alts');
INSERT INTO `yc_city` VALUES ('3205', '布尔津县', '3203', '1', '新疆,阿勒泰地区,布尔津县', null, null, '654321', 'b', 'buerjinxian', 'bejx');
INSERT INTO `yc_city` VALUES ('3206', '富蕴县', '3203', '1', '新疆,阿勒泰地区,富蕴县', null, null, '654322', 'f', 'fuyunxian', 'fyx');
INSERT INTO `yc_city` VALUES ('3207', '福海县', '3203', '1', '新疆,阿勒泰地区,福海县', null, null, '654323', 'f', 'fuhaixian', 'fhx');
INSERT INTO `yc_city` VALUES ('3208', '哈巴河县', '3203', '1', '新疆,阿勒泰地区,哈巴河县', null, null, '654324', 'h', 'habahexian', 'hbhx');
INSERT INTO `yc_city` VALUES ('3209', '青河县', '3203', '1', '新疆,阿勒泰地区,青河县', null, null, '654325', 'q', 'qinghexian', 'qhx');
INSERT INTO `yc_city` VALUES ('3210', '吉木乃县', '3203', '1', '新疆,阿勒泰地区,吉木乃县', null, null, '654326', 'j', 'jimunaixian', 'jmnx');
INSERT INTO `yc_city` VALUES ('3211', '石河子市', '3101', '1', '新疆,石河子市', null, null, null, 's', 'shihezishi', 'shzs');
INSERT INTO `yc_city` VALUES ('3212', '阿拉尔市', '3101', '1', '新疆,阿拉尔市', null, null, null, 'a', 'alaershi', 'ales');
INSERT INTO `yc_city` VALUES ('3213', '图木舒克市', '3101', '1', '新疆,图木舒克市', null, null, null, 't', 'tumushukeshi', 'tmsks');
INSERT INTO `yc_city` VALUES ('3214', '五家渠市', '3101', '1', '新疆,五家渠市', null, null, '659004', 'w', 'wujiaqushi', 'wjqs');
INSERT INTO `yc_city` VALUES ('3215', '台湾省', '1', '1', '台湾省', null, null, null, 't', 'taiwansheng', 'tws');
INSERT INTO `yc_city` VALUES ('3216', '香港', '1', '1', '香港', null, null, null, 'x', 'xianggang', 'xg');
INSERT INTO `yc_city` VALUES ('3217', '澳门', '1', '1', '澳门', null, null, null, 'a', 'aomen', 'am');
INSERT INTO `yc_city` VALUES ('3218', '台北市', '3215', '1', '台湾省,台北市', null, null, null, 't', 'taibeishi', 'tbs');
INSERT INTO `yc_city` VALUES ('3219', '高雄市', '3215', '1', '台湾省,高雄市', null, null, null, 'g', 'gaoxiongshi', 'gxs');
INSERT INTO `yc_city` VALUES ('3220', '基隆市', '3215', '1', '台湾省,基隆市', null, null, null, 'j', 'jilongshi', 'jls');
INSERT INTO `yc_city` VALUES ('3221', '台中市', '3215', '1', '台湾省,台中市', null, null, null, 't', 'taizhongshi', 'tzs');
INSERT INTO `yc_city` VALUES ('3222', '台南市', '3215', '1', '台湾省,台南市', null, null, null, 't', 'tainanshi', 'tns');
INSERT INTO `yc_city` VALUES ('3223', '新竹市', '3215', '1', '台湾省,新竹市', null, null, null, 'x', 'xinzhushi', 'xzs');
INSERT INTO `yc_city` VALUES ('3224', '嘉义市', '3215', '1', '台湾省,嘉义市', null, null, null, 'j', 'jiayishi', 'jys');
INSERT INTO `yc_city` VALUES ('3225', '新北市', '3215', '1', '台湾省,新北市', null, null, null, 'x', 'xinbeishi', 'xbs');
INSERT INTO `yc_city` VALUES ('3226', '宜兰县', '3215', '1', '台湾省,宜兰县', null, null, null, 'y', 'yilanxian', 'ylx');
INSERT INTO `yc_city` VALUES ('3227', '桃园县', '3215', '1', '台湾省,桃园县', null, null, null, 't', 'taoyuanxian', 'tyx');
INSERT INTO `yc_city` VALUES ('3228', '新竹县', '3215', '1', '台湾省,新竹县', null, null, null, 'x', 'xinzhuxian', 'xzx');
INSERT INTO `yc_city` VALUES ('3229', '苗栗县', '3215', '1', '台湾省,苗栗县', null, null, null, 'm', 'miaolixian', 'mlx');
INSERT INTO `yc_city` VALUES ('3230', '彰化县', '3215', '1', '台湾省,彰化县', null, null, null, 'z', 'zhanghuaxian', 'zhx');
INSERT INTO `yc_city` VALUES ('3231', '南投县', '3215', '1', '台湾省,南投县', null, null, null, 'n', 'nantouxian', 'ntx');
INSERT INTO `yc_city` VALUES ('3232', '云林县', '3215', '1', '台湾省,云林县', null, null, null, 'y', 'yunlinxian', 'ylx');
INSERT INTO `yc_city` VALUES ('3233', '嘉义县', '3215', '1', '台湾省,嘉义县', null, null, null, 'j', 'jiayixian', 'jyx');
INSERT INTO `yc_city` VALUES ('3234', '屏东县', '3215', '1', '台湾省,屏东县', null, null, null, 'p', 'pingdongxian', 'pdx');
INSERT INTO `yc_city` VALUES ('3235', '台东县', '3215', '1', '台湾省,台东县', null, null, null, 't', 'taidongxian', 'tdx');
INSERT INTO `yc_city` VALUES ('3236', '花莲县', '3215', '1', '台湾省,花莲县', null, null, null, 'h', 'hualianxian', 'hlx');
INSERT INTO `yc_city` VALUES ('3237', '澎湖县', '3215', '1', '台湾省,澎湖县', null, null, null, 'p', 'penghuxian', 'phx');
INSERT INTO `yc_city` VALUES ('3238', '盘锦市', '465', '1', '辽宁,盘锦市', null, null, '211100', 'p', 'panjinshi', 'pjs');

-- ----------------------------
-- Table structure for yc_file_resource
-- ----------------------------
DROP TABLE IF EXISTS `yc_file_resource`;
CREATE TABLE `yc_file_resource` (
  `file_id` int(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件编号',
  `file_name` varchar(100) DEFAULT NULL COMMENT '名称',
  `file_origin_name` varchar(100) DEFAULT NULL COMMENT '原始名字',
  `file_size` int(11) DEFAULT NULL COMMENT '大小',
  `file_mime_type` varchar(50) DEFAULT NULL COMMENT '原始类型',
  `file_time` int(11) DEFAULT NULL COMMENT '修改时间',
  `member_id` int(11) DEFAULT '0',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `status` tinyint(2) DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`file_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8 COMMENT='文件';

-- ----------------------------
-- Records of yc_file_resource
-- ----------------------------
INSERT INTO `yc_file_resource` VALUES ('1', '5b63132225e7443b872e851091054a7e.jpg', '5b63132225e7443b872e851091054a7e.jpg', '12', 'image/jpeg', '1430275903', '0', '目标人物哟', '1');
INSERT INTO `yc_file_resource` VALUES ('4', '8846403c6e0d6f41d8cba20b43b3bd24.jpg', '2.jpg', '16', 'image/jpeg', '1430277662', '0', '目标人物哟', '1');
INSERT INTO `yc_file_resource` VALUES ('5', '97204a0dabe9017539785c4daae356d7.jpg', 'Light.jpg', '1072', 'image/jpeg', '1430279971', '0', '这个图有点大', '1');
INSERT INTO `yc_file_resource` VALUES ('6', '92585eefa0b04c20ab20615af3a6cf62.jpg', 'a1.jpg', '139', 'image/jpeg', '1430281486', '0', '这些是图片嘛', '1');
INSERT INTO `yc_file_resource` VALUES ('7', 'cd09cefc46578cb09eabec91901690b5.jpg', 'b1.jpg', '86', 'image/jpeg', '1430281487', '0', '这些是图片嘛', '1');
INSERT INTO `yc_file_resource` VALUES ('8', 'd65b22efb51295beecf47e5d7ebcdc51.jpg', 'b2.jpg', '98', 'image/jpeg', '1430281487', '0', '这些是图片嘛', '1');
INSERT INTO `yc_file_resource` VALUES ('9', '615749c3885e616b903b3a68b94a2b6c.jpg', 'g1.jpg', '105', 'image/jpeg', '1430281487', '0', '这些是图片嘛', '1');
INSERT INTO `yc_file_resource` VALUES ('10', 'ae23b1d657bcb0f3252cfbe41dc1d753.jpg', 'z1.jpg', '156', 'image/jpeg', '1430314198', '0', '张馨予', '1');
INSERT INTO `yc_file_resource` VALUES ('11', 'dacb622d.png', 'avatarS.png', '101158', 'image/png', '1488871622', '0', null, '1');
INSERT INTO `yc_file_resource` VALUES ('12', '0f3438e7.jpg', '3607529247.jpg', '17838', 'image/jpeg', '1488872328', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('13', '037d836a.png', 'aHR0cDovL20ueGltYWxheWEuY29tLzM1MTQ0ODU3L3NvdW5kLzE2MTkxMzcy9dc675c0d5.png', '29157', 'image/png', '1488872469', '0', null, '1');
INSERT INTO `yc_file_resource` VALUES ('14', '862a1c0b.jpg', '82838c3b47e574cfe9f49bef97bd0beb_480_480.jpg', '35379', 'image/jpeg', '1488872740', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('15', '62bed4f9.jpg', 'a50f4bfbfbedab64cbaa52c1f536afc378311ed2.jpg', '15580', 'image/jpeg', '1488875803', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('16', 'c06192df.jpg', 'aaa.jpg', '8347', 'image/jpeg', '1488875803', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('17', 'cf9325af.jpg', 'huonwzuiwahjpg.jpg', '42918', 'image/jpeg', '1488875803', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('18', '61f79096.jpg', '3.jpg', '5945', 'image/jpeg', '1488901475', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('19', 'edc0504f.jpg', '2.jpg', '1360', 'image/jpeg', '1488901475', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('20', 'deb5b58e.jpg', '1.jpg', '2061', 'image/jpeg', '1488901475', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('21', '3802dfc9.jpg', '4.jpg', '8377', 'image/jpeg', '1488901475', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('22', '8018eedc.jpg', '5.jpg', '6205', 'image/jpeg', '1488901475', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('23', 'dfea2233.jpg', '6.jpg', '2798', 'image/jpeg', '1488901475', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('24', '9723d95b.jpg', '7.jpg', '4174', 'image/jpeg', '1488901475', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('25', '257e7e6f.jpg', 'TB1yiY_LVXXXXc6XVXXXXXXXXXX_!!0-item_pic.jpg', '79725', 'image/jpeg', '1488904487', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('26', '7066603a.jpg', 'TB2H3w9lFXXXXccXpXXXXXXXXXX_!!63939563.jpg', '58930', 'image/jpeg', '1488904487', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('27', '7c9f2c09.jpg', 'TB2zl7kgEhnpuFjSZFpXXcpuXXa_!!63939563.jpg', '99205', 'image/jpeg', '1488904487', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('28', '3c97f9d3.jpg', 'TB2bkT.sVXXXXXnXXXXXXXXXXXX_!!2126658491.jpg_430x430q90.jpg', '20604', 'image/jpeg', '1488994821', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('29', '05d2e25a.jpg', 'TB2LGv4sVXXXXamXXXXXXXXXXXX_!!2126658491.jpg_430x430q90.jpg', '21798', 'image/jpeg', '1488994821', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('30', '7ccb48f6.jpg', 'TB2I1bhsVXXXXboXpXXXXXXXXXX_!!2126658491.jpg_430x430q90.jpg', '52518', 'image/jpeg', '1488994821', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('31', 'ff7ef01a.jpg', 'TB2WbDzsVXXXXXOXpXXXXXXXXXX_!!2126658491.jpg_430x430q90.jpg', '20254', 'image/jpeg', '1488994821', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('32', '3ae46d9c.jpg', 'TB2YLbGdVXXXXa6XXXXXXXXXXXX-2126658491.jpg', '86998', 'image/jpeg', '1488994821', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('33', '1eeec5d9.jpg', 'TB2ElvguXXXXXbbXXXXXXXXXXXX_!!704298669.jpg_400x400.jpg', '84666', 'image/jpeg', '1490198401', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('34', '8f55efc2.jpg', 'TB1odV7PVXXXXccXXXXXXXXXXXX_!!0-item_pic.jpg', '226589', 'image/jpeg', '1490807721', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('35', '3f7d84c1.jpg', 'TB2BSs.hctnpuFjSZFKXXalFFXa_!!2857989582.jpg', '119294', 'image/jpeg', '1490807721', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('36', '7f125c91.jpg', 'TB2c2jQbdhvOuFjSZFBXXcZgFXa_!!2857989582.jpg', '107506', 'image/jpeg', '1490807721', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('37', 'd4cbbc55.jpg', 'TB2HgpahElnpuFjSZFjXXXTaVXa_!!2857989582.jpg', '108544', 'image/jpeg', '1490807721', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('38', '0cb69bc1.jpg', 'TB20WdrhCFmpuFjSZFrXXayOXXa_!!2857989582.jpg', '106925', 'image/jpeg', '1490807721', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('39', 'ca81f1e1.jpg', 'TB2eDXcdm0mpuFjSZPiXXbssVXa_!!775363579.jpg', '59645', 'image/jpeg', '1490812128', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('40', '1f9948da.jpg', 'TB2ikJ1brJmpuFjSZFwXXaE4VXa_!!775363579.jpg', '123733', 'image/jpeg', '1490812182', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('41', 'c2b26a1c.jpg', 'TB2rqV5btFopuFjSZFHXXbSlXXa_!!775363579.jpg', '67110', 'image/jpeg', '1490812321', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('42', '001f4845.jpg', 'TB2u7h6bxxmpuFjSZFNXXXrRXXa_!!775363579.jpg', '91861', 'image/jpeg', '1490812423', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('43', 'f0ddd84e.jpg', 'TB25lB_brBmpuFjSZFAXXaQ0pXa_!!775363579.jpg', '101929', 'image/jpeg', '1490812423', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('45', 'e3d99bfc.png', 'avatar-boy.png', '13596', 'image/png', '1490990509', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('46', '80324cde.jpg', '5681e977Na29f872f.jpg', '8913', 'image/jpeg', '1491005890', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('47', '34a7971e.jpg', '263927947.jpg', '66965', 'image/jpeg', '1491005890', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('48', '986c7c96.jpg', 'TB2osLccdRopuFjSZFtXXcanpXa_!!269334925.jpg', '200828', 'image/jpeg', '1491006684', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('49', '8cbb4baa.jpg', 'TB218Z.cxXkpuFjy0FiXXbUfFXa_!!1613887774.jpg', '85170', 'image/jpeg', '1491006684', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('50', '0af5b8cb.jpg', 'TB2jgPqhlNkpuFjy0FaXXbRCVXa_!!305564808.jpg_400x400.jpg', '34678', 'image/jpeg', '1491007137', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('51', '3eb9458b.jpg', 'TB2.VOkjFXXXXbXXpXXXXXXXXXX_!!1586509945.jpg', '30882', 'image/jpeg', '1491007137', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('52', '7d211c8c.jpg', 'TB2wZxYnXXXXXahXpXXXXXXXXXX_!!100576501.jpg', '166403', 'image/jpeg', '1491007320', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('53', '2c2b6a11.jpg', 'TB2.dXNeVXXXXagXpXXXXXXXXXX_!!125668391.jpg', '31002', 'image/jpeg', '1491007320', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('54', '5fd8ddfd.gif', 'TB230E4X9XlpuFjy0FeXXcJbFXa_!!814477235.gif', '287912', 'image/gif', '1491007320', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('55', '8f58f471.jpg', '1fdd1901672e4450a4e1cb42ca20b323-2.jpg', '271374', 'image/jpeg', '1491041268', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('56', '0b16176b.jpg', '455309.jpg', '446467', 'image/jpeg', '1491041885', '3', null, '1');
INSERT INTO `yc_file_resource` VALUES ('57', '3e2ceea2.jpg', '42a98226cffc1e1797615b384890f603728de9d9.jpg', '30736', 'image/jpeg', '1491042026', '3', null, '1');

-- ----------------------------
-- Table structure for yc_member
-- ----------------------------
DROP TABLE IF EXISTS `yc_member`;
CREATE TABLE `yc_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '会员编号',
  `name` varchar(128) DEFAULT NULL COMMENT '用户名字',
  `type_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户类型ID',
  `auths` varchar(255) CHARACTER SET ascii DEFAULT NULL COMMENT '权限集合',
  `avatar` varchar(200) DEFAULT NULL COMMENT '头像',
  `gender` tinyint(4) DEFAULT NULL COMMENT '性别(0:男,male;1:女,female)',
  `birth_date` date DEFAULT NULL COMMENT '用户生日',
  `id_card` varchar(20) DEFAULT NULL COMMENT '省份证',
  `phone` varchar(20) DEFAULT NULL COMMENT '电话',
  `register_time` int(11) DEFAULT NULL COMMENT '注册时间',
  `email` varchar(200) NOT NULL,
  `province` int(11) DEFAULT NULL,
  `city` int(11) DEFAULT NULL,
  `country` int(11) DEFAULT NULL,
  `points` int(11) DEFAULT '0' COMMENT '积分',
  `status` tinyint(2) DEFAULT '1' COMMENT '数据状态,1为正常，默认1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='用户信息表';

-- ----------------------------
-- Records of yc_member
-- ----------------------------
INSERT INTO `yc_member` VALUES ('1', 'wuyun', '0', null, '/upload/photo/170123153322.png', null, null, null, '1512411', '0', 'wuyun168668@163.com', null, null, null, '0', '1');
INSERT INTO `yc_member` VALUES ('3', 'yaclty', '0', null, null, null, null, null, '13882120428', '1486972382', '123', null, null, null, '0', '1');

-- ----------------------------
-- Table structure for yc_session
-- ----------------------------
DROP TABLE IF EXISTS `yc_session`;
CREATE TABLE `yc_session` (
  `session_id` char(32) NOT NULL DEFAULT '' COMMENT '编号',
  `last_access` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后访问时间',
  `user_data` text NOT NULL COMMENT '数据',
  `ip` char(15) DEFAULT '0.0.0.0' COMMENT '来源ip',
  `browser` tinyint(2) unsigned DEFAULT '0' COMMENT '浏览器',
  `platform` tinyint(2) unsigned DEFAULT '0' COMMENT '平台',
  PRIMARY KEY (`session_id`),
  KEY `sessid` (`session_id`) USING BTREE,
  KEY `ip` (`ip`),
  KEY `dateline` (`last_access`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yc_session
-- ----------------------------
INSERT INTO `yc_session` VALUES ('58de4556bfc3d', '1491044045', 'czoxOTI1OiJBZG1pbnxzOjE6IjEiO3ljZl91c2VyfE86MTg6Ik1vZGVsc1xNZW1iZXJNb2RlbCI6MjI6e3M6MjoiaWQiO3M6MToiMyI7czo0OiJuYW1lIjtzOjY6InlhY2x0eSI7czo2OiJhdmF0YXIiO047czo3OiJ0eXBlX2lkIjtzOjE6IjAiO3M6NjoiZ2VuZGVyIjtOO3M6NjoiaWRjYXJkIjtOO3M6MTA6ImJpcnRoX2RhdGUiO047czo1OiJwaG9uZSI7czoxMToiMTM4ODIxMjA0MjgiO3M6NToiZW1haWwiO3M6MzoiMTIzIjtzOjEzOiJyZWdpc3Rlcl90aW1lIjtzOjEwOiIxNDg2OTcyMzgyIjtzOjg6InByb3ZpbmNlIjtOO3M6NDoiY2l0eSI7TjtzOjc6ImNvdW50cnkiO047czo2OiJwb2ludHMiO3M6MToiMCI7czo2OiJzdGF0dXMiO3M6MToiMSI7czoxNzoiAE1vZGVsAHByaW1hcnlLZXkiO3M6MjoiaWQiO3M6MTY6IgBNb2RlbAB0YWJsZU5hbWUiO3M6OToieWNfbWVtYmVyIjtzOjE3OiIATW9kZWwAX2FycmF5RGF0YSI7YToxNzp7czoyOiJpZCI7czoxOiIzIjtzOjQ6Im5hbWUiO047czo2OiJhdmF0YXIiO047czo3OiJ0eXBlX2lkIjtOO3M6NjoiZ2VuZGVyIjtOO3M6NjoiaWRjYXJkIjtOO3M6MTA6ImJpcnRoX2RhdGUiO047czo1OiJwaG9uZSI7TjtzOjU6ImVtYWlsIjtOO3M6MTM6InJlZ2lzdGVyX3RpbWUiO047czo4OiJwcm92aW5jZSI7TjtzOjQ6ImNpdHkiO047czo3OiJjb3VudHJ5IjtOO3M6NjoicG9pbnRzIjtOO3M6Njoic3RhdHVzIjtOO3M6MTI6Imxhc3RJbnNlcnRJZCI7aTowO3M6OToiZXh0cmFEYXRhIjthOjA6e319czoxMzoiAE1vZGVsAGlnbm9yZSI7YTozOntpOjA7czoxMjoibGFzdEluc2VydElkIjtpOjE7czo2OiJpZ25vcmUiO2k6MjtzOjk6ImV4dHJhRGF0YSI7fXM6MTI6Imxhc3RJbnNlcnRJZCI7aTowO3M6OToiZXh0cmFEYXRhIjthOjE6e3M6MTM6IkNlcnRpZmljYXRpb24iO2E6MTA6e3M6MzoibWlkIjtzOjE6IjMiO3M6NDoidHlwZSI7czo2OiJwZXJzb24iO3M6MjA6ImNlcnRpZmljYXRpb25fc3RhdHVzIjtzOjE6IjEiO3M6MTg6ImNlcnRpZmljYXRpb25fZGF0YSI7TzoyNjoiTW9kZWxzXENlcnRpZmljYXRpb25QZXJzb24iOjE3OntzOjg6InBlcnNvblFRIjtzOjM6IjEyMyI7czoxMDoicGVyc29uTmFtZSI7czo5OiLlvKDlhajom4siO3M6MTI6InBlcnNvbkdlbmRlciI7czozOiLnlLciO3M6MTU6InBlcnNvbkJpcnRoRGF0ZSI7czoxMDoiMTk4Ny0wOS0xMiI7czoxMToicGVyc29uUGhvbmUiO3M6MTE6IjEzODEyMTIwNDI5IjtzOjY6IklkQ2FyZCI7czoxODoiNTEwMTIyMTk4OTEwMTQyOTQ5IjtzOjEzOiJwZXJzb25BZGRyZXNzIjtzOjI5OiLlm5vlt53nnIEg5oiQ6YO95biCIOWPjOa1geWOvyI7czoxMzoiSWRDYXJkQWRkcmVzcyI7czoyOToi5Zub5bed55yBIOaIkOmDveW4giDlj4zmtYHljr8iO3M6MTY6IklkQ2FyZEZyb250UGhvdG8iO3M6MTc6IjU4YTdiMTAxNzE0NDQuanBnIjtzOjE1OiJJZENhcmRCYWNrUGhvdG8iO3M6MTc6IjU4YTdiMTE0OGQxZjEuanBnIjtzOjE3OiIATW9kZWwAcHJpbWFyeUtleSI7TjtzOjE2OiIATW9kZWwAdGFibGVOYW1lIjtzOjE5OiJDZXJ0aWZpY2F0aW9uUGVyc29uIjtzOjE3OiIATW9kZWwAX2FycmF5RGF0YSI7TjtzOjEzOiIATW9kZWwAaWdub3JlIjthOjM6e2k6MDtzOjEyOiJsYXN0SW5zZXJ0SWQiO2k6MTtzOjY6Imlnbm9yZSI7aToyO3M6OToiZXh0cmFEYXRhIjt9czoxMjoibGFzdEluc2VydElkIjtpOjA7czo5OiJleHRyYURhdGEiO2E6MDp7fXM6MTg6IgBNb2RlbABxdWVyeU9iamVjdCI7Tjt9czo5OiJwb3N0X3RpbWUiO3M6MTA6IjE0ODczODYyNjUiO3M6MTg6ImNlcnRpZmljYXRpb25fdGltZSI7TjtzOjY6InJlbWFyayI7czo0OiJ0ZXN0IjtzOjY6InN0YXR1cyI7czoxOiIxIjtzOjEyOiJsYXN0SW5zZXJ0SWQiO2k6MDtzOjk6ImV4dHJhRGF0YSI7YTowOnt9fX1zOjE4OiIATW9kZWwAcXVlcnlPYmplY3QiO047fSI7', '127.0.0.1', '0', '0');

-- ----------------------------
-- Table structure for yc_session_copy
-- ----------------------------
DROP TABLE IF EXISTS `yc_session_copy`;
CREATE TABLE `yc_session_copy` (
  `session_id` char(32) NOT NULL DEFAULT '' COMMENT '编号',
  `last_access` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后访问时间',
  `user_data` varchar(1500) NOT NULL,
  `ip` char(15) DEFAULT '0.0.0.0' COMMENT '来源ip',
  `browser` tinyint(2) unsigned DEFAULT '0' COMMENT '浏览器',
  `platform` tinyint(2) unsigned DEFAULT '0' COMMENT '平台',
  `area` char(10) DEFAULT '' COMMENT '区域',
  KEY `sessid` (`session_id`) USING BTREE,
  KEY `ip` (`ip`),
  KEY `dateline` (`last_access`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yc_session_copy
-- ----------------------------

-- ----------------------------
-- Table structure for yc_system_setting
-- ----------------------------
DROP TABLE IF EXISTS `yc_system_setting`;
CREATE TABLE `yc_system_setting` (
  `option_key` varchar(255) NOT NULL COMMENT '键',
  `option_value` varchar(2000) DEFAULT NULL COMMENT '值',
  `category` varchar(20) DEFAULT NULL COMMENT '分类',
  `is_system` tinyint(2) DEFAULT '0' COMMENT '是否是系统项',
  `status` tinyint(2) DEFAULT '1' COMMENT '数据状态'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='系统配置表';

-- ----------------------------
-- Records of yc_system_setting
-- ----------------------------
INSERT INTO `yc_system_setting` VALUES ('roles', 'superadmin,admin,operator', null, '1', '1');

-- ----------------------------
-- Table structure for ycs_article
-- ----------------------------
DROP TABLE IF EXISTS `ycs_article`;
CREATE TABLE `ycs_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '文章ID',
  `title` varchar(50) DEFAULT NULL COMMENT '文章标题',
  `content` text COMMENT '文章内容',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `keyword` varchar(100) DEFAULT '' COMMENT '专题标签',
  `brief` varchar(200) DEFAULT NULL COMMENT '简介',
  `image_url` varchar(50) DEFAULT NULL COMMENT '图片',
  `update_time` int(11) DEFAULT NULL COMMENT '最后一次编辑时间',
  `seq` mediumint(9) NOT NULL DEFAULT '0' COMMENT '最后一次编辑时间',
  `status` tinyint(2) unsigned DEFAULT '1' COMMENT '状态(1:正常 0:删除)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='文章表';

-- ----------------------------
-- Records of ycs_article
-- ----------------------------
INSERT INTO `ycs_article` VALUES ('1', '净水器+空气净化器组合套装', '<h3 class=\"black size21\" style=\"margin: 0px; padding: 0px; font-size: 20px; color: rgb(51, 51, 51); font-family: 微软雅黑; white-space: normal; background-color: rgb(255, 255, 255);\"><a href=\"/index.php/Home/Index/goods_details.html?id=665\" target=\"_blank\"净水器+空气净化器组合套装</a></h3><p><br/></p><p><br/></p><p>高端定制，五层过滤系统！</p><p><br/></p><p>整机精美工艺！</p><p><br/></p><p>净水安全卫士！<br/></p><p><img src=\"/ueditor/php/upload/image/20160729/1469791288637429.jpg\" alt=\"4详情页.jpg\"/></p><p><img src=\"/ueditor/php/upload/image/20160729/1469791491394730.gif\" alt=\"12.gif\"/></p><p><br/></p>', '1469946754', '净水器 净化器 空气净化器', '净水器 空气净化器组合套装', null, '1469992429', '50', '1');
INSERT INTO `ycs_article` VALUES ('2', '净水器+空气净化器组合套装', '<h3 class=\"black size21\" style=\"margin: 0px; padding: 0px; font-size: 20px; color: rgb(51, 51, 51); font-family: 微软雅黑; white-space: normal; background-color: rgb(255, 255, 255);\"><a href=\"/index.php/Home/Index/goods_details.html?id=665\" target=\"_blank\"净水器+空气净化器组合套装</a></h3><p><br/></p><p><br/></p><p>高端定制，五层过滤系统！</p><p><br/></p><p>整机精美工艺！</p><p><br/></p><p>净水安全卫士！<br/></p><p><img src=\"/ueditor/php/upload/image/20160729/1469791288637429.jpg\" alt=\"4详情页.jpg\"/></p><p><img src=\"/ueditor/php/upload/image/20160729/1469791491394730.gif\" alt=\"12.gif\"/></p><p><br/></p>', '1469946754', '净水器 净化器 空气净化器', '净水器 空气净化器组合套装', null, '1469992429', '50', '1');
INSERT INTO `ycs_article` VALUES ('3', '净水器+空气净化器组合套装', '<h3 class=\"black size21\" style=\"margin: 0px; padding: 0px; font-size: 20px; color: rgb(51, 51, 51); font-family: 微软雅黑; white-space: normal; background-color: rgb(255, 255, 255);\"><a href=\"/index.php/Home/Index/goods_details.html?id=665\" target=\"_blank\"净水器+空气净化器组合套装</a></h3><p><br/></p><p><br/></p><p>高端定制，五层过滤系统！</p><p><br/></p><p>整机精美工艺！</p><p><br/></p><p>净水安全卫士！<br/></p><p><img src=\"/ueditor/php/upload/image/20160729/1469791288637429.jpg\" alt=\"4详情页.jpg\"/></p><p><img src=\"/ueditor/php/upload/image/20160729/1469791491394730.gif\" alt=\"12.gif\"/></p><p><br/></p>', '1469946754', '净水器 净化器 空气净化器', '净水器 空气净化器组合套装', null, '1469992429', '50', '1');
INSERT INTO `ycs_article` VALUES ('4', '净水器+空气净化器组合套装', '<h3 class=\"black size21\" style=\"margin: 0px; padding: 0px; font-size: 20px; color: rgb(51, 51, 51); font-family: 微软雅黑; white-space: normal; background-color: rgb(255, 255, 255);\"><a href=\"/index.php/Home/Index/goods_details.html?id=665\" target=\"_blank\"净水器+空气净化器组合套装</a></h3><p><br/></p><p><br/></p><p>高端定制，五层过滤系统！</p><p><br/></p><p>整机精美工艺！</p><p><br/></p><p>净水安全卫士！<br/></p><p><img src=\"/ueditor/php/upload/image/20160729/1469791288637429.jpg\" alt=\"4详情页.jpg\"/></p><p><img src=\"/ueditor/php/upload/image/20160729/1469791491394730.gif\" alt=\"12.gif\"/></p><p><br/></p>', '1469946754', '净水器 净化器 空气净化器', '净水器 空气净化器组合套装', null, '1469992429', '50', '1');
INSERT INTO `ycs_article` VALUES ('5', '净水器+空气净化器组合套装', '<h3 class=\"black size21\" style=\"margin: 0px; padding: 0px; font-size: 20px; color: rgb(51, 51, 51); font-family: 微软雅黑; white-space: normal; background-color: rgb(255, 255, 255);\"><a href=\"/index.php/Home/Index/goods_details.html?id=665\" target=\"_blank\"净水器+空气净化器组合套装</a></h3><p><br/></p><p><br/></p><p>高端定制，五层过滤系统！</p><p><br/></p><p>整机精美工艺！</p><p><br/></p><p>净水安全卫士！<br/></p><p><img src=\"/ueditor/php/upload/image/20160729/1469791288637429.jpg\" abs=\"c2hvcFNOIOiRl+S9nOadg+WxnuS6juS4iua1t+S6v+mAn+e9kee7nOenkeaKgOaciemZkOWFrOWPuO+8jOWmguacquaOiOadg++8jOWIoOmZpOW6lemDqOi/nuaOpeinhuS4uuebl+eJiOS+teadg+OAgg==\" alt=\"4详情页.jpg\"/></p><p><img src=\"/ueditor/php/upload/image/20160729/1469791491394730.gif\" alt=\"12.gif\"/></p><p><br/></p>', '1469946754', '净水器 净化器 空气净化器', '净水器 空气净化器组合套装', null, '1469992429', '50', '1');
INSERT INTO `ycs_article` VALUES ('6', '净水器+空气净化器组合套装', '<h3 class=\"black size21\" style=\"margin: 0px; padding: 0px; font-size: 20px; color: rgb(51, 51, 51); font-family: 微软雅黑; white-space: normal; background-color: rgb(255, 255, 255);\"><a href=\"/index.php/Home/Index/goods_details.html?id=665\" target=\"_blank\"净水器+空气净化器组合套装</a></h3><p><br/></p><p><br/></p><p>高端定制，五层过滤系统！</p><p><br/></p><p>整机精美工艺！</p><p><br/></p><p>净水安全卫士！<br/></p><p><img src=\"/ueditor/php/upload/image/20160729/1469791288637429.jpg\" alt=\"4详情页.jpg\"/></p><p><img src=\"/ueditor/php/upload/image/20160729/1469791491394730.gif\" alt=\"12.gif\"/></p><p><br/></p>', '1469946754', '净水器 净化器 空气净化器', '净水器 空气净化器组合套装', null, '1469992429', '50', '1');
INSERT INTO `ycs_article` VALUES ('7', '净水器+空气净化器组合套装', '<h3 class=\"black size21\" style=\"margin: 0px; padding: 0px; font-size: 20px; color: rgb(51, 51, 51); font-family: 微软雅黑; white-space: normal; background-color: rgb(255, 255, 255);\"><a href=\"/index.php/Home/Index/goods_details.html?id=665\" target=\"_blank\"净水器+空气净化器组合套装</a></h3><p><br/></p><p><br/></p><p>高端定制，五层过滤系统！</p><p><br/></p><p>整机精美工艺！</p><p><br/></p><p>净水安全卫士！<br/></p><p><img src=\"/ueditor/php/upload/image/20160729/1469791288637429.jpg\" alt=\"4详情页.jpg\"/></p><p><img src=\"/ueditor/php/upload/image/20160729/1469791491394730.gif\" alt=\"12.gif\"/></p><p><br/></p>', '1469946754', '净水器 净化器 空气净化器', '净水器 空气净化器组合套装', null, '1469992429', '50', '1');
INSERT INTO `ycs_article` VALUES ('8', '净水器+空气净化器组合套装', '<h3 class=\"black size21\" style=\"margin: 0px; padding: 0px; font-size: 20px; color: rgb(51, 51, 51); font-family: 微软雅黑; white-space: normal; background-color: rgb(255, 255, 255);\"><a href=\"/index.php/Home/Index/goods_details.html?id=665\" target=\"_blank\"净水器+空气净化器组合套装</a></h3><p><br/></p><p><br/></p><p>高端定制，五层过滤系统！</p><p><br/></p><p>整机精美工艺！</p><p><br/></p><p>净水安全卫士！<br/></p><p><img src=\"/ueditor/php/upload/image/20160729/1469791288637429.jpg\" alt=\"4详情页.jpg\"/></p><p><img src=\"/ueditor/php/upload/image/20160729/1469791491394730.gif\" alt=\"12.gif\"/></p><p><br/></p>', '1469946754', '净水器 净化器 空气净化器', '净水器 空气净化器组合套装', null, '1469992429', '50', '1');
